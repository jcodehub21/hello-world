package jc.lambda.util;

/**
 * 03/18/2024
 * General LinkList class to store objects with type <E>
 * <E> stands for generic type or any data type
 * @JaneCheng
 */
public class GeneralLinkList<E> {
	
	Node<E> head;  //first node or head 
	Node<E> tail;  //last node or tail
	int size;  //number of nodes in linklist
	Node<E> pointer; //iterate each node 
	
	//class to store client's file delayed obj  
	//the obj will contain all the file delayed info
	class Node<E>{
		
		E data;  //E is generic but here it will be FileDelayedInfo data type
		Node<E> next; //link to next node
		
		//constructor to store client's FileDelayedInfo obj
		public Node(E obj){
			data = obj;
			next = null;
			
		}
	}
	
	//constructor for generic does not need the <E> type
	public GeneralLinkList(){
		
		head = null;
		tail = null;
		size = 0;
	}
	
	public void addNode(E obj){
		
		Node<E> newNode = new Node<E>(obj);
		if(size == 0){
			head = newNode;
			tail = newNode;
		}
		else{
			
			//newNode.next = tail; //newNode.next will store the address of the first/previous tail
			//tail = newNode; //now the tail points to the new node
			
			newNode.next = head; //newNode.next will store the address of the first/previous head
		    head = newNode; //now the head points to the new node; head is moving forward
		}
		size++;
		
	}
	
	//return number of nodes in linklist
    public int getSize(){
		
		return size;
	}
	
    //clear all nodes
	public void clear(){
		if(size > 0)
		{
			head = null;
			tail = null;
			size = 0;
		}
		
	}
	
	public void setIterator(){
		   
		pointer = head;
	}
		
	public boolean hasNext(){
			
		if(pointer != null)  //tests if the head or the next node is null or not
			return true;
		return false;	
	}
	
	public E getNode() {
		// TODO Auto-generated method stub
		
	Node<E> tmp = null;
		
	tmp = pointer; 
	//if(pointer.next != null) don't need this condition as the hasNext() method will test if the current pointer is null
	pointer = pointer.next;
		
	return tmp.data; //returns the whole node but does not remove it from the queue
	}

}
