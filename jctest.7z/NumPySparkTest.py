#!/ptoan/shared/opt/miniconda3/user-envs/yulong/my-pyspark/bin/python3

'''
Created on Jan 30, 2024
Test NumPy module on TA ATR Spark cluster
Below are the steps if want to use spark-submit command: 
export SPARK_HOME=/ptoan/shared/hadoop/spark-3.5.0-bin-hadoop3
export PATH=$SPARK_HOME/bin:$JAVA_HOME/bin:$PATH
export SPARK_LOCAL_DIRS=/ptoan/dms_staging/parquet_logs
export PYSPARK_PYTHON=/ptoan/shared/opt/miniconda3/user-envs/yulong/my-pyspark/bin/python3
spark-submit --master yarn --deploy-mode client --executor-memory 8g --driver-memory 8g --conf spark.dynamicAllocation.enabled=false --conf spark.yarn.queue=FCM /home/janecheng/NumPySparkTest.py > /ptoan/dms_staging/parquet_logs/numpytest.log 2>&1 &

or 
spark-submit --master yarn --deploy-mode client --conf spark.pyspark.python=/ptoan/shared/hadoop/Anaconda3/bin/python3 --conf spark.pyspark.driver.python=/ptoan/shared/hadoop/Anaconda3/bin/python3

For Python 3.9:


Below are the steps if want to use python command to execute the pyspark script:
export PYTHON_HOME=/ptoan/shared/opt/miniconda3/user-envs/yulong/my-pyspark
export PATH=$PYTHON_HOME/bin:$PATH
python /home/janecheng/NumPySparkTest.py

https://stackoverflow.com/questions/36461054/i-cant-seem-to-get-py-files-on-spark-to-work
https://stackoverflow.com/questions/35214231/importerror-no-module-named-numpy-on-spark-workers
https://stackoverflow.com/questions/76308608/what-could-be-causing-py4jerror-when-calling-spark-createdataframe-on-pyspar
@author: JaneCheng
'''
import os
import sys
'''
In order to use spark-submit --py-files dependencies.zip app.py, I had to add the python files in the script too using
SparkContext.addPyFile(dependencies)
'''
import numpy as np
import pandas as pd

SPARK_HOME='/ptoan/shared/hadoop/spark-3.5.0-bin-hadoop3'
os.environ['PYSPARK_PYTHON']='/ptoan/shared/opt/miniconda3/user-envs/yulong/my-pyspark/bin/python3'
os.environ['PYSPARK_DRIVER_PYTHON']='/ptoan/shared/opt/miniconda3/user-envs/yulong/my-pyspark/bin/python3'
os.environ['SPARK_HOME']=SPARK_HOME
python_dir_name = 'python'
SPARK_PYTHON_DIR = os.path.join(SPARK_HOME, python_dir_name)
PYSPARK_HOME = os.path.join(SPARK_PYTHON_DIR, 'pyspark')
sys.path.insert(0, SPARK_PYTHON_DIR)
sys.path.insert(0, os.path.join(SPARK_PYTHON_DIR, 'lib/py4j-0.10.9.7-src.zip'))

from pyspark.sql import SparkSession
from pyspark.context import SparkConf, SparkContext

spark = SparkSession.builder.appName("NumPySparkTest").master("yarn").config("spark.dynamicAllocation.enabled", "false").config("spark.executor.memory", "8g").config("spark.driver.memory", "8g").config("spark.yarn.queue", "FCM").getOrCreate();
'''
Below we add the following code to use dependencies.zip
sc = SparkContext(SparkConf().setMaster('yarn').setAppName('NumPySparkTest'))
sc.addPyFile("file:///ptoan/dms_staging/parquet_logs/dependencies.zip"); 
'''

spark = SparkSession(sc)
import numpy as np
import pandas as pd

'''
Traceback (most recent call last):
  File "/ptoan/dms_staging/parquet_logs/jcpythontest.py", line 33, in <module>
    import numpy as np
ModuleNotFoundError: No module named 'numpy'

'''

    
def mean_udf(v: pd.Series) -> float:
    return v.mean()

def testPandas():
    df = spark.createDataFrame([(1, 1.0), (1, 2.0), (2, 3.0), (2, 5.0), (2, 10.0)],("id", "v"))
    df.groupby("id").count().show()
    df.foreach(lambda row: print(row))

    '''
    File "/home/janecheng/NumPySparkTest.py", line 28, in mean_udf
    return v.mean()
    TypeError: 'Column' object is not callable
    '''
    

def mult(x):
    y = np.array([2])
    return x*y

def testNumpy():
    print("numpy version: " + np.__version__)
    a = np.array(42)
    b = np.array([1, 2, 3, 4, 5])
    c = np.array([[1, 2, 3], [4, 5, 6]])
    d = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
    '''
    File "/home/janecheng/NumPySparkTest.py", line 45, in testNumpy
    print("0-D array: " + a + "; Number of Dimensions: " + a.ndim)
    numpy.core._exceptions._UFuncNoLoopError: ufunc 'add' did not contain a loop with signature matching types (dtype('<U11'), dtype('int64')) -> None
    The problem is that you can't add an object array (containing strings) to a number array
    a.ndim returns an integer
    convert integer to string with dataframe:  df1['Date'].astype(str) or df1['Date'].apply(str)
    '''
    print('0-D array: ' + str(a) + '; Number of Dimensions: ' + str(a.ndim))
    print("1-D array: " + str(b) + "; Number of Dimensions: " + str(b.ndim))
    print("2-D array: " + str(c) + "; Number of Dimensions: " + str(c.ndim))
    print("3-D array: " + str(d) + "; Number of Dimensions: " + str(d.ndim))
    x = np.arange(10000)
    distData = spark.sparkContext.parallelize(x)
    results = distData.map(mult).collect()
    print(results)

if __name__ == "__main__":
    '''testNumpy() works'''
    python_vers = platform.python_version()
    print(python_vers)
    testPandas()