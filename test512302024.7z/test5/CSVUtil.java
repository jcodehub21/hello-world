import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
//import java.time.LocalDateTime;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import jodd.io.FileUtil;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
//import org.apache.spark.sql.functions;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
//import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.LocalFileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

/**
 * 11/22/2024: This class can also convert CCS csv data into parquet file 
 * 
 * rhldmsprd002-45001: using local
 * spark-submit --master local --driver-memory 50g --executor-memory 60g --conf spark.dynamicAllocation.enabled=false --conf spark.yarn.queue=DataManagement --conf spark.network.timeout=10000001 --conf spark.executor.heartbeatInterval=10000000 --class CSVUtil /home/janecheng/ADEUtilv8.jar CCS_Parquet file:///ptoan/dms_staging/parquet_logs/15338061.FICO_PROD_OUTPUT_186_Sept01-Sept07-2024.csv /data/CCS > /ptoan/dms_staging/parquet_logs/ccs_parquet_11222024.log 2>&1 &
 * 
 * rhldmsprd002-45001: using yarn
 * spark-submit --master yarn --deploy-mode client --driver-memory 40g --executor-memory 40g --conf spark.dynamicAllocation.enabled=false --conf spark.yarn.queue=DSA --conf spark.network.timeout=10000001 --conf spark.executor.heartbeatInterval=10000000 --class CSVUtil /home/janecheng/ADEUtilv8.jar CCS_Parquet file:///ptoan/dms_staging/parquet_logs/15338061.FICO_PROD_OUTPUT_186_Sept01-Sept07-2024.csv /data/CCS > /ptoan/dms_staging/parquet_logs/ccs_parquet_11222024.log 2>&1 &
 * @author JaneCheng
 *
 */

public class CSVUtil implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	static BufferedReader br = null;
	static BufferedWriter bw = null;
	Dataset<Row> dataFile = null;
	StructType textSchema = null;
	static FileSystem fs;
	static LocalFileSystem lfs = null;
	static Configuration conf = new Configuration();
	static FileStatus[] list_files = null;
	String pattern = "^part-.+\\.gz\\.parquet$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	UDF1<String, String> userdefinedfunction = null;
	String udfName = "analyzeYYMM";
	String tempDir = "file:///mdswork/prd/work/CCS/";
	Connection conn = null;
	String updateQuery = "update files set status = ? where fileid = ?";
	PreparedStatement ps = null; //to run same query multiple times with different parameters
	
	public static void main(String[] args){
		CSVUtil util = new CSVUtil();
		util.startSparkSession(args[0]);
		//util.createCSV("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\1601.akbank-f6.none.pis12.3683804.1713.ascii_processed.bz2");
		//util.createCSV(args[0]);
		//util.loadCSV();
		//util.showFilesize();
		//args[0] = Spark app name
		//args[1] = fileid
		//args[2] = input filename
		//args[3] = action -> cp is createParquetFile; cd = changeColumnDataType
		util.createParquetFile(args[1], args[2]);
	}
	
	public void startSparkSession(String appName){
		
		spark = SparkSession.builder()
				.appName(appName)
				//.master("local")
				.config("spark.dynamicAllocation.enabled", "false")
		  			  .config("spark.locality.wait.node", 0)  //added in to change spark locality
		  			  .config("spark.locality.wait.executor", 0)
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		
		spark.sparkContext().setLogLevel("ERROR");
		try{
		  fs = FileSystem.get(conf);
		}catch(Exception e){e.printStackTrace();}
		//userdefinedfunction = new UDF();
	    //register the user defined funciton in spark
	   // spark.udf().register(udfName, userdefinedfunction, DataTypes.StringType);
		
	}
	
	public void connectDB(){
		  try{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms22001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated to SHK
	        ps = conn.prepareStatement(updateQuery);
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}
	}
	
	public void createCSV(String filename){
		String content;
		//RecordTypeMapper<FieldObj> fieldObj = AkbankRecordType.getRecordTypeMapper("pis12");
	   try{
		   if(filename.endsWith(".bz2")){
			   br = new BufferedReader(new InputStreamReader(new BZip2CompressorInputStream(new FileInputStream(filename))));
			   bw = new BufferedWriter(new FileWriter(filename.substring(0, filename.lastIndexOf(".bz2")) + ".csv"));
		   }else if(filename.endsWith(".gz")){
			   br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filename))));
			   bw = new BufferedWriter(new FileWriter(filename.substring(0, filename.lastIndexOf(".gz")) + ".csv"));
		   }else{  //plain ascii file or other
			   br = new BufferedReader(new FileReader(filename));
			   bw = new BufferedWriter(new FileWriter(filename + ".csv"));
		   }
		   
		  // br = new BufferedReader(new FileReader("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii"));
		   while((content = br.readLine()) != null){
			   //content = content.replace('\u00ef', ' ').replace('\u00bf', ' ').replace('\u00bd', ' ');  //have to replaced up here in new csv
			   System.out.println(content.indexOf("�"));
			   
			   /**
			    * On Windows my Java in Eclipse can detect � because it is Windows-1252 (or cp1252) so it will replace 
			    * � with an empty space.  However, when I move my CSVUtil.class to lux433 it was not able to detect
			    * � so it was not replaced with an empty string.  
			    * Found out that in Linux the � is considered UTF-8 encoding while my compiled class on eclipse is UTF-16 or even if written in UTF-8.
			    * So had to re-compile my code in Linux:
			    * /Anton/jyc_temp/jdk1.8.0_231/bin/javac -encoding UTF-8 -cp .:/ana/mds/prd/data/files/INCOMING/jane_temp:/Anton/jyc_temp/spark-3.0.1-bin-hadoop3.2/jars/* CSVUtil.java
			    */
			   //content = content.replace("�", " ");
			   content = content.replace("\uFFFD", " ");  //this one works without compiling with encoding UTF-8
			  // fieldObj.setFieldValue(content);
			  // bw.write(fieldObj.toString());
			   bw.write(content);
			   bw.newLine();
		   }
		   br.close();
		   bw.close();
		   
		  // loadCSV(filename);
		   
	   }catch(Exception e){e.printStackTrace();}
	}
	
	public void loadCSV(String filename){
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		dataFile = spark.read().option("delimiter", ",").csv("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii.csv");
		dataFile = dataFile.select("*").where("_c1 == '45522518blSPityR1Bk'");
		dataFile = dataFile.map(row -> {
			//String replace = row.mkString().replace('\u00ef', ' ').replace('\u00bf', ' ').replace('\u00bd', ' '); //did not work
			  return RowFactory.create(row.mkString());	
			  //return RowFactory.create(replace);
		  }, RowEncoder.apply(textSchema));
		dataFile.coalesce(1).write().format("text").option("compression","bzip2")
		//.option("encoding", "ignore")
		.save("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\csv");
		
		try{
		conf = new Configuration();
	     fs = FileSystem.get(conf);
	     
	     filePattern = Pattern.compile(pattern);
		    
 		  list_files = fs.listStatus(new Path("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\csv"));
 		  
	  		for(FileStatus oldFilePath : list_files){
		    	
 	           m = filePattern.matcher(oldFilePath.getPath().getName());
 	           if(m.matches()){
 	        	   //fs.rename also moved the new filename to another path
 	        	   fs.rename(oldFilePath.getPath(), new Path("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\csv\\" + filename.substring(filename.lastIndexOf("\\") + 1)));
 	        	   
 	           }
 	        }
 		  
		}catch(Exception e){e.printStackTrace();}
	     
	}
	
	public void showFilesize(){
		
		try{
		    String path = "C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii.csv"; 
		     Path filePath = new Path(path);
		     System.out.println("filePath: " + filePath);
		     
		     File file = new File(path);
			System.out.println("file length: " + file.length());
			
			System.out.println("using FileUtils: " + FileUtils.sizeOf(file));
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * on rhldmsprd002-45001, DMS will execute the processCCS.sh to process CCS data:
	 * #!/bin/bash

       set -o pipefail
       ###########################################################################
       ORACALL_UPDATEFILE()
       {
        #This procedure deletes empty CCS zip file and update file status to Empty File
        sqlplus -silent /nolog << EOF
        connect ${CONNECT_STRING}
        set SERVEROUTPUT ON TERMOUT OFF HEAD OFF FEEDBACK OFF LINESIZE 300
        Whenever sqlerror EXIT 13
        UPDATE FILES SET STATUS = $1 WHERE FILEID = ${FILEID}
        /
        COMMIT
        /
        exit

        EOF
        }

        ############################################################################


       STEPLOG=${LOGDIR}${FILEID}.${INCARNATION}.${WFID}.${STEPNUM}.log
       APPNAME="CCS_Parquet_${FILEID}"
       
       if [[ ${INFILENAME} == *"zip"* ]]
       then
           ORIGFILENAME=`echo ${INFILENAME} | cut -d '.' -f 2`
           unzip ${INFILENAME}          
           mv ${ORIGFILENAME}.csv ${FILEID}.${ORIGFILENAME}.csv >> ${STEPLOG}
           /ptoan/shared/hadoop/spark-3.3.0-bin-hadoop3/bin/spark-submit --master local --driver-memory 60g --executor-memory 60g --conf spark.dynamicAllocation.enabled=false --conf spark.yarn.queue=DataManagement --conf spark.network.timeout=10000001 --conf spark.executor.heartbeatInterval=10000000 --class CSVUtil /home/janecheng/ADEUtilv8.jar ${APPNAME} ${FILEID} ${FILEID}.${ORIGFILENAME}.csv > ${STEPLOG}
       else
          /ptoan/shared/hadoop/spark-3.3.0-bin-hadoop3/bin/spark-submit --master local --driver-memory 60g --executor-memory 60g --conf spark.dynamicAllocation.enabled=false --conf spark.yarn.queue=DataManagement --conf spark.network.timeout=10000001 --conf spark.executor.heartbeatInterval=10000000 --class CSVUtil /home/janecheng/ADEUtilv8.jar ${APPNAME} ${FILEID} ${INFILENAME} > ${STEPLOG}
       fi

       output=`cat ${STEPLOG}`

       if [ $output -ne 0 ]
       then
          echo Exit " ${INFILENAME} was not converted to parquet" >> ${STEPLOG}
          ORACALL_UPDATEFILE "0" >> ${STEPLOG}
       else
          echo "converted ${INFILENAME} to parquet at /data/CCS"  >> ${STEPLOG}
          ORACALL_UPDATEFILE "D" >> ${STEPLOG}
       fi
       rm ${INFILENAME}
       exit


	 * @param fileid
	 * @param input
	 */
	public void createParquetFile(String fileid, String input){
		//https://stackoverflow.com/questions/72891590/reading-zip-file-into-apache-spark-dataframe
		//https://stackoverflow.com/questions/28569788/how-to-open-stream-zip-files-through-spark
		//https://stackoverflow.com/questions/32080475/how-to-read-a-zip-containing-multiple-files-in-apache-spark
		try{//https://spark.apache.org/docs/3.5.3/sql-data-sources-csv.html
			//https://sparkbyexamples.com/spark/spark-read-options/
			//https://community.databricks.com/t5/data-engineering/spark-read-csv-doesn-t-preserve-the-double-quotes-while-reading/td-p/27086
			String command = "unzip ";
			File newFile = null;
			String[] commandArgs = null;
			ProcessBuilder builder = null;
			Process p = null; //process for Linux
			boolean zipFile = false;
			//File originalFile = null;
			
			//check if file is a zip file
			if(input.contains("zip")){
				//originalFile = new File(input);
				command += input + " -d /mdswork/prd/work";
				commandArgs = new String[] {"/bin/bash", "-c", command};
				builder = new ProcessBuilder(commandArgs);
				builder.redirectErrorStream(true); //redirect stderr to stdout 
				p = builder.start();  //start the bash process on linux
				
				//read process standard output to see if any errors
				//reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
				p.waitFor();
				newFile = new File("/mdswork/prd/work/" + input.substring(input.indexOf(".") + 1, input.indexOf("zip")) + "csv");
				if(newFile.renameTo(new File("/mdswork/prd/work/" + fileid + "." + input.substring(input.indexOf(".") + 1, input.indexOf("zip")) + "csv"))){
				  input = "/mdswork/prd/work/" + fileid + "." + input.substring(input.indexOf(".") + 1, input.indexOf("zip")) + "csv";
				}
				zipFile = true;
			}
			
			Dataset<Row> df = spark.read()
				        // .format("text")
				         .option("inferSchema", true)
				         .option("header", true)
				         .option("quote", "\"")  //this takes care of inline JSON objects with commas
				         .option("escape", "\"")
				         .option("multiLine", true)  //this for inline newLine added in middle of a record
				         .csv("file://" + input);
			
			//System.out.println("Read " + input + ": " + LocalDateTime.now());
			//df = df.withColumn("yymm", functions.concat(functions.substring(df.col("dt"), 3, 2),functions.substring(df.col("dt"), 6, 2)));
			//System.out.println("Added YYMM column to dataframe" + LocalDateTime.now());
						
			//find the most occurring solutionid and yymm
			//handle empty file first with only header row
			if(df.count() <= 1){
				System.out.println("1"); //no data
				if(zipFile){
				  newFile = new File(input);
          		  newFile.delete();
				}
          		//updateFileStatus("0", fileid, originalFile);
			}else{
			//Change the columns to StringType except dt and detail_deliverydate column
			String[] columns = df.columns();
			for (String column : columns){
				//With same column name, the column will be replaced with new one. You don't need to do add and delete steps.
				if(!column.equalsIgnoreCase("dt") && !column.equalsIgnoreCase("detail_deliverydate") && !column.equalsIgnoreCase("solutionid") && !column.equalsIgnoreCase("versionid") && !column.equalsIgnoreCase("ts") && !column.equalsIgnoreCase("time")){
				   df = df.withColumn(column, df.col(column).cast(DataTypes.StringType));
				}
			}
			Dataset<Row> solutionDF = df.groupBy("solutionid").count();
			String solutionid = solutionDF.orderBy(solutionDF.col("count").desc()).select(solutionDF.col("solutionid")).where(solutionDF.col("solutionid").isNotNull()).first().get(0).toString();
			Dataset<Row> yymmDF = df.groupBy("dt").count();
			String yymm = yymmDF.orderBy(yymmDF.col("count").desc()).select(yymmDF.col("dt")).where(yymmDF.col("dt").isNotNull()).first().get(0).toString();
			yymm = yymm.substring(2,4) + yymm.substring(5,7);
            
			//write out to temp first
			Path workDir = new Path(tempDir + fileid);
			df.repartition(1).write()
          //  .partitionBy("solutionid","yymm")
            .option("compression","gzip")
            .option("header", true)
            .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
            .parquet(workDir.toString());
			
			
			//conf.set("fs.file.impl", "org.apache.hadoop.fs.LocalFileSystem");
			//lfs = FileSystem.getLocal(conf); does not work
			
			//now rename and move file to /data/CCS
			filePattern = Pattern.compile(pattern);
			File temp = new File("/mdswork/prd/work/CCS/" + fileid);
			File[] list_files = temp.listFiles();
			for(File filePath : list_files){
				m = filePattern.matcher(filePath.getName());
      	        if(m.matches()){
      	        	//fs.rename(filePath.getPath(), new Path(workDir + "/" + input.substring(input.lastIndexOf("/") + 1, input.lastIndexOf("csv")) + "gz.parquet"));
      	        	filePath.renameTo(new File("/mdswork/prd/work/CCS/" + fileid + "/" + input.substring(input.lastIndexOf("/") + 1, input.lastIndexOf("csv")) + "gz.parquet"));
      	        	if(!fs.exists(new Path("/data/CCS/" + solutionid + "/" + yymm))){
      	        		fs.mkdirs(new Path("/data/CCS/" + solutionid + "/" + yymm));
      	        	}
      	            fs.copyFromLocalFile(new Path(workDir + "/" + input.substring(input.lastIndexOf("/") + 1, input.lastIndexOf("csv")) + "gz.parquet"), new Path("/data/CCS/" + solutionid + "/" + yymm + "/"));
      	        	//if(FileUtil.copy(lfs,new Path(workDir + "/" + input.substring(input.lastIndexOf("/") + 1, input.lastIndexOf("csv")) + "gz.parquet"),fs,new Path("/data/CCS/" + solutionid + "/" + yymm + "/"),false,true,conf));
      	            //now check if file successfully copied to hdfs before deleting work directory
      	            if(fs.exists(new Path("/data/CCS/" + solutionid + "/" + yymm + "/" + input.substring(input.lastIndexOf("/") + 1, input.lastIndexOf("csv")) + "gz.parquet"))){
      	            	//System.out.println("file exists on hdfs");
      	            	//temp.delete(); cannot delete directory because still have file in it
      	            	FileUtil.delete(temp);
      	            	//delete csv file from zip file if true
      	            	if(zipFile){
      	            		newFile = new File(input);
      	            		newFile.delete();
      	            	}
      	            }
      	        }
			}
			System.out.println("0");  //return this result to bash script; 0 = success
			}
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void updateFileStatus(String statuscode, String fileid, File originalFile){
		//update Oracle database for Done and Empty File status
		try{
			connectDB();
			ps.setString(1, statuscode);
			ps.setString(2, fileid);
			ps.executeUpdate();
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void changeColumnDataType(String fileid, String parquetFile, String columnName){
		try{
			/**
			 * spark-shell --master local --driver-memory 10g --conf spark.debug.maxToStringFields=2000 --conf spark.sql.parquet.enableVectorizedReader=false
			 * 
			 * scala> val ccs = spark.read.parquet("/data/CCS/189/2403/15390161.FICO_PROD_MANILA_OUTPUT_189_Mar25-Mar31-2024.gz.parquet")
			 * scala> import org.apache.spark.sql.functions._
			 * scala> import org.apache.spark.sql.types.DataTypes
             * import org.apache.spark.sql.types.DataTypes
             * 
             * scala> val ccs2 = ccs.withColumn("detail_deliverydate",ccs.col("detail_deliverydate").cast(DataTypes.TimestampType))
             * ccs2: org.apache.spark.sql.DataFrame = [flowsinstance: string, solutionid: int ... 65 more fields]
             *
             * scala> ccs2.repartition(1).write.option("compression","gzip").option("header", true).parquet("file:///mdswork/prd/work/CCS/15390161")
             * 
             * scala> import org.apache.spark.sql.types._
             * //below creates header row for CSV file
             * scala> val schema = StructType(Array(StructField("oldpan", StringType, true),StructField("newpan", StringType, true)))
             * 
             * scala> val mapper = spark.read.schema(schema).csv("/work/mapping/usbank/mapped_credit_pans.gz")
			 */
			Dataset<Row> df = spark.read().parquet(parquetFile);  //hdfs parquet file only
			df = df.withColumn(columnName, df.col(columnName).cast(DataTypes.TimestampType));
			
			//write out to temp first
			Path workDir = new Path(tempDir + fileid);
			df.repartition(1).write()
            .option("compression","gzip")
            .option("header", true)
            .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
            .parquet(workDir.toString());
			
			
		}catch(Exception e){e.printStackTrace();}
	}
}
