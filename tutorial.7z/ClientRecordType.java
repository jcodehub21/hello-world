import java.io.Serializable;


public class ClientRecordType implements Serializable{

	private static final long serialVersionUID = 1L;
	
    public static RecordTypeMapper<FieldObj> getAkbankRecordTypeMapper(String recordtype){
    	
		RecordTypeMapper<FieldObj> fieldObj = new RecordTypeMapper<FieldObj>();

    	if(recordtype.equalsIgnoreCase("nmon20")){
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 321));
    		fieldObj.addFieldObj(new FieldObj("pan", 321, 340));
    		fieldObj.addFieldObj(new FieldObj("filler2", 340, 3285));
    	}else if(recordtype.equalsIgnoreCase("pis12")){
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 240));
    		fieldObj.addFieldObj(new FieldObj("pan", 240, 259));
    		fieldObj.addFieldObj(new FieldObj("filler2", 259, 1713));
    	}else if(recordtype.equalsIgnoreCase("frd15")){
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 240));
    		fieldObj.addFieldObj(new FieldObj("pan", 240, 259));
    		fieldObj.addFieldObj(new FieldObj("filler2", 259, 1965));
    	}
    	else{  //crtran25 and dbtran25
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 240));
    		fieldObj.addFieldObj(new FieldObj("pan", 240, 259));
    		fieldObj.addFieldObj(new FieldObj("filler2", 259, 2130));
    		//testing mastercard-single-f6 dbtran25_auth csv file
    	}

    	return fieldObj;
    }
    
    public static RecordTypeMapper<FieldObj> getFDRRecordTypeMapper(String recordtype){
    	
		RecordTypeMapper<FieldObj> fieldObj = new RecordTypeMapper<FieldObj>();

        if(recordtype.equalsIgnoreCase("pis12")){  //record length is 0 - 2302 instead of 2305
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1901));
    		fieldObj.addFieldObj(new FieldObj("pan", 1901, 1920));
    		fieldObj.addFieldObj(new FieldObj("filler2", 1920));
        }
        else if(recordtype.equalsIgnoreCase("nmon20")){
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1982));
    		fieldObj.addFieldObj(new FieldObj("pan", 1982, 2001));
    		fieldObj.addFieldObj(new FieldObj("filler2", 2001));
        }
    	else{  //crtran25 and dbtran25
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1901));
    		fieldObj.addFieldObj(new FieldObj("pan", 1901, 1920));
    		fieldObj.addFieldObj(new FieldObj("filler2", 1920));
    		//testing mastercard-single-f6 dbtran25_auth csv file
    	}

    	return fieldObj;
    }
    
     public static RecordTypeMapper<FieldObj> getADSRecordTypeMapper(String recordtype){
    	
		RecordTypeMapper<FieldObj> fieldObj = new RecordTypeMapper<FieldObj>();

        if(recordtype.equalsIgnoreCase("pis12")){  //record length is 0 - 2302 instead of 2305
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1901));
    		fieldObj.addFieldObj(new FieldObj("pan", 1901, 1920));
    		fieldObj.addFieldObj(new FieldObj("filler2", 1920, 2242));
    		fieldObj.addFieldObj(new FieldObj("userData06", 2242, 2262));  //relocate old pan to userData06
    		fieldObj.addFieldObj(new FieldObj("filler3", 2262));
        }
        else if(recordtype.equalsIgnoreCase("nmon20")){
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1982));
    		fieldObj.addFieldObj(new FieldObj("pan", 1982, 2001));
    		fieldObj.addFieldObj(new FieldObj("filler2", 2001, 3664));
    		fieldObj.addFieldObj(new FieldObj("userData11", 3664, 3684));  //relocate old pan to userData11
    		fieldObj.addFieldObj(new FieldObj("filler3", 3684));
        }
        else if(recordtype.equalsIgnoreCase("frd13")){
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1901));
    		fieldObj.addFieldObj(new FieldObj("pan", 1901, 1920));
    		fieldObj.addFieldObj(new FieldObj("filler2", 1920, 2414));
    		fieldObj.addFieldObj(new FieldObj("RESERVED_01", 2414, 2434));  //relocate old pan to expandedBIN
    		fieldObj.addFieldObj(new FieldObj("filler3", 2434));
        }
    	else{  //crtran25
    		fieldObj.addFieldObj(new FieldObj("filler1", 0, 1901));
    		fieldObj.addFieldObj(new FieldObj("pan", 1901, 1920));  //new pan
    		fieldObj.addFieldObj(new FieldObj("filler2", 1920, 2288));
    		fieldObj.addFieldObj(new FieldObj("userData05", 2288, 2328));  //relocate old pan to userData05
    		fieldObj.addFieldObj(new FieldObj("filler3", 2328));
    		//testing mastercard-single-f6 dbtran25_auth csv file
    	}

    	return fieldObj;
    }


}
