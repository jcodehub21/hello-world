import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;

import scala.Tuple2;


/**
 * 01/17/2024 - This class stores all common services that is used across
 * multiple classes for rolling pis 
 */
public class CommonUtil implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public static SparkSession createSparkSession(String applicationName){
		SparkSession spark = null;
		try{
			System.out.println("called  CommonUtil.createSparkSession(): " + LocalDateTime.now());
			spark = SparkSession
		  			  .builder()
		  			  .appName(applicationName)
		  			  .config("spark.dynamicAllocation.enabled", "false")
		  			  .config("spark.locality.wait", "0s")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		}catch(Exception e){e.printStackTrace();}
		return spark;
	}
	
	public static Path createDestinationDir(String client, String portfolio, String hdfsParentDir){
		Path destination = null;		
		try{
			System.out.println("called  CommonUtil.createDestinationDir(): " + LocalDateTime.now());
			Configuration config = new Configuration();
			FileSystem fs = FileSystem.get(config);
			destination = new Path(hdfsParentDir + "/" + client + "/" + portfolio);
			if(!fs.exists(destination)){
				   fs.mkdirs(destination);
			}
			
		}catch(Exception e){e.printStackTrace();}
		return destination;
	}
	
	public static Dataset<Row> connectDBForRollup(SparkSession spark, String client, String portfolio, String begPeriod, String datePeriod, String recordtype, String recordTypeLength){

			System.out.println("called CommonUtil.connectDBForRollup() for " + recordtype + ": " + LocalDateTime.now());
			String query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*" + recordtype + "*" + recordTypeLength + ".ascii.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
				    	    	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.reclen = " + recordTypeLength + " and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
				    	    	+ " and f.portfolio = \'" + portfolio + "\' and f.status = \'D\' and f.date_period between \'" + begPeriod + "' and '" + datePeriod + "\') L, filestorage fs where fs.filestatus = 'O' and fs.filetype = 'O' and fs.fileid in (L.fileid)"
				    	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";

			System.out.println("Rollup query: " + query);
			    return spark.read().format("jdbc")
			  			  .option("url", "jdbc:oracle:thin:@rhldatdms22001:1521/MDWP3.WORLD") //05/25/2022 database migrated to SHK; used to be rhldatdms14001
			  			  .option("user", "mdw")
			    		  .option("password", "mdw")
			    		  .option("dbtable", query)
			    		  .load();
	}
	
	public static Dataset<Row> connectDBForUpdate(SparkSession spark, String client, String portfolio, String datePeriod, String recordtype, String recordTypeLength){

			System.out.println("called CommonUtil.connectDBForUpdate() for " + recordtype + ": " + LocalDateTime.now());
			String query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*" + recordtype + "*" + recordTypeLength + ".ascii.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
			        + " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.reclen = " + recordTypeLength + " and r.recordtype = f.recordtype and f.client = \'" + client + "\'"
			    	+ " and f.portfolio = \'" + portfolio + "\' and f.status = \'D\' and f.date_period = \'" + datePeriod + "\') L, filestorage fs where fs.filetype = 'O' and fs.filestatus = 'O' and fs.fileid in (L.fileid)"
			    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";

			    return spark.read().format("jdbc")
			  			  .option("url", "jdbc:oracle:thin:@rhldatdms22001:1521/MDWP3.WORLD") //05/25/2022 database migrated to SHK; used to be rhldatdms14001
			  			  .option("user", "mdw")
			    		  .option("password", "mdw")
			    		  .option("dbtable", query)
			    		  .load();
	}
	
	public static Dataset<Row> createDataSet(SparkSession spark, String rt, JavaRDD<Row> rdd){
		Dataset<Row> ds = null;
    	List<RollingObj> fieldnames = null;
    	List<StructField> fields = null;
    	RecordTypeMapperCSV rtm = null;
    	StructType schema = null;
		try{
			System.out.println("called CommonUtil.createDataset(): " + LocalDateTime.now());
			 rtm = new RecordTypeMapperCSV(rt);
		     fieldnames = rtm.getFieldInfo();
	         
	        //Store the StruckField object into a List
		    fields = new ArrayList<>();
		      
		    //create the StructFields for the Schema
		    for(int x = 0; x < fieldnames.size(); x++){
		    	  
		    	  fields.add(DataTypes.createStructField(fieldnames.get(x).fieldName, DataTypes.StringType, true));
		      }
		    
		    //create the schema
	  		schema = DataTypes.createStructType(fields);
	  		
   		  //to create an empty dataset<row> use spark.createDataFrame(new ArrayList<>(), schema)
	  		//ds = spark.createDataFrame(newRows, schema);
	  		ds = spark.createDataFrame(rdd, schema);
			//newRows.clear();
		}catch(Exception e){e.printStackTrace();}
	 	return ds;		
	}
	
	/**
	 * cut out the required bytes from /dmsdisks files to match RecordTypeMapperCSV
	 * @param spark
	 * @param inputPaths
	 * @param recordtype
	 * @param schema
	 * @param begPos
	 * @param endPos
	 * @return
	 */
	public static Dataset<Row> getGoodRecords(Dataset<Row> df, String inputPaths, String recordtype, StructType schema, int begPos, int endPos){
		try{
			System.out.println("called CommonUtil.transformPIS(): " + LocalDateTime.now());   			     
			   df = df.filter(row -> {
				          return row.mkString().length() >= endPos;}
  			        )
                    .map(row -> {
				          return RowFactory.create(row.mkString().substring(begPos, endPos));
			   }, RowEncoder.apply(schema));
			   
		}catch(Exception e){e.printStackTrace();}
		return df;
	}
	
	public static Dataset<Row> getRejectedRows(Dataset<Row> df, String inputPaths, int endPos, String recordCreationDateBytes){
	
		try{
			System.out.println("called CommonUtil.getRejectedRows(): " + LocalDateTime.now());
			
			df = df.filter(row -> {
				return checkRejectRecords(row, endPos, recordCreationDateBytes);
			});
		}catch(Exception e){e.printStackTrace();}
		return df;
	}
	
	public static JavaRDD<Row> mapReducePIS(JavaRDD<Row> rdd, Broadcast<NmonBroadcast> nmbc, String pisRecordType){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;

		System.out.println("called CommonUtil.mapReducePIS(): " + LocalDateTime.now());
		if(rdd != null){
			System.out.println("CommonUtil.mapReducePIS(): rdd not null");
		}
		javaPairRdd = rdd.filter(row -> {
			               return !row.mkString().substring(16,24).trim().isEmpty();  //only want recordtypes that have a value in it
		              })
		              .mapToPair(row -> {
                  //sortkey = pan
			       return new Tuple2<String, String>(row.mkString().substring(160, 179), row.mkString());
	            }).reduceByKey((v1, v2) -> {
	    			
	    			String record = "";
	    			String value1 = "";
	    			String value2 = "";
	    			//don't need the pandatefield in RecordTypeMapper class anymore 
	    			//because use it here to reduceByKey when PIS records
	    			
	    			value1 = v1.substring(160, 179) + v1.substring(45, 62);
	    			value2 = v2.substring(160, 179) + v2.substring(45, 62);
	    			//if value1.compareTo(value2) > 0 (returns positive value) then value1 > value2
	                //if value1 == value2 then returns 0
	                //if value1.compareTo(value2) < 0 (returns negative value) then value1 < value2
	    			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
	    				//record = v1;  //return whole string
	    				record = nmbc.value().rollupPIS12(v1, v2);
	    			}
	                if(value1.compareTo(value2) < 0){
	    				//record = v2;
	                	record = nmbc.value().rollupPIS12(v2, v1);
	    			}
	    			return record; 
	    		});
	    
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
	    	   // System.out.println("foreach: rt: " + f.substring(16,24).trim());
			//f._2 = scala.Tuple2._2 or the value from Tuple2<K,V>
			//f._1 = scala.Tuple2._1 = the key from Tuple2<K,V>
			//found out that some records have recordtype blank so the List<RollingObj> has size 0 and throws java.lang.NullPointerException: Null value appeared in non-nullable field:
 			rt = new RecordTypeMapperCSV(f._2.substring(16,24).trim());  //gets the recordtype value
 			//rt = new RecordTypeMapperCSV(pisRecordType);
			rt.setPISFieldValue(f._2);	
			return rt.getRow();  //throws java.lang.NullPointerException when List<RollingObj> has size 0 when returning rows
		});
		return newJavaRDD;
	}
	
	public static JavaRDD<Row> mapReduceNMON11(JavaRDD<Row> rdd, Broadcast<NmonBroadcast> nmbc){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("called  CommonUtil.mapReduceNMON11(): " + LocalDateTime.now());
		if(rdd != null){
			System.out.println("CommonUtil.mapReduceNMON11(): rdd not null");
		}
		javaPairRdd = rdd.mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		   **/
			return new Tuple2<String, String>(row.mkString().substring(212, 231) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			
  			if(v1.substring(174, 178).equalsIgnoreCase("3100")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3122")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3102")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3109")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3003")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1406, 1414);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1406, 1414);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3101")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1310, 1318);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1310, 1318);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3103")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3105")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1310, 1318);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1310, 1318);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3115")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3121")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1161, 1171);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1161, 1171);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3123")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3124")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3201")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1377, 1390);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1377, 1390);
  			}
  			else{
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000";
  			}

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				//record = v1;  //return whole string
  				record = nmbc.value().rollupNmon11(v1, v2, v1.substring(174, 178));
  			}
              if(value1.compareTo(value2) < 0){
  				//record = v2;
            	  record = nmbc.value().rollupNmon11(v2, v1, v1.substring(174, 178));
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis11");
			 rt.setNMON11FieldValue(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
		
		return newJavaRDD;
	}
	
	public static JavaRDD<Row> mapReduceNMON20(JavaRDD<Row> rdd, Broadcast<NmonBroadcast> nmbc){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON20(): map pan only: " + LocalDateTime.now());
		javaPairRdd = rdd
				   // .filter(row -> {
			         // return row.mkString().length() > 2133;}) //no need for filter since already filter in transformParquet()
		    .mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		    * took the trim() out because there were pans with blank recordCreationDate and recordCreationTime 
		    * so need to compare exactly same pans
		   **/
			return new Tuple2<String, String>(row.mkString().substring(241, 260) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			if(v1.substring(174, 178).equalsIgnoreCase("3100")){ //add in newCountryCode to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1207, 1210);
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1207, 1210);
  			}
  			else if(v1.substring(174,178).equalsIgnoreCase("3010")){  //add in newCode1 to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1501, 1504);
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1501, 1504);
  			}
  			else if(v1.substring(174,178).equalsIgnoreCase("3102")){  //add in newCode1 to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1501, 1504) ;
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1501, 1504) ;
  			}
  			else{
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000";
  			}

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				//record = v1;  //return whole string
  				record = nmbc.value().rollupNmon20(v1, v2, v1.substring(174, 178));
  			}
              if(value1.compareTo(value2) < 0){
  				//record = v2;
            	record = nmbc.value().rollupNmon20(v2, v1, v1.substring(174, 178));
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis12");
			 rt.setNMON20FieldValue(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
        
		return newJavaRDD;
	}
    
    public static void mergeDatasetPIS11(Dataset<Row> pis11, Dataset<Row> nmon11, SparkSession spark, Broadcast<NmonBroadcast> nmbc, String action, Path processedOutputDir, String dateFolder, String datePeriod, String pisRecordType){
    	Dataset<Row> pastDF = null;
    	JavaRDD<Row> rdd = null;
    	try{
    		System.out.println("called CommonUtil.mergeDatasetPIS11(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(pis11 != null){
            	if(nmon11 != null){  //make sure nmon11 has records   
            	  //merge pis and nmon, pis11 still contains pandatetime field
            	  nmon11.createOrReplaceTempView("nmon");
            	  nmon11 = spark.sql("select * from nmon where nonmonCode in ('3001','3003', '3100', '3101', '3102', '3103', '3104', '3105', '3109','3114', '3115', '3121', '3122', '3123', '3124', '3201')"); 
              	  pis11 = pis11.union(nmon11);
                  System.out.println("pis11 unioned nmon11");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			.withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis11 = pis11.union(pastDF);
                	System.out.println("pis11 unioned " + datePeriod);
                }
                
                rdd = mapReducePIS(pis11.javaRDD(), nmbc, pisRecordType);    		
                pis11 = createDataSet(spark,"pis11", rdd);
                System.out.println("pis11 completed final round of mapReducePIS");
                
                pis11 = pis11.drop("nonmonCode");  //drop nonmonCode column
                
                //remove empty pans
                pis11.createOrReplaceTempView("pis11");
                
                pis11 = spark.sql("select * from pis11 where trim(pan) <> ''");
                System.out.println("removed blank pans");
        
                //drop the pandatetime before writing it back out as another parquet file
                pis11 = pis11.drop("pandatetime");
                System.out.println("dropped pandatetime field");
                pis11 = pis11.dropDuplicates();
                System.out.println("dropped duplicates");
                pis11 = pis11.withColumn("cashbackLimitMode", functions.lit(null).cast(DataTypes.StringType));
                System.out.println("added field cashbackLimitMode to pis11");

                  pis11.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);

                System.out.println("Completed " + processedOutputDir + "/current_PIS/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
            }
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
    public static void mergeDatasetPIS12(Dataset<Row> pis12, Dataset<Row> nmon20, SparkSession spark, Broadcast<NmonBroadcast> nmbc, String action, Path processedOutputDir, String dateFolder, String datePeriod, String pisRecordType){
    	Dataset<Row> pastDF = null;
    	JavaRDD<Row> rdd = null;
    	try{
    		System.out.println("called CommonUtil.mergeDatasetPIS12(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon            
            if(pis12 != null){
            	//pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
            	if(nmon20 != null){
            		//merge pis and nmon, pis11 still contains pandatetime field
              	  nmon20.createOrReplaceTempView("nmon");
              	  nmon20 = spark.sql("select * from nmon where nonmonCode in ('3000','3010', '3100', '3102', '3104','3201')");
            	   //merge pis and nmon
            	   pis12 = pis12.union(nmon20);
            	   System.out.println("pis12 unioned nmon20");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			        .withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis12 = pis12.union(pastDF);
                	System.out.println("pis12 unioned " + datePeriod);
                }
                
                rdd = mapReducePIS(pis12.javaRDD(), nmbc, pisRecordType);    		
                pis12 = createDataSet(spark, "pis12", rdd);
                System.out.println("pis12 completed final round of mapReducePIS");
                
                pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
                
              //remove empty pans
                pis12.createOrReplaceTempView("pis12");
                
                pis12 = spark.sql("select * from pis12 where trim(pan) <> ''");
                System.out.println("removed blank pans");

                //drop the pandatetime before writing it back out as another parquet file
            	pis12 = pis12.drop("pandatetime");
            	System.out.println("dropped pandatetime field");
                pis12 = pis12.dropDuplicates();
                System.out.println("dropped duplicates");
                pis12 = pis12.withColumn("dailyLimitType", functions.lit(null).cast(DataTypes.StringType));
                System.out.println("added field dailyLimitType to pis12");

            		pis12.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);

            	System.out.println("Completed " + processedOutputDir + "/current_PIS/" + dateFolder + " Parquet File: " + LocalDateTime.now());           	
            } 	
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
    /**
	  * Need to pass in the recordCreationDate bytes to validate
	  * @param record
	  * @param endPosition
	  * @return
	  */
	 public static boolean checkRejectRecords(Row record, int endPosition, String recordCreationDateBytes){
		
		 return record.mkString().length() < (endPosition - 10) || checkRecordCreationDatebyString(record.mkString().substring(Integer.parseInt(recordCreationDateBytes.substring(0, recordCreationDateBytes.lastIndexOf("-"))), Integer.parseInt(recordCreationDateBytes.substring(recordCreationDateBytes.indexOf("-") + 1))));
	 }
	 
	 public static boolean checkRecordCreationDatebyString(String date){
		 try{
			 LocalDate.parse(date.trim(), DateTimeFormatter.ofPattern("yyyyMMdd"));
		 }catch(DateTimeParseException e){return true;}	
		 return false;
	 }
}
