import java.io.BufferedReader;
import java.io.FileReader;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;


public class StringTest {
	
	public static void main(String[] args){
		StringTest test = new StringTest();
		//test.checkRecordLength(args[0]);
		//test.checkCounter();
		test.checkLocalDate();
	}
	
	public void testString(){
		String value1 = "419742003j9rhduYPBq20190112020722";
		String value2 = "419742003j9rhduYPBq20190125134539";
		String value3 = "419742003j9rhduYPBq20190100533678";
		
		System.out.println("value1.compareTo(value2): " + value1.compareTo(value2));
		System.out.println("value2.compareTo(value1): " + value2.compareTo(value1));
		System.out.println("value1.compareTo(value3): " + value1.compareTo(value3));
		System.out.println("value2.compareTo(value3): " + value2.compareTo(value3));
		System.out.println("value3.compareTo(value2): " + value3.compareTo(value2));
	}
	
	public void checkLocalDateTime(){
		System.out.println("Year: " + LocalDateTime.now().getYear());
		System.out.println("Month: " + LocalDateTime.now().getMonth().getValue());
		System.out.println("YYMM: " + String.valueOf(LocalDateTime.now().getYear()).substring(2) + (LocalDateTime.now().getMonth().getValue() < 10 ? "0" + String.valueOf(LocalDateTime.now().getMonth().getValue()) : LocalDateTime.now().getMonth().getValue()));
	}
	
	public void checkLocalDate(){
		System.out.println("Today YYYYMM: " + String.valueOf(LocalDateTime.now().getYear()) + (LocalDateTime.now().getMonth().getValue() < 10 ? "0" + String.valueOf(LocalDateTime.now().getMonth().getValue()) : LocalDateTime.now().getMonth().getValue()));
		System.out.println("LocalDate parse: " + LocalDate.parse("2025-03-01"));
		System.out.println("LocalDate parse but 3 months back: " + LocalDate.parse("2025-03-01").minusMonths(4));
		System.out.println("Today's LocalDate: " + LocalDate.now());
		System.out.println("Today's LocalDate but 3 months back: " + LocalDate.now().minusMonths(3));
		long milli = 1748784300915L;
		System.out.println("Parse File.lastModified(): " + LocalDateTime.ofInstant(Instant.ofEpochMilli(milli),ZoneId.systemDefault()));
	}

	public void checkRecordLength(String fileName){
    	try{
    		String content = "";
    		BufferedReader br = new BufferedReader(new FileReader(fileName));
    		while((content = br.readLine()) != null){
    			System.out.println("record length: " + content.length());
    		}
    		br.close();
    	}catch(Exception e){e.printStackTrace();}   	
    }
	
	public void checkCounter(){
		int counter = 0;
		System.out.println(counter--);  //prints 0 first then counter change to -1
		counter = -1;
		System.out.println(--counter);  //counter changed to -2 and then print -2
		counter = 0;
		counter--;
		System.out.println(counter);
	}
}
