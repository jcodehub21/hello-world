import java.sql.*;
import java.util.*;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 * This class sends emails to MPB client owners of their clients 
 * with files delayed delivery
 * @author JaneCheng
 * 05/09/2020
 */
public class ClientFileDelayedDelivery {
	
	Connection conn = null;
	ResultSet rs = null;
	Statement sst = null; //complete query without any input parameters needed; execute one time
	//PreparedStatement ppStmt = null; //query that takes in input parameters "?"; execute multiple times
	
	ResultSetMetaData rsmd = null;
	StringBuffer sb = new StringBuffer();
	String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
	String endTable = "</table>";
	String dateQuery = null;
	String globalStatement = null;
	RecclassInfo recclassObj = null;
	ClientInfo clientObj = null;
	FileDelayedInfo primaryContactObj = null;
	//FileDelayedInfo secondaryContactObj = null;
	GeneralLinkList<FileDelayedInfo> linklist = new GeneralLinkList<FileDelayedInfo>();
	
	public static void main(String[] args){
		
		ClientFileDelayedDelivery test = new ClientFileDelayedDelivery();
		test.connectDB();
		//test.runSingleQuery();
		//test.testLinkList();
		test.closedAll();
	}
	
	public ClientFileDelayedDelivery(){
		
		globalStatement = "SELECT primary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),\'YYYY-MM-DD\') last_delivery,";
        globalStatement = globalStatement + "ROUND(AVG(delivery_interval)) grace_period,";
        globalStatement = globalStatement + "TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,";
        globalStatement = globalStatement + "COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client, ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn FROM ";
        globalStatement = globalStatement + "(SELECT f.client, f.portfolio, recClass, file_date, primary_internal_contact,";
        globalStatement = globalStatement + "TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,";
        globalStatement = globalStatement + "(SELECT key_value FROM client_data_setup s WHERE flag = \'C\' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval";
        globalStatement = globalStatement + " FROM (select * from files x where (x.client, x.portfolio, x.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds)) f, recordtypes t, client c WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN (\'D\',\'M\',\'0\') AND f.recordtype NOT IN (-1, 41, 114)";
        globalStatement = globalStatement + " AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = \'A\' AND inventory# NOT LIKE \'S%\' AND f.project_id=\'1\' AND c.product = \'MPB\')";                  
        globalStatement = globalStatement + " WHERE delivery_interval > 0 GROUP BY primary_internal_contact, client, portfolio, recClass";
        globalStatement = globalStatement + " HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14)";
        globalStatement = globalStatement + " AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3) UNION ";
		globalStatement = globalStatement + "SELECT secondary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),\'YYYY-MM-DD\') last_delivery,";
        globalStatement = globalStatement + "ROUND(AVG(delivery_interval)) grace_period,";
        globalStatement = globalStatement + "TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,";
        globalStatement = globalStatement + "COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client, ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn FROM ";
        globalStatement = globalStatement + "(SELECT f.client, f.portfolio, recClass, file_date, secondary_internal_contact,";
        globalStatement = globalStatement + "TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,";
        globalStatement = globalStatement + "(SELECT key_value FROM client_data_setup s WHERE flag = \'C\' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval";
        globalStatement = globalStatement + " FROM (select * from files x where (x.client, x.portfolio, x.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds)) f, recordtypes t, client c WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN (\'D\',\'M\',\'0\') AND f.recordtype NOT IN (-1, 41, 114)";
        globalStatement = globalStatement + " AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = \'A\' AND inventory# NOT LIKE \'S%\' AND f.project_id=\'1\' AND c.product = \'MPB\')";                  
        globalStatement = globalStatement + " WHERE delivery_interval > 0 GROUP BY secondary_internal_contact, client, portfolio, recClass";
        globalStatement = globalStatement + " HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14)";
        globalStatement = globalStatement + " AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3) ORDER BY client desc, portfolio, recClass";
		
	}
	
	public void connectDB(){
		
		 // boolean isClosed = true;
		  try{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	        //conn = DriverManager.getConnection("jdbc:oracle:thin:@lux104:1521:mdwp1", "mdw", "mdw");
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated from mdwp2 to mdwp3
	        sst = conn.createStatement();
	       // ppStmt = conn.prepareStatement(globalStatement);
	      //  isClosed = conn.isClosed();
	        runSingleQuery();
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}
		//  return isClosed;
		}
	
     public void runSingleQuery(){
		
		try{
              rs = sst.executeQuery(globalStatement);
              createFileDelayedInfo();
             /** while(rs.next()){
            	  
            	  System.out.println(rs.getString(1) + "," + rs.getString(2) + "," + rs.getString(3) + ","  + rs.getString(4) + "," + rs.getString(5) + "," + rs.getString(6) + "," + rs.getString(7));
              }**/
 
			}
			
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
     
     public void createFileDelayedInfo(){
    	 
    	 FileDelayedInfo temp = null;
    	 
    	 try{
    		 
    		 while(rs.next()){
    	    	 
    			 //if linklist size = 0 then first row of ResultSet has not been added
    			 if(linklist.size == 0){
    				 primaryContactObj = new FileDelayedInfo(rs.getString(1));
    				// secondaryContactObj = new FileDelayedInfo(rs.getString(2));
    			     clientObj = new ClientInfo(rs.getString(2), rs.getString(3));
    			     recclassObj = new RecclassInfo(rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
    			     
    			     //add recclassObj to clientObj
    			     clientObj.addRecclassObj(recclassObj);
    			     
    			     //add clientObj to FileDealyedInfo contacts
    			     primaryContactObj.addClientInfo(clientObj);
    			   //  secondaryContactObj.addClientInfo(clientObj);
    			     
    			     //add contactObj to linklist
    			     linklist.addNode(primaryContactObj);
    			 }
    			 else{
    				 
    				 boolean hasClient = false;
        	    	 boolean hasRecclass = false;
        	    	 boolean hasContact = false;
        	    	 
    				 //add second row and going forward
    				 linklist.setIterator();
    				 while(linklist.hasNext()){
    					 
    					 temp = linklist.getNode();
    					 //test if rs.getString(1) is equal to client owner
    					 if(rs.getString(1).equalsIgnoreCase(temp.Contact)){
    						// System.out.println("owner: " + rs.getString(1));
    						 hasContact = true;
    						// System.out.println("Contact: " + hasContact);
    						 //check if client is already created
    						 for(int x = 0; x < temp.client.size(); x++){
    							  //found a client match
    							 if(rs.getString(2).equalsIgnoreCase(temp.client.get(x).client) && rs.getString(3).equalsIgnoreCase(temp.client.get(x).portfolio)){
    								// System.out.println("client: " + rs.getString(2) + " temp client: " + temp.client.get(x).client);
    								 hasClient = true;
    								 
    								//check if recclass already added to client
    								   for(int y = 0; y < temp.client.get(x).recclassList.size(); y++){  
    								    if(rs.getString(4).equalsIgnoreCase(temp.client.get(x).recclassList.get(y).recclass)){
    								    //	System.out.println("recclass: " + rs.getString(4) + " temp client: " + temp.client.get(x).recclassList.get(y).recclass); 
    								    	 hasRecclass = true;
    								     }
    								     
    								   }//end of recclass check
    								   //no match in client's recclass so create new recclass and add to recclasslist
    								   if(!hasRecclass){
    									 //  System.out.println("no recclass so add new recclass");
    									   recclassObj = new RecclassInfo(rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
    									   temp.client.get(x).recclassList.add(recclassObj);
    								   }
    							 }
    							 
    						 }//end of for loop client check
    						 if(!hasClient){
    							// System.out.println("no client so add new client");
    							 clientObj = new ClientInfo(rs.getString(2), rs.getString(3));
    		    			     recclassObj = new RecclassInfo(rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
    		    			     
    		    			   //add recclassObj to clientObj
    		    			     clientObj.addRecclassObj(recclassObj);
    		    			   //add clientObj to FileDealyedInfo contacts
    		    			     temp.client.add(clientObj);
    		    			     
    						 }
    						 
    					 }//end of Contact check
    				 } //end of while	 
    				 if(!hasContact){
    					// System.out.println("no owner so add new owner");
    					 primaryContactObj = new FileDelayedInfo(rs.getString(1));
    	    			//	System.out.println("new owner: " + rs.getString(1));
    	    			     clientObj = new ClientInfo(rs.getString(2), rs.getString(3));
    	    			     recclassObj = new RecclassInfo(rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
    	    			     
    	    			     //add recclassObj to clientObj
    	    			     clientObj.addRecclassObj(recclassObj);
    	    			     
    	    			     //add clientObj to FileDealyedInfo contacts
    	    			     primaryContactObj.addClientInfo(clientObj);
    	    			     
    	    			     //add contactObj to linklist
    	    			     linklist.addNode(primaryContactObj);
    				     }
    				
    			 }//end of else
    		 }//end of while
    		 createHTMLEmailBody();
    	 }//end of try block
    	 catch(Exception e){e.printStackTrace();System.exit(-1);}
     }
     
     public void createHTMLEmailBody(){
    	 
    	 FileDelayedInfo temp = null;
    	 String recipient = "";
    	 boolean hasClient = false;
    	 List<ClientInfo> clientList = new ArrayList<ClientInfo>();
    	 
    	 try{
    		
    		//send email to primary and secondary client owner only
    		linklist.setIterator();
    		while(linklist.hasNext()){
    			temp = linklist.getNode();
    			recipient = temp.Contact + "@fico.com";
    			//sb.append("owner: " + recipient + "<br>");
    			sb.append("This report shows clients with broken file sending patterns.<br>");
    			sb.append("It checks two years back in history for the patterns or reads expectations defined in client properties.<br><br>");
    			//System.out.println("client size: " + temp.client.size());
    			for(int x = 0; x < temp.client.size(); x++){
    			
    				//System.out.println("client: " + temp.client.get(x).client);
    		         sb.append("Client: " + temp.client.get(x).client + " (" + temp.client.get(x).portfolio + ")<br><br>");	
 			         sb.append(beginTable);
 			         sb.append("<tr><td><b>Recclass</b></td><td><b>Last Delivery</b></td><td><b>Delivery Interval</b></td><td><b>Past Due</b></td></tr>");
 			         
 			    	for(int y = 0; y < temp.client.get(x).recclassList.size(); y++){
 	 			    	
 			    		//System.out.println("reclass: " + temp.client.get(x).recclassList.get(y).recclass);
 	 			    	  sb.append("<tr><td>").append(temp.client.get(x).recclassList.get(y).recclass).append("</td><td>").append(temp.client.get(x).recclassList.get(y).lastDeliveryDate).append("</td><td>");
 	 			    	  sb.append(temp.client.get(x).recclassList.get(y).deliveryInterval).append("</td><td>").append(temp.client.get(x).recclassList.get(y).pastDueDays).append("</td></tr>");
 	 			    }
 	 			    sb.append(endTable);
 	 				sb.append("<br>");
 			     
    			}//end of client loop
    			sendEmail(recipient, sb);
    			sb.setLength(0);  //clears the buffer
    		}//end of the while loop
    		
    		
    		/** send all clients to Caroline Chesney
    		 *  since linklist can have two same clients due to two 
    		 *  different client owners, the email to Caroline show
    		 *  two tables of same client
    		 *  need a way to check if same client 
    		 */
    		linklist.setIterator();
			recipient = "CarolineChesney@fico.com,SharonChen@fico.com";
			sb.append("This report shows clients with broken file sending patterns.<br>");
			sb.append("It checks two years back in history for the patterns or reads expectations defined in client properties.<br><br>");
			
			//add clients to clientList ArrayList first
    		while(linklist.hasNext()){
    			hasClient = false;
    			temp = linklist.getNode();
    			for(int x = 0; x < temp.client.size(); x++){
    				
    				if(clientList.size() == 0){	
 			          clientList.add(temp.client.get(x));
    				}
    				else{
                         
    					for(int z = 0; z < clientList.size(); z++){
     			    		
     			    		if(temp.client.get(x).client.equalsIgnoreCase(clientList.get(z).client)){
     			    			
     			    			hasClient = true;
     			    		}	
    			    	}//end of for loop
    					if(!hasClient){
    						
    						clientList.add(temp.client.get(x));
    					}
    						
    				}//end of else 
    			}//end of for loop
    		}//end of while loop
 			          
 			       for(int x = 0; x < clientList.size(); x++){
 			    	   
 			    	  sb.append("Client: " + clientList.get(x).client + " (" + clientList.get(x).portfolio + ")<br><br>");	
			           sb.append(beginTable);
			           sb.append("<tr><td><b>Recclass</b></td><td><b>Last Delivery</b></td><td><b>Delivery Interval</b></td><td><b>Past Due</b></td></tr>");
			         
			           for(int y = 0; y < clientList.get(x).recclassList.size(); y++){
 			    	  sb.append("<tr><td>").append(clientList.get(x).recclassList.get(y).recclass).append("</td><td>").append(clientList.get(x).recclassList.get(y).lastDeliveryDate).append("</td><td>");
 			    	  sb.append(clientList.get(x).recclassList.get(y).deliveryInterval).append("</td><td>").append(clientList.get(x).recclassList.get(y).pastDueDays).append("</td></tr>");
			         }
	 			          sb.append(endTable);
	  				     sb.append("<br>");
 			        }//end of for loop

			sendEmail(recipient, sb);
			sb.setLength(0);  //clears the buffer
    	 }
    	 catch(Exception e){e.printStackTrace(); System.exit(-1);}
     }
     
     public void testLinkList(){
    	 
    	 FileDelayedInfo temp = null;
    	 try{
    		 
     		linklist.setIterator();
     		while(linklist.hasNext()){
     			temp = linklist.getNode();
     			System.out.println(temp.Contact + "@fico.com");
     			for(int x = 0; x < temp.client.size(); x++){
     		     System.out.println("Client: " + temp.client.get(x).client + " (" + temp.client.get(x).portfolio + ")");	

  			       for(int y = 0; y < temp.client.get(x).recclassList.size(); y++){
  			    	
  			    	  System.out.println(temp.client.get(x).recclassList.get(y).recclass);
  			    	  System.out.println(temp.client.get(x).recclassList.get(y).lastDeliveryDate);
                      System.out.println(temp.client.get(x).recclassList.get(y).deliveryInterval);
                      System.out.println(temp.client.get(x).recclassList.get(y).pastDueDays);
  			    }

     			}
     			
     		}//end of the while loop
     	 }
     	 catch(Exception e){e.printStackTrace(); System.exit(-1);}
     }

    /**send emails
     * 
     * @param filedelayed
     */
    public void sendEmail(String recipient, StringBuffer tableBody){
	
	//String to = recipient;
	String to = recipient + ",janecheng@fico.com";
    //String to = "janecheng@fico.com";
    String from = "ml_data_management@fico.com";
    
    try
    {
    	
	    //sb.append("Wells-F6 Data Report for " + dateQuery).append("<br>");
	   // listFiles();
	  //  recordCountForEachFile();
    
    //sb.append("<br> Thank you, <br> Jane Cheng");
    String host = "mail.fairisaac.com";
    
  //create properties to store host and get or set the default mail session object
      Properties props = new Properties();
      props.put("mail.smtp.host", host);
      Session session = Session.getInstance(props);


          //create the message object
          MimeMessage msg = new MimeMessage(session);

          //set the sender's email address
          msg.setFrom(new InternetAddress(from));

          //set the recipient's email address
          msg.setRecipients(Message.RecipientType.TO, to);
      
          /* if you have more than 1 recipient to send to then use this:
           InternetAddress[] address = {new InternetAddress(args[0])};
           msg.setRecipients(Message.RecipientType.TO, address);

          */
       
          //set the subject heading
          //msg.setSubject("Wells-F6 Data Report " + dateQuery);
          msg.setSubject("MPB Clients With Delayed File Delivery");

         //set the date of sending the email; new date() initializes the to current date
          msg.setSentDate(new Date());

         //set the message body; setText method only uses text/plain
        // msg.setText(msgBody);
          Multipart mp = new MimeMultipart();
          
          //set the html body part
          MimeBodyPart htmlbody = new MimeBodyPart();
          htmlbody.setContent(tableBody.toString(), "text/html");
          mp.addBodyPart(htmlbody);
          
          //set the attachment part
          //MimeBodyPart attachment = new MimeBodyPart();
         // attachment.attachFile("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
          //--attachment.setFileName("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
          //--attachment.setContent(attachment, "application/vnd.ms-excel");
         // attachment.attachFile("/ana/mds/prd/data/FIS_Ind_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
          //mp.addBodyPart(attachment);
          
         //need to use setContent method if using text/html
       //  msg.setContent(sb.toString(), "text/html");
          msg.setContent(mp);

         //send the email
         Transport.send(msg);
          
          



       }
       catch(Exception mex){

          System.out.println("Error in sending: ");
          mex.printStackTrace();
          System.exit(1);


       }
	
}

public void closedAll(){
	
	   try{
		if(rs != null){
         rs.close();
         sst.close();
         conn.close();
       }
	   }
	   catch(Exception e){e.printStackTrace();}
	}

}
