import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


//import java.util.Properties;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
//import org.apache.spark.api.java.function.PairFunction; //needed if want to do a new PairFunction<>()
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.functions; //have to use functions.concat()
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.broadcast.Broadcast;

import java.time.LocalDateTime;

import scala.Tuple2;
import scala.reflect.ClassTag;
/**
 * 08/04/2021:  This class uses Spark JDBC connection to Oracle database
 * to retrieve the HDFS file paths
 * 01/04/2023: updated to give option to use /data/raw_falcon or /dmsdisks as source files
 * @author JaneCheng
 *
 */
public class RollingPISv2 implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	//static final List<Row> newRows = new ArrayList<>();
	RecordTypeMapperCSV rtm = null;
	StructType schema = null;
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
	String hdfsDest = "";
	String fileformat = ""; // dd = source files from /dmsdisks or rf = /data/raw_falcon
	String begPeriod = "";
	int pisBegPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	int pisEndPos = 0; //enter pis end position to extract text if using /dmsdisks files
	int nmonBegPos = 0; //enter nmon beginning position to extract text if using /dmsdisks files
	int nmonEndPos = 0; //enter nmon end position to extract text if using /dmsdisks files
	int pisPanEndPos = 0; //pis pan end position in bytes if using /dmsdisks files; some ts2_9330-f6 old files have no pans
	String query = "";
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
    // static final BufferedWriter bw;  //write out nmon comparisons
	// static final OutputStream os;
    // static final Path nmonRecords;
	//list represents an ordered sequence of objects
	String pis12List = "";
	String pis11List = ""; 
	String nmon20List = "";
	String nmon11List = "";
   	
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> pis12 = null;
	Dataset<Row> nmon11 = null;
	Dataset<Row> nmon20 = null;
	Dataset<Row> resultPaths = null;
	Broadcast<NmonBroadcast> nmbc = null;
	StructType textSchema = null;
	//static Properties connectionProperties = null;  //properties for jdbc connection
	
	public static void main(String[] args){
		/**
    	 * args[0] = client ex: ts2_8167-f6
    	 * args[1] = portfolio  ex: debit
    	 * args[2] = date period  ex: 1901
    	 * args[3] = action (r = rollup, u = update)
    	 * args[4] = main hdfs destination to store parquet files
    	 * args[5] = file format (rf = raw falcon; dd = dmsdisks)
    	 * args[6] = pis begin and end position to extract text from /dmsdisks separated by a dash if dd (optional)
    	 * args[7] = nmon begin and end position to extract text from /dmsdisks separated by a dash if dd(optional)
    	 * args[8] = start date period to rollup from eg start from 1502 and roll up to 2201
    	 * args[9] = pis pan end position if dd (optional)
    	 */
		if(args.length > 5 && args.length < 11){
		    //default to using dd format
			RollingPISv2 test = new RollingPISv2(args);
			//since I started the spark session first the Path object needs to be serialized
            test.createSparkSession();
		    //query for single or multiple months or roll up
		    test.processDatePeriod();
		}
		else{
			System.out.println("Usage: RollingPIS tool to roll up nmon pans to pis files from 1901 to present. \n"
					+ "Parameters separated by a space: client portfolio date_period action main_hdfs_destination fileformat\n"
					+ "Action: r for rollup and u for update \n" 
					+ "fileformat: dd for dmsdisks or rf for raw_falcon \n"
					+ "Example: ts2_9330-f6 none 2201 r /data/hive_falcon dd 416-977 416-2121 1502 595");
			
		}
		
	}
    public RollingPISv2(){}
    
    public RollingPISv2(String client, String portfolio, String dateFolder, String action, String hdfsDest){
		this.client = client;
		this.portfolio = portfolio;
		this.dateFolder = dateFolder;
		this.action = action; //r = rollup, u = update
		this.hdfsDest = hdfsDest;
		try{	
			processedOutputDir = new Path(this.hdfsDest + "/" + this.client + "/" + this.portfolio);
			fs = FileSystem.get(config);
			if(!fs.exists(processedOutputDir)){
				   fs.mkdirs(processedOutputDir);
			}
		}catch(Exception e){e.printStackTrace();}

    }
    
	public RollingPISv2(String[] args){
    	   	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		this.hdfsDest = args[4];	
		this.fileformat = args[5]; //dd or lf or rf format to use for source files
		if(fileformat.equalsIgnoreCase("dd")){
           this.pisBegPos = Integer.parseInt(args[6].substring(0, args[6].lastIndexOf("-")));
           this.pisEndPos = Integer.parseInt(args[6].substring(args[6].lastIndexOf("-") + 1));
           this.nmonBegPos = Integer.parseInt(args[7].substring(0, args[7].lastIndexOf("-")));
           this.nmonEndPos = Integer.parseInt(args[7].substring(args[7].lastIndexOf("-") + 1));
           System.out.println("Using dmsdisk files: pisBegPos: " + pisBegPos + "; pisEndPos: " + pisEndPos + "; nmonBegPos: " + nmonBegPos + "; nmonEndPos: " + nmonEndPos);
           if(action.equalsIgnoreCase("r")){
               this.begPeriod = args[8];          
               System.out.println("Roll-up starting with: " + begPeriod);
           }
		}

		if(fileformat.equalsIgnoreCase("rf")){
			if(action.equalsIgnoreCase("r")){
			    this.begPeriod = args[6];  //if using raw falcon files for roll-up, then this will be the start date period to use up to the date folder
			    System.out.println("Roll-up starting with: " + begPeriod);
			}
		}

	}
	
	/**
     * connect to rhldatdms14001 database
     * it works on rhlappfrd60005 server
     */
	public Dataset<Row> connectDB(String recordtype){
		System.out.println("connectDB(): " + LocalDateTime.now());
	    if(action.equalsIgnoreCase("r")){
	    //nmon rollup files < 1901
	    	//query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	    //	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
	    //	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'1901\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)"
	    //	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	       if(fileformat.equalsIgnoreCase("rf")){	
	    	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*" + recordtype + "*.ascii.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	    	    	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
	    	    	+ " and f.portfolio = \'" + portfolio + "\' and f.status = \'D\' and f.date_period between \'" + begPeriod + "' and '" + datePeriod + "\') L, filestorage fs where fs.filestatus = 'O' and fs.filetype = '2' and fs.fileid in (L.fileid)"
	    	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	       }
	       if(fileformat.equalsIgnoreCase("dd")){
	    	   query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*" + recordtype + "*.ascii.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
		    	    	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
		    	    	+ " and f.portfolio = \'" + portfolio + "\' and f.status = \'D\' and f.date_period between \'" + begPeriod + "' and '" + datePeriod + "\') L, filestorage fs where fs.filestatus = 'O' and fs.filetype = 'O' and fs.fileid in (L.fileid)"
		    	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	       }
	    }
	    else{
	    //update query ?
	    	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*" + recordtype + "*.ascii.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	        + " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'"
	    	+ " and f.portfolio = \'" + portfolio + "\' and f.status = \'D\' and f.date_period = \'" + datePeriod + "\') L, filestorage fs where fs.filetype = 'O' and fs.filestatus = 'O' and fs.fileid in (L.fileid)"
	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	    }
	    
	   // return spark.read().jdbc("jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2", query, connectionProperties);
	    return spark.read().format("jdbc")
	  			  .option("url", "jdbc:oracle:thin:@rhldatdms22001:1521/MDWP3.WORLD") //05/25/2022 database migrated to SHK; used to be rhldatdms14001
	  			  .option("user", "mdw")
	    		  .option("password", "mdw")
	    		  .option("dbtable", query)
	    		  .load();
	}
	
	/**
	 * set single date period or multiple date periods
	 * submitted by users
	 */
	public void processDatePeriod(){
		String[] split;
		System.out.println("processDatePeriod(): " + LocalDateTime.now());
		try{	
			processedOutputDir = new Path(hdfsDest + "/" + client + "/" + portfolio);
			fs = FileSystem.get(config);
			if(!fs.exists(processedOutputDir)){
				   fs.mkdirs(processedOutputDir);
			}
		}catch(Exception e){e.printStackTrace();}
		
		if(action.equalsIgnoreCase("u")){
			//multiple date periods submitted by users
        	if(dateFolder.contains("-")){
        		split = dateFolder.split("-");
        		dateFolder = split[0];  //first date period
        		while(Integer.parseInt(dateFolder) <= Integer.parseInt(split[1])){
        	       //have to catch January (01) month because the last month will be December (12)
			       //the lowest date period is 1901
        	       //if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       else{
        		      //date period greater than 1901
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       createPISandNMONList();
        	       dateFolder = String.valueOf((Integer.parseInt(dateFolder) + 1));
        		}
        	}
        	else{ //single date period submitted by users for update
        		//if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
         		   System.out.println("Date Period: " + datePeriod);
         	    }
         	    else{
         		   //date period greater than 1901
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
         		   System.out.println("Date Period: " + datePeriod);
         	    }
        			createPISandNMONList();	        			
        	}
        }
		else{ //roll-up
			System.out.println("Roll-up to Date Folder: " + dateFolder);
			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
      		   System.out.println("Date Period: " + datePeriod);
      	    }
			else{
      		   //date period greater than 1901
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
      		   System.out.println("Date Period: " + datePeriod);
      	    }
			createPISandNMONList(); //need to remember to put it back in after testing nmon records
			//checkNmonRecords();
		}
		//spark.stop();		
	}	
	
	/**
	 * fill out the pis and nmon list from resultset
	 */
	
	public void createPISandNMONList(){

		try{
			System.out.println("inside createPISandNMONList(): " + LocalDateTime.now());
			/**
			 * Using spark jdbc read works on executor side 
			 * so foreach does not work in a cluster; 
			 * foreach works on the master = local
			 * I need to collect the jdbc results back to the driver and 
			 * read the PIS and NMON paths
			 */
			//query pis11 and pis12 files
            resultPaths = connectDB("pis");
            if(fileformat.equalsIgnoreCase("dd")){
            	resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
    				if(row.getString(0).equalsIgnoreCase("pis11")){
    					//System.out.println("pis11 path: " + row.getString(1));
    					pis11List += "file://" + row.getString(1) + ",";
    				}
    				if(row.getString(0).equalsIgnoreCase("pis12")){
    					//System.out.println("pis12 path: " + row.getString(1));
    					pis12List += "file://" + row.getString(1) + ",";
    				}
    			});
            }
            else{
			    resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
				   if(row.getString(0).equalsIgnoreCase("pis11")){
					   //System.out.println("pis11 path: " + row.getString(1));
					   pis11List += row.getString(1) + ",";
				   }
				   if(row.getString(0).equalsIgnoreCase("pis12")){
					  //System.out.println("pis12 path: " + row.getString(1));
					  pis12List += row.getString(1) + ",";
				   }
			   });
            }

			//query nmon11 and nmon20 files
			resultPaths = connectDB("nmon");
			if(fileformat.equalsIgnoreCase("dd")){
				resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
					if(row.getString(0).equalsIgnoreCase("nmon11")){
						//System.out.println("nmon11 path: " + row.getString(1));
						nmon11List += "file://" + row.getString(1) + ",";
					}
					if(row.getString(0).equalsIgnoreCase("nmon20")){
						//System.out.println("nmon12 path: " + row.getString(1));
						nmon20List += "file://" + row.getString(1) + ",";
					}
				});
			}
			else{
			    resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
				   if(row.getString(0).equalsIgnoreCase("nmon11")){
					  //System.out.println("nmon11 path: " + row.getString(1));
					  nmon11List += row.getString(1) + ",";
				   }
				   if(row.getString(0).equalsIgnoreCase("nmon20")){
					  //System.out.println("nmon12 path: " + row.getString(1));
					  nmon20List += row.getString(1) + ",";
				   }
		    	});
			}
			
			//make sure there are paths in pis11List or pis12List
			if(!pis11List.isEmpty()){
				pis11List = pis11List.substring(0, pis11List.lastIndexOf(","));
				System.out.println("pis11List: " + pis11List);
				transformParquet(pis11List, "pis11");
			}
			if(!pis12List.isEmpty()){
				pis12List = pis12List.substring(0, pis12List.lastIndexOf(","));
				System.out.println("pis12List: " + pis12List);
				transformParquet(pis12List, "pis12");
			}
			//make sure there are paths in nmon11List or nmon20List
			if(!nmon11List.isEmpty()){
				nmon11List = nmon11List.substring(0, nmon11List.lastIndexOf(","));
				System.out.println("nmon11List: " + nmon11List);
				transformParquet(nmon11List, "nmon11");
			}
			if(!nmon20List.isEmpty()){
				nmon20List = nmon20List.substring(0, nmon20List.lastIndexOf(","));
				System.out.println("nmon20List: " + nmon20List);
				transformParquet(nmon20List, "nmon20");
			}
	        //now all transformations are done, merge the datasets 
			mergeDataset();
			pis12List = "";
			pis11List = ""; 
			nmon20List = "";
			nmon11List = "";
		}
		catch(Exception e){e.printStackTrace();}
	}	
    
	/**
	 * to check each nmon record to see if the length is greater than 231 bytes
	 */
	public void checkNmonRecords(){
		try{
			System.out.println("inside checkNmonRecords(): " + LocalDateTime.now());
			//query nmon11 and nmon20 files
			resultPaths = connectDB("nmon");
			if(fileformat.equalsIgnoreCase("dd")){
				resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
					if(row.getString(0).equalsIgnoreCase("nmon11")){
						//System.out.println("nmon11 path: " + row.getString(1));
						nmon11List += "file://" + row.getString(1) + ",";
					}
					if(row.getString(0).equalsIgnoreCase("nmon20")){
						//System.out.println("nmon12 path: " + row.getString(1));
						nmon20List += "file://" + row.getString(1) + ",";
					}
				});
			}
			else{
			    resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
				   if(row.getString(0).equalsIgnoreCase("nmon11")){
					  //System.out.println("nmon11 path: " + row.getString(1));
					  nmon11List += row.getString(1) + ",";
				   }
				   if(row.getString(0).equalsIgnoreCase("nmon20")){
					  //System.out.println("nmon12 path: " + row.getString(1));
					  nmon20List += row.getString(1) + ",";
				   }
		    	});
			}
			
			//make sure there are paths in nmon11List or nmon20List
			if(!nmon11List.isEmpty()){
				nmon11List = nmon11List.substring(0, nmon11List.lastIndexOf(","));
				System.out.println("nmon11List: " + nmon11List);
			}
						
			df = spark.read()
				         .format("text")
				         .option("inferSchema", false)
				         .option("header", false)
				         .load(nmon11List.split(",")); //to load different file locations using strings 
			
			System.out.println("total nmon roll-up records: " + df.count());
			
			df.select("value").foreach(row -> {
                if(row.mkString().length() < 231){
                	System.out.println("nmon record length less than 231: " + row.mkString());
                }
                else{
                	System.out.println("nmon record length greater than 231");
                }
			});
			nmon11List = "";
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("PISRollup")
		  			  .config("spark.dynamicAllocation.enabled", "false")
		  			  .config("spark.locality.wait.node", 0)  //added in to change spark locality
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  //.config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		      textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		     // connectionProperties = new Properties();
		     // connectionProperties.put("user", "mdw");
		     // connectionProperties.put("password", "mdw");	     
		      nmbc = spark.sparkContext().broadcast(new NmonBroadcast(), classTag(NmonBroadcast.class));
			  System.out.println("broadcast NmonBroadcast class");
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    public void transformParquet(String inputPaths, String recordtype){
    	try{
    		JavaRDD<Row> rdd = null;
    		System.out.println("inside transformParquet(): " + LocalDateTime.now());
                 /**
                  * Spark disables splitting for compressed files (eg .gz or .bz2) 
                  * and creates RDDs with only 1 partition depending on how many files in the folder
                  * Example: if reading two gzip text files, it will create 2 partitions
                  * Therefore, I have to repartition after reading in text files
                  */
    		      df = spark.read()
  				         .format("text")
  				         .option("inferSchema", false)
  				         .option("header", false)
  				         .load(inputPaths.split(",")); //to load different file locations using strings  
    		      df = df.repartition(200);
    		      
    		if(fileformat.equalsIgnoreCase("dd")){
    			if(recordtype.equalsIgnoreCase("pis12")){
    			   df = df.filter(row -> {
					          return row.mkString().length() >= pisEndPos;}
        			        )
    					   .map(row -> {
    				          return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
    			   }, RowEncoder.apply(textSchema));
    			}
    			if(recordtype.equalsIgnoreCase("pis11")){
    				//find records greater than pan end bytes but less than pis end position
    			/**	Dataset<Row> temp = df.filter(row -> {
    					if(row.mkString().length() > pisPanEndPos && row.mkString().length() < pisEndPos){
    						System.out.println("Length: " + row.mkString().length() + " - Record: " + row.mkString());
    					}
    					return (row.mkString().length() > pisPanEndPos && row.mkString().length() < pisEndPos);
    				}); **/
    				
    				//only keep records that have length greater than pisEndPos
    			  // df.createOrReplaceTempView("temp");
    			  // df = spark.sql("select * from temp where length(value) >= " + pisEndPos + " and value is not null");
     			  
    			    //System.out.println("dataframe partitions before filter: " + df.rdd().getNumPartitions());
    				df = df.filter(row -> {
     					     return row.mkString().length() >= pisEndPos;}
     			          )
     			         .map(row -> {   
     				         return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
     			   }, RowEncoder.apply(textSchema));
     			}
    			if(recordtype.equalsIgnoreCase("nmon20")){
     			   df = df.filter(row -> {
					         return row.mkString().length() >= nmonEndPos;}
        			        )
     					   .map(row -> {
     				         return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			}
    			if(recordtype.equalsIgnoreCase("nmon11")){
    			   //df.createOrReplaceTempView("temp");
     			   //df = spark.sql("select * from temp where length(value) >= " + nmonEndPos + " and value is not null");
     			   df = df.filter(row -> {
				              return row.mkString().length() >= nmonEndPos;}
       			           )
     			          .map(row -> {
     				          return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			}
    		}
    		
    		if(recordtype.equalsIgnoreCase("pis11")){
    			df = df.persist(StorageLevel.MEMORY_ONLY());
    			rdd = mapReducePIS(df.javaRDD());
    			df.unpersist();
    			rdd = rdd.coalesce(100).persist(StorageLevel.MEMORY_ONLY());
                pis11 = createDataSet("pis11", rdd);
                rdd.unpersist();
                pis11 = pis11.persist(StorageLevel.MEMORY_ONLY());
    		}
            if(recordtype.equalsIgnoreCase("pis12")){
            	df = df.persist(StorageLevel.MEMORY_ONLY());
            	rdd = mapReducePIS(df.javaRDD()); 
            	df.unpersist();
            	rdd = rdd.coalesce(100).persist(StorageLevel.MEMORY_ONLY());
                pis12 = createDataSet("pis12", rdd);
                rdd.unpersist();
                pis12 = pis12.persist(StorageLevel.MEMORY_ONLY());
    		}
            if(recordtype.equalsIgnoreCase("nmon11")){
            	df = df.persist(StorageLevel.MEMORY_ONLY());
        		rdd = mapReduceNMON11(df.javaRDD());
        		df.unpersist();
        		rdd = rdd.coalesce(160).persist(StorageLevel.MEMORY_ONLY());
                nmon11 = createDataSet("pis11", rdd);
                rdd.unpersist();
                nmon11 = nmon11.persist(StorageLevel.MEMORY_ONLY());
               // rdd = mapReduceNMON113001(df.javaRDD());
             //   nmon11 = nmon11.union(createDataSet("pis11", rdd));
            }
            if(recordtype.equalsIgnoreCase("nmon20")){
            	df = df.persist(StorageLevel.MEMORY_ONLY());
        		rdd = mapReduceNMON20(df.javaRDD());
        		df.unpersist();
        		rdd = rdd.coalesce(160).persist(StorageLevel.MEMORY_ONLY());
                nmon20 = createDataSet("pis12", rdd);
                rdd.unpersist();
                nmon20 = nmon20.persist(StorageLevel.MEMORY_ONLY());
                
               // rdd = mapReduceNMON203000(df.javaRDD());
              //  nmon20 = nmon20.union(createDataSet("pis12", rdd));
    		}
            
    	}catch(Exception e){e.printStackTrace(); System.exit(-1);}
    }
    
    public void mergeDataset(){
    	Dataset<Row> pastDF = null;
    	//Dataset<Row> nmonNewCodeOnly = null;
    	//Dataset<Row> nmonNewCountryCodeOnly = null;
    	JavaRDD<Row> rdd = null;
    	try{
    		System.out.println("inside mergeDataset(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(pis11 != null){
            	if(nmon11 != null){  //make sure nmon11 has records            		
            	  //merge pis and nmon, pis11 still contains pandatetime field
            	  nmon11.createOrReplaceTempView("nmon");
            	  nmon11 = spark.sql("select * from nmon where nonmonCode in ('3001','3003', '3100', '3101', '3102', '3103', '3104', '3105', '3109','3114', '3115', '3121', '3122', '3123', '3124', '3201')");
            	 // nmonNewCodeOnly = spark.sql("select * from nmon where (nonmonCode = '3109' AND trim(subType) != '') OR (nonmonCode = '3102' AND trim(status) != '')");
            	//  nmonNewCountryCodeOnly = spark.sql("select * from nmon where nonmonCode in ('3100', '3122') AND trim(cardholderCountryCode) != ''");
            	  
            	  //union all three nmon dataset together
            	//  nmon11 = nmon11.union(nmonNewCodeOnly);
            	//  nmon11 = nmon11.union(nmonNewCountryCodeOnly);
            	  
            	  //drop nonmonCode column
            	 // nmon11 = nmon11.drop("nonmonCode");
            	 // System.out.println("dropped nonmonCode column");  
              	  pis11 = pis11.union(nmon11);
                  System.out.println("pis11 unioned nmon11");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			.withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis11 = pis11.union(pastDF);
                	System.out.println("pis11 unioned " + datePeriod);
                }
                
                rdd = mapReducePIS(pis11.javaRDD());    		
                pis11 = createDataSet("pis11", rdd);
                System.out.println("pis11 completed final round of mapReducePIS");
                
                pis11 = pis11.drop("nonmonCode");  //drop nonmonCode column
                
                //remove empty pans
                pis11.createOrReplaceTempView("pis11");
                
                pis11 = spark.sql("select * from pis11 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                
               // pis11.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
               // pis11 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");
               // System.out.println("created max pandatetime with inner join");
        
                //drop the pandatetime before writing it back out as another parquet file
                pis11 = pis11.drop("pandatetime");
                System.out.println("dropped pandatetime field");
                pis11 = pis11.dropDuplicates();
                System.out.println("dropped duplicates");
                
               // if(action.equalsIgnoreCase("r")){
                //   pis11.repartition(1)
                 //       .write()
                 //       .option("compression","gzip")
                   //     .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                   //     .parquet(processedOutputDir + "/PIS11/" + dateFolder);
             //   }
              //  else{//update
                  pis11.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);
              //  }
                System.out.println("Completed " + processedOutputDir + "/current_PIS/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
                pis11.unpersist();
                nmon11.unpersist();
            }
            
            if(pis12 != null){
            	//pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
            	if(nmon20 != null){
            		//merge pis and nmon, pis11 still contains pandatetime field
              	  nmon20.createOrReplaceTempView("nmon");
              	  nmon20 = spark.sql("select * from nmon where nonmonCode in ('3000','3010', '3100', '3102', '3104','3201')");
              	  //nmonNewCodeOnly = spark.sql("select * from nmon where (nonmonCode = '3010' AND trim(subType) != '') OR (nonmonCode = '3102' AND trim(status) != '')");
              	 // nmonNewCountryCodeOnly = spark.sql("select * from nmon where nonmonCode = '3100' AND trim(cardholderCountryCode) != ''");
              	  
              	  //union all three nmon dataset together
              	//  nmon20 = nmon20.union(nmonNewCodeOnly);
              	 // nmon20 = nmon20.union(nmonNewCountryCodeOnly);
              	  
              	  //drop nonmonCode column
              	 // nmon20 = nmon20.drop("nonmonCode");
              	  //System.out.println("dropped nonmonCode column");
            	   //merge pis and nmon
            	   pis12 = pis12.union(nmon20);
            	   System.out.println("pis12 unioned nmon20");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			        .withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis12 = pis12.union(pastDF);
                	System.out.println("pis12 unioned " + datePeriod);
                }
                
                rdd = mapReducePIS(pis12.javaRDD());    		
                pis12 = createDataSet("pis12", rdd);
                System.out.println("pis12 completed final round of mapReducePIS");
                
                pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
                
              //remove empty pans
                pis12.createOrReplaceTempView("pis12");
                
                pis12 = spark.sql("select * from pis12 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                            
                //pis12.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
            	//pis12 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");

                //drop the pandatetime before writing it back out as another parquet file
            	pis12 = pis12.drop("pandatetime");
            	System.out.println("dropped pandatetime field");
                pis12 = pis12.dropDuplicates();
                System.out.println("dropped duplicates");
            	
            	//if(action.equalsIgnoreCase("r")){
            	//   pis12.repartition(1)
                 //       .write()
                 //       .option("compression","gzip")
                //       .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                 //       .parquet(processedOutputDir + "/PIS12/1901");
            	//}
            	//else{//update
            		pis12.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);
            //	}
            	System.out.println("Completed " + processedOutputDir + "/current_PIS/" + dateFolder + " Parquet File: " + LocalDateTime.now());   
            	pis12.unpersist();
            	nmon20.unpersist();
            } 	
            nmbc.destroy();
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
	public Dataset<Row> createDataSet(String rt, JavaRDD<Row> rdd){
		Dataset<Row> ds = null;
    	List<RollingObj> fieldnames = null;
    	List<StructField> fields = null;
		try{
			System.out.println("inside createDataset(): " + LocalDateTime.now());
			 rtm = new RecordTypeMapperCSV(rt);
		     fieldnames = rtm.getFieldInfo();
	         
	        //Store the StruckField object into a List
		    fields = new ArrayList<>();
		      
		    //create the StructFields for the Schema
		    for(int x = 0; x < fieldnames.size(); x++){
		    	  
		    	  fields.add(DataTypes.createStructField(fieldnames.get(x).fieldName, DataTypes.StringType, true));
		      }
		    
		    //create the schema
	  		schema = DataTypes.createStructType(fields);
	  		
   		  //to create an empty dataset<row> use spark.createDataFrame(new ArrayList<>(), schema)
	  		//ds = spark.createDataFrame(newRows, schema);
	  		ds = spark.createDataFrame(rdd, schema);
			//newRows.clear();
		}catch(Exception e){e.printStackTrace();}
	 	return ds;		
	}
	
	public JavaRDD<Row> mapReducePIS(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;

		System.out.println("inside mapReducePIS(): " + LocalDateTime.now());
		javaPairRdd = rdd.filter(row -> {
                           return !row.mkString().substring(16,24).trim().isEmpty();  //only take recordtype column with a value
                       })
		           .mapToPair(row -> {
                  //sortkey = pan
			       return new Tuple2<String, String>(row.mkString().substring(160, 179), row.mkString());
	            }).reduceByKey((v1, v2) -> {
	    			
	    			String record = "";
	    			String value1 = "";
	    			String value2 = "";
	    			//don't need the pandatefield in RecordTypeMapper class anymore 
	    			//because use it here to reduceByKey when PIS records
	    			
	    			value1 = v1.substring(160, 179) + v1.substring(45, 62);
	    			value2 = v2.substring(160, 179) + v2.substring(45, 62);
	    			//if value1.compareTo(value2) > 0 (returns positive value) then value1 > value2
	                //if value1 == value2 then returns 0
	                //if value1.compareTo(value2) < 0 (returns negative value) then value1 < value2
	    			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
	    				//record = v1;  //return whole string
	    				record = nmbc.value().rollupPIS12(v1, v2);
	    			}
	                if(value1.compareTo(value2) < 0){
	    				//record = v2;
	                	record = nmbc.value().rollupPIS12(v2, v1);
	    			}
	    			return record; 
	    		});
	    
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
	    	   // System.out.println("foreach: rt: " + f.substring(16,24).trim());
			//f._2 = scala.Tuple2._2 or the value from Tuple2<K,V>
			//f._1 = scala.Tuple2._1 = the key from Tuple2<K,V>
			//found out that some records have recordtype blank so the List<RollingObj> has size 0 and throws java.lang.NullPointerException: Null value appeared in non-nullable field:
 			rt = new RecordTypeMapperCSV(f._2.substring(16,24).trim());  //gets the recordtype value
 			rt.setPISFieldValue(f._2);	
			return rt.getRow();  //throws java.lang.NullPointerException when List<RollingObj> has size 0 when returning rows
		});
		return newJavaRDD;
	}
	
	public JavaRDD<Row> mapReduceNMON11(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON11(): " + LocalDateTime.now());
		javaPairRdd = rdd
				//.filter(row -> {
			      //  return row.mkString().length() > 1705;})  //don't need filter here as already did filter in transformParquet()
		    .mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		   **/
			return new Tuple2<String, String>(row.mkString().substring(212, 231) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			
  			if(v1.substring(174, 178).equalsIgnoreCase("3100")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3122")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3102")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3109")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3003")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1406, 1414);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1406, 1414);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3101")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1310, 1318);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1310, 1318);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3103")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3105")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1310, 1318);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1310, 1318);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3115")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3121")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1161, 1171);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1161, 1171);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3123")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3124")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3201")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1377, 1390);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1377, 1390);
  			}
  			else{
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000";
  			}

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				//record = v1;  //return whole string
  				record = nmbc.value().rollupNmon11(v1, v2, v1.substring(174, 178));
  			}
              if(value1.compareTo(value2) < 0){
  				//record = v2;
            	  record = nmbc.value().rollupNmon11(v2, v1, v1.substring(174, 178));
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis11");
			 rt.setNMON11FieldValue(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
		
		return newJavaRDD;
	}
	
	//Create PIS11 from NMON11 3001
	public JavaRDD<Row> mapReduceNMON113001(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON113001(): map newPan only with nmonCode 3001: " + LocalDateTime.now());
		javaPairRdd = rdd.filter(row -> {
			return row.mkString().substring(174, 178).equalsIgnoreCase("3001");
		}).mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		    * took the trim() out because there were pans with blank recordCreationDate and recordCreationTime 
		    * so need to compare exactly same pans
		   **/
			return new Tuple2<String, String>(row.mkString().substring(321, 340) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
            value1 = v1.substring(321, 340) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  		    value2 = v2.substring(321, 340) + v2.substring(160, 168) + v2.substring(168, 174) + "000";

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				record = v1;  //return whole string
  			}
              if(value1.compareTo(value2) < 0){
  				record = v2;
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis11");
			 rt.setNMON11FieldValue3001(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
		
		return newJavaRDD;
	}
	
	public JavaRDD<Row> mapReduceNMON20(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON20(): map pan only: " + LocalDateTime.now());
		javaPairRdd = rdd
				   // .filter(row -> {
			         // return row.mkString().length() > 2133;}) //no need for filter since already filter in transformParquet()
		    .mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		    * took the trim() out because there were pans with blank recordCreationDate and recordCreationTime 
		    * so need to compare exactly same pans
		   **/
			return new Tuple2<String, String>(row.mkString().substring(241, 260) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			if(v1.substring(174, 178).equalsIgnoreCase("3100")){ //add in newCountryCode to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1207, 1210);
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1207, 1210);
  			}
  			else if(v1.substring(174,178).equalsIgnoreCase("3010")){  //add in newCode1 to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1501, 1504);
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1501, 1504);
  			}
  			else if(v1.substring(174,178).equalsIgnoreCase("3102")){  //add in newCode1 to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1501, 1504) ;
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1501, 1504) ;
  			}
  			else{
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000";
  			}

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				//record = v1;  //return whole string
  				record = nmbc.value().rollupNmon20(v1, v2, v1.substring(174, 178));
  			}
              if(value1.compareTo(value2) < 0){
  				//record = v2;
            	record = nmbc.value().rollupNmon20(v2, v1, v1.substring(174, 178));
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis12");
			 rt.setNMON20FieldValue(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
        
		return newJavaRDD;
	}
	
	public JavaRDD<Row> mapReduceNMON203000(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON203000(): map newPan only with nmonCode 3000: " + LocalDateTime.now());
		javaPairRdd = rdd.filter(row -> {
			return row.mkString().substring(174, 178).equalsIgnoreCase("3000");
		}).mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		    * took the trim() out because there were pans with blank recordCreationDate and recordCreationTime 
		    * so need to compare exactly same pans
		   **/
			return new Tuple2<String, String>(row.mkString().substring(350, 369) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
            value1 = v1.substring(350, 369) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  		    value2 = v2.substring(350, 369) + v2.substring(160, 168) + v2.substring(168, 174) + "000";

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				record = v1;  //return whole string
  			}
              if(value1.compareTo(value2) < 0){
  				record = v2;
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis12");
			 rt.setNMON20FieldValue3000(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
		
		return newJavaRDD;
	}
	
	/**
     * input any class to broadcast in spark
     * returns the class T of ClassTag
     * @param clazz
     * @return 
     */
	 public static <T> ClassTag<T> classTag(Class<T> clazz) {
 	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
	 }
}
