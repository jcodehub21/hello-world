import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.LocalDateTime;


public class FDRParquet implements Serializable{
	SparkSession spark = null;
	List<StructField> fields = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	StructType sfxSchema = null;
	Dataset<Row> sfx = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static FileStatus[] list_files = null; 
	String pattern = "^part-.+\\.gz.parquet$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	String dfPath = "";
	static Path newDFPath = null;
	String hdfsMapString = "";
	
	private static final long serialVersionUID = 1L;

	public static void main(String[] args){
		String content = "";
		/**
		 * args[0] = hdfs mapper file location
		 * args[1] = file to read from
		 * args[2] = parquet path to write out
		 */
		try{
			   FDRParquet driver = new FDRParquet(args[0], args[2]);
			   driver.startSparkSession();
			   BufferedReader br = new BufferedReader(new FileReader(args[1]));
			   while((content = br.readLine()) != null){			  
				   driver.loadSFXFile(content);
			   }
			   if(br != null){br.close();}          
	          // driver.closeAll();  //this caused spark error of not being able to flush 
			}catch(Exception e){e.printStackTrace();}
		
	}
	
	public FDRParquet(String hdfsMap, String df){
		dfPath = df;
		hdfsMapString = hdfsMap;
	}
	
	public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("FDR SFX Pan Mapper")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
	    //store FieldObj into RecordTypeMapper so can separate the value
	    //in the text file into table columns
		fieldObj = new RecordTypeMapper<FieldObj>();
		fieldObj.addFieldObj(new FieldObj("filler1", 0, 12));
		fieldObj.addFieldObj(new FieldObj("pan", 12, 31));
		fieldObj.addFieldObj(new FieldObj("filler2", 31, 73));
		
		//create the schema for the SFX file
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
		}
		
		sfxSchema = DataTypes.createStructType(fields);
		
		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		   //  newDFPath = new Path("/hdfsTA/work/fdrMapping/2021/mapped"); //rhldmsprd001
		     newDFPath = new Path(dfPath);  //BP TA cluster
		}catch(Exception e){e.printStackTrace();}
 
	}
	
	public void loadSFXFile(String sfxFilePath){
		   //String updatedPath = sfxFilePath.substring(0, sfxFilePath.lastIndexOf("/") + 1);
		   
		   try{
		     sfx = spark.read()
				        .format("text")
				        .option("inferSchema", false)
				        .option("header", "false")
				        .load(sfxFilePath);  //on rhldmsprd001;  remember to use file:// if on BP cluster
		   
		     System.out.println("Load " + sfxFilePath + " complete");
		   /**
		    * Encoder.String() returns Dataset<String>
		    * RowEncoder.apply(StructType schema) returns Dataset<Row>
		    * MapFunction<Input, Output>
		    */
		     sfx = sfx.map((MapFunction<Row, Row>) row -> {
			      fieldObj.setFieldValue(row.mkString());
			      return fieldObj.getRow();
		      }, RowEncoder.apply(sfxSchema)); //applies the schema to the row so dataset will know it is for row
		     
		   //delete if /hdfsTA/work/fdrMapping/2021/mapped exists
			   if(fs.exists(newDFPath))
		    	{
		    		fs.delete(newDFPath, true);
		    	}
			   
		     sfx.coalesce(1)
		        .write()
		        .option("compression", "gzip")
		        .mode("overwrite")
		        .parquet(newDFPath.toString());
		     
		     System.out.println("finished writing text file " + LocalDateTime.now());
			  // Create a Pattern object
	  		  filePattern = Pattern.compile(pattern);
	  		    
	  		  list_files = fs.listStatus(newDFPath);
             for(FileStatus filePath : list_files){
		    	
   	           m = filePattern.matcher(filePath.getPath().getName());
   	           if(m.matches()){
   	        	   //fs.rename also moved the new filename to another path
   	        	   fs.rename(filePath.getPath(), new Path(hdfsMapString + "/" + sfxFilePath.substring(sfxFilePath.lastIndexOf("/") + 1, sfxFilePath.lastIndexOf("ascii")) + "gz.parquet"));
   	        	   System.out.println("rename " + sfxFilePath.substring(sfxFilePath.lastIndexOf("/") + 1, sfxFilePath.lastIndexOf("ascii")) + ".gz.parquet at " + hdfsMapString + " complete");
   	           }
   	        }
		         
		   }catch(Exception e){e.printStackTrace();}
	}
}
