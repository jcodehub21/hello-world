import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

//import io.delta.tables.DeltaTable;

/**
 * 07/13/2021 This class will replace old pans with new pans
 * using Spencer's mapping file for FDR B, C, E and N SFX Fraud files (sm_fraud_sorted)
 * Pan bytes are 13-31
 * 
 * To get rid of Parquet files metadata summary in sparksession config:
 * https://www.javadoc.io/doc/org.apache.parquet/parquet-hadoop/1.9.0/constant-values.html
 * @author JaneCheng
 *
 */
public class FDRPanDriverWindows implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> mapper = null; 
	Dataset<Row> sfx = null;
	Dataset<Row> newsfx = null;
	StructField sf = null;
	String yymm = ""; //date period to fix
	String client = "";
	String portfolio = "";
	ResultSet rs = null;
	Connection conn = null;
	PreparedStatement ps = null;
	String hdfsMapperFile = "";
	String sfxFilePath = "";
	List<StructField> fields = null; //store the mapper file two columns
	StructType mapperSchema = null;
	StructType sfxSchema = null;
	StructType textSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	//static Path mapperPath = null;  //path to deltatable for mapper
	//static Path sfxPath = null; //path to deltatable for sfx
	FileStatus[] list_files = null; 
	String pattern = "^part-.+\\.gz$"; 
	Pattern filePattern = null; 
	Matcher m = null; //match the pattern of part-m-#### files only
	
	public static void main(String[] args) {
		/**
		 * args[0] = hdfs mapper file location
		 * args[1] = client uppercase
		 * args[2] = portfolio uppercase
		 * args[3] = yymm
		 */
		String CDrive = "C:\\software\\eclipse_luna_4.4_projects\\FDRMapPan";
		String client = "FDR-C";
		String portfolio = "CREDIT";
		String datePeriod = "2105";
		FDRPanDriverWindows driver = new FDRPanDriverWindows(new String[]{CDrive, client, portfolio, datePeriod});
		//driver.queryDBForSFX();
		driver.startSparkSession();
		driver.loadMapperFile();
		driver.loadSFXFile("C:\\software\\eclipse_luna_4.4_projects\\FDRMapPan\\1905-2105.fdr-c.cdt.sm_fraud_sorted.9694142.87.test.ascii.gz");

	}
	
	public FDRPanDriverWindows(String[] args){
		hdfsMapperFile = args[0];
		client = args[1];
		portfolio = args[2];
		yymm = args[3];
	}
	
	public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("FDR SFX Pan Mapper")
				.master("local")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				//.config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
				//.config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
		//mapper fields and schema is fixed so only need to define once
		// Store the StruckField object into a List
		fields = new ArrayList<>();			
		fields.add(DataTypes.createStructField("oldPan", DataTypes.StringType, true));
	    fields.add(DataTypes.createStructField("newPan", DataTypes.StringType, true));
					
		//create the schema
	    mapperSchema = DataTypes.createStructType(fields);
	    
	    //store FieldObj into RecordTypeMapper so can separate the value
	    //in the text file into table columns
		fieldObj = new RecordTypeMapper<FieldObj>();
		fieldObj.addFieldObj(new FieldObj("filler1", 0, 12));
		fieldObj.addFieldObj(new FieldObj("pan", 12, 31));
		fieldObj.addFieldObj(new FieldObj("filler2", 31, 73));
		
		//create the schema for the SFX file
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
		}
		//fields.add(DataTypes.createStructField("Filler1", DataTypes.StringType, true));
	   // fields.add(DataTypes.createStructField("oldPan", DataTypes.StringType, true));
	   // fields.add(DataTypes.createStructField("Filler2", DataTypes.StringType, true));
		
		sfxSchema = DataTypes.createStructType(fields);
		
		  
		  //Text data source supports only a single column, and you have 3 columns.
		  textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		    // mapperPath = new Path("C:\\software\\eclipse_luna_4.4_projects\\FDRMapPan\\spark-warehouse\\mapper");
		    // sfxPath = new Path("C:\\software\\eclipse_luna_4.4_projects\\FDRMapPan\\spark-warehouse\\sfx");
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * connect to DMS database and query
	 * FDR B, C, E and N SFX sm_fraud_sorted files
	 * for specific date period
	 * return in resultset
	 */
	public void queryDBForSFX(){
		String query = "";
		
		try{
			System.out.println("queryDBForSFX()");
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2", "mdw", "mdw");
	        ps = conn.prepareStatement(query);
	        rs = ps.executeQuery();
	       
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}	
	}
	  
	  //loadMapperFile only loads the mapper file with different locations
	   public void loadMapperFile(){
			/**
			 * Need to use csv format in order for spark to read 
			 * the ! delimiter; 
			 * Using text format only gives one column called value 
			 * and will throw an error if used with delimiter and schema
			 */
			
			mapper = spark.read()
					      .format("csv")  
					      .schema(mapperSchema)
    				      .option("delimiter", "!")  //using ! delimiter to separate the data so don't need to create FieldObj
    				      .option("header", "false")
    				      .load(hdfsMapperFile + "\\*.bz2");
			//mapper.show();
			
		}
	   
	   public void loadSFXFile(String sfxFilePath){
		   
		   String updatedPath = sfxFilePath.substring(0, sfxFilePath.lastIndexOf("\\") + 1);
		   System.out.println(updatedPath);
		   try{
		   sfx = spark.read()
				      .format("text")
				      .option("inferSchema", false)
				      .option("header", "false")
				      .load(sfxFilePath);
		   
		   /**
		    * Encoder.String() returns Dataset<String>
		    * RowEncoder.apply(StructType schema) returns Dataset<Row>
		    * MapFunction<Input, Output>
		    */
		   sfx = sfx.map((MapFunction<Row, Row>) row -> {
			   fieldObj.setFieldValue(row.mkString());
			   //System.out.println(fieldObj.getRow());
			   return fieldObj.getRow();
		   }, RowEncoder.apply(sfxSchema)); //applies the schema to the row so dataset will know it is for row
		   
		  // sfx.show(10, false);
		   
		  // mapper.createOrReplaceTempView("mapper");
		 //  sfx.createOrReplaceTempView("sfx");
		   /**
		    * I'm using scala-2.11 so I need delta-core_2.11
		    * https://search.maven.org/artifact/io.delta/delta-core_2.11/0.6.1/jar
		    * remove the DeltaTable storage location because it accumulates every time it creates managed tables
		    * cannot use deltatable because running it on rhldmsprd001 created many small parquet files
		    * for just the mapper and taking too long
		    */

	    /**	if(fs.exists(mapperPath))
	    	{
	    		fs.delete(mapperPath, true);
	    	}

	    	if(fs.exists(sfxPath))
	    	{
	    		fs.delete(sfxPath, true);
	    	}	    	
           
			 mapper.write().format("delta").mode("overwrite").save(mapperPath.toString());
			  sfx.write().format("delta").mode("overwrite").save(sfxPath.toString());
		
			  DeltaTable deltaTable = DeltaTable.forPath(spark, sfxPath.toString());
			  
			  deltaTable.as("s")
			            .merge(mapper.as("m"), "s.oldPan = m.oldPan")
			            .whenMatched()
                        .updateExpr(new HashMap<String, String>(){
							private static final long serialVersionUID = 1L;

						   {
                        	   put("oldPan", "m.newPan");
                           }
						}).execute();
			 
			  Dataset<Row> text = deltaTable.toDF().map(row -> {
				  return RowFactory.create(row.mkString());				  
			  }, RowEncoder.apply(textSchema));
			  **/
			 // text.show(20, false);
			//df.coalesce(1).write.option("compression","gzip").format("text").save("/path/to/save")
		   
		   /**use dataframe left join to get all rows from sfx and also include only rows from mapper that 
		    * sfx pan == mapper pan
		    * and then replace the null values under newPan column with sfx pan column using
		    * functions.when() <- make sure that you import org.apache.spark.sql.functions 
		    * If you use just when() then java will not recognize the function, must use 
		    * functions.when(); there is also functions.otherwise() condition
		    */
		   
		   newsfx = sfx.join(mapper, sfx.col("pan").equalTo(mapper.col("oldPan")), "left");
		   //newsfx.show(20, false);
		   newsfx = newsfx.select(newsfx.col("filler1"),
				   newsfx.col("pan"),
				   newsfx.col("filler2"),
				   newsfx.col("newPan"),
				       functions.when(newsfx.col("newPan").isNull(),newsfx.col("pan"))  //replace newPan with pan if newpan is null
				       .otherwise(newsfx.col("newPan")).alias("newPanNoNull"));  //otherwise keep newPan value as is and be under new column called newPanNoNUll
		 
		   /**drop the original pan and newPan columns and then renamed the newPanNoNull to pan
		    * this produces the dataframe column order of filler1, filler2, pan which is the wrong order
		   **/
		   newsfx = newsfx.drop("pan").drop("newPan").withColumnRenamed("newPanNoNull", "pan");
		   
		   //have to reselect the columns to be in the correct order:  filler1, pan, filler2 so can be written out to text file
		   newsfx = newsfx.select(newsfx.col("filler1"), newsfx.col("pan"), newsfx.col("filler2"));
		   newsfx.show(20, false);
		   
		   //convert back from three columns to one column so can write in text file
		   newsfx = newsfx.map(row -> {
				  return RowFactory.create(row.mkString());				  
			  }, RowEncoder.apply(textSchema));
		   
		   newsfx.coalesce(1)
			            .write()
			            .format("text")
			            .option("compression", "gzip")
			            .mode("overwrite")
			            .save(updatedPath + "updated");
			  
				// Create a Pattern object
	  		    filePattern = Pattern.compile(pattern);
	  		    
	  		  list_files = fs.listStatus(new Path(updatedPath + "updated"));
              for(FileStatus filePath : list_files){
  		    	
      	           m = filePattern.matcher(filePath.getPath().getName());
      	           if(m.matches()){
      	        	   //fs.rename also moved the new filename to another path
      	        	   fs.rename(filePath.getPath(), new Path(updatedPath + sfxFilePath.substring(sfxFilePath.lastIndexOf("\\") + 1, sfxFilePath.lastIndexOf("ascii")) + "mapped.ascii.gz"));
      	           }
      	        }

			                           		  
		 /** sfx = spark.sql("MERGE INTO sfx AS s USING (SELECT * FROM mapper) AS m ON (s.oldPan = m.oldPan) WHEN MATCHED"
		      	+ " THEN UPDATE SET s.oldPan = m.newPan");**/
		   }catch(Exception e){e.printStackTrace();}
	   
	   }
		
		public void closeAll(){
			try{
				if(conn != null){
					conn.close();
					rs.close();
				}
			}catch(Exception e){e.printStackTrace();}
		}

}
