import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;


public class AnalyzeEmptyPan implements Serializable{
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
	static BufferedReader br = null;
	StringBuffer sb = new StringBuffer();
	String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
	String endTable = "</table>";
	
	public static void main(String[] args){
		AnalyzeEmptyPan driver = new AnalyzeEmptyPan();
		driver.createSparkSession();
		driver.checkRollingPISCount(args[0]);
	}
	
	public AnalyzeEmptyPan(){}
	
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("AnalyzeEmptyPan")
		  			  .config("spark.dynamicAllocation.enabled", "false")
		  			  //.config("spark.locality.wait", "0s")
		  			  .config("spark.locality.wait.node", 0)
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  //.config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		      fs = FileSystem.get(config);

		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    public void checkEmptyPan(String fileList){
    	try{
    		Dataset<Row> df = null;
    		Dataset<Row> newDF = null;
    		long count = 0;
    		String content = "";
			 String[] data = null;
		     br = new BufferedReader(new FileReader(fileList));
		     while((content = br.readLine()) != null){
		    	 data = content.split(",");
		    	 //data[0] = client name
		    	 //data[1] = portfolio
		    	 System.out.println("Checking client " + data[0]);
		    	 listDirs = fs.listStatus(new Path("/data/hive_falcon/" + data[0] + "/" + data[1] + "/current_PIS"));
		    	 for(FileStatus filepath : listDirs){
		    		 df = spark.read().parquet(filepath.getPath().toString());
		    		 df.persist(StorageLevel.MEMORY_ONLY());
		    		 df.createOrReplaceTempView("temp");
		    		 count = spark.sql("select pan from temp where trim(pan) == ''").count();
		    		 if( count > 0 ){
		    			 System.out.println("Found empty pan at: " + filepath.getPath() + " : " + count);
		    			 newDF = spark.sql("select * from temp where trim(pan) != ''");
		    			 newDF.persist(StorageLevel.MEMORY_ONLY());
		    			 newDF.repartition(1)
		    			 .write()
		    			 .option("compression","gzip")
 			             .mode("append")
 			             .parquet(filepath.getPath().toString());
		    			 System.out.println("wrote new parquet file at " + filepath.getPath().toString());
		    			 newDF.unpersist();
		    		 }
		    		 
		    		 df.unpersist();
		    	 }
		     }
		     br.close();
    		
    	}catch(Exception e){e.printStackTrace();}
    }
    
    public void checkRollingPISCount(String fileList){
    	try{
    		Dataset<Row> df = null;
    		Dataset<Row> newDF = null;
    		String content = "";
    		long count = 0;
    		long uniqueCount = 0;
			 String[] data = null;
		     br = new BufferedReader(new FileReader(fileList));
				sb.append("Rolling PIS Check Pan Counts " + LocalDate.now() + ": <br>");			
	    		sb.append(beginTable);
		        sb.append("<tr><td><b>File Path</b></td><td><b>Count</b></td><td><b>Distinct Count</b></td></tr>");
		     while((content = br.readLine()) != null){
		    	 data = content.split(",");
		    	 //data[0] = client name
		    	 //data[1] = portfolio
		    	 System.out.println("Checking client: " + data[0] + " (" + data[1] + ")");
		    	 listDirs = fs.listStatus(new Path("/data/hive_falcon/" + data[0] + "/" + data[1] + "/current_PIS"));
		    	 for(FileStatus filepath : listDirs){
		    		 System.out.println("Checking folder: " + filepath.getPath().getName());
		    		 df = spark.read().parquet(filepath.getPath().toString());
		    		// df.persist(StorageLevel.MEMORY_ONLY());
		    		 df.createOrReplaceTempView("temp");
		    		 newDF = spark.sql("select count(pan) as pancount, count(distinct pan) as uniquecount from temp");
                     count = newDF.select("pancount").first().getLong(0);
                     uniqueCount = newDF.select("uniquecount").first().getLong(0);
                     if(count > uniqueCount){
                    	sb.append("<tr><td>").append(filepath.getPath()).append("</td><td>").append(count).append("</td><td>").append(uniqueCount).append("</td></tr>");
                     }
		    		// df.unpersist();
		    	 }
		     }
		     sb.append(endTable);
		     br.close();
		     sendEmail();
    	}catch(Exception e){e.printStackTrace();}
    }
    
    public void sendEmail(){

	    String to = "janecheng@fico.com";
	    String from = "janecheng@fico.com";
	    
	    try
	    {	    
	       //sb.append("<br> Thank you, <br> Jane Cheng");
	       String host = "mail.fairisaac.com";
	    
	       //create properties to store host and get or set the default mail session object
	       Properties props = new Properties();
	       props.put("mail.smtp.host", host);
	       Session session = Session.getInstance(props);
	    
	       //create the message object
	       MimeMessage msg = new MimeMessage(session);

	       //set the sender's email address
	       msg.setFrom(new InternetAddress(from));

	       //set the recipient's email address
	       msg.setRecipients(Message.RecipientType.TO, to);
	       
	       //set the subject heading
	       msg.setSubject("Rolling PIS Pan Count Report");

	       //set the date of sending the email; new date() initializes the to current date
	       msg.setSentDate(new Date());

	       //set the message body; setText method only uses text/plain
	       // msg.setText(msgBody);
	       Multipart mp = new MimeMultipart();
	          
	       //set the html body part
	       MimeBodyPart htmlbody = new MimeBodyPart();
	       htmlbody.setContent(sb.toString(), "text/html");
	       mp.addBodyPart(htmlbody);
	          
	       //need to use setContent method if using text/html
	       //msg.setContent(sb.toString(), "text/html");
	       msg.setContent(mp);

	       //send the email
	       Transport.send(msg);
	          
	     }
	       catch(Exception mex){

	          System.out.println("Error in sending: ");
	          mex.printStackTrace();
	          System.exit(1);
	       }
	    }	
}
