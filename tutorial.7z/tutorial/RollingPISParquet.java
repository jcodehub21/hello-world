import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.Tuple2;
import scala.reflect.ClassTag;


/**
 * 11/13/2022 - this class roll up pis and nmon files using all parquet files at /data/parquet_falcon
 * @author JaneCheng
 *
 */
public class RollingPISParquet implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	//static final List<Row> newRows = new ArrayList<>();
	RecordTypeMapperCSV rtm = null;
	StructType schema = null;
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
	String hdfsDest = "";
	String query = "";
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
    // static final BufferedWriter bw;  //write out nmon comparisons
	// static final OutputStream os;
    // static final Path nmonRecords;
	String pis12List = "";
	String pis11List = ""; 
	String nmon20List = "";
	String nmon11List = "";
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> pis12 = null;
	Dataset<Row> nmon11 = null;
	Dataset<Row> nmon20 = null;
	Dataset<Row> resultPaths = null;
	Broadcast<NmonBroadcast> nmbc = null;
	//static Properties connectionProperties = null;  //properties for jdbc connection
	
	public static void main(String[] args){
		/**
    	 * args[0] = client ex: ts2_8167-f6
    	 * args[1] = portfolio  ex: debit
    	 * args[2] = date period  ex: 1901
    	 * args[3] = action (r = rollup, u = update)
    	 * args[4] = main hdfs destination to store parquet files
    	 * args[5] = boolean true means use parquet files; false means use raw falcon data; added 11/2/2022 
    	 */
		if(args.length == 5){
			RollingPISParquet test = new RollingPISParquet(args);
			//since I started the spark session first the Path object needs to be serialized
            test.createSparkSession();
		   //query for single or multiple months or roll up
		   test.processDatePeriod();

		}
		else{
			System.out.println("Usage: RollingPIS tool to roll up nmon pans to pis files from 1901 to present. \n"
					+ "Parameters separated by a space: client portfolio date_period action main_hdfs_destination\n"
					+ "Action: r for rollup and u for update \n" 
					+ "Example: ts2_8167-f6 debit 1901 r /data/rollingPIS_test");
			
		}
		
	}
    public RollingPISParquet(){}
    
	public RollingPISParquet(String[] args){
    	   	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		this.hdfsDest = args[4];		
	}
	
	/**
     * connect to rhldatdms14001 database
     * it works on rhlappfrd60005 server
     */
	public Dataset<Row> connectDB(String recordtype){
		System.out.println("connectDB(): " + LocalDateTime.now());
	    if(action.equalsIgnoreCase("r")){
	    //nmon rollup files < 1901
	    	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.parquet\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	    	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
	    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'" + dateFolder + "\') L, filestorage fs where fs.filetype = 'P' and fs.fileid in (L.fileid)"
	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	    }
	    else{
	    //update query ?
	    	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.parquet\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	        + " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'"
	    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period = \'" + datePeriod + "\') L, filestorage fs where fs.filetype = 'P' and fs.fileid in (L.fileid)"
	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	    }
	    
	   // return spark.read().jdbc("jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2", query, connectionProperties);
	    return spark.read().format("jdbc")
	  			  .option("url", "jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD")
	  			  .option("user", "mdw")
	    		  .option("password", "mdw")
	    		  .option("dbtable", query)
	    		  .load();
	}
	
	/**
	 * set single date period or multiple date periods
	 * submitted by users
	 */
	public void processDatePeriod(){
		String[] split;
		System.out.println("Inside processDatePeriod(): " + LocalDateTime.now());
		try{	
			processedOutputDir = new Path(hdfsDest + "/" + client + "/" + portfolio);
			fs = FileSystem.get(config);
			if(!fs.exists(processedOutputDir)){
				   fs.mkdirs(processedOutputDir);
			}
		}catch(Exception e){e.printStackTrace();}
		
		if(action.equalsIgnoreCase("u")){
			//multiple date periods submitted by users
        	if(dateFolder.contains("-")){
        		split = dateFolder.split("-");
        		dateFolder = split[0];  //first date period
        		while(Integer.parseInt(dateFolder) <= Integer.parseInt(split[1])){
        	       //have to catch January (01) month because the last month will be December (12)
			       //the lowest date period is 1901
        	       if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       else{
        		      //date period greater than 1901
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       loadParquetMonth();
        	       dateFolder = String.valueOf((Integer.parseInt(dateFolder) + 1));
        		}
        	}
        	else{ //single date period submitted by users for update
        		if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
         		   System.out.println("Date Period: " + datePeriod);
         	    }
         	    else{
         		   //date period greater than 1901
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
         		   System.out.println("Date Period: " + datePeriod);
         	    }
        			loadParquetMonth();      			
        	}
        }
		else{ //roll-up
			System.out.println("Roll-up to Date Folder: " + dateFolder);
			loadParquetMonth();
		}
		//spark.stop();		
	}	
	
	/**
	 * load parquet files at /data/parquet_falcon for the update month
	 * instead of using raw falcon files at /data/raw_falcon
	 */
	public void loadParquetMonth(){
		try{
			System.out.println("inside loadParquetMonth(): " + LocalDateTime.now());
			String nmon = "";
			String pis = "";
			
			if(action.equalsIgnoreCase("r")){
				//query pis11 and pis12 files
	            resultPaths = connectDB("pis");
				resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
					if(row.getString(0).equalsIgnoreCase("pis11")){
						//System.out.println("pis11 path: " + row.getString(1));
						pis11List += row.getString(1) + ",";
					}
					if(row.getString(0).equalsIgnoreCase("pis12")){
						//System.out.println("pis12 path: " + row.getString(1));
						pis12List += row.getString(1) + ",";
					}
				});

				//query nmon11 and nmon20 files
				resultPaths = connectDB("nmon");
				resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
					if(row.getString(0).equalsIgnoreCase("nmon11")){
						//System.out.println("nmon11 path: " + row.getString(1));
						nmon11List += row.getString(1) + ",";
					}
					if(row.getString(0).equalsIgnoreCase("nmon20")){
						//System.out.println("nmon12 path: " + row.getString(1));
						nmon20List += row.getString(1) + ",";
					}
				});
				
				//make sure there are paths in pis11List or pis12List
				if(!pis11List.isEmpty()){
					pis11List = pis11List.substring(0, pis11List.lastIndexOf(","));
					System.out.println("pis11List: " + pis11List);
					transformParquet(pis11List, "pis11");
				}
				if(!pis12List.isEmpty()){
					pis12List = pis12List.substring(0, pis12List.lastIndexOf(","));
					System.out.println("pis12List: " + pis12List);
					transformParquet(pis12List, "pis12");
				}
				//make sure there are paths in nmon11List or nmon20List
				if(!nmon11List.isEmpty()){
					nmon11List = nmon11List.substring(0, nmon11List.lastIndexOf(","));
					System.out.println("nmon11List: " + nmon11List);
					transformParquet(nmon11List, "nmon11");
				}
				if(!nmon20List.isEmpty()){
					nmon20List = nmon20List.substring(0, nmon20List.lastIndexOf(","));
					System.out.println("nmon20List: " + nmon20List);
					transformParquet(nmon20List, "nmon20");
				}
				//now all transformations are done, merge the datasets 
				mergeDataset();
				pis12List = "";
				pis11List = ""; 
				nmon20List = "";
				nmon11List = "";
			}
			else{ //update
			listDirs = fs.listStatus(new Path("/data/parquet_falcon/" + client + "/" + portfolio + "/"));
			for(FileStatus dir : listDirs){
				if(dir.isDirectory()){
					if(dir.getPath().getName().equalsIgnoreCase("nmon20")){
						nmon = "nmon20";
						System.out.println("inside loadParquetMonth() found folder : " + nmon + " : " + LocalDateTime.now());
					}
					if(dir.getPath().getName().equalsIgnoreCase("nmon11")){
						if(!nmon.equalsIgnoreCase("nmon20")){  //sometimes a client has both nmon11 and nmon20
						   nmon = "nmon11";
						   System.out.println("inside loadParquetMonth() found folder : " + nmon + " : " + LocalDateTime.now());
						}
					}
					if(dir.getPath().getName().equalsIgnoreCase("pis12")){
						pis = "pis12";
						System.out.println("inside loadParquetMonth() found folder : " + pis + " : " + LocalDateTime.now());
					}
					if(dir.getPath().getName().equalsIgnoreCase("pis11")){
						if(!pis.equalsIgnoreCase("pis12")){  //sometimes a client has both nmon11 and nmon20
							pis = "pis11";
							System.out.println("inside loadParquetMonth() found folder : " + pis + " : " + LocalDateTime.now());
						}						
					}					
				}
			  }
			
			  transformParquet("/data/parquet_falcon/" + client + "/" + portfolio + "/" + pis + "/" + datePeriod, pis);
			  transformParquet("/data/parquet_falcon/" + client + "/" + portfolio + "/" + nmon + "/" + datePeriod, nmon);
			  //now all transformations are done, merge the datasets 
			  mergeDataset();
			}
			
		}catch(Exception e){e.printStackTrace();}
		
	}
		
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("PISRollup")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		     // connectionProperties = new Properties();
		     // connectionProperties.put("user", "mdw");
		     // connectionProperties.put("password", "mdw");	     
		      nmbc = spark.sparkContext().broadcast(new NmonBroadcast(), classTag(NmonBroadcast.class));
			  System.out.println("broadcast NmonBroadcast class");
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    public void transformParquet(String inputPaths, String recordtype){
    	try{
    		JavaRDD<Row> rdd = null;
    		System.out.println("inside transformParquet(): " + LocalDateTime.now());

    		if(action.equalsIgnoreCase("r")){
    		    df = spark.read()
				          .format("parquet")
				          .load(inputPaths.split(",")); //to load different file locations using strings 
    		}
    		else{
    			df = spark.read().parquet(inputPaths);  //load parquet files
    		}
    		
    		df.createOrReplaceTempView("fieldnames");  //create temp field
    		
    		if(recordtype.equalsIgnoreCase("pis11")){
    			df = spark.sql(SQLStatements.pis11 + "fieldnames");
    			df = df.withColumnRenamed("tokenAssuranceLevel", "offlineLowerLimit");
    			rdd = mapReducePIS(df.javaRDD());    		
                pis11 = createDataSet("pis11", rdd);			
    		}
            if(recordtype.equalsIgnoreCase("pis12")){
            	df = spark.sql(SQLStatements.pis12 + "fieldnames");
            	df = df.withColumnRenamed("tokenAssuranceLevel", "offlineLowerLimit");
            	rdd = mapReducePIS(df.javaRDD());    		
                pis12 = createDataSet("pis12", rdd);		
    		}
            if(recordtype.equalsIgnoreCase("nmon11")){
            	df = spark.sql(SQLStatements.nmon11 + "fieldnames");
        		rdd = mapReduceNMON11(df.javaRDD());
                nmon11 = createDataSet("pis11", rdd);
            }
            if(recordtype.equalsIgnoreCase("nmon20")){
            	df = spark.sql(SQLStatements.nmon20 + "fieldnames");
        		rdd = mapReduceNMON20(df.javaRDD());
                nmon20 = createDataSet("pis12", rdd);
    		}	
    	}catch(Exception e){e.printStackTrace();}
    }
    
    public void mergeDataset(){
    	Dataset<Row> pastDF = null;
    	JavaRDD<Row> rdd = null;
    	try{
    		System.out.println("inside mergeDataset(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(pis11 != null){
            	if(nmon11 != null){  //make sure nmon11 has records            		
            	  //merge pis and nmon, pis11 still contains pandatetime field
            	  nmon11.createOrReplaceTempView("nmon");
            	  nmon11 = spark.sql("select * from nmon where nonmonCode in ('3001','3003', '3100', '3101', '3102', '3103', '3104', '3105', '3109','3114', '3115', '3121', '3122', '3123', '3124', '3201')");

              	  pis11 = pis11.union(nmon11);
                  System.out.println("pis11 unioned nmon11");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/PIS11/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			.withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis11 = pis11.union(pastDF);
                	System.out.println("pis11 unioned " + datePeriod);
                }
                
                rdd = mapReducePIS(pis11.javaRDD());    		
                pis11 = createDataSet("pis11", rdd);
                System.out.println("pis11 completed final round of mapReducePIS");
                
                pis11 = pis11.drop("nonmonCode");  //drop nonmonCode column
                
                //remove empty pans
                pis11.createOrReplaceTempView("pis11");
                
                pis11 = spark.sql("select * from pis11 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                
               // pis11.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
               // pis11 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");
               // System.out.println("created max pandatetime with inner join");
        
                //drop the pandatetime before writing it back out as another parquet file
                pis11 = pis11.drop("pandatetime");
                System.out.println("dropped pandatetime field");
                pis11 = pis11.dropDuplicates();
                System.out.println("dropped duplicates");

             //   else{//update
                  pis11.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/PIS11/" + dateFolder);
            //    }
                System.out.println("Completed " + processedOutputDir + "/PIS11/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
            }
            
            if(pis12 != null){
            	if(nmon20 != null){
            		//merge pis and nmon, pis11 still contains pandatetime field
              	  nmon20.createOrReplaceTempView("nmon");
              	  nmon20 = spark.sql("select * from nmon where nonmonCode in ('3000','3010', '3100', '3102', '3104','3201')");
            	   //merge pis and nmon
            	   pis12 = pis12.union(nmon20);
            	   System.out.println("pis12 unioned nmon20");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/PIS12/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			        .withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis12 = pis12.union(pastDF);
                	System.out.println("pis12 unioned " + datePeriod);
                }
                
                rdd = mapReducePIS(pis12.javaRDD());    		
                pis12 = createDataSet("pis12", rdd);
                System.out.println("pis12 completed final round of mapReducePIS");
                
                pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
                
              //remove empty pans
                pis12.createOrReplaceTempView("pis12");
                
                pis12 = spark.sql("select * from pis12 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                            
                //pis12.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
            	//pis12 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");

                //drop the pandatetime before writing it back out as another parquet file
            	pis12 = pis12.drop("pandatetime");
            	System.out.println("dropped pandatetime field");
                pis12 = pis12.dropDuplicates();
                System.out.println("dropped duplicates");

            //	else{//update
            		pis12.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/PIS12/" + dateFolder);
            //	}
            	System.out.println("Completed " + processedOutputDir + "/PIS12/" + dateFolder + " Parquet File: " + LocalDateTime.now());           	
            } 	
            nmbc.destroy();
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
	public Dataset<Row> createDataSet(String rt, JavaRDD<Row> rdd){
		Dataset<Row> ds = null;
    	List<RollingObj> fieldnames = null;
    	List<StructField> fields = null;
		try{
			System.out.println("inside createDataset(): " + LocalDateTime.now());
			rtm = new RecordTypeMapperCSV(rt);
		     fieldnames = rtm.getFieldInfo();
	         
	        //Store the StruckField object into a List
		    fields = new ArrayList<>();
		      
		    //create the StructFields for the Schema
		    for(int x = 0; x < fieldnames.size(); x++){
		    	  
		    	  fields.add(DataTypes.createStructField(fieldnames.get(x).fieldName, DataTypes.StringType, true));
		      }
		    
		    //create the schema
	  		schema = DataTypes.createStructType(fields);
	  		
   		  //to create an empty dataset<row> use spark.createDataFrame(new ArrayList<>(), schema)
	  		//ds = spark.createDataFrame(newRows, schema);
	  		ds = spark.createDataFrame(rdd, schema);
			//newRows.clear();
		}catch(Exception e){e.printStackTrace();}
	 	return ds;		
	}
	
	public JavaRDD<Row> mapReducePIS(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;

		System.out.println("inside mapReducePIS(): " + LocalDateTime.now());
		javaPairRdd = rdd.mapToPair(row -> {
                  //sortkey = pan;  row.get(int i) <-- get pan column #
			       return new Tuple2<String, String>(row.mkString().substring(160, 179), row.mkString());
	            }).reduceByKey((v1, v2) -> {
	    			
	    			String record = "";
	    			String value1 = "";
	    			String value2 = "";
	    			//don't need the pandatefield in RecordTypeMapper class anymore 
	    			//because use it here to reduceByKey when PIS records
	    			
	    			value1 = v1.substring(160, 179) + v1.substring(45, 62);
	    			value2 = v2.substring(160, 179) + v2.substring(45, 62);
	    			//if value1.compareTo(value2) > 0 (returns positive value) then value1 > value2
	                //if value1 == value2 then returns 0
	                //if value1.compareTo(value2) < 0 (returns negative value) then value1 < value2
	    			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
	    				//record = v1;  //return whole string
	    				record = nmbc.value().rollupPIS12(v1, v2);
	    			}
	                if(value1.compareTo(value2) < 0){
	    				//record = v2;
	                	record = nmbc.value().rollupPIS12(v2, v1);
	    			}
	    			return record; 
	    		});
	    		
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
	    	   // System.out.println("foreach: rt: " + f.substring(16,24).trim());
			//f._2 = scala.Tuple2._2 or the value from Tuple2<K,V>
			//f._1 = scala.Tuple2._1 = the key from Tuple2<K,V>
 			rt = new RecordTypeMapperCSV(f._2.substring(16,24).trim());  //gets the recordtype value
 			rt.setPISFieldValue(f._2);	
			return rt.getRow();
		});
		return newJavaRDD;
	}
	
	public JavaRDD<Row> mapReduceNMON11(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON11(): " + LocalDateTime.now());
		javaPairRdd = rdd.mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		   **/
			return new Tuple2<String, String>(row.mkString().substring(212, 231) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			
  			if(v1.substring(174, 178).equalsIgnoreCase("3100")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3122")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3102")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3109")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3003")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1406, 1414);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1406, 1414);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3101")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1310, 1318);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1310, 1318);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3103")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3105")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1310, 1318);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1310, 1318);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3115")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3121")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1161, 1171);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1161, 1171);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3123")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1361, 1364);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1361, 1364);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3124")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1171, 1174);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1171, 1174);
  			}
  			else if(v1.substring(174, 178).equalsIgnoreCase("3201")){ 
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1377, 1390);
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1377, 1390);
  			}
  			else{
  				value1 = v1.substring(212, 231) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  	  		    value2 = v2.substring(212, 231) + v2.substring(160, 168) + v2.substring(168, 174) + "000";
  			}

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				//record = v1;  //return whole string
  				record = nmbc.value().rollupNmon11(v1, v2, v1.substring(174, 178));
  			}
              if(value1.compareTo(value2) < 0){
  				//record = v2;
            	  record = nmbc.value().rollupNmon11(v2, v1, v1.substring(174, 178));
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis11");
			 rt.setNMON11FieldValue(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
		
		return newJavaRDD;
	}
	
	public JavaRDD<Row> mapReduceNMON20(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON20(): map pan only: " + LocalDateTime.now());
		javaPairRdd = rdd.mapToPair(row -> {
           /**found out that there were same pans with different nmonCode.  Using pan here as
		    * sorting key will reduce/compare the same pans with different nmonCode and 
		    * give wrong recordCreationDate and recordCreationTime
		    * therefore, need make the sorting key pan + nonmonCode so they compare to the same ones
		    * took the trim() out because there were pans with blank recordCreationDate and recordCreationTime 
		    * so need to compare exactly same pans
		   **/
			return new Tuple2<String, String>(row.mkString().substring(241, 260) + row.mkString().substring(174, 178), row.mkString());
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			if(v1.substring(174, 178).equalsIgnoreCase("3100")){ //add in newCountryCode to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1207, 1210);
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1207, 1210);
  			}
  			else if(v1.substring(174,178).equalsIgnoreCase("3010")){  //add in newCode1 to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1501, 1504);
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1501, 1504);
  			}
  			else if(v1.substring(174,178).equalsIgnoreCase("3102")){  //add in newCode1 to compare
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000" + v1.substring(1501, 1504) ;
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000" + v2.substring(1501, 1504) ;
  			}
  			else{
  				value1 = v1.substring(241, 260) + v1.substring(160, 168) + v1.substring(168, 174) + "000";
  	  		    value2 = v2.substring(241, 260) + v2.substring(160, 168) + v2.substring(168, 174) + "000";
  			}

  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				//record = v1;  //return whole string
  				record = nmbc.value().rollupNmon20(v1, v2, v1.substring(174, 178));
  			}
              if(value1.compareTo(value2) < 0){
  				//record = v2;
            	record = nmbc.value().rollupNmon20(v2, v1, v1.substring(174, 178));
  			}
  			return record; 
  		});

		newJavaRDD = javaPairRdd.map(f -> {
			 RecordTypeMapperCSV rt = new RecordTypeMapperCSV("pis12");
			 rt.setNMON20FieldValue(f._2);			
            return rt.getRow();  //this is all we need to create data frame
		});  
        
		return newJavaRDD;
	}
	
	 public static <T> ClassTag<T> classTag(Class<T> clazz) {
 	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
	 }

}
