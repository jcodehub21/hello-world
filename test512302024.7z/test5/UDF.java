import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
//import java.time.format.ResolverStyle;

import org.apache.spark.sql.api.java.UDF1;

/**
 * Java UserDefinedFunction for Spark SQLContext
 * It will check if the recordCreationDate is a valid date
 * Remove from table if it is not valid
 * @author JaneCheng
 *
 */
public class UDF implements UDF1<String, Boolean>{

	private static final long serialVersionUID = 1L;

	@Override
	public Boolean call(String date){
		try{
			//System.out.println("checking date: " + date.trim());
			LocalDate.parse(date.trim(), DateTimeFormatter.ofPattern("yyyyMMdd"));
		}catch(DateTimeParseException e){return false;}	
		return true;
	}
}
