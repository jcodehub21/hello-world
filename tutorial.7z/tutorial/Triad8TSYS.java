import java.io.BufferedReader;
import java.io.File;
import java.io.FilenameFilter;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


/**
 * 06/08/2020 - This class is to process Triad 8 TSYS-UK and TSYS-US only
 * 
 * Triad8 TSYS-UK class with attributes
 * original file: SEP2012.C3095.MONTHLY.FB6038.binary.gz 
 * rename file: C3095.20121001.FB6038.binary.gz 
 * format:  C<4-digit client number>.<4-digit year><2-digit month>01.FB6038.binary.gz
 * March or September only files
 * 
 * Triad8 TSYS-US has April or October only files.  Same format as above.
 * Some files come with multiple parts (A, B, C, etc.)
 * /Anton/jyc_temp/jdk1.8.0_231/bin/java -cp .:/Anton/jyc_temp/TRIAD:/Anton/jyc_temp/TRIAD/ojdbc6.jar:/Anton/jyc_temp/TRIAD/mail.jar Triad8TSYS TRIAD8TSYSUS > /Anton/jyc_temp/TRIAD/TSYS.log 2>&1 &
 * @author JaneCheng
 *
 */
public class Triad8TSYS implements FilenameFilter{

	Connection conn = null;
	ResultSet rs = null;
	Statement sst = null; //complete query without any input parameters needed; execute one time
	String globalStatement = "";
	String pattern = "";
	Pattern filePattern = null;
	Matcher m = null;
	File[] filelist = null;
	File[] multiplefiles = null;
	FilenameFilter files = null;
	String[] triad8TsysMon = new String[]{"MAR", "APR", "SEP", "OCT"};
	//keeps track of number of files for TSYS-UK and TSYS-US
	GeneralLinkList<FilenameInfo> filecount = new GeneralLinkList<FilenameInfo>(); 
	//String directoryPath = "";
	String clientName = "";
	StringBuffer sb = new StringBuffer();
	String directoryPath = ""; //directory for Triad TSYS
	Date today = new Date(); //today's date
	SimpleDateFormat sdf = new SimpleDateFormat(); //format date to find month and year
	
	public static void main(String[] args) {
		
		Triad8TSYS driver = new Triad8TSYS();
		//driver.testStringPattern();
		
		//args[0] will be the client code
          driver.analyzeandprocessTSYS(args[0]);
          driver.processedFiles();
		  driver.closeAll();
		//driver.createTriggers();
	}
	
	public Triad8TSYS(){}
	
	public Triad8TSYS(String filenamefilterpattern){
		
		pattern = filenamefilterpattern;
	}
	
	//connect to database
	public void connectDB(){
		
		 // boolean isClosed = true;
		  try{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	        //conn = DriverManager.getConnection("jdbc:oracle:thin:@lux104:1521:mdwp1", "mdw", "mdw");
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated from mdwp2 to mdwp3
	        sst = conn.createStatement();
	       // ppStmt = conn.prepareStatement(globalStatement);
	      
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}
		//  return isClosed;
		}
	
	/**
	 * query DMS to see if client id exists or not
	 * @param clientid
	 * @return
	 */
	public boolean runSingleQueryForClientID(String clientid){
		
		boolean result = false; //assume that we do not have that client id in database
		try{
			globalStatement = "select api_value from desctab where client like 'TRIAD8%' and api_value = \'" + clientid + "\'";
			rs = sst.executeQuery(globalStatement);
			
			while(rs.next()){ //has a record			
				   result = true;
			}
		}
		catch(Exception e){e.printStackTrace();System.exit(-1);}
		return result;
	}
	
	/**
	 * query to find average file count for Triad and compare
	 * @param clientid
	 * @return
	 */
    public int runSingleQueryForProcessedFiles(String query){
		
		int result = 0; //average number of file count
		try{
            
			rs = sst.executeQuery(query);
			while(rs.next()){  //has a record
                result = Integer.parseInt(rs.getString(1));
			}
		}
		catch(Exception e){e.printStackTrace();System.exit(-1);}
		return result;
	}
	
	/**
	 * for TSYS-UK and US, need to check client id, count how many files by date in filenames and compare to average count 
	 * @param clientToCheck - 1 stands for TSYS-UK and TSYS-US and 2 is everything else
	 */
	public void analyzeandprocessTSYS(String dmsClientCode){
		
		directoryPath = "/mds_files20/DataRepository/";  //old directory is /work/gama3/DataRepository
	    //directoryPath = "/Anton/jyc_temp/TRIAD/"; //for testing
		FilenameInfo filenameObj = null;
		FilenameInfo temp = null;
		String name = "";
		boolean hasClient = false;
		String month = "";  //month from the file names
		int currentMonth = 0;  //month from lux432 system
		String monthForSB = ""; //month attached to string buffer
		//String year = "";  //year from the file names
		String currentYear = "";  //month from lux432 system
		//String monthAsNumberString = ""; 
		int average = 0;
		int totalProcessed = 0;
		String query = "";
		
		try{
			
			//find today's month and year first
			sdf.applyPattern("MM"); //"MM" displays the month number as two digits ex 06 for Jun
			currentMonth = Integer.parseInt(sdf.format(today));
			sdf.applyPattern("yyyy");
			currentYear = sdf.format(today); //get the year
			
			clientName = dmsClientCode;
			File directory = new File(directoryPath);
			
			//first find all single client files associated with the client name
			if(clientName.equalsIgnoreCase("TRIAD8TSYSUK")){
				
				if(currentMonth >= 3 && currentMonth < 9){
					monthForSB = "03";
					query = "select count(filename) from files where status = \'M\' and client = \'" + clientName + "\' and portfolio = 'none' and filename like \'C%" + currentYear + "0301%binary.gz\'";
				}
				if(currentMonth >= 9 && currentMonth <= 12){
					monthForSB = "09";
					query = "select count(filename) from files where status = \'M\' and client = \'" + clientName + "\' and portfolio = 'none' and filename like \'C%" + currentYear + "0901%binary.gz\'";
				}
				
				sb.append(clientName + ":<br><br>");
				files = new TRIAD_Driver("(MAR|SEP)\\d+[.]C\\d+[.]MONTHLY[.](FB603.+)[.]binary[.]gz");
			}

			if(clientName.equalsIgnoreCase("TRIAD8TSYSUS")){
				
				if(currentMonth >= 4 && currentMonth < 10){
					monthForSB = "04";
					query = "select count(filename) from files where status = \'M\' and client = \'" + clientName + "\' and portfolio = 'none' and filename like \'C%" + currentYear + "0401%binary.gz\'";
				}
				if(currentMonth >= 10 && currentMonth <= 12){
					monthForSB = "10";
					query = "select count(filename) from files where status = \'M\' and client = \'" + clientName + "\' and portfolio = 'none' and filename like \'C%" + currentYear + "1001%binary.gz\'";
				}
				
				sb.append(clientName + ":<br><br>");
				files = new TRIAD_Driver("(APR|OCT)\\d+[.]C\\d+[.]MONTHLY[.](FB603.+)[.]binary[.]gz");
			}
			
			filelist = directory.listFiles(files);
			
			if(filelist.length > 0){
			   if(conn == null){  //connect to run single query for client id
					   
					   connectDB();
					   //System.out.println("connected to database");
				   }
			   System.out.println("filelist size: " + filelist.length);
			   for(File singleFile : filelist){
				
				if(singleFile.isFile()){
					name = singleFile.toString();
					//System.out.println("file name in singleFile.isFile(): " + name);
					if(filecount.size == 0){
						
						filenameObj = new FilenameInfo(name);
						//get the month so can compare to average file count
						month = filenameObj.mm;
						//year = filenameObj.yyyy;
						
						if(!runSingleQueryForClientID(filenameObj.clientNumber.substring(1))){
							
							sb.append("New client id found: " + filenameObj.origFileName.substring(filenameObj.origFileName.lastIndexOf("/") + 1) + "<br><br>");
							
						}
						filecount.addNode(filenameObj);
						System.out.println("File: " + name + " added to filecount");
						sb.append("File: " + name + " added to filecount <br>");
					}
					else{
						hasClient = false; //reset to false to capture other client files from filelist
						if(filecount.size > 0){
							
							filecount.setIterator();
							while(filecount.hasNext()){
								
								temp = filecount.getNode();
								//temp.mmyyyy.equalsIgnoreCase(name.substring(name.lastIndexOf("/") + 1, name.lastIndexOf("/") + 8))
								//System.out.println("client number: " + temp.clientNumber);
								//System.out.println("name: " + name.substring(name.lastIndexOf("/") + 9, name.lastIndexOf("/") + 14));
								if(temp.clientNumber.equalsIgnoreCase(name.substring(name.lastIndexOf("/") + 9, name.lastIndexOf("/") + 14))){
									
									hasClient = true;
									System.out.println("Found multipart: " + name);
									//same client id and date period so have multiparts
									temp.addMultipart(name); 
									sb.append("Multipart: " + name + " added to filecount <br>");
									//break;
								}		
							}//end of while loop/iterator
							if(!hasClient){ //client number not in linklist yet
								
								//we only need one file for each client id to process on DMS
								filenameObj = new FilenameInfo(name);
								//no client id found in linklist so have to add the new file into linklist
								//also check in database if we have that client id already
								if(!runSingleQueryForClientID(filenameObj.clientNumber.substring(1))){
									
									sb.append("New client id found: " + filenameObj.origFileName.substring(filenameObj.origFileName.lastIndexOf("/") + 1) + "<br><br>");
								
								}
								
								filecount.addNode(filenameObj);
								System.out.println("File: " + name + " added to filecount");
								sb.append("File " + name + " added to filecount <br>");
								
							}
						}//end of if 
					}//end of else
				}//end of first if
			}//end of for loop
			   System.out.println("Got out of the filelist loop");
			//now compare # of files send to average # of files processed on DMS in the past
			//also need to check database and count the ones that were processed if same month and year
			ClientAverageFileCountInfo avgCount = new ClientAverageFileCountInfo(clientName);
			
			switch(month){
			case "MAR":
				//monthAsNumberString = "03";
				average = avgCount.getAverageCount("03");
				break;
			case "APR":
				//monthAsNumberString = "04";
				average = avgCount.getAverageCount("04");
				break;
			case "SEP":
				//monthAsNumberString = "09";
				average = avgCount.getAverageCount("09");
				break;
			default:  //default is Oct
				//monthAsNumberString = "10";
				average = avgCount.getAverageCount("10");
				break;
			}
			
		 }//end of if
			
		sb.append("Files processed: <br><br>");
		System.out.println("filecount: " + filecount.size);
		cpFilesForTSYS();
			  // if(conn == null){  //connect to database to run single query for processed files if not already connected
				   
				 //  connectDB();
				   //System.out.println("connected to database");
			 //  }
			// totalProcessed = filecount.size + runSingleQueryForProcessedFiles(query);
			// if(totalProcessed < average){
					//System.out.println("filecount size: " + filecount.size + "   total Processed: " + totalProcessed);
					//sb.append("We have " + totalProcessed + " files from " + clientName + " which is less than the average " + average + " files sent for " + currentYear + monthForSB + ".<br><br>");
			//	}
			// else{
				 
				// sb.append(totalProcessed + " files processed from " + clientName + " for " + currentYear + monthForSB + ".<br><br>");
				 //sb.append("Grouping will start next.<br><br>");
			// }
			
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	public void cpFilesForTSYS(){
		
		FilenameInfo temp = null;
		String zcatCommand = "zcat ";
		String[] commandArgs = null;
		ProcessBuilder builder = null;
		Process p = null; //process for Linux
		BufferedReader reader = null; //read the process.InputStream()
		//String result = "";
		//File trigger = null;
		
		try{
			
			filecount.setIterator();
			while(filecount.hasNext()){
				
				temp = filecount.getNode();
				System.out.println("cpFilesForTSYS filename: " + temp.origFileName);
				//check if multipleFiles arraylist is empty or not
				if(temp.multipleFiles.isEmpty()){
					
					sb.append(temp.newFilename + "<br>");
					//create trigger file after all files have been copied over to /ana/mds_files8
					//trigger = new File("/ana/mds_files8/" + temp.newFilename + ".trg");
					//trigger.createNewFile();  
					
					//change from Files.copy to Files.move(Path source, Path target, CopyOption... options)
					Files.move(FileSystems.getDefault().getPath(temp.origFileName),FileSystems.getDefault().getPath("/ana/mds_files8/" + temp.newFilename), StandardCopyOption.REPLACE_EXISTING);
					//System.out.println("file copied over to /ana/mds_files8");
					
				}
				else{
					//has multiple parts so need merge them
					//create the inputstream for the StreamUtils(InputStream in, OutputStream out)
					temp.sortMultipleFileparts();
					
					sb.append(temp.newFilename + "<br>");
					//create trigger file 
					//trigger = new File("/ana/mds_files8/" + temp.newFilename + ".trg");
					//trigger.createNewFile();
					
					//add all fileparts into the zcat command
					for(String filepartname : temp.multipleFiles){
						zcatCommand += filepartname + " ";	
					}
					zcatCommand += "| gzip > /ana/mds_files8/" + temp.newFilename;
					//sb.append("zcat command: " + zcatCommand + "<br>");
					commandArgs = new String[] {"/bin/bash", "-c", zcatCommand};
					builder = new ProcessBuilder(commandArgs);
					builder.redirectErrorStream(true); //redirect stderr to stdout 
					p = builder.start();  //start the bash process on linux
					
					//read process standard output to see if any errors
					reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
					zcatCommand = "zcat "; //start the string for next node
					//while ((result = reader.readLine()) != null){
					   // System.out.println("process result: " + result);
					//}
					p.waitFor();
					

				}//end of else
			}//end of while loop
			sb.append("<br>");
			//filecount.clear();
			createTriggers();
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	/*
	 * method to copy single files over to FMT directory or merge multiple file parts 
	 * together before moving over to FMT directory
	 * fileStatus = 1 = single file
	 * fileStatus = 2 = multiple parts file
	 */
	public void checkHasClient(boolean client, int fileStatus){
		
		try{
		   //if clientID already exists then copy file to FMT directory
		 /**  if(client && fileStatus == 1){
			Files.copy(FileSystems.getDefault().getPath(origFileName),FileSystems.getDefault().getPath(origDirectory + "FMT" + newFilename), StandardCopyOption.REPLACE_EXISTING);
			
		   }
		   else if(client && fileStatus == 2){
			   
			 //create the inputstream for the StreamUtils(InputStream in, OutputStream out)
			   
			   sortMultipleFileparts();
			   for(String singleFile : sortFileNames){
				   
			   gzipIS = new GZIPInputStream(new FileInputStream(singleFile));
			   
			   }
		   }
		   else{ //new clientID so write filename to log and contact Joe Beal
			
			bw.write(origFileName);
			bw.newLine();
			
		   }**/
			
			/**
			 * if clientID does not exist then check with Fran Ferguson or (TSYS-US or TSYS-UK) or 
			 * the appropriate processor liaison to determine which client name should be associated with this new client ID
			**/
			
		}
		catch(Exception e){e.printStackTrace();System.exit(-1);}
	}
	
	/**
	 * create trigger files after all files copied over /ana/mds_files8
	 * 10/22/2020
	 */
	
	public void createTriggers(){
		
		directoryPath = "/ana/mds_files8/";
        File trigger = null;
        
		try{
			File directory = new File(directoryPath);
			//System.out.println("directory: " + directoryPath);
			files = new TRIAD_Driver("^C\\d+[.]\\d+[.]FB6038[.]binary[.]gz");
			filelist = directory.listFiles(files);
			//System.out.println("trigger filelist size: " + filelist.length);
			for(File file : filelist){
				
				//System.out.println("file name for trigger: " + file.getName());
				trigger = new File("/ana/mds_files8/" + file.getName() + ".trg");
				trigger.createNewFile(); 
			}
			
			//delete files at /work/gama3/DataRepository/
			//directory = new File("/work/gama3/DataRepository/");
           // if(clientName.equalsIgnoreCase("TRIAD8TSYSUK")){
				
				//files = new TRIAD_Driver("(MAR|SEP)\\d+[.]C\\d+[.]MONTHLY[.](FB6038|FB6038.+)[.]binary[.]gz");
		//	}

		//	if(clientName.equalsIgnoreCase("TRIAD8TSYSUS")){
				
			//	files = new TRIAD_Driver("(APR|OCT)\\d+[.]C\\d+[.]MONTHLY[.](FB6038|FB6038.+)[.]binary[.]gz");
			//}
		//	filelist = directory.listFiles(files);
		//	for(File file : filelist){
				
			//	if(file.exists()){
				  // file.delete();
				//}
		//	}
			
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	//accept method belongs to FilenameFilter interface
	@Override
	public boolean accept(File dir, String filename) {
		
		boolean result = false;
		
		//register the pattern to Pattern class as a template
		filePattern = Pattern.compile(pattern);
		
		//add the filename to the matcher to check if matches pattern
		m = filePattern.matcher(filename);
		
		//if filename matches the pattern then we continue to process the file
		if(m.matches()){
			result = true;
		}
		else
		{
			result = false;
		}
		return result;
	}
	
	public void processedFiles(){
		
		try{
			
			if(sb.length() > 0){
				
				sendEmail();
			}
			else{
				System.out.println("No files on : " + Calendar.DATE);
			}
			
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	/**send emails
     * 
     * @param filedelayed
     */
    public void sendEmail(){
	
	//String to = "janecheng@fico.com,joebeals@fico.com,pariarezaeinia@fico.com,carolinechesney@fico.com,jianjunxie@fico.com,spencerworkman@fico.com";
    String to = "janecheng@fico.com";
    //String from = "ml_data_management@fico.com";
    String from = "janecheng@fico.com";
    
    try
    {
    	
    //sb.append("<br> Thank you, <br> Jane Cheng");
    String host = "mail.fairisaac.com";
    
  //create properties to store host and get or set the default mail session object
      Properties props = new Properties();
      props.put("mail.smtp.host", host);
      Session session = Session.getInstance(props);


          //create the message object
          MimeMessage msg = new MimeMessage(session);

          //set the sender's email address
          msg.setFrom(new InternetAddress(from));

          //set the recipient's email address
          msg.setRecipients(Message.RecipientType.TO, to);
      
          /* if you have more than 1 recipient to send to then use this:
           InternetAddress[] address = {new InternetAddress(args[0])};
           msg.setRecipients(Message.RecipientType.TO, address);

          */
       
          //set the subject heading
          //msg.setSubject("Wells-F6 Data Report " + dateQuery);
          msg.setSubject("TRIAD8 TSYSUK and TSYSUS Processing Email");

         //set the date of sending the email; new date() initializes the to current date
          msg.setSentDate(new Date());

         //set the message body; setText method only uses text/plain
        // msg.setText(msgBody);
          Multipart mp = new MimeMultipart();
          
          //set the html body part
          MimeBodyPart htmlbody = new MimeBodyPart();
          htmlbody.setContent(sb.toString(), "text/html");
          mp.addBodyPart(htmlbody);
          
          //set the attachment part
          //MimeBodyPart attachment = new MimeBodyPart();
         // attachment.attachFile("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
          //--attachment.setFileName("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
          //--attachment.setContent(attachment, "application/vnd.ms-excel");
         // attachment.attachFile("/ana/mds/prd/data/FIS_Ind_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
          //mp.addBodyPart(attachment);
          
         //need to use setContent method if using text/html
       //  msg.setContent(sb.toString(), "text/html");
          msg.setContent(mp);

         //send the email
         Transport.send(msg);
          
       }
       catch(Exception mex){

          System.out.println("Error in sending: ");
          mex.printStackTrace();
          System.exit(1);
       }

    }
	
    public void closeAll(){
		
		try {
			if(conn != null){
				sb.setLength(0);
				rs.close();
				sst.close();
				conn.close();
			}		
		}
			catch (Exception e) {e.printStackTrace();}
	}
	

}
