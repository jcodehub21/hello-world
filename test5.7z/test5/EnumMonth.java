package jc.lambda.util;

public enum EnumMonth {
    /**
     * 03/17/2024 - each constants is a mini-object of EnumMonth class
     * that needs it's own constructor
     * Enum is similar to:
     * class EnumMonth
     * public static final EnumMonth Day1 = new EnumMonth(some args here);
     * public static finale EnumMonth Day2 = new EnumMonth(some args here);
     * The things inside enums are identifiers, names of static final (constant) objects that'll be created.
     * So, you can't use an int for naming an object.  Java naming rules say you cannot start variables, class names ect... with numbers
     * These are actual objects of enum.
     */
    January("01", "January"),
    February("02", "February"),
    March("03", "March"),
    April("04", "April"),
    May("05", "May"),
    June("06", "June"),
    July("07", "July"),
    August("08", "August"),
    September("09", "September"),
    October("10", "October"),
    November("11", "November"),
    December("12", "December");

    private final String numberMonth;
    private final String monthName;
    //enum constructor; require for each enum object
    EnumMonth(String numberMonth, String monthName) {
        this.numberMonth = numberMonth;
        this.monthName = monthName;
    }

    public String getNumberMonth(){
        return numberMonth;  //returns 01, 02, etc..
    }
    public String getMonthName(){
        return monthName;
    }
}
