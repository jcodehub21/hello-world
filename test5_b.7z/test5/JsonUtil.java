package jc.lambda.util;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
//JsonReadFeature starts in jackson-core version 2.10.0
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 01/26/2024 - This is Json utility that will read the EventBridge details if it is a Json string
 */
public class JsonUtil {

     ObjectMapper mapper = null;
     JsonFactory factory = null;
     String field;
     int fieldID = 1;
     StringBuilder strBuilder = null;
    List<String> listResult = new ArrayList<>();
    String strInstanceID = "";
    String strResult = "";

    public void setFactory(){
        factory = JsonFactory.builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS).build();
    }

    public JsonFactory getFactory(){
        if(factory == null){
            factory = JsonFactory.builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS).build();
        }
        return factory;
    }

    /**
     * read the json string and returns the root node
     * @param jsonString
     * @return String
     */
    public String getInstanceInfo(String jsonString, String key) throws JsonProcessingException, IOException {
        mapper = new ObjectMapper(getFactory());
        return traverse(mapper.readTree(jsonString), key);
    }

    /**
     * read the json string and returns the list of instanceIds
     * @param jsonString
     * @param key
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    public List<String> getInstanceID(String jsonString, String key) throws JsonProcessingException, IOException {
        mapper = new ObjectMapper(getFactory());
        return traverseReturnList(mapper.readTree(jsonString), key);
    }

    public String readJsonFile(String filename, String key) throws JsonProcessingException, IOException{
        mapper = new ObjectMapper(getFactory());
        return traverse(mapper.readTree(new File(filename)), key);
    }

    public ObjectMapper getObjectMapper(){
        if(mapper == null){
            mapper = new ObjectMapper();
        }
        return mapper;
    }

    /**
     * go down the tree to get all nodes and values
     * this method works to traverse down the nodes
     * https://javaee.github.io/tutorial/jsonp001.html
     * Objects are enclosed in braces ({}), each individual name-value pairs are separated by a comma (,), and the name and
     * value in one pair are separated by a colon (:). Names in an object are strings, whereas values may be any of
     * the seven value types, including another object or an array.
     * Arrays are enclosed in brackets ([]), and their values are separated by a comma (,).
     * Each value in an array may be of a different type, including another array or an object
     * When objects and arrays contain other objects or arrays, the data has a tree-like structure
     * Be careful when returning a String because there might be multiple fields with same name but different values
     * and the returning String can be overridden by each of those values
     * @param node
     */
    public List<String> traverseReturnList(JsonNode node, String key) {
        if (node.isObject()) {  //is an Object
            //System.out.println("node: " + node);
            Iterator<String> iterator = node.fieldNames(); //get all field names of the object
            while (iterator.hasNext()) {
                field = iterator.next();  //gets the next element/node key name
                //System.out.println("field: " + field);
                JsonNode value = node.get(field); //returns the node value
                traverseReturnList(value, key); //it iterates the fields inside the object, get value and then keeps going to next field node
            }
        } else if (node.isArray()) {  //is an Array
            ArrayNode arrayNode = (ArrayNode) node;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                //System.out.println("Enter arrayNode");
                traverseReturnList(arrayElement, key); //goes down to all fields/nodes in an array
            }
        } else { //single field with value
            if (field.equalsIgnoreCase(key)) {
                if(key.equalsIgnoreCase("instanceId")){
                    //one instance id from user manually start EC2 instance
                    if(listResult.size() == 0){
                        listResult.add(node.textValue());
                    }
                    else{  //multiple instanceId
                        if(!node.textValue().equalsIgnoreCase(strInstanceID)) {
                            listResult.add(node.textValue());
                        }
                    }
                    strInstanceID = node.textValue();
                }
           }
        }
        return listResult;
    }

    public String traverse(JsonNode node, String key) {
        if (node.isObject()) {  //is an Object
            //System.out.println("node: " + node);
            Iterator<String> iterator = node.fieldNames(); //get all field names of the object
            while (iterator.hasNext()) {
                field = iterator.next();  //gets the next element/node key name
                //System.out.println("field: " + field);
                JsonNode value = node.get(field); //returns the node value
                traverse(value, key); //it iterates the fields inside the object, get value and then keeps going to next field node
            }
        } else if (node.isArray()) {  //is an Array
            ArrayNode arrayNode = (ArrayNode) node;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                //System.out.println("Enter arrayNode");
                traverse(arrayElement, key); //goes down to all fields/nodes in an array
            }
        } else { //single field with value
            if (field.equalsIgnoreCase(key)) {
                if(node.textValue().contains("@")) {  //principalId
                    //System.out.println("principalId indexOf : " + String.valueOf(node.textValue().indexOf(":")));
                    strResult = node.textValue().substring(node.textValue().indexOf(":") + 1, node.textValue().indexOf("@"));
                    //System.out.println("found " + key + ": " + result);
                }
                if(key.equalsIgnoreCase("userName")){
                    strResult = node.textValue();
                }
                if(key.equalsIgnoreCase("recipientAccountId")){
                    strResult = node.textValue();
                }
                if(key.equalsIgnoreCase("eventSource")){
                    strResult = node.textValue();
                }
                if(key.equalsIgnoreCase("notebookInstanceName")){
                    strResult = node.textValue();
                }
                // }
            }
        }
        return strResult;
    }
}
