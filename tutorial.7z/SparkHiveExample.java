//import java.io.File;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.List;





import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
//import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
//import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.StructType;
/**
 * 05/13/2021 Test spark 3.0.1 enableHiveSupport() in TA ATR cluster
 * https://jaceklaskowski.gitbooks.io/mastering-spark-sql/content/spark-sql-hive-metastore.html
 * https://sparkbyexamples.com/apache-hive/connect-to-hive-using-jdbc-connection/
 * https://spark.apache.org/docs/latest/sql-data-sources-hive-tables.html
 * https://spark.apache.org/docs/3.2.0/sql-data-sources-hive-tables.html
 * https://spark.apache.org/docs/latest/sql-ref-syntax-ddl-create-table-hiveformat.html
 * https://kontext.tech/article/294/spark-save-dataframe-to-hive-table
 * https://stackoverflow.com/questions/37433986/how-to-load-data-into-hive-external-table-using-spark
 * https://stackoverflow.com/questions/42261701/how-to-create-hive-table-from-spark-data-frame-using-its-schema
 * @author JaneCheng
 *
 */
public class SparkHiveExample implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> df = null;
	static BufferedReader br = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	
	public static void main(String[] args){
		
		SparkHiveExample test = new SparkHiveExample();
		test.createSparkSession();
		
	}
	
	public void createSparkSession(){
       try{
			
			spark = SparkSession
				  .builder()
				  .appName("Java Spark Test")
				 // .master("local")
				  .config("spark.sql.warehouse.dir", "hdfs://nameservice1/warehouse/tablespace/external/hive")
				  .enableHiveSupport()  //to test if can use hive sql and communicate with hive tables
				  .getOrCreate();
			if(spark != null){
				
				System.out.println("Successfully enable hive support");
			}
			 conf = new Configuration();
		     fs = FileSystem.get(conf);
			//df = spark.read().format("text").load("file:///ptoan/telecom8/IDMv15_RetuningPOC/GID_15.0_FFM_finalRelease/devel_out/v15_TF_FRD_Scale_CP/06_prescale_B4/prescale.15nordea_000-1.a1.b4CustomFilter.gz");
			//System.out.println("First row value: " + df.select("value").first().mkString());
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	public void loadParquetIntoHive(String parquetFile){
		StructType schema = null;
		try{
			df = spark.read().parquet(parquetFile);
			schema = df.schema();
			
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	public void loadCSVIntoHive(String csvFile){
		try{
			br = new BufferedReader(new InputStreamReader(fs.open(new Path(csvFile))));
			String header = br.readLine();
			if(header != null && header.contains(",")){
				String[] fields = header.split(",");
				spark.sql("CREATE EXTERNAL TABLE IF NOT EXISTS janetable(" + fields[0] + " STRING," + fields[1] + " STRING," + fields[2] + " STRING," + fields[3] + " STRING," + ") STORED AS PARQUET LOCATION /user/janecheng");
			}
			df = spark.read().format("csv")
					.option("delimiter", ",")  //using comma delimiter to separate the data so don't need to create FieldObj
				    .option("header", "true")
				  //  .option("inferSchema", "true")
				    .load(csvFile);
			df.write()
			.format("parquet")
			.mode("overwrite")
			.option("compression","gzip")
			.saveAsTable("janetable");  //save into hive table
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	
}
