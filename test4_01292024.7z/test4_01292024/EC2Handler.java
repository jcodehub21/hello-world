
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.CloudWatchLogsEvent;

import java.util.Map;

/**
 * 01/26/2024 - This class is a lambda function that reads in the EC2 state event such as launching the instance
 * from AWS EventBridge (similar to CloudWatch Events), find the user who launched the instance, and update
 * instance to include tag fico:common:owner = username
 * EC2 -> EventBridge -> Lambda -> CloudTrail
 * To access EventBridge, the Event as Map<String,Object>.
 * The "detail" key in the map gives the actual values those are put in the Eventbridge.
 */
public class EC2Handler implements RequestHandler<Map<String,Object>, String>{
    AmazonEC2 ec2;
    @Override
    public String handleRequest(Map<String,Object> event, Context context) {
        ec2 = AmazonEC2ClientBuilder.standard().build();
        LambdaLogger logger = context.getLogger();
        logger.log("EVENT TYPE: " + event.getClass().toString());
        event.forEach((k,v) -> {
            logger.log("key: " + k + "; value: " + v.toString());
        });
        return "Read EventBridge logs for EC2 launched instance";
    }
}
