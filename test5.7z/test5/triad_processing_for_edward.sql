SELECT filename cc
  FROM filestorage
 WHERE yymm = 2
   AND fileid = 11867122;
   
   SELECT *
  FROM filestorage
 WHERE fileid = 11623515;
 
 select 'rsync -a rsync://rhldmsprd001/adapt5/TSYS-UK/incoming/work/' || filename  || ' /mdswork/prd/work' from files where client = 'TRIAD8TSYSUK' and portfolio = 'none' 
    and date_period = 2209 and filename like '%.stat';
    
    select fileid from files where client = 'TRIAD8TSYSUK' and portfolio = 'none' 
    and date_period = 2209 and filename like '%.stat';
    
    select * from filestorage where fileid in (select fileid from files where
    client = 'TRIAD8TSYSUK' and portfolio = 'none' and date_period = 2209 and filename like '%.stat') and filename like '%.csv';
    
    select 'rsync -a rsync://rhldmsprd001/adapt5/TSYS-UK/incoming/csv' || substr(filename,instr(filename,'/',-1))  || '.gz /mdswork/prd/work' cc from filestorage where fileid in (select fileid from files where
    client = 'TRIAD8TSYSUK' and portfolio = 'none' and date_period = 2209 and filename like '%.stat') and filename like '%.csv';
    
    select count(filename) from filestorage where fileid in (select fileid from files where
    client = 'TRIAD8TSYSUK' and portfolio = 'none' and date_period = 2209 and filename like '%.stat') and filename like '%.csv';
    
    select * from files where fileid = 11626921;
 
 select * from filehistory where fileid = 11870102;
 
 update filehistory set status = 'E' where step# = 10 and fileid = 11870102;
 
 delete from filehistory where step# = 25 and fileid = 11870102;
 
 ------------------------------------------------------------------
 
 --TRIAD FIS-US Linkage and RRBILPST
 
 select * from triad9linkage;

select * from triad9reportkt;

select * from triad9tenants;

select * from XTriad9Linkage;

select filename from files where filename = 'TRIAD.FIS.US.OCT2022.RRBILPST.BASE.zip' and status = 'D';
 