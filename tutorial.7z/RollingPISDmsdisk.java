import java.io.Serializable;
import java.time.LocalDateTime;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.reflect.ClassTag;


public class RollingPISDmsdisk implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	//static final List<Row> newRows = new ArrayList<>();
	RecordTypeMapperCSV rtm = null;
	StructType schema = null;
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
	String hdfsDest = "";
	String fileformat = ""; // dd = source files from /dmsdisks or rf = /data/raw_falcon
	int pisBegPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	int pisEndPos = 0; //enter pis ending position to extract text if using /dmsdisks files
	int nmonBegPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	int nmonEndPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	String query = "";
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
    // static final BufferedWriter bw;  //write out nmon comparisons
	// static final OutputStream os;
    // static final Path nmonRecords;
	//list represents an ordered sequence of objects
	String pis12List = "";
	String pis11List = ""; 
	String nmon20List = "";
	String nmon11List = "";
   	
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> pis12 = null;
	Dataset<Row> nmon11 = null;
	Dataset<Row> nmon20 = null;
	Dataset<Row> resultPaths = null;
	Broadcast<NmonBroadcast> nmbc = null;
	StructType textSchema = null;
	//static Properties connectionProperties = null;  //properties for jdbc connection
	
	public static void main(String[] args){
		/**
    	 * args[0] = client ex: ts2_8167-f6
    	 * args[1] = portfolio  ex: debit
    	 * args[2] = date period  ex: 1901
    	 * args[3] = action (r = rollup, u = update)
    	 * args[4] = main hdfs destination to store parquet files
    	 * args[5] = file format (rf = raw falcon; dd = dmsdisks)
    	 * args[6] = pis begin and end position to extract text from /dmsdisks separated by a dash (optional)
    	 * args[7] = nmon begin and end position to extract text from /dmsdisks separated by a dash (optional)
    	 */
		if(args.length == 6 || args.length == 8){
			RollingPISDmsdisk test = new RollingPISDmsdisk(args);
			//since I started the spark session first the Path object needs to be serialized
            test.createSparkSession();
		   //query for single or multiple months or roll up
		   test.processDatePeriod();

		}
		else{
			System.out.println("Usage: RollingPIS tool to roll up nmon pans to pis files from 1901 to present. \n"
					+ "Parameters separated by a space: client portfolio date_period action main_hdfs_destination fileformat\n"
					+ "Action: r for rollup and u for update \n" 
					+ "fileformat: dd for dmsdisks or rf for raw_falcon \n"
					+ "Example: ts2_8167-f6 debit 1901 r /data/rollingPIS_test rf");
			
		}
		
	}
	
    public RollingPISDmsdisk(){}
    
	public RollingPISDmsdisk(String[] args){
    	System.out.println("Inside RollingPISDmsdisk constructor");	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		this.hdfsDest = args[4];	
		this.fileformat = args[5]; //dd or rf format to use for source files
		System.out.println("fileformt: " + fileformat);	
		if(fileformat.equalsIgnoreCase("dd")){
           this.pisBegPos = Integer.parseInt(args[6].substring(0, args[6].lastIndexOf("-")));
           this.pisEndPos = Integer.parseInt(args[6].substring(args[6].lastIndexOf("-") + 1));
           this.nmonBegPos = Integer.parseInt(args[7].substring(0, args[6].lastIndexOf("-")));
           this.nmonEndPos = Integer.parseInt(args[7].substring(args[6].lastIndexOf("-") + 1));
           System.out.println("Using dmsdisk files: isBegPos: " + pisBegPos + "; pisEndPos: " + pisEndPos + "; nmonBegPos: " + nmonBegPos + "; nmonEndPos: " + nmonEndPos);
		}

	}
	
	/**
     * connect to rhldatdms14001 database
     * it works on rhlappfrd60005 server
     */
	public Dataset<Row> connectDB(String recordtype){
		System.out.println("connectDB(): " + LocalDateTime.now());
	    if(action.equalsIgnoreCase("r")){
	    //nmon rollup files < 1901
	    	//query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	    //	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
	    //	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'1901\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)"
	    //	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	       if(fileformat.equalsIgnoreCase("rf")){	
	    	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	    	    	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
	    	    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'" + dateFolder + "\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)"
	    	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	       }
	       if(fileformat.equalsIgnoreCase("dd")){
	    	   query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*" + recordtype + "*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
		    	    	+ " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
		    	    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'" + dateFolder + "\') L, filestorage fs where fs.filetype = 'O' and fs.fileid in (L.fileid)"
		    	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	       }
	    }
	    else{
	    //update query ?
	    	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
	        + " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'"
	    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period = \'" + datePeriod + "\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)"
	    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	    }
	    
	   // return spark.read().jdbc("jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2", query, connectionProperties);
	    return spark.read().format("jdbc")
	  			  .option("url", "jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD")
	  			  .option("user", "mdw")
	    		  .option("password", "mdw")
	    		  .option("dbtable", query)
	    		  .load();
	}
	
	/**
	 * set single date period or multiple date periods
	 * submitted by users
	 */
	public void processDatePeriod(){
		String[] split;
		System.out.println("processDatePeriod(): " + LocalDateTime.now());
		try{	
			processedOutputDir = new Path(hdfsDest + "/" + client + "/" + portfolio);
			fs = FileSystem.get(config);
			if(!fs.exists(processedOutputDir)){
				   fs.mkdirs(processedOutputDir);
			}
		}catch(Exception e){e.printStackTrace();}
		
		if(action.equalsIgnoreCase("u")){
			//multiple date periods submitted by users
        	if(dateFolder.contains("-")){
        		split = dateFolder.split("-");
        		dateFolder = split[0];  //first date period
        		while(Integer.parseInt(dateFolder) <= Integer.parseInt(split[1])){
        	       //have to catch January (01) month because the last month will be December (12)
			       //the lowest date period is 1901
        	       //if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       else{
        		      //date period greater than 1901
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       createPISandNMONList();
        	       dateFolder = String.valueOf((Integer.parseInt(dateFolder) + 1));
        		}
        	}
        	else{ //single date period submitted by users for update
        		//if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
         		   System.out.println("Date Period: " + datePeriod);
         	    }
         	    else{
         		   //date period greater than 1901
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
         		   System.out.println("Date Period: " + datePeriod);
         	    }
        			createPISandNMONList();	        			
        	}
        }
		else{ //roll-up
			System.out.println("Roll-up to Date Folder: " + dateFolder);
			createPISandNMONList();
		}
		//spark.stop();		
	}
	
	/**
	 * fill out the pis and nmon list from resultset
	 */
	
	public void createPISandNMONList(){

		try{
			System.out.println("inside createPISandNMONList(): " + LocalDateTime.now());
			/**
			 * Using spark jdbc read works on executor side 
			 * so foreach does not work in a cluster; 
			 * foreach works on the master = local
			 * I need to collect the jdbc results back to the driver and 
			 * read the PIS and NMON paths
			 */
			//query pis11 and pis12 files
            resultPaths = connectDB("pis");
            if(fileformat.equalsIgnoreCase("dd")){
            	resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
    				if(row.getString(0).equalsIgnoreCase("pis11")){
    					//System.out.println("pis11 path: " + row.getString(1));
    					pis11List += "file://" + row.getString(1) + ",";
    				}
    				if(row.getString(0).equalsIgnoreCase("pis12")){
    					//System.out.println("pis12 path: " + row.getString(1));
    					pis12List += "file://" + row.getString(1) + ",";
    				}
    			});
            }
            else{
			    resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
				   if(row.getString(0).equalsIgnoreCase("pis11")){
					   //System.out.println("pis11 path: " + row.getString(1));
					   pis11List += row.getString(1) + ",";
				   }
				   if(row.getString(0).equalsIgnoreCase("pis12")){
					  //System.out.println("pis12 path: " + row.getString(1));
					  pis12List += row.getString(1) + ",";
				   }
			   });
            }

			//query nmon11 and nmon20 files
			resultPaths = connectDB("nmon");
			if(fileformat.equalsIgnoreCase("dd")){
				resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
					if(row.getString(0).equalsIgnoreCase("nmon11")){
						//System.out.println("nmon11 path: " + row.getString(1));
						nmon11List += "file://" + row.getString(1) + ",";
					}
					if(row.getString(0).equalsIgnoreCase("nmon20")){
						//System.out.println("nmon12 path: " + row.getString(1));
						nmon20List += "file://" + row.getString(1) + ",";
					}
				});
			}
			else{
			    resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
				   if(row.getString(0).equalsIgnoreCase("nmon11")){
					  //System.out.println("nmon11 path: " + row.getString(1));
					  nmon11List += row.getString(1) + ",";
				   }
				   if(row.getString(0).equalsIgnoreCase("nmon20")){
					  //System.out.println("nmon12 path: " + row.getString(1));
					  nmon20List += row.getString(1) + ",";
				   }
		    	});
			}
			
			//make sure there are paths in pis11List or pis12List
			if(!pis11List.isEmpty()){
				pis11List = pis11List.substring(0, pis11List.lastIndexOf(","));
				System.out.println("pis11List: " + pis11List);
				transformParquet(pis11List, "pis11");
			}
			if(!pis12List.isEmpty()){
				pis12List = pis12List.substring(0, pis12List.lastIndexOf(","));
				System.out.println("pis12List: " + pis12List);
				transformParquet(pis12List, "pis12");
			}
			//make sure there are paths in nmon11List or nmon20List
			if(!nmon11List.isEmpty()){
				nmon11List = nmon11List.substring(0, nmon11List.lastIndexOf(","));
				System.out.println("nmon11List: " + nmon11List);
				transformParquet(nmon11List, "nmon11");
			}
			if(!nmon20List.isEmpty()){
				nmon20List = nmon20List.substring(0, nmon20List.lastIndexOf(","));
				System.out.println("nmon20List: " + nmon20List);
				transformParquet(nmon20List, "nmon20");
			}
	        //now all transformations are done, merge the datasets 
			pis12List = "";
			pis11List = ""; 
			nmon20List = "";
			nmon11List = "";
		}
		catch(Exception e){e.printStackTrace();}
	}	
    
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("PISRollup")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		      textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		     // connectionProperties = new Properties();
		     // connectionProperties.put("user", "mdw");
		     // connectionProperties.put("password", "mdw");	     
		      nmbc = spark.sparkContext().broadcast(new NmonBroadcast(), classTag(NmonBroadcast.class));
			  System.out.println("broadcast NmonBroadcast class");
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    public void transformParquet(String inputPaths, String recordtype){
    	try{
    		System.out.println("inside transformParquet(): " + LocalDateTime.now());

    		      df = spark.read()
  				         .format("text")
  				         .option("inferSchema", false)
  				         .option("header", false)
  				         .load(inputPaths.split(",")); //to load different file locations using strings   	
    		      
    		if(fileformat.equalsIgnoreCase("dd")){
    			if(recordtype.equalsIgnoreCase("pis12")){
    			   df = df.map(row -> {
    				    return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
    			   }, RowEncoder.apply(textSchema));
    			   
    			   df.repartition(1)
                   .write()
                   .option("compression","gzip")
                   .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                   .parquet(processedOutputDir + "/PIS12/" + dateFolder);
    			}
    			if(recordtype.equalsIgnoreCase("pis11")){
     			   df = df.map(row -> {
     				    return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
     			   }, RowEncoder.apply(textSchema));
     			}
    			if(recordtype.equalsIgnoreCase("nmon20")){
     			   df = df.map(row -> {
     				    return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			   
     			  df.repartition(1)
                  .write()
                  .option("compression","gzip")
                  .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                  .parquet(processedOutputDir + "/NMON20/" + dateFolder);
     			}
    			if(recordtype.equalsIgnoreCase("nmon11")){
     			   df = df.map(row -> {
     				    return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			}
    		}
    		

    	}catch(Exception e){e.printStackTrace();}
    }
    
    public static <T> ClassTag<T> classTag(Class<T> clazz) {
  	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
 	 }
}
