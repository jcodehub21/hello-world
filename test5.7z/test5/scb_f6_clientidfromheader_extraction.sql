
--below query has statid 23478 clientIdFromHeader-Frequency on sampled files so need to multiple by 10
select date_period, sum(stat_f) as stat_f
  from files f,
       (SELECT fileid, sum(statvalue)*10 as stat_f
         FROM filestats_compr WHERE statid=23478 and api_value='SC_PHXSG_CR' GROUP BY fileid) s
 where s.fileid = f.fileid
   and f.status='D'
   and f.recordtype=862
   and f.client='scb-f6' and f.portfolio='none'
   and f.date_period between '2201' and '2211'
group by date_period
order by 1;

--below query has statid 23984 clientIdFromHeader-Frequency on full file so no need to multiply by 10
select date_period, sum(stat_f) as stat_f
  from files f,
       (SELECT fileid, sum(statvalue) as stat_f
         FROM filestats_compr WHERE statid=23984 and api_value='SC_PHXSG_CR' GROUP BY fileid) s
 where s.fileid = f.fileid
   and f.status='D'
   and f.recordtype=862
   and f.client='scb-f6' and f.portfolio='none'
   and f.date_period between '2201' and '2211'
group by date_period
order by 1;

select distinct(substr(filename, 0, instr(filename, '/', -1))) || '*crtran25*' from filestorage where filestatus = 'O' and filetype = 'O' and yymm = '2208' and filename like '%scb-f6.none.crtran25%';

--- to find child files by dates only
select L.filename from (select filename from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'scotia-f6' and filename like 'TSYSBRPROD%_20230613%')) L
  where L.filename like '%CRTRAN%' OR L.filename like '%PIS%' OR L.filename like '%NMON%' OR L.filename like '%FRD%' OR L.filename like '%AIS%' OR L.filename like '%CIS%';