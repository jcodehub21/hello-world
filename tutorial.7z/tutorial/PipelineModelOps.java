package com.jc.spark.mllib.MLlibUtil;

import java.io.Serializable;

import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.classification.DecisionTreeClassificationModel;
import org.apache.spark.ml.classification.DecisionTreeClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.IndexToString;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.StringIndexerModel;
import org.apache.spark.ml.feature.VectorIndexer;
import org.apache.spark.ml.feature.VectorIndexerModel;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

/**
 * 02/16/2023 - pipeline model to include all transformer stages
 * @author JaneCheng
 * https://stats.stackexchange.com/questions/61328/libsvm-data-format#:~:text=LibSVM%20format%20means%20that%20your,(e.g.%200%2C1).
 * https://stackoverflow.com/questions/41416291/how-to-prepare-data-into-a-libsvm-format-from-dataframe
 * https://stackoverflow.com/questions/44965186/how-to-understand-the-format-type-of-libsvm-of-spark-mllib
 */

public class PipelineModelOps implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> data;
	
	public static void main( String[] args )
    {
		PipelineModelOps linear = new PipelineModelOps();
        linear.runModel("C:\\software\\Spark3.2.1\\spark-3.2.1-bin-hadoop3.2\\data\\mllib\\sample_libsvm_data.txt");
    }
	
	 public void runModel(String filename) {
	    	
	    	CommonUtil.startSparkSession("Pipeline Model");
	    	data = CommonUtil.loadLibSVMData(filename, "libsvm");
	    	//drop any rows with null values; na uses the DataframeNaFunctions
	    	data = data.na().drop();
	    	data.show(20, false);
	    	
	    	//split data into training (0.7) and test (0.3) samples
	    	Dataset<Row>[] split = data.randomSplit(new double[] {0.7,0.3});
	    	
	    	
	    	/**
	    	 * Spark MLlib cannot handle String data types
	    	 * Logistic Regression needs features to be all numbers
	    	 * StringIndexer encodes a string column of labels to a column of label indices (0.0, 1.0, 2.0, etc). 
	    	 * StringIndexer can encode multiple columns
	    	 * 
	    	 * Below are the stages for the PipelineModel
	    	 */
	    	
	    	//stage 1:
	    	// Index labels, adding metadata to the label column.
	    	// Fit on whole dataset to include all labels in index.
	    	StringIndexerModel  labelIndexer = new StringIndexer().setInputCol("label") 
	    			.setOutputCol("indexedLabel")
	    			.setHandleInvalid("skip")
	    			//.setStringOrderType("frequencyDesc") //https://spark.apache.org/docs/latest/ml-features.html#stringindexer
	    			.fit(data);
	    	
	    	//stage 2:
	    	//Automatically identify categorical features, and index them.
	    	VectorIndexerModel featureIndexer = new VectorIndexer()  //feature
	    			  .setInputCol("features")
	    			  .setOutputCol("indexedFeatures")
	    			  .setMaxCategories(4) // features with > 4 distinct values are treated as continuous.
	    			  .fit(data);
	    	
	    	//stage 3:
	    	// Train a DecisionTree model.
	    	DecisionTreeClassifier dt = new DecisionTreeClassifier()
	    			  .setLabelCol("indexedLabel")
	    			  .setFeaturesCol("indexedFeatures");
            
	    	//stage 4:
	    	// Convert indexed labels back to original labels.
	    	IndexToString labelConverter = new IndexToString() //feature
	    			  .setInputCol("prediction")
	    			  .setOutputCol("predictedLabel")
	    			  .setLabels(labelIndexer.labelsArray()[0]);

	    	// Chain indexers and tree in a Pipeline. Put all stages into pipeline
	    	Pipeline pipeline = new Pipeline()
	    			  .setStages(new PipelineStage[]{labelIndexer, featureIndexer, dt, labelConverter});

	    	// Train model. This also runs the indexers.
	    	PipelineModel model = pipeline.fit(split[0]);  //training data

	    	// Make predictions.
	    	Dataset<Row> predictions = model.transform(split[1]);  //testing data

	    	// Select example rows to display.
	    	predictions.select("predictedLabel", "label", "features").show(5);

	    	//use a basic metric called accuracy to see if the model is accurate
	    	
	    	// Select (prediction, true label) and compute test error.
	    	MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
	    	  .setLabelCol("indexedLabel")
	    	  .setPredictionCol("prediction")
	    	  .setMetricName("accuracy");
	    	double accuracy = evaluator.evaluate(predictions);
	    	System.out.println("Test Error = " + (1.0 - accuracy));

	    	DecisionTreeClassificationModel treeModel = (DecisionTreeClassificationModel) (model.stages()[2]);
	    	System.out.println("Learned classification tree model:\n" + treeModel.toDebugString());
	    	System.out.println("accuracy = " + accuracy);
	    	System.out.println("Test Error = " + (1.0 - accuracy));
	    	
	    	System.out.println("--------------------------------------------------------------------------------");
	    	
	    	data = CommonUtil.loadData("C:\\software\\Spark3.2.1\\spark-3.2.1-bin-hadoop3.2\\data\\mllib\\sample_libsvm_data.txt", "csv", true, true);
	    	//drop any rows with null values; na uses the DataframeNaFunctions
	    	data = data.na().drop();
	    	
	    	String[] labels = new String[] {"ChestPain", "Thal", "AHD"};
	    	labelIndexer = new StringIndexer().setInputCols(labels)
	    			.setOutputCols(new String[] {"chestLabel", "thalLabel", "ahdLabel"})
	    			.setHandleInvalid("skip")
	    			.fit(data);
	    }
}
