package com.jc.spark.mllib.MLlibUtil;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.ml.regression.LinearRegressionTrainingSummary;

import java.io.Serializable;
import java.util.Arrays;

import org.apache.spark.ml.linalg.Vectors;

/**
 * 07/09/2021 - build a model using linear regression
 * using Spark MLlib 3.1.2
 * https://www.analyticsvidhya.com/blog/2022/08/complete-guide-to-run-machine-learning-on-spark-using-spark-mllib/
 *
 */
public class LinearRegressionOps implements Serializable
{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> data;
	
    public static void main( String[] args )
    {
        LinearRegressionOps linear = new LinearRegressionOps();
        linear.runModel("C:\\software\\eclipse_oxygen_4.7_projects_with_python\\MLlibUtil\\boston_housing.csv");
    }
    
    public void runModel(String filename) {
    	
    	CommonUtil.startSparkSession("Linear Regression");
        //load the data; since data is all numbers I need spark to infer the schema as DataType.Doubles 
    	//in order for VectorAssembler to work
    	data = CommonUtil.loadData(filename, "csv", true, true);
    	
    	//drop any rows with null values; na uses the DataframeNaFunctions
    	data = data.na().drop();
    	
    	//plot the two columns in a scatter plot with 10 rows
       // data = data.select("zn", "age").filter("zn > 0.0").limit(10);	
    	//VisualUtil.scatterPlot(data, new String[] {"zn", "age"});
    	
    	/**
    	 * Dataset<T>.describe("column_names_separated_by_comma") gives you basic statistics
    	 * such as count, mean, stddev, min and max on the specified columns
    	 * You can also use Dataset<T>.describe().show() to get stats for all columns
    	 * You an also use Dataset<T>.summary() to pick your stats such as mean, median
    	 */
    	
    	//Dataset<Row> stats = data.describe("zn","age");
    	//stats.show();   	
    	
    	/**
    	 * Now we will create the feature array by omitting the last column or dependent column of the dataset. 
    	 * If you remember that to train a machine learning model, we want to feed features and labels to predict a label 
    	 * for new features.
    	 * 
    	 * 
    	 * create the features and label using VectorAssembler -> creates a new vector by summing all the columns as one feature
    	 * VectorAssembler does not support Data type string of column; supports only numerical, boolean, vector types
    	 * data.columns() = return String[] = arrays are non-resizable, you will have to copy everything into a new, shorter array.
    	 * */
    	//get the VectorAssembler with the features (new vector type) column and transforms the data or add the feature column to the data
    	data = CommonUtil.getVectorAssembler(Arrays.copyOf(data.columns(), data.columns().length-1)).transform(data);  //data with feature
    	
    	//split data into training (0.7) and test (0.3) samples
        Dataset<Row>[] split = data.randomSplit(new double[] {0.7,0.3});
        
        //Peek into training data
        split[0].describe().show();
        
    	//set the linear regression equation parameters
        //need to set the FeaturesCol (feature column) and LabelCol (label column) names or will give errors
        //don't set your max Iterations too high or it will crash
    	LinearRegression lr = new LinearRegression().setFeaturesCol("features")
    			              .setLabelCol("medv")
    			              .setMaxIter(10)
    			              .setRegParam(0.5)
    			              .setElasticNetParam(0.8);
    	
    	// Fit the model with the training set to get the linear regression equation
    	LinearRegressionModel lrModel = lr.fit(split[0]);
    	
    	// Print the coefficients and intercept for linear regression.
    	//WARN BLAS: Failed to load implementation from: com.github.fommil.netlib.NativeSystemBLAS <-- just a warning
    	System.out.println("Coefficients: "
    	  + lrModel.coefficients() + " Intercept: " + lrModel.intercept());
    	

    	// Summarize the model over the training set and print out some metrics.
    	LinearRegressionTrainingSummary trainingSummary = lrModel.summary();
    	System.out.println("numIterations: " + trainingSummary.totalIterations());
    	System.out.println("objectiveHistory: " + Vectors.dense(trainingSummary.objectiveHistory()));
    	
    	trainingSummary.residuals().show();
    	System.out.println("mean absolute error: " + trainingSummary.meanAbsoluteError());
    	System.out.println("mean squared error: " + trainingSummary.meanSquaredError());
    	System.out.println("RMSE: " + trainingSummary.rootMeanSquaredError());
    	System.out.println("r2: " + trainingSummary.r2());
    	
    	//now get the LinearRegressionModel to predict the test data
    	data = lrModel.transform(split[1].select("features"));
    	data.show(20, false);
    	
    }
}
