import java.util.Properties;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

/**
 * ./bin/spark-shell --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar
 * @author JaneCheng
 *
 */
public class SparkJDBC {
	SparkSession spark;
	String query;
	
	public static void main(String[] args){
		
		SparkJDBC test = new SparkJDBC();
		test.connectDB("ts2_8167-f6", "debit", "pis", "1903");
	}

	public void connectDB(String client, String portfolio, String recordtype, String datePeriod){
		
		//create a spark session
	  	  spark = SparkSession
	  			  .builder()
	  			  .appName("PISRollup")
	  			  .config("spark.master", "local")  //only used on Eclipse
	  			  .config("spark.debug.maxToStringFields", 2000)
	  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
	  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
	  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
	  			  .getOrCreate();
	  	  
	  	spark.sparkContext().setLogLevel("WARN");
	  	
	  	/**
	  	 * You need to enclose the select sql statement within �()� brackets. 
	  	 * If not specified spark would throw an error as invalid select syntax.
	  	 */
	  	
	  	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
		        + " where r.alt_file_name_suffix like \'" + recordtype + "%\' and r.recordtype = f.recordtype and f.client = \'" + client + "\'"
		    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period = \'" + datePeriod + "\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)"
		    	+ " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))";
	  	
	  /**	query = "(select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r" 
    	 + " where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = \'" + client + "\'" 
    	+ " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'1901\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)"
    	 + " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)))"; **/
	  	
	  	//query = "(select fileid, filename, client, portfolio from files where fileid = 8224538)";
	  	
    	/**Dataset<Row> df = spark.read().format("jdbc")
    			  .option("url", "jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2")
    			  .option("driver", "oracle.jdbc.driver.OracleDriver")
    			  .option("dbtable", query)
    			  .option("user", "mdw")
    			  .option("password", "mdw")
    			  .load(); **/
	  	
	  	//loading option
    /**	Dataset<Row> df = spark.read().format("jdbc")
  			  .option("url", "jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2")
  			  .option("user", "mdw")
    		  .option("password", "mdw")
    		  .option("dbtable", query)
    		  .load();**/
    	
    	//or JDBC option
    	Properties connectionProperties = new Properties();
    	connectionProperties.put("user", "mdw");
    	connectionProperties.put("password", "mdw");
    	
    	Dataset<Row> df = spark.read().jdbc("jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2", query, connectionProperties);
    	//df.show(10, false);
    	df.foreach(row -> {
    		if(row.getString(0).equalsIgnoreCase("pis11")){
				System.out.println("pis11 path: " + row.getString(1));
				//pis11List += row.getString(1) + ",";
			}
    	});
	  	
	}
}
