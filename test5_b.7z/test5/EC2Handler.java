package jc.lambda.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloudtrail.AWSCloudTrail;
import com.amazonaws.services.cloudtrail.AWSCloudTrailClientBuilder;
//import com.amazonaws.services.cloudtrail.model.LookupAttribute;
//import com.amazonaws.services.cloudtrail.model.LookupAttributeKey;
//import com.amazonaws.services.cloudtrail.model.LookupEventsRequest;
//import com.amazonaws.services.cloudtrail.model.LookupEventsResult;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.CreateTagsResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
//import com.amazonaws.services.lambda.runtime.events.CloudWatchLogsEvent;
//import com.amazonaws.util.DateUtils;
import com.amazonaws.services.sagemaker.AmazonSageMaker;
import com.amazonaws.services.sagemaker.AmazonSageMakerClientBuilder;
import com.amazonaws.services.sagemaker.model.AddTagsRequest;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.GetIdentityVerificationAttributesRequest;
import com.amazonaws.services.simpleemail.model.GetIdentityVerificationAttributesResult;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
//import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import com.google.gson.Gson;

/**
 * 01/26/2024 - This class is a lambda function that reads in the EC2 state event such as launching the instance
 * from AWS EventBridge (similar to CloudWatch Events), find the user who launched the instance, and update
 * instance to include tag fico:common:owner = username
 * EC2 -> EventBridge -> Lambda -> CloudTrail
 * To access EventBridge, the Event as Map<String,Object>.
 * The "detail" key in the map gives the actual values those are put in the Eventbridge.
 * RunInstances will be triggered when EC2 is created and starts running for first time.
 * If you stop and restart the EC2 Instance, then startInstances will be triggered
 * https://docs.aws.amazon.com/cli/latest/reference/sagemaker/describe-project.html
 * https://stackoverflow.com/questions/54446521/how-to-tell-how-much-an-individual-job-costs
 * https://awscli.amazonaws.com/v2/documentation/api/latest/reference/sagemaker/describe-training-job.html
 */
public class EC2Handler implements RequestHandler<Map<String,Object>, String>{
    AmazonEC2 ec2;
    AWSCloudTrail ct;
    AmazonSageMaker sagemaker = AmazonSageMakerClientBuilder.standard().withRegion(Regions.US_WEST_2).build();;
    AmazonSimpleEmailService ses = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
    Date date;
    List<String> instanceId = new ArrayList<>();
    String username = "";
    String eventSource = "";
    String notebookInstanceName = "";
    String recipientAccountId = "";
    StringBuffer sb = new StringBuffer();
    SimpleDateFormat format;
    JsonUtil jsonUtil;
    CreateTagsRequest cTagRequest;
    boolean addedTag = false;

    @Override
    public String handleRequest(Map<String,Object> event, Context context) {
        //CommonOps.setCredentialProvider();
        ec2 = AmazonEC2ClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        ct = AWSCloudTrailClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        jsonUtil = new JsonUtil();
        jsonUtil.setFactory();
        //format = new SimpleDateFormat("yyyy-MM-dd'T'HH:'00':'00Z'", Locale.US);
        //format.setTimeZone(TimeZone.getTimeZone("UTC"));

        LambdaLogger logger = context.getLogger();
        //logger.log("EVENT TYPE: " + event.getClass().toString());
        //event do return cloudtrail information for RunInstances under key = detail, value = object format
        //need Gson to convert value object to json string
        event.forEach((k,v) -> {
           // logger.log("Key: " + k + "; value: " + v.toString());
            if(k.equalsIgnoreCase("detail")){
                try {
                    String jsonString = new Gson().toJson(v);
                    logger.log("json string: " + jsonString);
                    username = jsonUtil.getInstanceInfo(jsonString, "principalId");
                    eventSource = jsonUtil.getInstanceInfo(jsonString, "eventSource");
                    recipientAccountId = jsonUtil.getInstanceInfo(jsonString, "recipientAccountId");
                    if(!username.isEmpty() && eventSource.contains("sagemaker")){ //sagemaker
                        username = username + "-sagemaker";
                        notebookInstanceName = jsonUtil.getInstanceInfo(jsonString, "notebookInstanceName");
                    }
                    if(username.isEmpty()){  //EMR
                        username = jsonUtil.getInstanceInfo(jsonString, "userName");
                        if(username.contains("EMR")){
                           username = username.substring(username.indexOf("EMR"), username.lastIndexOf("-"));
                        }
                    }
                    instanceId = jsonUtil.getInstanceID(jsonString, "instanceId");
                }catch (JsonProcessingException j){
                    j.printStackTrace();
                }catch(IOException ioe){
                    ioe.printStackTrace();
                }
            }
            //if(k.equalsIgnoreCase("time")){
               // logger.log("Event Time: " + v.toString());
              //  try {
                   // date = format.parse(v.toString().substring(0, v.toString().indexOf(":")) + ":00:00Z");
                    /** below time format works.  It gave me the second most recent cloudtrail RunInstances event which is
                     *  "eventTime": "2024-02-16T00:01:07Z".  It does not capture the ec2 instance that I created as Cloudtrail
                     *  has a delay in time.
                     **/
                  //    date = format.parse("2024-02-15T22:00:00Z");
              //  } catch (ParseException e) {
               //     throw new RuntimeException(e);
             //   }
          //  }
            /** if(k.equalsIgnoreCase("detail")){
                logger.log("Found instanceId: value: " + v.toString());
                instanceId = v.toString().substring(v.toString().indexOf("instance"), v.toString().indexOf("="));
            }**/
        });
        /** below code shows up when go to Lambda function -> Monitor tab -> View CloudWatch Logs
         key: detail; value: {instance-id=i-01ee2b73064eab549, state=running}
         Get instance-id from above then go to CloudTrail Lookup Events for Event Name: RunInstances and User Name user@fico.com
         */
        /**if(ct != null){  //this test worked in lambda
            logger.log("ct: " + ct.toString());
        }  **/
        //LookupEventsRequest lEventRequest = new LookupEventsRequest();
        //LookupAttribute attribute1 = new LookupAttribute();
       // attribute1.setAttributeKey(LookupAttributeKey.EventName);
       // attribute1.setAttributeValue("RunInstances");  //when user create a new instance it does not have username in StartInstances
      //  lEventRequest = lEventRequest.withLookupAttributes(attribute1).withMaxResults(1);
      //  lEventRequest.setStartTime(date);  //current date and time
       // logger.log("lEventRequest start time: " + lEventRequest.getStartTime());
        //logger.log("lEventRequest: " + lEventRequest.getLookupAttributes());

        //look up cloudtrail management events eg start, stop, remove aws resources
      /**  LookupEventsResult lEventsResult = ct.lookupEvents(lEventRequest);
        if(lEventsResult.getEvents().size() > 0) {
            lEventsResult.getEvents().forEach(e -> {
                if(e.getUsername().contains("fico.com")){
                 logger.log("username: " + e.getUsername());
                 username = e.getUsername().substring(0, e.getUsername().indexOf("@"));
                 }
                logger.log("event: " + e.getCloudTrailEvent());
            });
        } **/

        //add new tags (fico:common:owner, username) to the startup ec2 instance
        //make sure to check if the tag already exists in the startup ec2 instance
        // The list of tags to create
      // ArrayList<Tag> requestTags = new ArrayList<Tag>();
      // requestTags.add(new Tag("fico:common:owner","value1"));
        // cTagRequest.setTags(requestTags);
        //sagemaker will return zero instanceId
        //sb.append(System.getProperty("line.separator")) does not work in lambda
        if(username.contains("sagemaker")){
               if(!CommonOps.checkSageMakerTags(sagemaker,notebookInstanceName,"fico:common:owner")){
                   sagemaker.addTags(new AddTagsRequest().withResourceArn(CommonOps.getSageMakerNotebookResourceARN(sagemaker,notebookInstanceName)).withTags(new com.amazonaws.services.sagemaker.model.Tag().withKey("fico:common:owner").withValue(username)));
                   sb.append("Added Sagemaker fico:common:owner tag to " + notebookInstanceName + " for " + username).append("</br>");
                   addedTag = true;
               }
               else{
                   logger.log("sagemaker notebook fico:common:owner tag exist => " + CommonOps.checkSageMakerTags(sagemaker,notebookInstanceName,"fico:common:owner"));
               }
        }else{ //ec2 instance
            if(instanceId.size() > 0) {
                instanceId.forEach(instanceID -> {
                    if(!CommonOps.checkEC2Tags(ec2,instanceID, "fico:common:owner", username)){
                        cTagRequest = new CreateTagsRequest().withResources(instanceID).withTags(new Tag().withKey("fico:common:owner").withValue(username));
                        CreateTagsResult cTagResult = ec2.createTags(cTagRequest);
                        //tag EC2 EBS volumes if instance has it
                        CommonOps.checkEBSVolume(ec2,instanceID,"fico:common:owner", username);
                        sb.append("Added EC2 fico:common:owner tag to " + instanceID + " for " + username).append("</br>");
                        addedTag = true;
                    }
                    else{  //EC2 instance already has the fico:common:owner tag
                        //now check EC2 EBS volumes if it needs tagging
                        CommonOps.checkEBSVolume(ec2,instanceID,"fico:common:owner", username);
                        logger.log("ec2 fico:common:owner tag exist => " + CommonOps.checkEC2Tags(ec2,instanceID, "fico:common:owner"));
                    }
                });
            }
        }

        if(addedTag){
            /**
             * uses SES to check if the email address has been verified
             */
            GetIdentityVerificationAttributesResult getIVAR = ses.getIdentityVerificationAttributes(new GetIdentityVerificationAttributesRequest().withIdentities("janecheng@fico.com"));
            getIVAR.getVerificationAttributes().forEach((email,status) -> {
                System.out.println("email: " + email + " => status: " + status);
                if(status.getVerificationStatus().equalsIgnoreCase("Success")){
                    CommonOps.sendSESEmail(ses, "janecheng@fico.com", "janecheng@fico.com", CommonOps.getAWSAccountName(recipientAccountId) + " Notification For "+ LocalDate.now(), sb.toString());
                }
            });

        }
        return "EC2 instance tagging completed";
    }
}
