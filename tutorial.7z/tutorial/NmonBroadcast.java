import java.io.Serializable;



/**
 * 9/16/2022
 * this class will be used to broadcast to all machines to do roll-up data during reduceByKey method
 * @author JaneCheng
 *
 */
public class NmonBroadcast implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//for nonmon files
	public String rollupNmon20(String bigger, String smaller, String nonmonCode){
		  if(nonmonCode.equalsIgnoreCase("3000") || nonmonCode.equalsIgnoreCase("3010")){
			//check if newDate2 is empty for up-to-date recordCreationDate
	        if(bigger.substring(1405, 1413).trim().isEmpty()){
	            bigger = bigger.substring(0,1405) + smaller.substring(1405, 1413) + bigger.substring(1413);
	        }
	             
	        //compare newIndicator1
	        if(bigger.substring(1519, 1520).trim().isEmpty()){
	        	bigger = bigger.substring(0,1519) + smaller.substring(1519, 1520) + bigger.substring(1520);
	        }

	     	//compare newIndicator2
	        if(bigger.substring(1521, 1522).trim().isEmpty()){
	        	bigger = bigger.substring(0,1521) + smaller.substring(1521, 1522) + bigger.substring(1522);
	        }
			  
		  }
		  if(nonmonCode.equalsIgnoreCase("3000")){
        	 //lets compare newPaymentInstrumentId
        	 //if bigger < smaller then take the smaller field value
        	 //otherwise keep bigger field value
        	 if(bigger.substring(369, 399).trim().isEmpty()){
        		 bigger = bigger.substring(0,369) + smaller.substring(369, 399) + bigger.substring(399);
        	 }

        	 //lets compare newDate1
             if(bigger.substring(1389, 1397).trim().isEmpty()){
            	 bigger = bigger.substring(0,1389) + smaller.substring(1389, 1397) + bigger.substring(1397);
        	 }

        	 //lets compare newCountryCode
             if(bigger.substring(1207, 1210).trim().isEmpty()){
            	 bigger = bigger.substring(0,1207) + smaller.substring(1207, 1210) + bigger.substring(1210);
        	 }

         }
         
         if(nonmonCode.equalsIgnoreCase("3010")){ 
        	 
        	//compare newNumericValue1
        	 if(bigger.substring(1581, 1591).trim().isEmpty()){
        		 bigger = bigger.substring(0,1581) + smaller.substring(1581, 1591) + bigger.substring(1591);
        	 }

        	 //compare newIndicator4
        	 if(bigger.substring(1525, 1526).trim().isEmpty()){
        		 bigger = bigger.substring(0,1525) + smaller.substring(1525, 1526) + bigger.substring(1526);
        	 }
        	 
        	 //compare newCode1
        	 if(bigger.substring(1501, 1504).trim().isEmpty()){
        		 bigger = bigger.substring(0,1501) + smaller.substring(1501, 1504) + bigger.substring(1504);
        	 }

         }
         if(nonmonCode.equalsIgnoreCase("3100")){
        	 //compare newPostalCode
            if(bigger.substring(1187, 1197).trim().isEmpty()){
            	bigger = bigger.substring(0,1187) + smaller.substring(1187, 1197) + bigger.substring(1197);
        	 }
            
            //lets compare newCountryCode
            if(bigger.substring(1207, 1210).trim().isEmpty()){
           	 bigger = bigger.substring(0,1207) + smaller.substring(1207, 1210) + bigger.substring(1210);
       	    }
         }
         
         if(nonmonCode.equalsIgnoreCase("3104")){
        	//compare newIndicator1
             if(bigger.substring(1519, 1520).trim().isEmpty()){
            	 bigger = bigger.substring(0,1519) + smaller.substring(1519, 1520) + bigger.substring(1520);
        	 }
         }
         if(nonmonCode.equalsIgnoreCase("3201")){
	        //compare newMonetaryValue
            if(bigger.substring(1527, 1546).trim().isEmpty()){
            	bigger = bigger.substring(0,1527) + smaller.substring(1527, 1546) + bigger.substring(1546);
        	 }
        	//compare currencyCode
            if(bigger.substring(1565, 1568).trim().isEmpty()){
            	bigger = bigger.substring(0,1565) + smaller.substring(1565, 1568) + bigger.substring(1568);
          	 }
            //compare currencyConversionRate
            if(bigger.substring(1568, 1581).trim().isEmpty()){
            	bigger = bigger.substring(0,1568) + smaller.substring(1568, 1581) + bigger.substring(1581);
       	    }
         }
         
         if(nonmonCode.equalsIgnoreCase("3102")){
        	//compare newCode1
        	 if(bigger.substring(1501, 1504).trim().isEmpty()){
        		 bigger = bigger.substring(0,1501) + smaller.substring(1501, 1504) + bigger.substring(1504);
        	 }
          }
         return bigger;
	}
	
	public String rollupNmon11(String bigger, String smaller, String nonmonCode){
		
		if(nonmonCode.equalsIgnoreCase("3003")){
		    //lets compare numericaValue1
            if(bigger.substring(1406, 1414).trim().isEmpty()){
       	       bigger = bigger.substring(0,1406) + smaller.substring(1406, 1414) + bigger.substring(1414);
   	        }
		}

		if(nonmonCode.equalsIgnoreCase("3100") || nonmonCode.equalsIgnoreCase("3122") || nonmonCode.equalsIgnoreCase("3124")){
		    //lets compare newCountryCode
            if(bigger.substring(1171, 1174).trim().isEmpty()){
       	       bigger = bigger.substring(0,1171) + smaller.substring(1171, 1174) + bigger.substring(1174);
   	        }
		}
		
		if(nonmonCode.equalsIgnoreCase("3100") || nonmonCode.equalsIgnoreCase("3121")){
		    //lets compare newPostalCode
            if(bigger.substring(1161, 1171).trim().isEmpty()){
       	       bigger = bigger.substring(0,1161) + smaller.substring(1161, 1171) + bigger.substring(1171);
   	        }
		}
		
		if(nonmonCode.equalsIgnoreCase("3101") || nonmonCode.equalsIgnoreCase("3102") || nonmonCode.equalsIgnoreCase("3103") || nonmonCode.equalsIgnoreCase("3105")){
		    //lets compare date2
            if(bigger.substring(1310, 1318).trim().isEmpty()){
       	       bigger = bigger.substring(0,1310) + smaller.substring(1310, 1318) + bigger.substring(1318);
   	        }
		}
        
		if(nonmonCode.equalsIgnoreCase("3102") || nonmonCode.equalsIgnoreCase("3103") || nonmonCode.equalsIgnoreCase("3109") || nonmonCode.equalsIgnoreCase("3115") || nonmonCode.equalsIgnoreCase("3123")){
            //compare newCode
   	        if(bigger.substring(1361, 1364).trim().isEmpty()){
   		       bigger = bigger.substring(0,1361) + smaller.substring(1361, 1364) + bigger.substring(1364);
   	        }
		}
		
		if(nonmonCode.equalsIgnoreCase("3201")){
		    //lets compare newMonetaryValue
            if(bigger.substring(1377, 1390).trim().isEmpty()){
       	       bigger = bigger.substring(0,1377) + smaller.substring(1377, 1390) + bigger.substring(1390);
   	        }
		}
		return bigger;
	}
	
	public String rollupPIS12(String bigger, String smaller){
		
		//type
		if(bigger.substring(179, 180).trim().isEmpty()){
		    bigger = bigger.substring(0,179) + smaller.substring(179, 180) + bigger.substring(180);
		}
		//subType
		if(bigger.substring(180, 182).trim().isEmpty()){
		    bigger = bigger.substring(0,180) + smaller.substring(180, 182) + bigger.substring(182);
		}
		//category
		if(bigger.substring(182, 183).trim().isEmpty()){
		    bigger = bigger.substring(0,182) + smaller.substring(182, 183) + bigger.substring(183);
		}
		//panOpenDate
		if(bigger.substring(184, 192).trim().isEmpty()){
        	bigger = bigger.substring(0,184) + smaller.substring(184, 192) + bigger.substring(192);
   	    }
		//issuingCountry
		if(bigger.substring(200, 203).trim().isEmpty()){
		    bigger = bigger.substring(0,200) + smaller.substring(200, 203) + bigger.substring(203);
		}
		
		//cardholderPostalCode
		if(bigger.substring(248, 258).trim().isEmpty()){
		    bigger = bigger.substring(0,248) + smaller.substring(248, 258) + bigger.substring(258);
		}
		
		//cardholderCountryCode
		if(bigger.substring(258, 261).trim().isEmpty()){
        	bigger = bigger.substring(0,258) + smaller.substring(258, 261) + bigger.substring(261);
   	    }
		
		//numberOfPaymentIds
		if(bigger.substring(261, 264).trim().isEmpty()){
        	bigger = bigger.substring(0,261) + smaller.substring(261, 264) + bigger.substring(264);
   	    }
		
		//paymentInstrumentId
		if(bigger.substring(264, 294).trim().isEmpty()){
        	bigger = bigger.substring(0,264) + smaller.substring(264, 294) + bigger.substring(294);
   	    }
		//status
		if(bigger.substring(294, 296).trim().isEmpty()){
		    bigger = bigger.substring(0,294) + smaller.substring(294, 296) + bigger.substring(296);
		}
		//activeIndicator
		if(bigger.substring(315, 316).trim().isEmpty()){
        	bigger = bigger.substring(0,315) + smaller.substring(315, 316) + bigger.substring(316);
   	    }
		
		//expirationDate
		if(bigger.substring(356, 364).trim().isEmpty()){
		    bigger = bigger.substring(0,356) + smaller.substring(356, 364) + bigger.substring(364);
		}
		//lastIssueDate
		if(bigger.substring(364, 372).trim().isEmpty()){
		    bigger = bigger.substring(0,364) + smaller.substring(364, 372) + bigger.substring(372);
		}

		//plasticIssueType
		if(bigger.substring(372, 373).trim().isEmpty()){
		    bigger = bigger.substring(0,372) + smaller.substring(372, 373) + bigger.substring(373);
		}
		//incentive
		if(bigger.substring(373, 374).trim().isEmpty()){
        	bigger = bigger.substring(0,373) + smaller.substring(373, 374) + bigger.substring(374);
   	    }
		//currencyCode
		if(bigger.substring(374, 377).trim().isEmpty()){
        	bigger = bigger.substring(0,374) + smaller.substring(374, 377) + bigger.substring(377);
   	    }
		//currencyConversionRate
		if(bigger.substring(377, 390).trim().isEmpty()){
        	bigger = bigger.substring(0,377) + smaller.substring(377, 390) + bigger.substring(390);
   	    }
		//dailyPosLimit
		if(bigger.substring(410,420).trim().isEmpty()){
        	bigger = bigger.substring(0,410) + smaller.substring(410,420) + bigger.substring(420);
   	    }
		//mediaType
		if(bigger.substring(431,432).trim().isEmpty()){
		    bigger = bigger.substring(0,431) + smaller.substring(431,432) + bigger.substring(432);
		}
        return bigger;
	}

}
