import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.SparkContext;
//import org.apache.spark.api.java.function.PairFunction; //needed if want to do a new PairFunction<>()
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.broadcast.Broadcast;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

//import scala.Function1;
import scala.reflect.ClassTag;

/**
 * 04/18/2025 This class will call the CommonUtil methods and run clients with only one PIS record type 
 * ie PIS11 or PIS12
 * @author JaneCheng
 *
 */
public class RollingPISv3 implements Serializable{
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	RecordTypeMapperCSV rtm = null;
	StructType schema = null;
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
	String hdfsDest = "";
	String fileformat = ""; // dd = source files from /dmsdisks or rf = /data/raw_falcon
	String begPeriod = "1201";
	int pisBegPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	int pisEndPos = 0; //enter pis end position to extract text if using /dmsdisks files
	int nmonBegPos = 0; //enter nmon beginning position to extract text if using /dmsdisks files
	int nmonEndPos = 0; //enter nmon end position to extract text if using /dmsdisks files
	int pisPanEndPos = 0; //pis pan end position in bytes if using /dmsdisks files; some ts2_9330-f6 old files have no pans
	String pisRecordCreationDateBytes = "";
	String nmonRecordCreationDateBytes = "";
	String query = "";
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 

	//list represents an ordered sequence of objects
	String pisList = "";	
	String nmonList = "";
	String pisRecordType = "";
	String nmonRecordType = "";
	String pisRecordTypeLength = "";
	String nmonRecordTypeLength = "";
	UDF1<String, Boolean> userdefinedfunction = null;
	String udfName = "checkValidDate";
   	
	Dataset<Row> df = null;
	Dataset<Row> pisDF = null;
	Dataset<Row> nmonDF = null;
	Dataset<Row> resultPaths = null;
	Dataset<Row> rejectsPis = null;  //store pis reject records
	Dataset<Row> rejectsNmon = null;  //store nmon reject records
	Broadcast<NmonBroadcast> nmbc = null;
	StructType textSchema = null;
	SparkContext sc = null;
	String pisRecordTypeTemp = "";
	String addFixes = "";
		
	public RollingPISv3(){}
	
	public RollingPISv3(String client, String portfolio, String hdfsDest, String addFixes){
		this.client = client;
		this.portfolio = portfolio;
		this.hdfsDest = hdfsDest;
		this.addFixes = addFixes;
	}
	
	public RollingPISv3(String[] args){
	   	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		this.hdfsDest = args[4];	
		//System.out.println("args[5]: " + args[5]);
           this.pisBegPos = Integer.parseInt(args[5].substring(0, args[5].lastIndexOf("-")));
           this.pisEndPos = Integer.parseInt(args[5].substring(args[5].lastIndexOf("-") + 1));
           this.nmonBegPos = Integer.parseInt(args[6].substring(0, args[6].lastIndexOf("-")));
           this.nmonEndPos = Integer.parseInt(args[6].substring(args[6].lastIndexOf("-") + 1));
           System.out.println("Using dmsdisk files: pisBegPos: " + pisBegPos + "; pisEndPos: " + pisEndPos + "; nmonBegPos: " + nmonBegPos + "; nmonEndPos: " + nmonEndPos);
           if(action.equalsIgnoreCase("r")){
               this.begPeriod = args[7];          
               System.out.println("Roll-up starting with: " + begPeriod);
               this.pisRecordType = args[8].substring(0,args[8].lastIndexOf("-"));
               this.pisRecordTypeLength = args[8].substring(args[8].indexOf("-") + 1);
        	   this.nmonRecordType = args[9].substring(0,args[9].lastIndexOf("-"));
        	   this.nmonRecordTypeLength = args[9].substring(args[9].indexOf("-") + 1);
        	   System.out.println("recordtype to query: " + pisRecordType + " and " + nmonRecordType);
        	   System.out.println("pis and nmon recordtype length: " + pisRecordTypeLength + " and " + nmonRecordTypeLength);
        	   this.pisRecordCreationDateBytes = args[10];
        	   this.nmonRecordCreationDateBytes = args[11];
        	   System.out.println("pis recordCreationDate bytes: " + pisRecordCreationDateBytes + " and nmon recordCreationDate bytes: " + nmonRecordCreationDateBytes);

           }
           else{ //update
        	   this.pisRecordType = args[7].substring(0,args[7].lastIndexOf("-"));
        	   this.pisRecordTypeLength = args[7].substring(args[7].indexOf("-") + 1);
        	   this.nmonRecordType = args[8].substring(0,args[8].lastIndexOf("-"));
        	   this.nmonRecordTypeLength = args[8].substring(args[8].indexOf("-") + 1);
        	   System.out.println("recordtype to query: " + pisRecordType + " and " + nmonRecordType);
        	   System.out.println("pis and nmon recordtype length: " + pisRecordTypeLength + " and " + nmonRecordTypeLength);
        	   this.pisRecordCreationDateBytes = args[9];
        	   this.nmonRecordCreationDateBytes = args[10];
        	   System.out.println("pis recordCreationDate bytes: " + pisRecordCreationDateBytes + " and nmon recordCreationDate bytes: " + nmonRecordCreationDateBytes);
           }
	  }
	
	public void setRecordTypes(String[] args){
		System.out.println("RollingPISv3.setRecordTypes(): " + LocalDateTime.now());
		this.pisBegPos = Integer.parseInt(args[0].substring(0, args[0].lastIndexOf("-")));
        this.pisEndPos = Integer.parseInt(args[0].substring(args[0].lastIndexOf("-") + 1));
        this.nmonBegPos = Integer.parseInt(args[1].substring(0, args[1].lastIndexOf("-")));
        this.nmonEndPos = Integer.parseInt(args[1].substring(args[1].lastIndexOf("-") + 1));
        System.out.println("Using dmsdisk files: pisBegPos: " + pisBegPos + "; pisEndPos: " + pisEndPos + "; nmonBegPos: " + nmonBegPos + "; nmonEndPos: " + nmonEndPos);
        if(action.equalsIgnoreCase("r")){
            this.begPeriod = args[2];          
            System.out.println("Roll-up starting with: " + begPeriod);
            this.pisRecordType = args[3].substring(0,args[3].lastIndexOf("-"));
            this.pisRecordTypeLength = args[3].substring(args[3].indexOf("-") + 1);
     	   this.nmonRecordType = args[4].substring(0,args[4].lastIndexOf("-"));
     	   this.nmonRecordTypeLength = args[4].substring(args[4].indexOf("-") + 1);
     	   System.out.println("recordtype to query: " + pisRecordType + " and " + nmonRecordType);
     	   System.out.println("pis and nmon recordtype length: " + pisRecordTypeLength + " and " + nmonRecordTypeLength);
     	   this.pisRecordCreationDateBytes = args[5];
     	   this.nmonRecordCreationDateBytes = args[6];
     	   System.out.println("pis recordCreationDate bytes: " + pisRecordCreationDateBytes + " and nmon recordCreationDate bytes: " + nmonRecordCreationDateBytes);

        }
        else{ //update
     	   this.pisRecordType = args[2].substring(0,args[2].lastIndexOf("-"));
     	   this.pisRecordTypeLength = args[2].substring(args[2].indexOf("-") + 1);
     	   this.nmonRecordType = args[3].substring(0,args[3].lastIndexOf("-"));
     	   this.nmonRecordTypeLength = args[3].substring(args[3].indexOf("-") + 1);
     	   System.out.println("recordtype to query: " + pisRecordType + " and " + nmonRecordType);
     	   System.out.println("pis and nmon recordtype length: " + pisRecordTypeLength + " and " + nmonRecordTypeLength);
     	   this.pisRecordCreationDateBytes = args[4];
     	   this.nmonRecordCreationDateBytes = args[5];
     	   System.out.println("pis recordCreationDate bytes: " + pisRecordCreationDateBytes + " and nmon recordCreationDate bytes: " + nmonRecordCreationDateBytes);
        }
        
        /**
    	 * Broadcast variables are read-only. 
    	 * Once broadcasted, the data is immutable, meaning it cannot be modified or updated. 
    	 */
        if(nmbc == null){
        	setNmonBroadcast(pisRecordType);
        }
        else{
        	if(!pisRecordType.equalsIgnoreCase(pisRecordTypeTemp)){
        		setNmonBroadcast(pisRecordType);
        	}
        }
        pisRecordTypeTemp = pisRecordType;
	}
	
	public void setNmonBroadcast(String pisRecordType){
    	nmbc = spark.sparkContext().broadcast(new NmonBroadcast(pisRecordType), classTag(NmonBroadcast.class));
		  System.out.println("inside setNmonBroadcast(): broadcast NmonBroadcast class");
    }
	
	/**
     * input any class to broadcast in spark
     * returns the class T of ClassTag
     * @param clazz
     * @return 
     */
	 public static <T> ClassTag<T> classTag(Class<T> clazz) {
 	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
	 }
	
	public void processFromPISFactory(SparkSession sparktemp, Broadcast<NmonBroadcast> nmbctemp){
		try{
		   System.out.println("RollingPISv3.processFromPISFactory(): " + LocalDateTime.now());
		   spark = sparktemp;
		   textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		   fs = FileSystem.get(config);
		   processedOutputDir = CommonUtil.createDestinationDir(client, portfolio, hdfsDest);
 		   //nmbc.destroy();	
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * set single date period or multiple date periods
	 * submitted by users
	 */
	public void processDatePeriod(){
		String[] split;
		System.out.println("RollingPISv3.processDatePeriod(): " + LocalDateTime.now());		
		if(action.equalsIgnoreCase("u")){
			//multiple date periods submitted by users
        	if(dateFolder.contains("-")){
        		split = dateFolder.split("-");
        		dateFolder = split[0];  //first date period
        		while(Integer.parseInt(dateFolder) <= Integer.parseInt(split[1])){
        	       //have to catch January (01) month because the last month will be December (12)
			       //the lowest date period is 1901
        	       //if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       else{
        		      //date period greater than 1901
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       createPISandNMONList();
        	       dateFolder = String.valueOf((Integer.parseInt(dateFolder) + 1));
        		}
        	}
        	else{ //single date period submitted by users for update
        		//if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
         		   System.out.println("Date Period: " + datePeriod);
         	    }
         	    else{
         		   //date period greater than 1901
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
         		   System.out.println("Date Period: " + datePeriod);
         	    }
        			createPISandNMONList();	        			
        	}
        }
		else{ //roll-up
			System.out.println("Roll-up to Date Folder: " + dateFolder);
			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
      		   System.out.println("Date Period: " + datePeriod);
      	    }
			else{
      		   //date period greater than 1901
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
      		   System.out.println("Date Period: " + datePeriod);
      	    }
			createPISandNMONList(); //need to remember to put it back in after testing nmon records
		}	
	}
	
	/**
	 * fill out the pis and nmon list from resultset
	 */
	
	public void createPISandNMONList(){

		try{
			System.out.println("RollingPISv3.createPISandNMONList(): " + LocalDateTime.now());

			if(action.equalsIgnoreCase("r")){
				pisList = CommonUtil.connectDBForRollupString(spark, client, portfolio, begPeriod, datePeriod, pisRecordType, pisRecordTypeLength);
				nmonList = CommonUtil.connectDBForRollupString(spark, client, portfolio, begPeriod, datePeriod, nmonRecordType, nmonRecordTypeLength);
			}else{//update
				pisList = CommonUtil.connectDBForUpdateString(spark, client, portfolio, datePeriod, pisRecordType, pisRecordTypeLength);
				nmonList = CommonUtil.connectDBForUpdateString(spark, client, portfolio, datePeriod, nmonRecordType, nmonRecordTypeLength);
			}
            
			//make sure there are paths in pis11List or pis12List
			//it is require to have pis files before processing nmon files
			if(!pisList.isEmpty()){
				pisList = pisList.substring(0, pisList.lastIndexOf(","));
				System.out.println("pisList: " + pisList);
				//now insert into the oracle database of the record type and date processed
            	CommonUtil.connectDBForInsertChanges(client, portfolio, pisRecordType.toUpperCase(), datePeriod, LocalDate.now().toString());
				transformParquet(pisList, pisRecordType);
			}				
				//make sure there are paths in nmon11List or nmon20List
				if(!nmonList.isEmpty()){
					nmonList = nmonList.substring(0, nmonList.lastIndexOf(","));
					System.out.println("nmonList: " + nmonList);
					//now insert into the oracle database of the record type and date processed
	            	CommonUtil.connectDBForInsertChanges(client, portfolio, nmonRecordType.toUpperCase(), datePeriod, LocalDate.now().toString());
					transformParquet(nmonList, nmonRecordType);
				}
	
	        //now all transformations are done, merge the datasets only if one of the lists contain data
			if(!pisList.isEmpty() || !nmonList.isEmpty()){
				mergeDataset();
			}
			pisList = "";			
			nmonList = "";
		}
		catch(Exception e){e.printStackTrace();}
	}
	
    public void transformParquet(String inputPaths, String recordtype){
    	try{    		
    		System.out.println("RollingPISv3.transformParquet(): " + LocalDateTime.now());
                 /**
                  * Spark disables splitting for compressed files (eg .gz or .bz2) 
                  * and creates RDDs with only 1 partition depending on how many files in the folder
                  * Example: if reading two gzip text files, it will create 2 partitions
                  * Therefore, I have to repartition after reading in text files
                  */
    		      df = spark.read()
  				         .format("text")
  				         .option("inferSchema", false)
  				         .option("header", false)
  				         .load(inputPaths.split(",")); //to load different file locations using strings  
    		      df = df.repartition(200);
    		      
    			if(recordtype.equalsIgnoreCase("pis12") || recordtype.equalsIgnoreCase("pis11")){
    				System.out.println("Start filtering " + recordtype + " reject records");
    				rejectsPis = df.filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
    					return CommonUtil.checkRejectRecords(row, pisEndPos, pisRecordCreationDateBytes, recordtype);
    				});
    				
    				System.out.println("Start filtering " + recordtype + " good records");
    				//RowEncoder.apply(schema) no longer exist in Spark 3.5.0 and higher
    				//have to change to Encoders.row(schema)
    				//also added (Function1<Row, Object>) and (Function1<Row, Row>) <-- Caused by: java.io.NotSerializableException: RollingPISListv3$$Lambda$3541/660103401 when df.save()
    				//had to use strict java FilterFunction and MapFunction
    			   df = df.filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
					          return row.mkString().length() >= pisEndPos;}
        			        )
        			        .filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
        			        	return !CommonUtil.checkRecordCreationDatebyString(row, pisRecordCreationDateBytes);
        			        })
        			        .filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
        			        	return !CommonUtil.checkRecordType(row, recordtype);
        			        })
    					   .map((org.apache.spark.api.java.function.MapFunction<Row, Row>) row -> {
    				          return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
    			   }, Encoders.row(textSchema));
    			}

    			if(recordtype.equalsIgnoreCase("nmon20") || recordtype.equalsIgnoreCase("nmon11")){
    				System.out.println("Start filtering " + recordtype + " reject records");
    				rejectsNmon = df.filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
    					return CommonUtil.checkRejectRecords(row, nmonEndPos, nmonRecordCreationDateBytes, recordtype);
    				});
    				
    				System.out.println("Start filtering " + recordtype + " good records");
    				//RowEncoder.apply(schema) no longer exist in Spark 3.5.0 and higher
    				//have to change to Encoders.row(schema)
    				df = df.filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
					         return row.mkString().length() >= nmonEndPos;}
        			        )
        			        .filter((org.apache.spark.api.java.function.FilterFunction<Row>) row ->{
        			        	return !CommonUtil.checkRecordCreationDatebyString(row, nmonRecordCreationDateBytes);
        			        })
        			        .filter((org.apache.spark.api.java.function.FilterFunction<Row>) row -> {
        			        	return !CommonUtil.checkRecordType(row, recordtype);
        			        })
     					   .map((org.apache.spark.api.java.function.MapFunction<Row, Row>) row -> {
     				         return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, Encoders.row(textSchema));  
     			}

    			if(recordtype.contains("pis")){
    			   pisDF = CommonUtil.runMapReduce(df, recordtype, spark, nmbc, addFixes);
    			}
    			if(recordtype.contains("nmon")){
     			   nmonDF = CommonUtil.runMapReduce(df, recordtype, spark, nmbc, addFixes);
     			}
            
    	}catch(Exception e){e.printStackTrace(); System.exit(-1);}
    }

	public void mergeDataset(){
    	Dataset<Row> pastDF = null;
    	Dataset<Row> pastYYMMFull = null;
    	try{
    		System.out.println("RollingPISv3.mergeDataset(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(nmonDF != null){
            	System.out.println("RollingPISv3.mergeDataset(): nmonDF not null");
            	if(nmonRecordType.equalsIgnoreCase("nmon11")){
            		nmonDF = CommonUtil.getNmonDataset(nmonDF, spark, "select * from nmon where nonmonCode in ('3001','3003', '3100', '3101', '3102', '3103', '3104', '3105', '3109','3114', '3115', '3121', '3122', '3123', '3124', '3201')");
            	}
            	if(nmonRecordType.equalsIgnoreCase("nmon20")){
            		nmonDF = CommonUtil.getNmonDataset(nmonDF, spark, "select * from nmon where nonmonCode in ('3000','3010', '3100', '3102', '3104','3201')");
            	}
            }
            
          //both pis and nmon not null
            if(pisDF != null && nmonDF != null){
            	/**System.out.println("nmonDF # of columns: " + nmonDF.columns().length);
            	for(String column : nmonDF.columns()){
            		System.out.println("nmonDF column name: " + column);
            	}
            	System.out.println("pisDF # of columns: " + pisDF.columns().length);
            	for(String column : pisDF.columns()){
            		System.out.println("pisDF column name: " + column);
            	}**/
              	pisDF = pisDF.union(nmonDF);
              	System.out.println(pisRecordType + " unioned with " + nmonRecordType);
              	nmonDF.unpersist();
            }

            //assuming that rollup will always have pis files            
            if(action.equalsIgnoreCase("u")){
            	pastYYMMFull = CommonUtil.getLastUpdatedYYMM(fs, processedOutputDir.toString(), datePeriod, spark, pisRecordType);
            	pastDF = pastYYMMFull.select("*").where("trim(recordType) == \'" + pisRecordType.toUpperCase() + "\'");
            	if(pisDF != null){
                	pisDF = pisDF.union(pastDF);
                	System.out.println(pisRecordType + " unioned with " + datePeriod);
                }
                else{//pisDF is null and nmonDF is not null
                	pisDF = nmonDF.union(pastDF);
                }     
        	}                   
            
            pisDF = CommonUtil.runMapReduce(pisDF, pisRecordType, spark, nmbc, addFixes);
            System.out.println(pisRecordType + " ompleted final round of mapReducePIS");
                
            pisDF = pisDF.drop("nonmonCode");  //drop nonmonCode column
            //remove empty pans
            pisDF.createOrReplaceTempView("pisDF");
                
            pisDF = spark.sql("select * from pisDF where trim(pan) <> ''");
            System.out.println("removed blank pans");
            pisDF = spark.sql("select * from pisDF where checkValidDate(recordCreationDate) IS TRUE");
            System.out.println("removed invalid recordCreationDate");
        
            //drop the pandatetime before writing it back out as another parquet file
            pisDF = pisDF.drop("pandatetime");
            System.out.println("dropped pandatetime field");
            pisDF = pisDF.dropDuplicates();
            System.out.println("dropped duplicates");
            pisDF.createOrReplaceTempView("temp"); //check one more time
            pisDF = spark.sql("select * from temp where trim(pan) != ''");
            
            CommonUtil.writeParquet(pisDF, 10, "gzip", "overwrite", processedOutputDir + "/current_PIS/" + dateFolder);
            System.out.println("Completed " + processedOutputDir + "/current_PIS/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
            //pisDF.unpersist();
            
            System.out.println("Now check " + nmonRecordType + " reject records: " + LocalDateTime.now());
            if(rejectsNmon != null){
              if(!rejectsNmon.isEmpty()){
                  CommonUtil.writeParquet(rejectsNmon, 5, "gzip", "append", processedOutputDir + "/current_PIS/" + dateFolder + "/rejects/" + nmonRecordType);
              	  System.out.println("Finished writing nmon11 rejects: " + LocalDateTime.now());
              }
              else{
            	  System.out.println("rejectsNmon is not null and has 0 count:" + LocalDateTime.now());
              }
            }else{
              	  System.out.println("rejectsNmon is null: " + LocalDateTime.now());
            }
            
            
            System.out.println("Now check " + pisRecordType + " reject records: " + LocalDateTime.now());
            if(rejectsPis != null){
              if(!rejectsPis.isEmpty()){
            	  CommonUtil.writeParquet(rejectsPis, 5, "gzip", "append", processedOutputDir + "/current_PIS/" + dateFolder + "/rejects/" + pisRecordType);
            	  System.out.println("Finished writing pis11 rejects: " + LocalDateTime.now());
              }
              else{
            	  System.out.println("rejectsPis is not null and has 0 count:" + LocalDateTime.now());
              }
            }else{
            	  System.out.println("rejectsPis is null: " + LocalDateTime.now());
            }
            
            	 
            //now check other pis record types exist besides pisRecordType
            if(action.equalsIgnoreCase("u")){
              if(pisRecordType.equalsIgnoreCase("pis12")){
            	  pastYYMMFull = pastYYMMFull.select("*").where("trim(recordType) == \'PIS11\'");
            	  if(!pastYYMMFull.isEmpty()){
            		  CommonUtil.writeParquet(pastYYMMFull, 10, "gzip", "append", processedOutputDir + "/current_PIS/" + dateFolder);
            		  System.out.println("Processed " + pisRecordType + " but found PIS11 records from last date period: " + LocalDateTime.now());
            	  }
              }
            
              if(pisRecordType.equalsIgnoreCase("pis11")){
            	  pastYYMMFull = pastYYMMFull.select("*").where("trim(recordType) == \'PIS12\'");
                  if(!pastYYMMFull.isEmpty()){
                	  CommonUtil.writeParquet(pastYYMMFull, 10, "gzip", "append", processedOutputDir + "/current_PIS/" + dateFolder);
                	  System.out.println("Processed " + pisRecordType + " but found PIS12 records from last date period: " + LocalDateTime.now());
            	  }
              }
            }
                        
            //clear all pis and nmon dataset<row> for the next date period processing
            if(pisDF != null){
            	pisDF = null;
            }
            if(nmonDF != null){
                nmonDF = null;
            }           
            
    	}catch(Exception e){
    		e.printStackTrace();
    	 }  	
    }
}
