import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;

import lombok.Getter;
import lombok.Setter;

/**
 * 07/12/2021 This is a generic class to create 
 * the field objects and their byte positions
 * I had to make T extends the interface IFieldObj
 * so I can call the T.method() in this generic class
 * to set the FieldObj values
 * Basically saying T is subclass of IFieldObj and inherits all methods of IFieldObj (bound type generics)
 * https://docs.oracle.com/javase/specs/jls/se10/html/jls-4.html#jls-4.4 
 * @author JaneCheng
 * @param <T>
 * You should either have a generic class or a generic method
 */

@Getter @Setter
public class RecordTypeMapper<T extends IFieldObj> implements Serializable{

	private static final long serialVersionUID = 1L;
	//List represents an ordered sequence of objects
	List<T> pan = new ArrayList<T>();
	
	public RecordTypeMapper(){}
    
	/**
	 * This method will add in any object (o) with generic type T
	 * @param o
	 */
    public void addFieldObj(T o){
    	
    	pan.add(o);
    }
    	   
	   /**
	    * gets the List<RollingObj>
	    * @return fieldInfo
	    */
	 public List<T> getFieldObjList(){
		   
		   return pan;
	 }
	 
     /**
      * return the generic object only by index
      */
	 public T getFieldObj(int x){
		 return pan.get(x);
	 }
	 
	 /**
	  * collect all T values into Object[] for RowFactory.create
	  * @return Object[]
	  */
	 public Object[] getArray(){
		 
		 List<String> values = new ArrayList<String>();
		 for(int x=0; x < pan.size(); x++){
			 
			 values.add(pan.get(x).getValue());
		 }
		 return values.toArray();
	 }
	 
	 /**
	  * Set field value for each T fieldname using it's begPos and endPos
	  * @param record
	  */
	 
	 public void setFieldValue(String record){
		 
		//HDFS files have different positions than files stored on NFS disks (eg /dmsdisk2..)
	    // List<E> starts from 0 to N-1 where N is size() of list.

		   try{
			   //testing purposes
			   //System.out.println("record length: " + record.length());
			    for(int x=0; x < pan.size(); x++){ 
			    	
			      pan.get(x).setValueByRecord(record);  //calling T.setValueByRecord() method
			    }
		   }
		   catch(Exception e){e.printStackTrace();}
	 }
	 
	 /**
	  * Set field value for each T fieldname for Bancolumbia-F6 PIS files only
	  * @param record
	  */
	 public void setFieldValueBancolumbia(String record){
		 try{
			    for(int x=0; x < pan.size(); x++){ 
			    	
			      pan.get(x).setValueByBancolumbia(record);
			    }
		   }
		   catch(Exception e){e.printStackTrace();}
	 }
	 
	 /**
	  * Set field value for each T fieldname for ads-f6 files only
	  * @param record
	  */
	 public void setFieldValueADS(String record){
		 try{
			    for(int x=0; x < pan.size(); x++){ 
			    	
			      pan.get(x).setValueByADS(record);
			    }
		   }
		   catch(Exception e){e.printStackTrace();}
	 }
	 
	   /**
	     * RowFactory class return new GenericRow(Object...values); take in arrays
	     * GenericRow can be found in rows.scala and InternalRow.scala
	     * need to find a way to create rows in a generic way
	     * create a row to return 
	     * @return row
	     */
	    public Row getRow(){
	    	Row row = null;
	    	try{
	    		row = RowFactory.create(getArray()); //comes back as rows of FieldObj instead of row of strings
	    		/**row = RowFactory.create(pan.get(0).getValue(),
	    				pan.get(1).getValue(),
	    				pan.get(2).getValue());**/
	    	}catch(Exception e){e.printStackTrace();}
	    	return row;
	    }
	    
	    @Override
		public String toString(){
	    	
			String results = pan.get(0).getValue(); //get the first T value
			
			for(int x = 1; x < pan.size(); x++){
				
			   //separated by comma delimiter
			   //want the last string is value not comma
			   //get the rest of T values
				//found out that some client data has comma in them so not good idea to use comma as delimiter
				//have to use a tab \t
			   results = results + "\t" + pan.get(x).getValue();	
				
			}
			return results;
		}
 
}
