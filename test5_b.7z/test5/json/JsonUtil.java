package org.jc;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
//JsonReadFeature starts in jackson-core version 2.10.0
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.wnameless.json.flattener.JsonFlattener;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.GZIPInputStream;

/**
 * 03/07/2025 - this class will read in jsonl file and hash the values of given nodes/keys
 * then write out the header and TransactionDecisionRequest part
 * Google - how to get the json key using jackson in java; how to extract some parts of json file using jackson in java; how to update json value using jackson in java
 *
**/

public class JsonUtil {
    ObjectMapper mapper = null;
    JsonFactory factory = null;
    String field;
    int fieldID = 1;
    StringBuilder strBuilder = null;
    List<String> listResult = new ArrayList<>();
    String strInstanceID = "";
    String strResult = "";
    BufferedReader br;
    BufferedWriter bw;
    List<String> keyFieldNames = new ArrayList<>();
    private Map<String, Object> properties;  //json-flatter to flatten json to map
    Set<Map.Entry<String, Object>> mapEntry; //captures key-value pairs using Map.Entry interface
    private static Logger logger = LogManager.getLogger(JsonUtil.class);
    public void setFactory(){
        factory = JsonFactory.builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS).build();
    }

    public JsonFactory getFactory(){
        if(factory == null){
            factory = JsonFactory.builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS).build();
        }
        return factory;
    }

    /**
     * read the json string and returns the root node
     * @param jsonString
     * @return String
     */
    /**public String getInstanceInfo(String jsonString, String key) throws JsonProcessingException, IOException {
        mapper = new ObjectMapper(getFactory());
        return traverse(mapper.readTree(jsonString), key);
    }**/

    /**
     * read the json string and returns the list of instanceIds
     * @param jsonString
     * @param key
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    public List<String> getInstanceID(String jsonString, String key) throws JsonProcessingException, IOException {
        mapper = new ObjectMapper(getFactory());
        return traverseReturnList(mapper.readTree(jsonString), key);
    }

    /**
     * read a .json file
     * @param filename
     * @param key
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    /**public String readJsonFile(String filename, String key) throws JsonProcessingException, IOException{
        mapper = new ObjectMapper(getFactory());
        return traverse(mapper.readTree(new File(filename)), key);
    }**/

    public ObjectMapper getObjectMapper(){
        if(mapper == null){
            mapper = new ObjectMapper();
        }
        return mapper;
    }

    /**
     * go down the tree to get all nodes and values
     * this method works to traverse down the nodes
     * https://javaee.github.io/tutorial/jsonp001.html
     * Objects are enclosed in braces ({}), each individual name-value pairs are separated by a comma (,), and the name and
     * value in one pair are separated by a colon (:). Names in an object are strings, whereas values may be any of
     * the seven value types, including another object or an array.
     * Arrays are enclosed in brackets ([]), and their values are separated by a comma (,).
     * Each value in an array may be of a different type, including another array or an object
     * When objects and arrays contain other objects or arrays, the data has a tree-like structure
     * Be careful when returning a String because there might be multiple fields with same name but different values
     * and the returning String can be overridden by each of those values
     * @param node
     */
    public List<String> traverseReturnList(JsonNode node, String key) {
        if (node.isObject()) {  //is an Object
            //System.out.println("node: " + node);
            Iterator<String> iterator = node.fieldNames(); //get all field names of the object
            while (iterator.hasNext()) {
                field = iterator.next();  //gets the next element/node key name
                //System.out.println("field: " + field);
                JsonNode value = node.get(field); //returns the node value
                traverseReturnList(value, key); //it iterates the fields inside the object, get value and then keeps going to next field node
            }
        } else if (node.isArray()) {  //is an Array
            ArrayNode arrayNode = (ArrayNode) node;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                //System.out.println("Enter arrayNode");
                traverseReturnList(arrayElement, key); //goes down to all fields/nodes in an array
            }
        } else { //single field with value
            if (field.equalsIgnoreCase(key)) {
                if(key.equalsIgnoreCase("instanceId")){
                    //one instance id from user manually start EC2 instance
                    if(listResult.size() == 0){
                        listResult.add(node.textValue());
                    }
                    else{  //multiple instanceId
                        if(!node.textValue().equalsIgnoreCase(strInstanceID)) {
                            listResult.add(node.textValue());
                        }
                    }
                    strInstanceID = node.textValue();
                }
            }
        }
        return listResult;
    }

    public void traverse(JsonNode node) throws IOException{
        int count = 0;
        if (node.isObject()) {  //is an Object
            //System.out.println("node: " + node);
            Iterator<String> iterator = node.fieldNames(); //get all field names of the object
            while (iterator.hasNext()) {
                field = iterator.next();  //gets the next element/node key name
                //System.out.println("field: " + field);
                if(field.equalsIgnoreCase("header") && count == 0){
                    //JsonNode value = node.get(field); //returns the next node after header or transactionDecisionRequest
                    //we want the header or transactionDecisionRequest node
                    bw.write(String.valueOf(node));
                    bw.newLine();
                    count++;
                }else {
                    JsonNode value = node.get(field); //returns the node value
                    traverse(value); //it iterates the fields inside the object, get value and then keeps going to next field node
                }
            }
        }
       /** if (node.isArray()) {  //is an Array
            ArrayNode arrayNode = (ArrayNode) node;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                //System.out.println("Enter arrayNode");
                traverse(arrayElement); //goes down to all fields/nodes in an array
            }
        }**/
    }

    /**
     * hashRequiredJsonNode does not work with jsonNode.path()
     * @param node
     * @param bw
     */
    public void hashRequiredJsonNode(JsonNode node, BufferedWriter bw){
        String[] keys = null;
        JsonNode nodeExtract = null;
        try {
            //key = header.customerIdFromHeader or TransactionDecisionRequest.AccountInfo.StatementAddress.StreetLine1
            for (String key : keyFieldNames) {
                System.out.println("hashRequiredJsonNode: key: " + key);
                if (key.contains(".")) {
                    keys = key.split("\\.");
                    for (String keyName : keys) {
                        //System.out.println("hashRequiredJsonNode: keyname: " + keyName);
                        if (!node.path(keyName).isMissingNode()) {
                            nodeExtract = node.path(keyName);  //get to the wanted key
                            System.out.println("hashRequiredJsonNode: nodeExtract: " + nodeExtract);
                            //hash the wanted key
                            if(keyName.equalsIgnoreCase(keys[keys.length - 1])){
                                ((ObjectNode) node).put(keys[keys.length - 1], CommonUtil.hashing(nodeExtract.textValue()));
                            }
                        }
                    }
                } else {
                    nodeExtract = node.path(key);
                    if (!nodeExtract.isMissingNode()) {
                        System.out.println("hashRequiredJsonNode: nodeExtract: " + nodeExtract);
                        ((ObjectNode) node).put(key, CommonUtil.hashing(nodeExtract.textValue()));
                    }
                }
            }
            bw.write(String.valueOf(node));
            bw.newLine();
        }catch(Exception e){e.printStackTrace();}
    }
    //method to read in json string only
    /**public void hashRequiredJsonNode(String jsonString, BufferedWriter bw){
        String[] keys = null;
        JsonNode nodeExtract = null;
        try {
            //key = header.customerIdFromHeader or TransactionDecisionRequest.AccountInfo.StatementAddress.StreetLine1
                System.out.println("hashRequiredJsonNode: key: " + keyName);
                if (keyName.contains(".")) {
                    keys = keyName.split("\\.");
                    for (String key : keys) {
                        System.out.println("path not exist: " + node.path(key).isMissingNode());
                        if (!node.path(key).isMissingNode()) {
                            nodeExtract = node.path(key);  //get to the wanted key
                            System.out.println("hashRequiredJsonNode: nodeExtract: " + nodeExtract);
                            //hash the wanted key
                            if(key.equalsIgnoreCase(keys[keys.length - 1])){
                                System.out.println(CommonUtil.hashing(nodeExtract.textValue()));
                            }
                        }
                    }
                    //jsonNode.path() only works if given the whole path from start to finish
                    //System.out.println("test path: " + node.path("inputs").path("transactionDecision").path("data").path("header").path("customerIdFromHeader").textValue());
                    //does not work below because it is an object with other objects inside; result is null
                   // System.out.println("test path: " + node.path("inputs").path("transactionDecision").path("data").path("header").textValue());
                    //using jsonNode.get() does not work below
                    //System.out.println("using jsonNode get method: " + node.get("customerIdFromHeader").textValue());
                }
        }catch(Exception e){e.printStackTrace();}
    } **/

    /**
     * Read each newline-delimited Json (NDJSON) string from .jsonl (json line) file
     * and send the Json string to traverse method
     * https://stackoverflow.com/questions/3571223/how-do-i-get-the-file-extension-of-a-file-in-java
     */
    public void readJSONL(List<String> jsonList, String keyFileName){
        String content;
        String result;
        JsonNode node = null;
        JsonNode newNode = null;
        try{
            mapper = new ObjectMapper(getFactory());
            //bw = new BufferedWriter(new FileWriter(output, true));
            br = new BufferedReader(new FileReader(keyFileName));
            //put keyFieldNames into the list
            while((content = br.readLine()) != null){
                keyFieldNames.add(content);
            }
            //now read the jsonl file
            //get file extension
            if(!jsonList.isEmpty()){
                for(String jsonlFileName : jsonList){
                    bw = new BufferedWriter(new FileWriter(jsonlFileName.substring(0, jsonlFileName.indexOf("jsonl") - 1) + "_update.jsonl"));
                    br = new BufferedReader(new FileReader(jsonlFileName));
                    //skip first two header rows
                    br.readLine();
                    br.readLine();
                    while((content = br.readLine()) != null){
                        /**if (content.startsWith("{\"inputs\"")) {
                            System.out.println("readJSONL: found inputs: " + content);
                            //hashRequiredJsonNode(mapper.readTree(content), bw);
                            result = CommonUtil.hashp2fieldv2(content, keyFieldNames);
                            node = mapper.readTree(result);
                            bw.write("{\"header\":" + String.valueOf(node.path("inputs").path("transactionDecision").path("data").path("header")) + ",");
                            bw.write("\"transactionDecisionRequest\":" + String.valueOf(node.path("inputs").path("transactionDecision").path("data").path("transactionDecisionRequest")) + "}");
                            bw.newLine();
                            //traverse(mapper.readTree(result));
                        }**/
                        node = mapper.readTree(content);
                        if(!node.path("inputs").isMissingNode()){
                            System.out.println("found: " + node);
                            result = CommonUtil.hashp2fieldv2(String.valueOf(node), keyFieldNames);
                            newNode = mapper.readTree(result);
                            bw.write("{\"header\":" + newNode.path("inputs").path("transactionDecision").path("data").path("header") + ",");
                            bw.write("\"transactionDecisionRequest\":" + newNode.path("inputs").path("transactionDecision").path("data").path("transactionDecisionRequest") + "}");
                            bw.newLine();
                        }
                    }
                }
            }
            //System.out.println(FilenameUtils.getExtension(jsonlFileName));  to get file extension
            bw.flush();
            bw.close();
            br.close();
        }catch(Exception e){
            //logger.error("File {} not found in : {}", jsonList, e.getMessage());
            e.printStackTrace();
        }
    }

    public void setKeyFieldNames(String jsonlFileName, String keyFileName){
        String content = "";
        try{
            br = new BufferedReader(new FileReader(keyFileName));
            //put keyFieldNames into the list
            while((content = br.readLine()) != null){
                keyFieldNames.add(content);
            }
            bw = new BufferedWriter(new FileWriter(jsonlFileName + "_hashed.jsonl"));
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void closeAll(){
        try {
            if(bw != null) {
                bw.flush();
                bw.close();
            }
            if(br != null){
                br.close();
            }
        }catch(Exception e){e.printStackTrace();}
    }
    /**
     * process jsonl tar file
     * https://stackoverflow.com/questions/14515994/convert-json-string-to-pretty-print-json-output-using-jackson
     */
    public void readJSONL(String jsonString){
        String result;
        JsonNode node = null;
        JsonNode newNode = null;
        try{
            mapper = new ObjectMapper(getFactory());
                        /**if (content.startsWith("{\"inputs\"")) {
                         System.out.println("readJSONL: found inputs: " + content);
                         //hashRequiredJsonNode(mapper.readTree(content), bw);
                         result = CommonUtil.hashp2fieldv2(content, keyFieldNames);
                         node = mapper.readTree(result);
                         bw.write("{\"header\":" + String.valueOf(node.path("inputs").path("transactionDecision").path("data").path("header")) + ",");
                         bw.write("\"transactionDecisionRequest\":" + String.valueOf(node.path("inputs").path("transactionDecision").path("data").path("transactionDecisionRequest")) + "}");
                         bw.newLine();
                         //traverse(mapper.readTree(result));
                         }**/
                        node = mapper.readTree(jsonString);
                        if(!node.path("inputs").isMissingNode()){
                            //System.out.println("found: " + node);
                            result = CommonUtil.hashp2fieldv2(String.valueOf(node), keyFieldNames);
                            //System.out.println("result: " + result);
                            newNode = mapper.readTree(result);
                            bw.write("{\"header\":" + newNode.path("inputs").path("transactionDecision").path("data").path("header") + ",");
                            bw.write("\"transactionDecisionRequest\":" + newNode.path("inputs").path("transactionDecision").path("data").path("transactionDecisionRequest") + "}");
                            bw.newLine();
                        }

            //System.out.println(FilenameUtils.getExtension(jsonlFileName));  to get file extension
        }catch(JsonParseException e){
             System.out.println("cannot parse json string: " + jsonString);
             e.printStackTrace();
        } catch (JsonProcessingException e) {
            System.out.println("cannot process json string: " + jsonString);
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readJSONLWindows(String jsonString){
        String content;
        try{
            mapper = new ObjectMapper(getFactory());
            JsonNode node = mapper.readTree(jsonString);
            if(!node.path("inputs").isMissingNode()){
                System.out.println("found inputs node");
            }
            //traverseWindows(mapper.readTree(jsonString));
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void traverseWindows(JsonNode node) throws IOException{
        if (node.isObject()) {  //is an Object
            //System.out.println("node: " + node);
            Iterator<String> iterator = node.fieldNames(); //get all field names of the object
            while (iterator.hasNext()) {
                field = iterator.next();  //gets the next element/node key name
                System.out.println("field: " + field);
                if(field.equalsIgnoreCase("header") || field.equalsIgnoreCase("transactionDecisionRequest")){
                    //JsonNode value = node.get(field); //returns the node value of next field; we don't want that
                    System.out.println("traverseWindows: JsonNode: " + node); //we want the header or transactionDecisionRequest node
                }else {
                    JsonNode value = node.get(field); //returns the node value
                    traverseWindows(value); //it iterates the fields inside the object, get value and then keeps going to next field node
                }
            }
        }
        if (node.isArray()) {  //is an Array
            ArrayNode arrayNode = (ArrayNode) node;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                //System.out.println("Enter arrayNode");
                traverseWindows(arrayElement); //goes down to all fields/nodes in an array
            }
        }
    }

    /**
     * Read in a .jsonL file and use JsonFlattener utility to parse each record
     * only read in the number of records submitted by user
     * @param filename
     * @param output
     * @param numRecsToRead
     */
    public void callJsonFlattener(String filename, String output, int numRecsToRead){
        String content;
        int count = 0;
        try {
            File out = new File(output);
            if(out.exists()){
                out.delete();
            }
            if(getFactory() == null){
                setFactory();
            }
            bw = new BufferedWriter(new FileWriter(output, true));
            if(filename.endsWith(".gz")){
                br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filename))));
            }
            else{
                br = new BufferedReader(new FileReader(filename));
            }
            logger.info("Start reading {}: {}", filename, LocalDateTime.now());
            while((content = br.readLine()) != null){
                if(count < numRecsToRead) {
                    //withSeparator separates the key names with underscore instead of dot
                    //key names cannot contain dots in spark dataframes
                   // properties = new JsonFlattener(getJsonNode(content, false).toString()).withSeparator('.').flattenAsMap();
                   // mapEntry = properties.entrySet();
                   // writeKeys();
                   // writeValues();
                    bw.write(content);
                    bw.newLine();
                    count++;
                }
                else{ break;}
            }
            bw.flush();
            bw.close();
            logger.info("Finished reading {} records at {}", count, LocalDateTime.now());
        }catch(Exception e){
            logger.error("JsonProcessingException: {}", e.getMessage());
        }
    }

    //read the whole file
    public void callJsonFlattener(String filename, String output){
        String content;
        int count = 0;
        try {
            File out = new File(output);
            if(out.exists()){
                out.delete();
            }
            if(getFactory() == null){
                setFactory();
            }
            bw = new BufferedWriter(new FileWriter(output, true));
            if(filename.endsWith(".gz")){
                br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filename))));
            }
            else{
                br = new BufferedReader(new FileReader(filename));
            }
            logger.info("Start reading {}: {}", filename, LocalDateTime.now());
            while((content = br.readLine()) != null) {
                //withSeparator separates the key names with underscore instead of dot
                //key names cannot contain dots in spark dataframes
                properties = new JsonFlattener(getJsonNode(content, false).toString()).withSeparator('.').flattenAsMap();
                mapEntry = properties.entrySet();
                writeKeys();
                writeValues();
                count++;
            }
            bw.flush();
            bw.close();
            logger.info("Total records read {} at {}",count, LocalDateTime.now());
        }catch(Exception e){
            logger.error("JsonProcessingException: {}", e.getMessage());
        }
    }

    /**returns the root node
     * if the file is a regular .json file then you can read the whole file in
     * if the file is a .jsonL file then you can only use getJsonNode method to read each string
     * @param content
     * @param isFile
     * @return
     * @throws IOException
     */
    public JsonNode getJsonNode(String content, boolean isFile) throws IOException {
        /**
         * JsonFactory factory = new JsonFactory();
         *
         *        ObjectMapper mapper = new ObjectMapper(factory);
         *        JsonNode rootNode = mapper.readTree(json);
         *
         *        Iterator<Map.Entry<String,JsonNode>> fieldsIterator = rootNode.fields();
         *        while (fieldsIterator.hasNext()) {
         *
         *            Map.Entry<String,JsonNode> field = fieldsIterator.next();
         *            System.out.println("Key: " + field.getKey() + "\tValue:" + field.getValue());
         *        }
         */
        mapper = new ObjectMapper(factory);
        //properties = mapper.readValue(new File(filename), Map.class);  //did not work
        //JsonNode rootNode = mapper.readTree(filename);
        return isFile ? mapper.readTree(new File(content)) : mapper.readTree(content);

        /** Iterator<Map.Entry<String, JsonNode>> fieldsIterator = rootNode.fields();
         while(fieldsIterator.hasNext()) {
         Map.Entry<String, JsonNode> field = fieldsIterator.next();
         }**/

    }

    /**
     * write tab delimited keys only from Set<Map.Entry<k,v>>
     */
    public void writeKeys(){
        String key;
        int mapSizeCounter = 0;
        try {
            for (Map.Entry<String, Object> entry : mapEntry) {
                key = entry.getKey();
                key = key.substring(key.lastIndexOf(".") + 1);
                if (mapSizeCounter == mapEntry.size() - 1) {
                    //last key so don't need a tab at end
                    bw.write(key);
                } else {
                    bw.write(key + ",");
                    mapSizeCounter++;
                }
            }
            bw.newLine();
        }catch(Exception e) {
            logger.error("Write Keys Exception: {}", e.getMessage());
        }
    }

    /**
     * write tab delimited values only from Set<Map.Entry<k,v>>
     */
    public void writeValues(){
        String value;
        int mapSizeCounter = 0;
        try {
            for (Map.Entry<String, Object> entry : mapEntry) {
                value = entry.getValue().toString();
                if (mapSizeCounter == mapEntry.size() - 1) {
                    //last key so don't need a tab at end
                    bw.write(value);
                } else {
                    bw.write(value + ",");
                    mapSizeCounter++;
                }
            }
            bw.newLine();
        }catch(Exception e) {
            logger.error("Write Keys Exception: {}", e.getMessage());
        }
    }
}
