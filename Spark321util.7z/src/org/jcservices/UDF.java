package org.jcservices;

import java.util.Random;

import org.apache.spark.sql.api.java.UDF1;


/**
 * Java UserDefinedFunction for Spark SQLContext
 * This UDF will generate random number for partitionID
 * @author JaneCheng
 *
 */
public class UDF implements UDF1<Integer, Integer>{

	private static final long serialVersionUID = 1L;
	Random r = new Random();
	
	
	@Override
	public Integer call(Integer columnValue) throws Exception {
		
		return r.nextInt(51);
	}

}