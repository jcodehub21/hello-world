
public class HowToRunRollingPIS {
	
	/**
	 * 01/04/2023:
	 * On BP rhlappfrd60005, you need to be fmtdata to use /dmsdisks.  file format = dd; pisBegPos-pisEndPos nmonBegPos-nmonEndPos
	 * spark2-submit --master yarn --deploy-mode client --executor-memory 40g --num-executors 2 --executor-cores 1 --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class RollingPISv2 /home/janecheng/RollingPISNMONv2.jar fiserv-eft-f6 none 1905 r /data/rollingPIS_test dd 80-641 80-2213 > /apps/jyc/fiserv-eft-f6-none_pis_rollup_1905_01042023.log 2>&1 &
	 * 
	 * On BP rhlappfrd60005, you can use user janecheng as long as 'newgrp ipfrd'
	 * spark2-submit --master yarn --deploy-mode client --executor-memory 40g --num-executors 2 --executor-cores 1 --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class RollingPISv2 /home/janecheng/RollingPISNMONv2.jar fiserv-eft-f6 none 1906 u /data/rollingPIS_test rf > /apps/jyc/fiserv-eft-f6-none_pis_update_1906_01042023.log 2>&1 &
	 * 
	 * 12/14/2022: for rollup using Cloudera Spark 3.2.1 JDBC with network.timeout and on SHK cluster using RollingPISParquet class and RollingPISNMONv2.jar:
	 * export JAVA_HOME=/ptoan/dms_staging/parquet/jdk1.8.0_231
	 * export PATH=$JAVA_HOME/bin:$PATH
	 * spark3-submit --master yarn --deploy-mode client --executor-memory 40g --num-executors 2 --executor-cores 1 --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class RollingPISParquet /home/janecheng/RollingPISNMONv2.jar cfg-f6 none 2008 r /work/mapping > /home/janecheng/cfg-f6-none_pis_rollup_2008_12162022.log 2>&1 &
	 * spark3-submit --master yarn --deploy-mode client --executor-memory 40g --num-executors 2 --executor-cores 1 --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class RollingPISParquet /home/janecheng/RollingPISNMONv2.jar cfg-f6 none 2212 u /work/mapping > /home/janecheng/cfg-f6-none_pis_update_2212_12212022.log 2>&1 &
	 * 
	 * 10/13/2022: for rollup using Spark 3.0.1 JDBC with network.timeout and on SHK cluster: If using class RollingPISv2, you have to add either 'rf' or 'dd pisBegPos-pisEndPos nmonBegPos-nmonEndPos' parameters
	 * export JAVA_HOME=/ptoan/dms_staging/parquet/jdk1.8.0_231
	 * export SPARK_HOME=/ptoan/shared/opt/spark/spark-3.0.1-bin-without-hadoop
	 * export PATH=$SPARK_HOME/bin:$JAVA_HOME/bin:$PATH
	 * spark-submit --master yarn --deploy-mode client --executor-memory 40g --num-executors 2 --executor-cores 1 --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class RollingPISParquet /home/janecheng/RollingPISNMONv2.jar cfg-f6 none 2008 r /work/mapping > /home/janecheng/cfg-f6-none_pis_rollup_2008_12162022.log 2>&1 &
	 * spark-submit --master yarn --deploy-mode client --executor-memory 40g --num-executors 2 --executor-cores 1 --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class RollingPISParquet /home/janecheng/RollingPISNMONv2.jar cfg-f6 none 2212 u /work/mapping > /home/janecheng/cfg-f6-none_pis_update_2212_12212022.log 2>&1 &
	 */
	
	/**
	 * To update a parquet field:
	 * SHK: /home/janecheng/cfg-f6_parquetupdate.txt contains list of parquet files location to update
     * spark3-submit --master yarn --deploy-mode client --executor-memory 40g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class ParquetFieldUtil /home/janecheng/RollingPISNMONv2.jar numberOfPaymentIds 001 /home/janecheng/cfg-f6_parquetupdate.txt > /home/janecheng/parquetfieldutil.log 2>&1 &
	 */

}
