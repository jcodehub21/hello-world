DECLARE
    FILEhandle  UTL_FILE.FILE_TYPE;
BEGIN
        FILEhandle := UTL_FILE.FOPEN('ADMBIN', 'rectypedef.tsv','W');
        FOR cc IN (SELECT recordtype||CHR(9)||startpos||CHR(9)||fieldlen||CHR(9)||fieldname AS a FROM recordtypedef ORDER BY recordtype, startpos)
        LOOP
            UTL_FILE.PUT_LINE(FILEhandle, cc.a);
        END LOOP;  
        UTL_FILE.FCLOSE(FILEhandle);

        -- had to change HDFSTA_TSV location to ADMBIN (/mdswork/prd/bin) since move to SHK.  /ptoan/dms_staging/parquet does not work to write the file to in SHK.
        UTL_FILE.FREMOVE('ADMBIN', 'DMSrecordTypes.csv');
        FILEhandle := UTL_FILE.FOPEN('ADMBIN', 'DMSrecordTypes.csv','W');
        FOR cc IN (SELECT recordtype||','|| field# ||','|| fieldname ||','|| fieldlen||','||fieldtype AS a
                     FROM (
                    SELECT recordtype, ROW_NUMBER() OVER (PARTITION BY recordtype ORDER BY startpos) AS field#
                          , NVL(x.proper_name, d.fieldname) AS fieldname, fieldlen,
                           (CASE WHEN fieldname IN ('score_3','score_4','score_5','score_6','score_7','score_8','score_9','score_10','filler1_2','filler2_2')
                                 THEN 'INT32'
                                 WHEN fieldname = 'FEED_VALIDATION_ERROR' THEN 'INT16'
                                 ELSE 'String'
                            END) AS fieldtype
                      FROM recordtypedef d, name_translation x
                     WHERE recordtype IN (SELECT recordtype FROM recordtype_falcon6 UNION ALL SELECT recordtype_post FROM recordtype_falcon6)
                       AND d.fieldname <> 'tagX'
                       AND UPPER(d.fieldname) = UPPER(x.dms_name(+))
                     ORDER BY 1, 2)
                  )
        LOOP
            UTL_FILE.PUT_LINE(FILEhandle, cc.a);
        END LOOP;  
        UTL_FILE.FCLOSE(FILEhandle);
END;