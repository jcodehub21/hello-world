package org.jc.udf.athena;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class HashUDF implements RequestHandler<Map<String, Object>, String> {

	@Override
    public String handleRequest(Map<String,Object> input, Context context) {
        context.getLogger().log("Input: " + input);
        //implement handler
        //have to convert the hashmap coming in to a Set first before converting to Entry
        // Convert HashMap<K, V> to Set<Map.Entry<K, V>>
        //entrySet() returns a collection of Entry
        Set<Entry<String, Object>> set = input.entrySet();
        //Map.Entry<String, String> is a single entry while Set is a map of items/list
        //need to iterate the set to use each entry item
        //you cannot cast a Set<Map.Entry<String, String>> as a single Map.Entry<String, String>
		//set.iterator().next() iterates to the first entry item of the set
        Map.Entry<String, Object> entry = set.iterator().next();
        String value = new String();
        value = entry.getValue().toString();
       
        return value;
    }
    
    

}
