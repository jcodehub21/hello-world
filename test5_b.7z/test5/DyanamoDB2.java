package jc.lambda.util;

import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


import java.util.ArrayList;
import java.util.List;

public class DyanamoDB2 {

    DynamoDB dynamo;
    List<KeySchemaElement> keySchema = new ArrayList<KeySchemaElement>(); //collection
    List<AttributeDefinition> attributes = new ArrayList<AttributeDefinition>(); //collection
    private static Logger logger = LogManager.getLogger(DyanamoDB2.class);

    public void setDynamo(String region){
        dynamo = CommonOps.getDynamoDBClient(region);
    }

    /**
     * create table with key schema element
     * In Amazon DynamoDB, a database is a collection of tables (no specific database)
     * A table is a collection of items and each item is a collection of attributes.
     * All the tables are just under your aws account
     *
     * public KeySchemaElement(String attributeName, KeyType keyType)
     * Parameters:
     *   attributeName - The name of a key attribute.
     *   keyType - The role that this key attribute will assume:
     *       HASH - partition key
     *
     *       RANGE - sort key
     *
     *  Primary key = partition key + sort key
     *
     * public AttributeDefinition(String attributeName,ScalarAttributeType attributeType)
     * Parameters:
     *   attributeName - A name for the attribute.
     *   attributeType - The data type for the attribute, where:
     *      S - the attribute is of type String
     *
     *      N - the attribute is of type Number
     *
     *      B - the attribute is of type Binary
     */
    public void createTable(String tableName, String hashName, String rangeName){

        Table table;
        AttributeDefinition field1;
        AttributeDefinition field2;
        KeySchemaElement hash;
        KeySchemaElement range;
        try{
            //check if table exists or not by retrieving TableDescription
            //Table.getDescription() = Returns the table description;
            //or null if the table description has not yet been described via describe(). No network call.
            if(dynamo.getTable(tableName).getDescription() == null){
                //DynamoDB.createTable requires KeySchema and AttributeDefinition to be the same number of fields and names
                //DynamoDB.createTable requires hash and range keys only.
                field1 = new AttributeDefinition(hashName, ScalarAttributeType.S);
                field2 = new AttributeDefinition(rangeName, ScalarAttributeType.S);

                attributes.add(field1);
                attributes.add(field2);

                //cannot update hash and range because they are part of the key
                //hash and range must be the same as the AttributeDefinition field names
                hash = new KeySchemaElement(hashName, KeyType.HASH);
                range = new KeySchemaElement(rangeName, KeyType.RANGE);
                keySchema.add(hash);
                keySchema.add(range);
                //create a table request with required attributes
                //AWS required to put a ProvisionedThroughput WriteCapcityUnits and ReadCapacityUnits
                //CreateTableRequest tableRequest = new CreateTableRequest(attributes, tableName, keySchema, new ProvisionedThroughput(10L, 10L));

                //Create a table request with On-Demand billing instead of Provisioned to save money
                CreateTableRequest tableRequest = new CreateTableRequest();
                tableRequest.setAttributeDefinitions(attributes);
                tableRequest.setTableName(tableName);
                tableRequest.setKeySchema(keySchema);
                tableRequest.setBillingMode("PAY_PER_REQUEST");

                //create table
                table = dynamo.createTable(tableRequest);
                table.waitForActive();  //returns TableDescription
                System.out.println("Success.  Table status: " + table.getDescription().getTableStatus());
            }

        }catch (Exception e){
            System.err.println("Unable to create table: ");
            /**
             * 2 validation errors detected:
             * Value null at 'provisionedThroughput.writeCapacityUnits' failed to satisfy constraint:
             * Member must not be null;
             * Value null at 'provisionedThroughput.readCapacityUnits' failed to satisfy constraint:
             * Member must not be null
             */
            System.err.println(e.getMessage());
        }
    }
}
