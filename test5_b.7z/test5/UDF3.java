import org.apache.spark.sql.api.java.UDF1;


public class UDF3 implements UDF1<String, String>{

	/**
	 * Java UserDefinedFunction for Spark SQLContext
	 * This UDF3 will substring the YYMM from the dt (date-timestamped) column from CCS file
	 * @author JaneCheng
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	public String call(String columnValue) throws Exception {
		
		return columnValue.substring(2,4) + columnValue.substring(5,7);
	}
}
