select filename from filestorage where filename like '/dmsdisk%/FDR-C-F6/NONE/%fdr-c-f6.none.nmon20%' and yymm = '2001' and filestatus = 'O' and filetype = 'O';

select filename from filestorage where filename like '/dmsdisk%/FDR-E-F6/NONE/%fdr-e-f6.none.pis12%' and yymm = '1912' and filestatus = 'O' and filetype = 'O' order by fileid desc;

select filename from filestorage where filename like '/dmsdisk%/FDR-E-F6/NONE/%fdr-e-f6.none.pis12%' and yymm between '1801' and '1911' and filestatus = 'O' and filetype = 'O' order by fileid desc;

-- to find total file size
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-C-F6/NONE/%fdr-c-f6.none.%tran25_Auths%' and yymm = '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-E-F6/NONE/%fdr-e-f6.none.%tran25_Auths%' and yymm = '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-E-F6/NONE/%fdr-e-f6.none.%tran25_Auths%' and yymm = '2002' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-B-F6/NONE/%fdr-b-f6.none.%tran25_Auths%' and yymm = '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-C-F6/NONE/%fdr-c-f6.none.pis12%' and yymm between '1801' and '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-E-F6/NONE/%fdr-e-f6.none.pis12%' and yymm between '1801' and '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), sum(filesize) from filestorage where filename like '/dmsdisk%/FDR-B-F6/NONE/%fdr-b-f6.none.pis12%' and yymm between '1801' and '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-C-F6/NONE/%fdr-c-f6.none.nmon20%' and yymm between '1801' and '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-E-F6/NONE/%fdr-e-f6.none.nmon20%' and yymm between '1801' and '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';
select sum(numrows), round(sum(filesize)/1024/1024/1024) from filestorage where filename like '/dmsdisk%/FDR-B-F6/NONE/%fdr-b-f6.none.nmon20%' and yymm between '1801' and '2001' and (filestatus = 'O' or filestatus = 'A') and filetype = 'O';

select sum(filesize) from filestorage where filename like '/dmsdisk%/FDR-B-F6/NONE/%fdr-b-f6.none.pis12%' and yymm between '1801' and '2001' and (filestatus = 'O') and filetype = 'O';
select sum(filesize) from filestorage where filename like '/dmsdisk%/FDR-B-F6/NONE/%fdr-b-f6.none.pis12%' and yymm = '1801' and filestatus = 'O' and filetype = 'O';

select * from filestorage where fileid = 10534680;

-- for SFX fraud files on BP

select 'file://' || filename from filestorage where filename like '/dmsdisk%/FDR-%/%/2212/%.sm_fraud_sorted.%' and filestatus = 'O' and filetype = 'R';

--- for SFX fraud files on SHK
select 'file://' || filename from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/FDR-%/%/2402/%.sm_fraud_sorted.%' and filestatus = 'O' and filetype = 'R';

--- for RBS files on SHK
select filename from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%/2305/%rbs-f6.dbt.pis%' and filestatus = 'O' and filetype = 'O';

select filename from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%/2305/%rbs-f6.dbt.frd%' and filestatus = 'O' and filetype = 'O';

select filename from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%/2305/%rbs-f6.dbt.dbtran%_Auths%' and filestatus = 'O' and filetype = 'O';

-- insert all RBS files that were mapped into change log table or manual_changes
select fileid from manual_changes where note = 'rbs-f6(debit) pan mapping';

insert into manual_changes values ('12487218', DATE '2023-07-10', 'rbs-f6(debit) pan mapping', 'JaneCheng');

-- to find RBS files that are not mapped after all mapping completes
select filename, yymm from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%rbs-f6.dbt.pis%' and yymm between '2109' and '2305' and filestatus = 'O' and filetype = 'O' 
and fileid not in (select fileid from manual_changes where note = 'rbs-f6(debit) pan mapping');

select filename, yymm from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%rbs-f6.dbt.dbtran25_Auth%' and yymm between '2109' and '2305' and filestatus = 'O' and filetype = 'O' 
and fileid not in (select fileid from manual_changes where note = 'rbs-f6(debit) pan mapping');

select filename, yymm from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%rbs-f6.dbt.frd%' and yymm between '2111' and '2305' and filestatus = 'O' and filetype = 'O' 
and fileid not in (select fileid from manual_changes where note = 'rbs-f6(debit) pan mapping');

select count(filename) from filestorage where filename like '/ptoan/datamgmt/dmsdisk%/RBS-F6/%rbs-f6.dbt.frd%' and yymm between '2111' and '2306' and filestatus = 'O' and filetype = 'O';

-- ADS Mapping for crtran25 (reclength = 2722), frd13 (2557), nmon20 (3877) and pis12 (3403)

select filename from filestorage where filename like '/dmsdisk%/prd/arch/FALCON/ADS-F6/CREDIT/%/%.ads-f6.cdt.nmon20.%.3877.ascii.bz2' and filestatus = 'O' and filetype = 'O' order by yymm desc;