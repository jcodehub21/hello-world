package org.jcservices;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.apache.spark.sql.SparkSession;
import lombok.Getter;

public class CommonUtil implements Serializable{

	private static final long serialVersionUID = 1L;
	@Getter
	private static HashMap<String, Long> timer = new LinkedHashMap<String, Long>();
   
	public static SparkSession getSparkSession(String appname) {
		return SparkSession
	  			  .builder()
	  			  .appName(appname)
	  			  .master("local")
	  			  .config("spark.sql.debug.maxToStringFields", 2000)
	  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
	  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
	  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
	  			  .getOrCreate();
	}
	
	public static void recordProcessTime(String message) {
		timer.put(message, System.nanoTime());
	}
	
    
}
