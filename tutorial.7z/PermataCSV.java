import java.io.Serializable;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.PathFilter;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.DataTypes;
//import org.apache.spark.sql.functions;


/**
 * 09/02/2021 - encrypt Customeracctnumber and pan in FRD csv file and 
 * write out a new csv file; run on BP Spark cluster
 * rhlappfrd60005: 
 * newgrp ipfrd
 * spark2-submit --master yarn --deploy-mode client --driver-memory 5g --executor-memory 10g --class PermataCSV /home/janecheng/ADEUtil.jar > /apps/jyc/permatacsv.log 2>&1 & 
 * 
 * 10/6/2021:  changed to below: need to execute as janecheng
 * spark2-submit --master yarn --deploy-mode client --driver-memory 5g --executor-memory 10g --class PermataCSV /home/janecheng/ADEUtil.jar /data/rollingPIS_test/csv > /apps/jyc/permatacsv.log 2>&1 & 
 * @author JaneCheng
 *
 */
public class PermataCSV implements PathFilter, Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> df = null;
	Dataset<Row> hashed = null;
	static FileSystem fs = null;
	static Configuration conf = null;
	//static String hdfsCSVDir = "/data/rollingPIS_test/csv";
	//static String hdfsCSVDir = "C:\\software\\eclipse_luna_4.4_projects\\ADEUtil";
	UDF1<String, String> udf = null; //interface
	UDF1<String, String> udf2 = null;  //interface
	
	public static void main(String[] args){
		PermataCSV csv = new PermataCSV();
		PathFilter filter = new PermataCSV();
		csv.startSparkSession();
		conf = new Configuration();
		try{
		  fs = FileSystem.get(conf);
		  //Path csvPath = new Path(hdfsCSVDir);
		  Path csvPath = new Path(args[0]);  //allow user to enter a hdfs CSV directory to process csv files eg. /data/rollingPIS_test/csv
		  if(fs.exists(csvPath)){
			  FileStatus[] filestatus = fs.listStatus(csvPath, filter);
			  for(FileStatus eachFile : filestatus){
				  csv.encryptCSV(eachFile.getPath(), args[0]);
			  }
		  }
		  
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	public void startSparkSession(){
		spark = SparkSession.builder()
				//.master("local")
				.appName("Permata CSV Processing")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("warn");
		//register UDF and UDF2
		//UDF1<String, String> is an interface so need to create a class that implements the UDF1 interface
		//in order to be to instantiate; here UDF() and UDF2 are classes that implements UDF1<String,String>
	    udf = new UDF();
	    udf2 = new UDF2();
	    //register the user defined funciton in spark
	    spark.udf().register("udf1", udf, DataTypes.StringType);
	    spark.udf().register("udf2", udf2, DataTypes.StringType);
	}
	
	public void encryptCSV(Path filename, String hdfsCSVDir){
		String query = "select ";
		FileStatus[] listFiles = null;
		System.out.println("Filename to process: " + filename);
		try{
			df = spark.read().format("csv").option("header", true).option("sep", ",").load(filename.toString());
			df = df.select("*").where(df.col("Pan").isNotNull());  //get rid of blank records in permata csv files
			String[] columns = df.columns();
			
            for(String columnName : columns){
  		    	
  		    	if(columnName.equalsIgnoreCase("Customeracctnumber")){
  		    		
  		    		query = query + "udf2(" + columnName + ") as Customeracctnumber, ";
  		    	}
  		    	else if(columnName.equalsIgnoreCase("pan")){
  		    		
  		    		query = query + "udf1(" + columnName + ") as pan, ";
  		    	}
  		    	else{
  		    		
  		    		query = query + columnName + ", ";
  		    	 }
  		      }
            
            query = query.substring(0, query.lastIndexOf(",")); //remove last comma
            //System.out.println("query: " + query);
            df.createOrReplaceTempView("csv");
			hashed = spark.sql(query + " from csv");
			//hashed.select("pan").show(20, false);
			//had to take out overwrite mode because hashed files are stored in same directory
			//had to put back in overwrite mode because spark was complaining about the hashed directory already exists
			hashed.coalesce(1).write().mode("overwrite").option("header", true).csv(hdfsCSVDir + "/temp");
			//hashed.coalesce(1).write().mode("overwrite").option("header", true).csv(hdfsCSVDir + "\\hashed");
			
			//rename the hashed csv 
			//FileStatus object contains the metadata for the file not just the path
			listFiles = fs.listStatus(new Path(hdfsCSVDir + "/temp"));
			for(FileStatus csvFile : listFiles){
				if(csvFile.getPath().getName().startsWith("part-00000")){
					System.out.println(csvFile.getPath());
					//FileSystem.rename(Source_path, destination_path) actually moves the file to the new destination
					fs.rename(csvFile.getPath(), new Path(hdfsCSVDir + "/hashed/" + filename.getName().substring(0, filename.getName().indexOf(".csv")) + "_hashed.csv"));
					
				}
			}
			
		}catch(Exception e){e.printStackTrace();}
	}

	@Override
	public boolean accept(Path arg0) {
		
		return arg0.getName().endsWith(".csv");
	}

}
