import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;


public class CSVUtil implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	static BufferedReader br = null;
	static BufferedWriter bw = null;
	Dataset<Row> dataFile = null;
	StructType textSchema = null;
	static FileSystem fs;
	static Configuration conf;
	static FileStatus[] list_files = null;
	String pattern = "^part-.+\\.bz2$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	
	public static void main(String[] args){
		CSVUtil util = new CSVUtil();
		//util.startSparkSession();
		//util.createCSV("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\1601.akbank-f6.none.pis12.3683804.1713.ascii_processed.bz2");
		util.createCSV(args[0]);
		//util.loadCSV();
		//util.showFilesize();
	}
	/**public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("AKBANK-F6 CSV")
				.master("local")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
	}**/
	
	public void createCSV(String filename){
		String content;
		//RecordTypeMapper<FieldObj> fieldObj = AkbankRecordType.getRecordTypeMapper("pis12");
	   try{
		   if(filename.endsWith(".bz2")){
			   br = new BufferedReader(new InputStreamReader(new BZip2CompressorInputStream(new FileInputStream(filename))));
			   bw = new BufferedWriter(new FileWriter(filename.substring(0, filename.lastIndexOf(".bz2")) + ".csv"));
		   }else if(filename.endsWith(".gz")){
			   br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filename))));
			   bw = new BufferedWriter(new FileWriter(filename.substring(0, filename.lastIndexOf(".gz")) + ".csv"));
		   }else{  //plain ascii file or other
			   br = new BufferedReader(new FileReader(filename));
			   bw = new BufferedWriter(new FileWriter(filename + ".csv"));
		   }
		   
		  // br = new BufferedReader(new FileReader("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii"));
		   while((content = br.readLine()) != null){
			   //content = content.replace('\u00ef', ' ').replace('\u00bf', ' ').replace('\u00bd', ' ');  //have to replaced up here in new csv
			   System.out.println(content.indexOf("�"));
			   
			   /**
			    * On Windows my Java in Eclipse can detect � because it is Windows-1252 (or cp1252) so it will replace 
			    * � with an empty space.  However, when I move my CSVUtil.class to lux433 it was not able to detect
			    * � so it was not replaced with an empty string.  
			    * Found out that in Linux the � is considered UTF-8 encoding while my compiled class on eclipse is UTF-16 or even if written in UTF-8.
			    * So had to re-compile my code in Linux:
			    * /Anton/jyc_temp/jdk1.8.0_231/bin/javac -encoding UTF-8 -cp .:/ana/mds/prd/data/files/INCOMING/jane_temp:/Anton/jyc_temp/spark-3.0.1-bin-hadoop3.2/jars/* CSVUtil.java
			    */
			   //content = content.replace("�", " ");
			   content = content.replace("\uFFFD", " ");  //this one works without compiling with encoding UTF-8
			  // fieldObj.setFieldValue(content);
			  // bw.write(fieldObj.toString());
			   bw.write(content);
			   bw.newLine();
		   }
		   br.close();
		   bw.close();
		   
		  // loadCSV(filename);
		   
	   }catch(Exception e){e.printStackTrace();}
	}
	
	public void loadCSV(String filename){
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		dataFile = spark.read().option("delimiter", ",").csv("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii.csv");
		dataFile = dataFile.select("*").where("_c1 == '45522518blSPityR1Bk'");
		dataFile = dataFile.map(row -> {
			//String replace = row.mkString().replace('\u00ef', ' ').replace('\u00bf', ' ').replace('\u00bd', ' '); //did not work
			  return RowFactory.create(row.mkString());	
			  //return RowFactory.create(replace);
		  }, RowEncoder.apply(textSchema));
		dataFile.coalesce(1).write().format("text").option("compression","bzip2")
		//.option("encoding", "ignore")
		.save("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\csv");
		
		try{
		conf = new Configuration();
	     fs = FileSystem.get(conf);
	     
	     filePattern = Pattern.compile(pattern);
		    
 		  list_files = fs.listStatus(new Path("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\csv"));
 		  
	  		for(FileStatus oldFilePath : list_files){
		    	
 	           m = filePattern.matcher(oldFilePath.getPath().getName());
 	           if(m.matches()){
 	        	   //fs.rename also moved the new filename to another path
 	        	   fs.rename(oldFilePath.getPath(), new Path("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\csv\\" + filename.substring(filename.lastIndexOf("\\") + 1)));
 	        	   
 	           }
 	        }
 		  
		}catch(Exception e){e.printStackTrace();}
	     
	}
	
	public void showFilesize(){
		
		try{
		    String path = "C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii.csv"; 
		     Path filePath = new Path(path);
		     System.out.println("filePath: " + filePath);
		     
		     File file = new File(path);
			System.out.println("file length: " + file.length());
			
			System.out.println("using FileUtils: " + FileUtils.sizeOf(file));
		}catch(Exception e){e.printStackTrace();}
	}
}
