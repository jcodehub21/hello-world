import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

/**
 * 03/29/2022 - This class will print out file id and record counts quickly
 * @author JaneCheng
 *
 *  spark2-submit --master yarn --deploy-mode client --driver-memory 20g --executor-memory 20g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=2g --conf spark.executor.heartbeatInterval=10000000 --class HdfsFileRecordCount /home/janecheng/ADEUtilv6.jar /work/fdrMapping/parquet2check2.txt > /apps/jyc/ParquetRecordCount5.log 2>&1 &
 *  
 *  spark2-submit --master local --driver-memory 20g --executor-memory 20g --class HdfsFileRecordCount /home/janecheng/ADEUtilv6.jar /work/fdrMapping/parquet2check2.txt > /apps/jyc/ParquetRecordCount5.log 2>&1 &
 */
public class HdfsFileRecordCount implements Serializable{
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> file = null;
	Configuration conf = null;
	FileSystem fs = null;

	public static void main(String[] args) {
		HdfsFileRecordCount count = new HdfsFileRecordCount();
        count.startSparkSession();
        //count.readList(args[0]);
        count.getRecordCount(args[0]);
       // count.closeAll();
	}

    public void startSparkSession(){
		
		spark = SparkSession
	  			  .builder()
	  			  .appName("Test Reading HDFS Files")
	  			  .config("spark.dynamicAllocation.enabled", "false")
	  			  .config("spark.locality.wait", "0s")
	  			  .config("spark.locality.wait.node", 0)
	  			  .config("spark.locality.wait.executor", 0)
	  			  .config("spark.debug.maxToStringFields", 2000)
	  			  .config("spark.sql.debug.maxToStringFields", 4000)
	  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
	  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
	  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
	  			  .getOrCreate();
	  	  
	  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
	      spark.sparkContext().setLogLevel("WARN");

		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		}catch(Exception e){e.printStackTrace();}
	}
    
    public void readList(String inputFile){
    	String content = "";
    	try{
    	  BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(new Path(inputFile))));
    	  while((content = br.readLine())!= null){
               getRecordCount(content);
    	  }
    	  
    	}catch(Exception e){e.printStackTrace();}
    }
    public void getRecordCount(String filename){
    	try{
            if(fs.exists(new Path(filename))){
    	      file = spark.read().parquet(filename);
    	      System.out.println(filename + " - Record Count: " + file.count());
            }
            else{
            	System.out.println(filename + " does not exist");
            }
    	}catch(Exception e){e.printStackTrace();}
    }
    
    public void closeAll(){
		try{
			if(fs != null){
				fs.close();
			}
		}catch(Exception e){e.printStackTrace();}
	}
}
