import java.io.Serializable;

import org.apache.spark.sql.types.DataType;

public class RollingObj implements Serializable{

	private static final long serialVersionUID = 1L;
	String fieldName;
	String value;
	DataType dataType;
	int begPos;
	int endPos;
	
    public RollingObj(String name, int start, int end){
		
		fieldName = name;
		begPos = start;
		endPos = end;
		
	}
	
	public RollingObj(String name, DataType datatype, int start, int end){
		
		fieldName = name;
		dataType = datatype;
		begPos = start;
		endPos = end;
		
	}
	
	
	public void setValue(String record){
		
		//substring(x,y) starts at 0;  x=inclusive y=exclusive
		value = record.substring(begPos, endPos);
	}
	
        public void setNmonValue(String value){
		
		this.value = value;
	}
	
	public String getValue(){
		
		return value;
	}
	
	
	public String getFieldName(){
		
		return fieldName;
	}
	
   public DataType getDataType(){
   	
   	return dataType;
   }

}


