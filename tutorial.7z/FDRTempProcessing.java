//import java.io.BufferedReader;
import java.io.File;
//import java.io.FileReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;

/**
 * 2/17/2022: FDRTempProcessing class is located at /ana/mds/prd/data/files. 
 * 1. Pull fdr-b/c/e-f6 files from /hdfsTA/work/fdrMapping/2021/mapped/{B,C,E} files down to landing zone
 * 2. Connect to database to find parent_fileid
 * 3. call the stored procedure to process the mapped files
 * 
 * Example: lux432:
 * /Anton/jyc_temp/jdk1.8.0_231/bin/java -cp .:/ana/mds/prd/data/files:/Anton/jyc_temp/ojdbc6.jar FDRTempProcessing /hdfsTA/work/fdrMapping/2021/mapped/C/nmon20/1812 > /ana/mds/prd/data/files/fdrcnmon1812.log 2>&1 &
 * @author JaneCheng
 *
 */
public class FDRTempProcessing {
	
	Connection conn = null;
	CallableStatement cstmt = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	String fileName = "";
	String parentFileIdQuery = "";
	String client, portfolio;
	int parentFileId, recordType, recLength;
	long filesize;
	String[] data;
	FileSystem fs = null;

	public static void main(String[] args){
		FDRTempProcessing temp = new FDRTempProcessing();
		//String content = "";
		temp.connectDB();
		//temp.setProcedureParameters(args[0]); input is one file at a time
		try{
			
			/**BufferedReader br = new BufferedReader(new FileReader(args[0]));
			while((content = br.readLine()) != null){
				temp.setProcedureParameters(content);
			}
			if(br != null){
				br.close();
			}**/
			File dir = new File(args[0]);
			File[] filelist = dir.listFiles();
			for(File file : filelist){
				if(file.isFile() && file.getName().endsWith(".bz2")){
					temp.setProcedureParameters(file.getAbsolutePath());
				}
			}
		}catch(Exception e){e.printStackTrace();}
		temp.closeAll();
	}
	
	public FDRTempProcessing(){
		parentFileIdQuery = "select parent_fileid from files where fileid = ?";
		fs = FileSystems.getDefault();
	}

	//connect to database
	public void connectDB(){
			
		try{
			 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		     conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521:mdwp2", "mdw", "mdw");  //06272019 PROD database migrated
             cstmt = conn.prepareCall("{call REPROCESSFDRTEMPFILES(?,?,?,?,?,?,?,?)}"); 
             ps = conn.prepareStatement(parentFileIdQuery);
             System.out.println("Connected to DB");
			}catch(Exception e){e.printStackTrace();System.exit(-1);}
	}
	
	public void setProcedureParameters(String filename){
		try{
			File hdfsFile = new File(filename);
			fileName = "/ana/mds/prd/data/files/" + filename.substring(filename.lastIndexOf("/") + 1, filename.indexOf("ascii") + 6) + "mapped.bz2";
			if(hdfsFile.exists()){
				System.out.println(filename + " exists");
				//move it to /ana/mds/prd/data/files/ or ADMLZ
				//hdfsFile.renameTo() does not work
				Files.move(fs.getPath(filename), fs.getPath(fileName));
			}
			File movedFile = new File(fileName);
			filesize = movedFile.length();
			data = fileName.substring(fileName.lastIndexOf("/") + 1).split("\\.");
			setParentFileID(Integer.parseInt(data[4]));
			client = data[1] + "-temp";
			portfolio = data[2];
			recLength = Integer.parseInt(data[5]);
			
			switch (data[3]){
			case "pis12": 
				recordType = 689;
			    break;
					      
			case "nmon20": 
				recordType = 652;
				break;
						   
			case "crtran25_Auths": 
				recordType = 866;
			    break;
			
			//dbtran25_Auths
			default: 
				recordType = 875;  
			    break;
			}
			
			System.out.println("ParentFileid: " + parentFileId);
			System.out.println("Recordtype: " + recordType);
			System.out.println("RecLength: " + recLength);
			System.out.println("Client: " + client);
			System.out.println("Filesize: " + filesize);
			
			cstmt.setString(1, fileName);
			cstmt.setString(2, "M");
			cstmt.setInt(3, parentFileId);
			cstmt.setInt(4, recordType);
			cstmt.setInt(5, recLength);
			cstmt.setString(6, client);
			cstmt.setString(7, portfolio);
			cstmt.setLong(8, filesize);
			if(cstmt.execute()){
				System.out.println("Call procedure REPROCESSFDRTEMPFILES successful");
			}
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void setParentFileID(int fileid){
		try{
			ps.setInt(1, fileid);
			rs = ps.executeQuery();
			parentFileId = (rs.next() ? rs.getInt(1) : 0);
		}catch(Exception e){e.printStackTrace();}

	}
	
	public void closeAll(){
		try{
		   if(!rs.isClosed()){
			   rs.close();
		   }
		   if(!ps.isClosed()){
			   ps.close();
		   }
		   if(!cstmt.isClosed()){
			   cstmt.close();
		   }
		   if(!conn.isClosed()){
			   conn.close();
		   }
		}catch(Exception e){e.printStackTrace();}
	}
		
}
