package org.jcservices;

import java.io.Serializable;
import java.util.Properties;
//import java.util.function.Function;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
//import org.apache.kafka.clients.producer.ProducerRecord;

/**
 * 8/5/2022 - this is a wrapper class for KafkaProducer as KafkaProducer is not serializable
 * Using spark broadcast to broadcast this class to all executing machines
 * @author JaneCheng
 *
 */
public class MyKafkaProducer implements Serializable{

	private static final long serialVersionUID = 1L;
	Producer<String,String> producer;
	Properties producerProps;
	//Runnable r;
	
    public MyKafkaProducer() {
    	//producerProps = new Properties();
		 //  producerProps.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092");
		 //  producerProps.setProperty(ProducerConfig.ACKS_CONFIG, "1");
		//   producerProps.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
		//   producerProps.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
		// producer = new KafkaProducer<String,String>(producerProps);  //this is where the exception starts
    }
    
    public Producer<String,String> getProducer(){
 	   producerProps = new Properties();
		   producerProps.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092");
		   producerProps.setProperty(ProducerConfig.ACKS_CONFIG, "1");
		   producerProps.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
		   producerProps.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
    	return new KafkaProducer<String,String>(producerProps); 
    } 
    
   /** public void send(String topic, String message) {
    	r = (Runnable & Serializable) producer.send(new ProducerRecord<String,String>(topic, message));
    	r.run();
    	//Function<String,String> function = (Function<String,String> & Serializable) producer.send(new ProducerRecord<String,String>(topic, message));
    }
    
    public void close() {
    	producer.flush();
    	producer.close();
    }**/

}
