import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.LocalDateTime;

/**
 * 07/13/2021 This class will replace old pans with new pans
 * using Spencer's mapping file for FDR B, C, E and N SFX Fraud files (sm_fraud_sorted)
 * Pan bytes are 13-31
 * 
 * Per Ezra, the mapping file to use depends on the date stamped on the file name.  
 * Example: FALCON.FDR-B.DEBIT.SFX.FRM7035.20231130.230631 will use the 2311 mapping file because it is still within 20231130
 * Example: FALCON.FDR-C.CREDIT.SFX.FRM7035.20231201.002811 will use the 2312 mapping file because the file date stamped is 20231201
 * 
 * rhlappfrd6005: 
 * spark2-submit --master yarn --deploy-mode client --driver-memory 20g --executor-memory 25g --class FDRSFXPanDriver /home/janecheng/ADEUtilv5.jar /work/fdrMapping/spencer/FDR/mapping /home/janecheng/sfxFile.txt /work/fdrMapping/2021/mapped/temp > /apps/jyc/sfxfile20.log 2>&1 &
 * This class is in ADEUtilv4.jar
 * 
 * rhlmodana45103: using Spark 3.3.0 need to export JAVA_HOME and SPARK_HOME
 * spark-submit --master yarn --deploy-mode client --driver-memory 40g --executor-memory 50g --conf spark.dynamicAllocation.enabled=false --conf spark.yarn.queue=FCM --conf spark.network.timeout=10000001 --conf spark.executor.heartbeatInterval=10000000 --class FDRSFXPanDriver /home/janecheng/ADEUtilv8.jar /work/mapping/spencer/FDR/mapping /home/janecheng/sfxFile.txt /work/mapping/2021/mapped/temp 2406 > /ptoan/dms_staging/parquet_logs/sfxfile2406_06122024.log 2>&1 &
 * 
 * @author JaneCheng
 *
 */

public class FDRSFXPanDriver implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> mapper = null; 
	Dataset<Row> sfx = null;
	Dataset<Row> newsfx = null;
	StructField sf = null;
	String yymm = ""; //date period to fix
	String client = "";
	String hdfsMapString = "";
	String hdfsMapperFile = "";
	String sfxFilePath = "";
	List<StructField> fields = null; //store the mapper file two columns
	StructType mapperSchema = null;
	StructType sfxSchema = null;
	StructType textSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static FileStatus[] list_files = null; 
	String pattern = "^part-.+\\.gz$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	String dfPath = "";
	static Path newDFPath = null;

	public static void main(String[] args) {		
		String content = "";
		//String datePeriod = "";
		/**
		 * args[0] = hdfs mapper file location  args[0]
		 * args[1] = file to read from
		 * args[2] = newDFPath to write text file to
		 * args[3] = datePeriod to use for the mapping file
		 */
		try{
			FDRSFXPanDriver driver = new FDRSFXPanDriver(args[0], args[2]);
		   driver.startSparkSession();
		   BufferedReader br = new BufferedReader(new FileReader(args[1]));
		   while((content = br.readLine()) != null){
			   //datePeriod = content.substring(content.lastIndexOf("/") - 4, content.lastIndexOf("/"));
			   driver.setArgs(content.substring(content.indexOf("FDR-") + 4, content.indexOf("FDR-") + 5),args[3]);
			   driver.loadMapperFile();
			   driver.loadSFXFile(content);
		   }
		   if(br != null){br.close();}          
          // driver.closeAll();  //this caused spark error of not being able to flush 
		}catch(Exception e){e.printStackTrace();}

	}
	
	public FDRSFXPanDriver(String hdfsMap, String df){		
		
		dfPath = df;  //hdfsTA on rhldmsprd001 or /work on BP - newDFPath to write text file to
		hdfsMapString = hdfsMap;  //fdr mapping file main location 
	}
	
	public void setArgs(String clientName, String datePeriod){
		client = clientName;
		///work/fdrMapping/2021/C/1912 - 07/26/2021 
		///work/fdrMapping/spencer/FDR/mapping - 12/16/2021 contains newer months for fdr mapping files
		System.out.println("File Date Period: " + datePeriod);
		/**if(datePeriod.substring(2).equalsIgnoreCase("12")){
			  //use YY01 mapping.bz2
			   datePeriod = (Integer.parseInt(datePeriod.substring(0,2)) + 1) + "01";
		   }
		else{
			datePeriod = String.valueOf(Integer.parseInt(datePeriod) + 1);
		}**/
		hdfsMapperFile = hdfsMapString + "/" + client + "/20" + datePeriod;  
		System.out.println("Mapper File: " + hdfsMapperFile);
	}
	
	public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("FDR SFX Pan Mapper")
				.config("spark.dynamicAllocation.enabled", "false")
				.config("spark.debug.maxToStringFields", 2000)
				.config("spark.sql.debug.maxToStringFields", 4000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
		//mapper fields and schema is fixed so only need to define once
		// Store the StruckField object into a List
		fields = new ArrayList<>();			
		fields.add(DataTypes.createStructField("oldPan", DataTypes.StringType, true));
	    fields.add(DataTypes.createStructField("newPan", DataTypes.StringType, true));
					
		//create the schema for the mapper
	    mapperSchema = DataTypes.createStructType(fields);
	    
	    //store FieldObj into RecordTypeMapper so can separate the value
	    //in the text file into table columns
		fieldObj = new RecordTypeMapper<FieldObj>();
		fieldObj.addFieldObj(new FieldObj("filler1", 0, 12));
		fieldObj.addFieldObj(new FieldObj("pan", 12, 31));
		fieldObj.addFieldObj(new FieldObj("filler2", 31, 73));
		
		//create the schema for the SFX file
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
		}
		
		sfxSchema = DataTypes.createStructType(fields);
 
		 //Text data source supports only a single column, and you have 3 columns.
		//create the schema for the new text file
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		
		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		   //  newDFPath = new Path("/hdfsTA/work/fdrMapping/2021/mapped"); //rhldmsprd001
		     newDFPath = new Path(dfPath);  //BP TA cluster
		}catch(Exception e){e.printStackTrace();}
	}
		
	//loadMapperFile only loads the mapper file with different locations
	public void loadMapperFile(){
		/**
		 * Need to use csv format in order for spark to read 
		 * the ! delimiter; 
		 * Using text format only gives one column called value 
		 * and will throw an error if used with delimiter and schema
		 */
		mapper = spark.read()
				      .format("csv")
				      .schema(mapperSchema)
				      .option("delimiter", "!")  //using ! delimiter to separate the data so don't need to create FieldObj
				      .option("header", "false")
				      .load(hdfsMapperFile + "/*.bz2");
		System.out.println("Load mapper file complete");
	}
	
	public void loadSFXFile(String sfxFilePath){
		   //String updatedPath = sfxFilePath.substring(0, sfxFilePath.lastIndexOf("/") + 1);
		   
		   try{
		   sfx = spark.read()
				      .format("text")
				      .option("inferSchema", false)
				      .option("header", "false")
				      .load(sfxFilePath);  //on rhldmsprd001;  remember to use file:// if on BP cluster
		   
		   System.out.println("Load sfx file complete: " + sfxFilePath);
		   /**
		    * Encoder.String() returns Dataset<String>
		    * RowEncoder.apply(StructType schema) returns Dataset<Row>
		    * MapFunction<Input, Output>
		    */
		   sfx = sfx.map((MapFunction<Row, Row>) row -> {
			   fieldObj.setFieldValue(row.mkString());
			   return fieldObj.getRow();
		   }, RowEncoder.apply(sfxSchema)); //applies the schema to the row so dataset will know it is for row
		   
		   
		   /**use dataframe left join to get all rows from sfx and also include only rows from mapper that 
		    * sfx pan == mapper pan
		    * and then replace the null values under newPan column with sfx pan column using
		    * functions.when() <- make sure that you import org.apache.spark.sql.functions 
		    * If you use just when() then java will not recognize the function, must use 
		    * functions.when(); there is also functions.otherwise() condition
		    */
		   
		   newsfx = sfx.join(mapper, sfx.col("pan").equalTo(mapper.col("oldPan")), "left");
		   //newsfx.show(20, false);
		   newsfx = newsfx.select(newsfx.col("filler1"),
				   newsfx.col("pan"),
				   newsfx.col("filler2"),
				   newsfx.col("newPan"),
				       functions.when(newsfx.col("newPan").isNull(),newsfx.col("pan"))  //replace newPan with pan if newpan is null
				       .otherwise(newsfx.col("newPan")).alias("newPanNoNull"));  //otherwise keep newPan value as is and be under new column called newPanNoNUll
		 
		   System.out.println("Joined and dropped old pans and inserted new pans no nulls");
		   /**drop the original pan and newPan columns and then renamed the newPanNoNull to pan
		    * this produces the dataframe column order of filler1, filler2, pan which is the wrong order
		   **/
		   newsfx = newsfx.drop("pan").drop("newPan").withColumnRenamed("newPanNoNull", "pan");
		   
		   //have to reselect the columns to be in the correct order:  filler1, pan, filler2 so can be written out to text file
		   newsfx = newsfx.select(newsfx.col("filler1"), newsfx.col("pan"), newsfx.col("filler2"));
		   
		   //convert back from three columns to one column so can write in text file
		   newsfx = newsfx.map(row -> {
				  return RowFactory.create(row.mkString());				  
			  }, RowEncoder.apply(textSchema));
	  
			  //df.coalesce(1).write.option("compression","gzip").format("text").save("/path/to/save")
		   
		   //delete if /hdfsTA/work/fdrMapping/2021/mapped exists
		   if(fs.exists(newDFPath))
	    	{
	    		fs.delete(newDFPath, true);
	    	}
		   
		   System.out.println("Start writing text file " + LocalDateTime.now());
		   //write back out as text file
		   newsfx.coalesce(1)
			            .write()
			            .format("text")
			            .option("compression", "gzip")  //.option("compression","bzip2")
			            .mode("overwrite")
			            .save(newDFPath.toString());
			            
		   
			  System.out.println("finished writing text file " + LocalDateTime.now());
			  // Create a Pattern object
	  		  filePattern = Pattern.compile(pattern);
	  		    
	  		  list_files = fs.listStatus(newDFPath);
              for(FileStatus filePath : list_files){
		    	
    	           m = filePattern.matcher(filePath.getPath().getName());
    	           if(m.matches()){
    	        	   //fs.rename also moved the new filename to another path
    	        	   fs.rename(filePath.getPath(), new Path(hdfsMapString + "/" + sfxFilePath.substring(sfxFilePath.lastIndexOf("/") + 1, sfxFilePath.lastIndexOf("ascii")) + "mapped.ascii.gz"));
    	        	   System.out.println("rename " + sfxFilePath.substring(sfxFilePath.lastIndexOf("/") + 1, sfxFilePath.lastIndexOf("ascii")) + "mapped.ascii.gz at " + hdfsMapString + " complete");
    	           }
    	        }
		   }catch(Exception e){e.printStackTrace();}
		   
	   }
	
	public void closeAll(){
		try{
			if(fs != null){
				fs.close();
			}
		}catch(Exception e){e.printStackTrace();}
	}

}
