
public class StringTest {
	
	public static void main(String[] args){
		
		String value1 = "419742003j9rhduYPBq20190112020722";
		String value2 = "419742003j9rhduYPBq20190125134539";
		String value3 = "419742003j9rhduYPBq20190100533678";
		
		System.out.println("value1.compareTo(value2): " + value1.compareTo(value2));
		System.out.println("value2.compareTo(value1): " + value2.compareTo(value1));
		System.out.println("value1.compareTo(value3): " + value1.compareTo(value3));
		System.out.println("value2.compareTo(value3): " + value2.compareTo(value3));
		System.out.println("value3.compareTo(value2): " + value3.compareTo(value2));

	}

}
