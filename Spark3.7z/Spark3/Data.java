package org.jcservices;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.FlatMapGroupsWithStateFunction;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Encoders;
//import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.serializer.KryoSerializer;
//import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
//import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
//import org.apache.spark.sql.streaming.GroupState;
import org.apache.spark.sql.streaming.GroupStateTimeout;
import org.apache.spark.sql.streaming.OutputMode;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.reflect.ClassTag;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.rocksdb.Options;
import org.rocksdb.RocksDB;

/**
 * ATR SHK servers:
 * /ptoan/shared/opt/spark/spark-3.2.1-bin-without-hadoop/bin/spark-submit --master yarn --deploy-mode client --driver-memory 5g --executor-memory 10g --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=2g
 * --class org.jcservices.Data /home/janecheng/Spark321Util.jar jctest11 1 3 file:///home/janecheng/pan.csv /home/janecheng/kafka.properties readRocksDB > /home/janecheng/readRocksDBState3.log 2>&1 &
 * 
 * http://rhldatdms22003.fairisaac.com:8088/proxy/application_1664092347050_1176/  <-- successful RocksDB
 * @author JaneCheng
 *
 */

public class Data implements Serializable{
    
	private static final long serialVersionUID = 1L;
	SparkSession spark;
    Dataset<Row> df;
    static FileSystem fs;
    static Configuration conf;
    String topic;
    int partition;
    short replicationFactor;
    String dataFile;
    Properties props;
    KafkaUtil kafka;
    UDF1<Integer,Integer> udf = null;  //interface
    
   /** class FieldObj{
   	 
   	 String fieldID;
   	 int count;
    }**/
    
	public static void main(String[] args) {
         /**
          * args[0] = topic name
          * args[1] = partition
          * args[2] = replication factor
          * args[3] = csv file to read to produce records in topic
          * args[4] = kafka property file location or null	
          * args[5] = action	
          */
		
		Data test = new Data(args);
       switch (args[5]) {
       
           case "create":    test.createTopic();
                             break;
           case "write":     test.writeToTopic();
                             break;
           case "readbatch": test.readBatchData();
                             break;
           case "readspark": test.readFromSparkToKafka();
                             break;
           case "broadcast": test.broadcast();
                             break;
           case "readjson":  test.readJson();
                             break;
           case "readRocksDB": test.readRocksDBState();
                               break;
           case "readRocks": test.readRocksDB();;
                               break;
           default:          test.readStreamData();    //default to reading streams
        	                 break;
       } 
		
		//test.writeToTopic();
		//test.createTopic();
        //Data test = new Data("test", "1", "3", "C:\\software\\test", "default");
		//test.getProperties();

	}
	
	public Data(String topicName, String partitionNum, String replication, String csv, String property) {
		topic = topicName;
		partition = Integer.parseInt(partitionNum);
		replicationFactor = (short)Integer.parseInt(replication);
		dataFile = csv;
  	     if(property.equalsIgnoreCase("default")) {
   	    	 KafkaUtil.setProperties();
   	     }else {
   	    	 KafkaUtil.setProperties(property);
   	     }
  	   try {
	    	 conf = new Configuration();
	   	     fs = FileSystem.get(conf);
	     }catch(Exception e) {e.printStackTrace();}
	}
	
	public Data(String[] args) {
		topic = args[0];
		partition = Integer.parseInt(args[1]);
		replicationFactor = (short)Integer.parseInt(args[2]);
		dataFile = args[3];
  	     if(args[4].equalsIgnoreCase("default")) {
   	    	 KafkaUtil.setProperties();
   	     }else {
   	    	 KafkaUtil.setProperties(args[4]);
   	     }
  	     try {
  	    	 conf = new Configuration();
  	   	     fs = FileSystem.get(conf);
  	     }catch(Exception e) {e.printStackTrace();}
	}
	
    public void startSparkSession(){
		
    	SparkConf conf = new SparkConf()
    			         .setAppName("Test Kafka")
    			         .set("spark.debug.maxToStringFields", "2000")
    			         .set("spark.serializer", KryoSerializer.class.getCanonicalName())
    			         .set("spark.kryo.registrationRequired", "false")
    			         .registerKryoClasses(new Class[]{org.jcservices.MyKafkaProducer.class});
    			         
		spark = SparkSession.builder()
				.config(conf)
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("ERROR");
		
	}
    
    /** 
     * test to see if it can load kafka.properties from resources directory
     */
    public void getProperties() {
    	props = KafkaUtil.getProperties();
    	System.out.println(props.getProperty("bootstrap.servers"));
    	System.out.println(props.getProperty("key.serializer"));
    	System.out.println(props.getProperty("value.serializer"));
    	System.out.println(props.getProperty("key.deserializer"));
    	System.out.println(props.getProperty("value.deserializer"));
    }
    public void createTopic() {
    	//boolean result;
    	try {
   	     KafkaUtil.createTopic(topic, partition, replicationFactor);
    		
    	}catch(Exception e) {e.printStackTrace();}
    }
    
    public void writeToTopic() {
    	try {
    		KafkaUtil.writeToTopics(topic, dataFile, fs);
    	}catch(Exception e) {e.printStackTrace();}
    	
    }
    
    /**
     * read and write using spark structured streaming
     */
    public void readStreamData() {
    	try {
    		startSparkSession();
    		df = spark.readStream()
    				.format("kafka")
    				//.option("kafka.bootstrap.servers", props.getProperty("bootstrap.servers"))
    				.option("kafka.bootstrap.servers", "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092")
    				.option("subscribe", topic)
    				.load();   
    		
    		df = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)");
    		System.out.println("Read stream mode and cast to string");
    		//df = df.withColumn("key", df.col("key").cast(DataTypes.StringType)).withColumn("value", df.col("value").cast(DataTypes.StringType));
    		
    		/**List<StructField> fields = new ArrayList<>();
    		df.select("key").foreach(row -> {
    			fields.add(DataTypes.createStructField(row.get(0).toString(), DataTypes.StringType,true));
    		});**/
    		
    		/** does not work; gives exception Queries with streaming sources must be executed with writeStream.start();
    		 df.select("key","value")
    		.foreach(row -> {
    			System.out.println("key: " + row.get(0).toString() + " value: " + row.get(1).toString());
    		});**/
    		
    		//this works; it picks up new messages from kafka topics in batches
    		/** df.writeStream()
    		.format("console")
    		.outputMode("append")
    		.option("startingOffsets", "earliest")
    		.start()
    		.awaitTermination();  **/
    		
    		/**
    		 * below works; spark creates a new parquet file for every new messages pushed to kafka topic
    		 */
    		df.writeStream()
            .format("parquet")
            .outputMode("append")  //optional
            .option("path", "/work/mapping/sparkstream")  //directory to store parquet files
            .option("compression","gzip")  //spark default is snappy which needs /tmp with exec permissions to load snappyjava.so; changed to gzip better
           // .trigger(Trigger.Once())  //optional
            .option("checkpointLocation", "/work/mapping/checkpoint")  //hdfs directory for checkpoint logs
            .start()
            .awaitTermination();
    		
    		//pivot the table so the values under key column will become the column names
    		//df = df.groupBy(col("value")).pivot(col("key")).agg(sum(col("partition")));
    		
    	}catch(Exception e) {e.printStackTrace();}
    }
    
    /**
     * read (spark streaming) and write (using spark structured streaming)
     */
    public void readBatchData() {
    	try {
    		startSparkSession();
    		df = spark.read()
    				.format("kafka")
    				//.option("kafka.bootstrap.servers", props.getProperty("bootstrap.servers"))
    				.option("kafka.bootstrap.servers", "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092")
    				.option("subscribe", topic)
    				.load();   
    		
    		df = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)");
    		System.out.println("Read batch mode and cast to string");
    		//df = df.withColumn("key", df.col("key").cast(DataTypes.StringType)).withColumn("value", df.col("value").cast(DataTypes.StringType));
    		
    		/**List<StructField> fields = new ArrayList<>();
    		df.select("key").foreach(row -> {
    			fields.add(DataTypes.createStructField(row.get(0).toString(), DataTypes.StringType,true));
    		});**/
    		
    		//// Write new data to Parquet files
    		//https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html#output-modes
            df.writeStream()
            .format("parquet")
            .outputMode("append")  //optional
            .option("path", "/work/mapping/sparkstream")  //directory to store parquet files
            .trigger(Trigger.Once())  //optional
            .option("checkpointLocation", "/work/mapping/checkpoint")  //hdfs directory for checkpoint logs
            .start()
            .awaitTermination();
    		
    		//does not work; gives exception Queries with streaming sources must be executed with writeStream.start();
    		/** df.select("key","value")
    		.foreach(row -> {
    			System.out.println("key: " + row.get(0).toString() + " value: " + row.get(1).toString());
    		});**/
    		
    		
    		//pivot the table so the values under key column will become the column names
    		//df = df.groupBy(col("value")).pivot(col("key")).agg(sum(col("partition")));
    		
    	}catch(Exception e) {e.printStackTrace();}
    }
    
    /**
     * read file and write to Kafka topic using Spark SQL batch mode queries
     */
    public void readFromSparkToKafka() {
    	try {
    		startSparkSession();    		
    		
    		df = spark.read()
		      .format("text")
		      .option("inferSchema", false)
		      .option("header", "false")
		      .load(dataFile);
    			
    		//df = spark.read().json(dataFile);  //does not work for jsonl file
    		
    		//below works for spark batch mode to write from spark to kafka topic
    		df.selectExpr("CAST(value AS STRING)")
    		.write()
    		.format("kafka")
    		.option("kafka.bootstrap.servers", "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092")
    		.option("topic", topic)
    		.save();
    		
    	}catch(Exception e) {e.printStackTrace();}
    }
    
     public static <T> ClassTag<T> classTag(Class<T> clazz) {
    	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
    	}
     
     /**
      * batch mode
      * Successfully shuffled with repartition() instead of partitionBy()
      * http://rhldatdms22003.fairisaac.com:18088/history/application_1658648583531_0812/stages/stage/?id=3&attempt=0
      */
     public void broadcast() {
    	 try {
    		 startSparkSession(); 
    		//register UDF and UDF2
    		//UDF1<String, String> is an interface so need to create a class that implements the UDF1 interface
    		//in order to be to instantiate; here UDF() and UDF2 are classes that implements UDF1<String,String>
    		 udf = new UDF();
    		//register the user defined function in spark
    		 spark.udf().register("udf1", udf, DataTypes.IntegerType);  //return type is Integer
     		//JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());
     		//jsc.broadcast(producer);
     		//jsc.close();
    		 
    		//testing out spark broadcasting object
     		//Broadcast<MyKafkaProducer> br = spark.sparkContext().broadcast(new MyKafkaProducer(), classTag(MyKafkaProducer.class));
                //br.value.

     		df = spark.read()
     			      .format("text")
     			      .option("inferSchema", false)
     			      .option("header", "false")
     			      .load(dataFile);
     	    
     		df = df.withColumn("partition", functions.spark_partition_id());
     		System.out.println("numOfPartitions before changing partition: " + df.rdd().getNumPartitions());
     		df.createOrReplaceTempView("dftemp");
     		df = spark.sql("select value, udf1(partition) as partition from dftemp");
     		df  = df.repartition(50, df.col("partition"));
     		System.out.println("numOfPartitions after changing partition: " + df.rdd().getNumPartitions());
          // df.groupBy("partition").count().show();
     		
     		df.selectExpr("CAST(value AS STRING)")
    		.write()
    		.format("kafka")
    		.partitionBy("partition")
    		.option("kafka.bootstrap.servers", "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092")
    		.option("topic", topic)
    		.save();
     		  		
     		//br.destroy();
    		     		 
    	 }catch(Exception e) {e.printStackTrace();}
     }
     
     public void readJson() {
    	 try {
    		 startSparkSession(); 
    		//register UDF and UDF2
    		//UDF1<String, String> is an interface so need to create a class that implements the UDF1 interface
    		//in order to be to instantiate; here UDF() and UDF2 are classes that implements UDF1<String,String>
    		 udf = new UDF();
    		//register the user defined function in spark
    		 spark.udf().register("udf1", udf, DataTypes.IntegerType);  //return type is Integer


     		df = spark.read()
     				.json(dataFile);
     		
     	    df = df.select(functions.to_timestamp(functions.concat(df.col("creditTransaction.creditPayload.transactionDate"), df.col("creditTransaction.creditPayload.transactionTime")),"yyyyMMddHHmmss").alias("transactionDatetimeUnix"),
     	    		functions.when(df.col("creditTransaction.creditPayload.pan").isNull(), df.col("panTransaction.panPayload.pan"))
     	    		.otherwise(df.col("creditTransaction.creditPayload.pan")).alias("pan"));

     		System.out.println("numOfPartitions before changing partition: " + df.rdd().getNumPartitions());
     		//df.show(20);
     		df = df.withColumn("partition", functions.spark_partition_id());
     		
     		df.createOrReplaceTempView("dftemp");
     		df = spark.sql("select transactionDatetimeUnix, pan, udf1(partition) as partition from dftemp");
     		//df  = df.repartition(50, df.col("partition"));
     		System.out.println("numOfPartitions after changing partition: " + df.rdd().getNumPartitions());
          // df.groupBy("partition").count().show();
     		
     		//Column col = functions.to_json(functions.struct(df.col("transactionDatetimeUnix"), df.col("pan"))); //converts to json for one record and return one column
     		//When Spark reads a dataframe it turns a record into a Row. The Row is a json like structure. That can be transformed and written out to json
     		//creates a new column called value and contains json strings
     		df = df.withColumn("value", functions.to_json(functions.struct(df.col("transactionDatetimeUnix"), df.col("pan"))));
     		df = df.repartition(50, df.col("partition"));
    		df.selectExpr("CAST(value AS STRING)")
    		.write()
    		.format("kafka")
    		.partitionBy("partition")
    		.option("kafka.bootstrap.servers", "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092")
    		.option("topic", topic)
    		.save();
    		     		 
    	 }catch(Exception e) {e.printStackTrace();}
     }
     
     /**
      * Dataset.writestream requires spark to readstream from a source such as Kafka, Rate, etc
      * org.apache.spark.sql.AnalysisException: 'writeStream' can be called only on streaming Dataset/DataFrame
      * java.lang.IllegalArgumentException:
      * Schema must be specified when creating a streaming source DataFrame. If some
      * files already exist in the directory, then depending on the file format you
      * may be able to create a static DataFrame on that directory with
      * 'spark.read.load(directory)' and infer schema from it.

      */
     public void readRocksDBState() {
    	 try {
    	 SparkConf conf = new SparkConf()
		         .setAppName("Test Kafka")
		         .set("spark.debug.maxToStringFields", "2000")
		         .set("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider");
		         
          spark = SparkSession.builder()
		          .config(conf)
		          .getOrCreate();

          spark.sparkContext().setLogLevel("ERROR");
          
        /**Dataset<Row> json = spark.readStream().schema(schema)
        		  .json(dataFile);  //has to be a directory if using .csv or .json with readStream()
        
        json = json.select(functions.to_timestamp(functions.concat(df.col("creditTransaction.creditPayload.transactionDate"), df.col("creditTransaction.creditPayload.transactionTime")),"yyyyMMddHHmmss").alias("transactionDatetimeUnix"),
   		functions.when(df.col("creditTransaction.creditPayload.pan").isNull(), df.col("panTransaction.panPayload.pan"))
   		.otherwise(df.col("creditTransaction.creditPayload.pan")).alias("pan")); **/
          
          /**Dataset<Row> csv = spark.read().format("csv")
        		  .option("inferSchema", true)
			      .option("header", "true")
			      .load(dataFile); **/
          List<StructField> fields = new ArrayList<>();
          
          fields.add(DataTypes.createStructField("pan", DataTypes.StringType, true));
          fields.add(DataTypes.createStructField("id", DataTypes.StringType, true));
          StructType schema = DataTypes.createStructType(fields);
          
          df = spark.readStream()
        		    .schema(schema)
			        .csv("/user/janecheng/input");

         /** df = spark.readStream()
        		  .format("rate")
        		  .option("rowsPerSecond", 10)
        		  .load()
        		  .withColumn("pan", csv.col("pan")); // randomly assigned to values **/
          
          //clear the fields to reuse
          fields.clear();
          fields.add(DataTypes.createStructField("pan", DataTypes.StringType, true));
          fields.add(DataTypes.createStructField("id", DataTypes.StringType, true));
          fields.add(DataTypes.createStructField("state", DataTypes.StringType, true));
          
          schema = DataTypes.createStructType(fields);
         // Encoder<FieldObj> fieldObjEncoder = Encoders.kryo(FieldObj.class);
                    
          //public Dataset<T> as(String alias) - Returns a new Dataset with an alias set. Same as alias(String alias)
          
          /**
           * FlatMapGroupsWithStateFunction func: (K, Iterator[V], GroupState[S]) => U
           * FlatMapGroupsWithStateFunction call(K key, java.util.Iterator<V> values, GroupState<S> state) 
           * U = returns java.util.Iterator<R>
           * K is simply an ID of your grouped computation. In our case, it should be userId
           * Iterator[V] is an iterator over the new values, coming from the batch for this particular ID.
           * GroupState[S] is an object, that gives you the state API.
           * 
           * An Iterator is an object that can be used to loop through collections, like ArrayList and HashSet. 
           * It is called an "iterator" because "iterating" is the technical term for looping.
           * 
           * RowFactory.create() = public static Row create(Object... values) = Create a Row from the given arguments. Position i in the argument list becomes position i in the created Row object.
           * 
           *  ERROR cluster.YarnScheduler: Lost executor 1 on rhlmodhdp22505.fairisaac.com: 
           *  Container killed by YARN for exceeding physical memory limits. 2.3 GB of 2 GB physical memory used. 
           *  Consider boosting spark.executor.memoryOverhead.
           */
          df = df.groupByKey((MapFunction<Row,String>) row ->{
        	  return row.get(0).toString();
          }, Encoders.STRING())
             .flatMapGroupsWithState((FlatMapGroupsWithStateFunction<String, Row, Integer, Row>) (key, iteratorRow, state) -> {
            	 
            	 List<Row> list = new ArrayList<>();
            	 Integer s;
            	 if(state.exists()) {          		 
            		 s = state.get();
            	 }
            	 else {
            		 s = 0;
            	 }
            	 while(iteratorRow.hasNext()) {
            	   Row row = iteratorRow.next();
            	   s = s + 1;
            	   //String data = String.format("%-5d", row.mkString()) + s;  //this did not work
            	   //String data = row.mkString() + " " + s;  //this worked
            	   row = RowFactory.create(row.get(0).toString(), row.get(1).toString(), String.valueOf(s)); //need to change s to String because schema has state equal StringType         	   
            	   list.add(row);           	    
            	   state.update(s);
            	 }
            	 return list.iterator();
             }, OutputMode.Append(), Encoders.INT(), RowEncoder.apply(schema), GroupStateTimeout.NoTimeout()); 
          
          df.writeStream()
          .format("parquet")
          .outputMode("append")  //optional
          .trigger(Trigger.Once())  //optional
          .option("path", "/work/mapping/sparkstream")  //directory to store parquet files
          .option("checkpointLocation", "/work/mapping/checkpoint")  //hdfs directory for checkpoint logs
          .start()
          .awaitTermination();
    	 
    	 }catch(Exception e) {e.printStackTrace();}
     }
     
     /**
      * RocksDB works with bytes so it's all transformed to byte array 
      * and back when interacting with it's APIs
      */ 
     public void readRocksDB() {
    	 try {
    		 SparkConf conf = new SparkConf()
    		         .setAppName("Test Kafka")
    		         .set("spark.debug.maxToStringFields", "2000")
    		         .set("spark.sql.streaming.stateStore.providerClass", "org.apache.spark.sql.execution.streaming.state.RocksDBStateStoreProvider");
    		         
              spark = SparkSession.builder()
    		          .config(conf)
    		          .getOrCreate();

              spark.sparkContext().setLogLevel("ERROR");
              
              RocksDB.loadLibrary();
              Options options = new Options();
              //set options to create database if does not exist
              options.setCreateIfMissing(true);
              //database directory location on local file system
              File rocksDir = new File("/ptoan/dms_staging/rocks/rocksdb");
              if(!rocksDir.exists())
              {
            	  rocksDir.mkdirs();
              }
              /** 
               * RocksDB.open(Options options, String databasePath) = The factory constructor of RocksDB 
               * that opens a RocksDB instance given the path to the database using the specified options 
               * and db path.
               * 
               **/
               
              RocksDB rocksdb = RocksDB.open(options, rocksDir.getAbsolutePath());
              System.out.println("RocksDB created and read to use");
              
              options.close();  //need to close or resource leaks
              
    	 }catch(Exception e) {e.printStackTrace();}
     }

}
