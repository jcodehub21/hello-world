import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
/**
 * 07/24/2025 - Archive tool for TRIAD client directories at /ptoan/adapt5 that are older than 5 years
 * java -cp .:/mdswork/prd/bin:/ptoan/dms_staging/parquet_logs:/mdswork/prd/bin/commons-io-2.20.0.jar:/mdswork/prd/bin/ojdbc6.jar:/mdswork/prd/bin/mail.jar TriadArchiveUtil /ptoan/dms_staging/parquet_logs/triadarchiveclientlist.txt /ptoan/datamgmt/landing_zone/jane_temp /ptoan/adapt5/TRIAD_data_archive_logs > "/ptoan/dms_staging/parquet_logs/triadarchive_${HOSTNAME}_`date +%F`".log 2>&1 &
 * @author JaneCheng
 *
 */

public class TriadArchiveUtil implements FilenameFilter{
	//SimpleDateFormat sdf = null;
	long year = 5;
	LocalDateTime subDirDate = null;  //each sub folder date YYYYMM
	FilenameFilter files = null; //eg 14056685.6075.csv.gz
	File[] subDirList = null;  //store the list of sub folders under Triad main folder (eg /ptoan/adapts/FDR)
	File checkFile = null;
	LocalDateTime fileLastModifiedDate = null; //stores the last modified date of each file
	LocalDateTime todayDateTime = LocalDateTime.now();  //today's date
	File archiveTempDir = null;
	String tarCommand = "";
	String[] commandArgs = null;
	ProcessBuilder builder = null;
	Process p = null; //process for Linux
	StringBuffer sb = new StringBuffer();
	String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
	String endTable = "</table>";
	BufferedWriter bw = null;
	BufferedWriter bwBashScript = null;
	Connection conn = null;
	PreparedStatement ps = null;
	String psQuery = "";
	ResultSet rs = null;
	
	public static void main(String[] args){
		//args[0] client list
		//args[1] temporary archive destination
		//args[2] directory to store archive log file
		TriadArchiveUtil driver = new TriadArchiveUtil();
		driver.readClientList(args[0], args[1], args[2]);
		//driver.moveArchivedFileToLZ(args[1]);
	}
   
	public TriadArchiveUtil(){
		psQuery = "select filename from files where status = 'D' and filename like ?";
	}
	
	public TriadArchiveUtil(LocalDateTime todayDateTime){
		this.todayDateTime = todayDateTime;
		//this.sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	}
	
	public void readClientList(String clientList, String archiveDir, String archiveLogDir){
		String content = "";
        int todayYYYYMM = Integer.parseInt(String.valueOf(LocalDateTime.now().getYear()) + (LocalDateTime.now().getMonth().getValue() < 10 ? "0" + String.valueOf(LocalDateTime.now().getMonth().getValue()) : LocalDateTime.now().getMonth().getValue()));
        files = new TriadArchiveUtil(todayDateTime);
		this.archiveTempDir = new File(archiveDir);
		
		try{
			System.out.println("Begin TriadArchiveUtil.readClientList(): " +  LocalDateTime.now());	
			connectDB();
			BufferedReader br = new BufferedReader(new FileReader(clientList));
			bw = new BufferedWriter(new FileWriter(archiveLogDir + "/archive_log_" + LocalDate.now() + ".log", true));
			bwBashScript = new BufferedWriter(new FileWriter(archiveLogDir + "/archive_bash_script_" + LocalDate.now() + ".sh", true));
			sb.append("Log file: " + archiveLogDir + "/archive_log_" + LocalDate.now() + ".log<br><br>");
			sb.append("Removal Bash Script: " + archiveLogDir + "/archive_bash_script_" + LocalDate.now() + ".sh<br><br>");
			bwBashScript.write("#!/bin/bash");
			bwBashScript.newLine();
			
			while((content = br.readLine()) != null){
				System.out.println("Start checking Triad directory: " + content);
				subDirList = new File(content).listFiles();
				//System.out.println("todayYYYYMM: " + todayYYYYMM);
				//System.out.println("todaydateTime: " + todayDateTime);
				System.out.println("todayDateTime minus 5 years: " + todayDateTime.minusYears(year));
				if(subDirList.length > 0){  //has sub folders
					//Arrays.sort(T, Comparator.comparing(Class::method).reversed())
		     		  Arrays.sort(subDirList, Comparator.comparing(File::getPath).reversed());
		     		  //check the sub folder YYYYMM to be less than 5 years old
		     		  for(File subDir : subDirList){
		     			  if(subDir.isDirectory()){
		     			     if(subDir.getName().matches("[0-9]+")){  //do not include the incoming sub folder		     				 
		     				    if(Integer.parseInt(subDir.getName()) < todayYYYYMM - 500){  //less than 5 years
		     					    System.out.println("Checking: " + subDir.getAbsolutePath());
		     					    //check DMS to see if sub folder has already been archived
		     					    if(!checkDMSForArchivedFile(subDir)){
		     						   if(analyzeTempFreeDiskSpace(subDir)){
			     					      analyzeSubFolder(subDir);
			     					   }
		     					    }		     					 
		     				    }		     				 
		     			     }else{ //not a yyyymm sub folder but still want to check except for "incoming" folder
		     				     if(!subDir.getName().equalsIgnoreCase("incoming")){
		     					    System.out.println("Checking: " + subDir.getAbsolutePath());
		     					   if(!checkDMSForArchivedFile(subDir)){
		     						   if(analyzeTempFreeDiskSpace(subDir)){
		     						      analyzeSubFolder(subDir);
		     						   }
		     					    }	
		     				     }
		     			     }
		     			  }
		     		  }//end of for-loop
				  }
			}
			moveArchivedFileToLZ(archiveDir);
			commandArgs = new String[] {"/bin/bash", "-c", "chmod 754 " + archiveLogDir + "/archive_bash_script_" + LocalDate.now() + ".sh"};			
			builder = new ProcessBuilder(commandArgs);
			builder.redirectErrorStream(true); //redirect stderr to stdout 
			p = builder.start();  //start the bash process on linux
			p.waitFor();
			
			sendEmail();
			br.close();
			bw.close();
			bwBashScript.close();
			if(conn != null){
				conn.close();
			}
		}catch(Exception e){e.printStackTrace();}
	}
	
	public boolean checkDMSForArchivedFile(File subDir){
		String tarDestFilename = "";
		boolean result = false;
		try{
			System.out.println("Begin TriadArchiveUtil.checkDMSForArchiveFile(): " +  LocalDateTime.now());
			for(String destName : subDir.getAbsolutePath().split("/")){
				tarDestFilename += destName + ".";
			}
			tarDestFilename = tarDestFilename.substring(1) + "tar.gz";
			result = runPSQuery(tarDestFilename) > 0 ? true : false;
		}catch(Exception e){e.printStackTrace();}
		return result;
	}
	
	public void analyzeSubFolder(File subDir){
		File[] csvFiles = null;

		try{
			System.out.println("Begin TriadArchiveUtil.analyzeSubFolder(): " +  LocalDateTime.now());
			csvFiles = subDir.listFiles(files);
			/**for(File file : csvFiles){
				System.out.println(file.getAbsolutePath() + " (" + file.lastModified() + ") checked");
			} **/
			//only check for first level sub folder;  does not check sub folders under sub folder
			if(csvFiles.length == subDir.listFiles().length){
				for(File filename : csvFiles){
					bw.write(filename.getAbsolutePath());
					bw.newLine();
					bwBashScript.write("chmod g+w " + filename.getAbsolutePath());
					bwBashScript.newLine();
					bwBashScript.write("rm " + filename.getAbsolutePath());
					bwBashScript.newLine();
				}
				//archive
				archive(subDir);
			}
		}catch(Exception e){e.printStackTrace();}
	}
	
	
	public boolean analyzeTempFreeDiskSpace(File subDirToArchive){
		boolean result = false;
		long dirSize = 0;
		double tempSize = 0;
		
		try{
			System.out.println("Begin TriadArchiveUtil.analyzeTempFreeDiskSpace(): " +  LocalDateTime.now());
			//get subDir size
			dirSize = FileUtils.sizeOfDirectory(subDirToArchive);
			System.out.println(subDirToArchive.getAbsolutePath() + " size: " + dirSize);
			//File.getUsableSpace() is the Returns the number of bytes available to this virtual machine
			//File.getFreeSpace() does not tell me if it is usable 
            tempSize = archiveTempDir.getUsableSpace() * 1000 * .90; //only want 90% of usable space for temp archiving
			System.out.println(archiveTempDir + " 90% of total usable size: " + tempSize);
			//need to check if enough disk space to create tar file
			if((dirSize * 2) < tempSize){  //tempSize needs to be in Terabytes
				result = true;	
			}
			
		}catch(Exception e){e.printStackTrace();}
		return result;
	}
	
	
	public void archive(File subDirToArchive){
		tarCommand = "tar -zcvf";
		String tarDestFilename = "";  //destination name for the created tar file
		try{
			System.out.println("Begin TriadArchiveUtil.archive(): " +  LocalDateTime.now());
			System.out.println("Directory to archive: " + subDirToArchive);
			for(String destName : subDirToArchive.getAbsolutePath().split("/")){
				tarDestFilename += destName + ".";
			}
			tarDestFilename = tarDestFilename.substring(1) + "tar.gz";
			bw.write("Archived Tar Filename: " + tarDestFilename);
			bw.newLine();
			sb.append(tarDestFilename + "<br>");
			System.out.println("Tar destination filename: " + tarDestFilename);
			commandArgs = new String[] {"/bin/bash", "-c", tarCommand + " " + archiveTempDir + "/" + tarDestFilename + " " + subDirToArchive.getAbsolutePath()};
			//System.out.println("commandArgs: " + tarCommand + " " + archiveTempDir + "/" + tarDestFilename + " " + subDirToArchive.getAbsolutePath());
				
			builder = new ProcessBuilder(commandArgs);
			builder.redirectErrorStream(true); //redirect stderr to stdout 
			p = builder.start();  //start the bash process on linux
			p.waitFor();
				//read process standard output to see if any errors
				//reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
				//while ((result = reader.readLine()) != null){
				   // System.out.println("process result: " + result);
				//}				
			
		}catch(Exception e){e.printStackTrace();}
	}

	@Override
	public boolean accept(File dir, String filename) {
		boolean result = false;
		  //System.out.println("Begin TriadArchiveUtil.accept(): " +  LocalDateTime.now());
		  checkFile = new File(dir + "/" + filename);
		  fileLastModifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(checkFile.lastModified()),ZoneId.of("America/Chicago"));
		  if(fileLastModifiedDate.isBefore(todayDateTime.minusYears(year))){
				result = true;
			}else{
				System.out.println("File: " + checkFile.getAbsolutePath() + " is less than 5 years old");
			}		
		return result;
	}
	
	public void moveArchivedFileToLZ(String archiveDir){
		File triggerfile = null;
		try{
			System.out.println("Begin TriadArchiveUtil.moveArchivedFileToLZ(): " +  LocalDateTime.now());
			File[] archivedFiles = new File(archiveDir).listFiles();
			for(File archivedfile : archivedFiles){
				if(archivedfile.getName().contains("ptoan.adapt5")){
					triggerfile = new File("/ptoan/datamgmt/landing_zone/" + archivedfile.getName() + ".trg");
					Files.move(FileSystems.getDefault().getPath(archivedfile.getAbsolutePath()),FileSystems.getDefault().getPath("/ptoan/datamgmt/landing_zone/" + archivedfile.getName()), StandardCopyOption.REPLACE_EXISTING);
					if(!triggerfile.exists()){
					  FileUtils.touch(triggerfile);
					}
				}
			}
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * connect to Oracle DB to see if the sub folder has been archived
	 */
	public void connectDB(){
		  try{
			System.out.println("Begin TriadArchiveUtil.connectDB(): " +  LocalDateTime.now());
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms22001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated to SHK
			ps = conn.prepareStatement(psQuery);
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}
		}
	
	/**
	 * Run same query multiple times with different parameters passed in
	 * to find processed files or multiple files or done files
	 * @param recordtype
	 */
	public int runPSQuery(String tarfilename){	
		   int result = 0;
		   try{
			System.out.println("Begin TriadArchiveUtil.runPSQuery(): " +  LocalDateTime.now());
			ps.setString(1, tarfilename);
			rs = ps.executeQuery();
			
			//if records were returned
			if(rs.next()){
				
				result = Integer.parseInt(rs.getString(1));
				System.out.println("result: " + result);
			}
			
		   }
		   catch(Exception e){e.printStackTrace();}
		   return result;
		}
	
	 public void sendEmail(){

		    String to = "janecheng@fico.com";
		    String from = "janecheng@fico.com";
		    
		    try
		    {	    
		       //sb.append("<br> Thank you, <br> Jane Cheng");
		       String host = "mail.fairisaac.com";
		    
		       //create properties to store host and get or set the default mail session object
		       Properties props = new Properties();
		       props.put("mail.smtp.host", host);
		       Session session = Session.getInstance(props);
		    
		       //create the message object
		       MimeMessage msg = new MimeMessage(session);

		       //set the sender's email address
		       msg.setFrom(new InternetAddress(from));

		       //set the recipient's email address
		       msg.setRecipients(Message.RecipientType.TO, to);
		       
		       //set the subject heading
		       msg.setSubject("TRIAD Archival " + LocalDate.now().getYear() + CalenderOps.convertSingleDigitToString(LocalDate.now().getMonthValue()) + " Report");

		       //set the date of sending the email; new date() initializes the to current date
		       msg.setSentDate(new Date());

		       //set the message body; setText method only uses text/plain
		       // msg.setText(msgBody);
		       Multipart mp = new MimeMultipart();
		          
		       //set the html body part
		       MimeBodyPart htmlbody = new MimeBodyPart();
		       htmlbody.setContent(sb.toString(), "text/html");
		       mp.addBodyPart(htmlbody);
		          
		       //need to use setContent method if using text/html
		       //msg.setContent(sb.toString(), "text/html");
		       msg.setContent(mp);

		       //send the email
		       Transport.send(msg);
		          
		     }
		       catch(Exception mex){

		          System.out.println("Error in sending: ");
		          mex.printStackTrace();
		          System.exit(1);
		       }

		    }
}
