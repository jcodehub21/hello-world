package com.jc.spark.mllib.MLlibUtil;

import java.io.Serializable;
import java.util.Arrays;

import org.apache.spark.ml.classification.LogisticRegression;
import org.apache.spark.ml.classification.LogisticRegressionModel;
import org.apache.spark.ml.classification.RandomForestClassificationModel;
import org.apache.spark.ml.classification.RandomForestClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
//import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

//https://spark.apache.org/docs/latest/ml-pipeline.html 
//https://spark.apache.org/docs/latest/ml-features.html#featurehasher
//https://dhiraj-p-rai.medium.com/logistic-regression-in-spark-ml-8a95b5f5434c  <-- good read
//https://data-flair.training/blogs/spark-machine-learning-algorithm/

public class LogisticRegressionOps implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> data;
	
    public static void main( String[] args )
    {
    	LogisticRegressionOps linear = new LogisticRegressionOps();
        linear.runModel("C:\\software\\machine_learning_java\\ALL_CSV_FILES\\Heart.csv");
    }
    
    public void runModel(String filename) {
    	
    	CommonUtil.startSparkSession("Logistic Regression");
    	data = CommonUtil.loadData(filename, "csv", true, true);
    	//drop any rows with null values; na uses the DataframeNaFunctions
    	data = data.na().drop();
    	
    	/**
    	 * data contains ChestPain column which is String DataType which Logistic Regression cannot handle
    	 * Logistic Regression needs features to be all numbers
    	 * so first transform the ChestPain column into indices using the StringIndexer Transformer
    	 * StringIndexer encodes a string column of labels to a column of label indices (0.0, 1.0, 2.0, etc). 
    	 * StringIndexer can encode multiple columns
    	 * Below I need only each indices once in order to do a left join;
    	 * Otherwise it generates one record on data dataframe for each same chestPain indices
    	 */
    	/**Dataset<Row> chestPain = data.select("ChestPain");
    			
    	chestPain = new StringIndexer().setInputCol("ChestPain")
    			.setOutputCol("ChestPainIndices")
    			.setHandleInvalid("skip") //skip the row containing the unseen label entirely
    			.fit(chestPain)
    			.transform(chestPain)
    			.select("ChestPain", "ChestPainIndices").distinct();   **/
    	
    	//I only want these 4 columns of data to fit and transform to Logistic Regression
    	//Sex column is last because I am trying to make predictions on the sex for the other conditions
    	/**data = data.join(chestPain, chestPain.col("ChestPain").equalTo(data.col("ChestPain")), "left")
    			.select("Age", "ChestPainIndices", "RestBP", "Chol", "Sex");**/
    	
    	//data.select("*").orderBy(data.col("Age")).show(20, false);
    	
    	data = data.select("Age", "RestBP", "Chol", "MaxHR", "Oldpeak", "Sex");
    	
    	/**
    	 * Now we will create the feature array by omitting the last column or dependent column of the dataset. 
    	 * If you remember that to train a machine learning model, we want to feed features and labels to predict a label 
    	 * for new features.
    	 * 
    	 * 
    	 * create the features and label using VectorAssembler -> creates a new vector by summing all the columns as one feature
    	 * VectorAssembler does not support Data type string of column; supports only numerical, boolean, vector types
    	 * data.columns() = return String[] = arrays are non-resizable, you will have to copy everything into a new, shorter array.
    	 */
    	//get the VectorAssembler with the features (new vector type) column and transforms the data
    	//have to not include the Sex column for VectorAssembler to generate the features column and then transform
    	data = CommonUtil.getVectorAssembler(Arrays.copyOf(data.columns(), data.columns().length-1)).transform(data); //data with feature
    	data.show(10, false);
    	
        //data.select("*").orderBy(data.col("Age")).show(20, false);
    	
    	
    	//Now select only the feature and label to create the machine learning model.
    	data = data.select("features", "Sex");
    	//split data into training (0.7) and test (0.3) samples
    	Dataset<Row>[] split = data.randomSplit(new double[] {0.7,0.3});
    	
    	//Peek into training data
        split[1].describe().show();
        
        /**
         * Set the LogisticRegression equation parameters 
         * and FeaturesCol and LabelCol
         * using the features column to infer the Label (Sex) column.  features -> Sex
         */
        LogisticRegression lr = new LogisticRegression().setFeaturesCol("features")  //Estimator
        		                     .setLabelCol("Sex")
        		                     .setMaxIter(10)
        		                     .setRegParam(0.3)
        		                     .setElasticNetParam(0.8);
     
        //Fit the model with the training set to get the logistic regression (binary) equation
        //binary with 0 and 1 where 0 = male and 1 = female
        //Remember to use org.apache.spark.ml.classification.LogisticRegressionModel; not spark.mllib
        /**
         * For Transformer stages, the transform() method is called on the DataFrame. It converts one DataFrame into another, generally by appending one or more columns.
         * For Estimator stages, the fit() method is called to produce a Transformer (which becomes part of the PipelineModel, or fitted Pipeline), 
         * and that Transformer’s transform() method is called on the DataFrame.
         * An Estimator abstracts the concept of a learning algorithm or any algorithm that fits or trains on data. 
         * Technically, an Estimator implements a method fit(), which accepts a DataFrame and produces a Model, which is a Transformer. 
         * For example, a learning algorithm such as LogisticRegression is an Estimator, and calling fit() trains a LogisticRegressionModel, which is a Model and hence a Transformer.
         */
        LogisticRegressionModel lrModel = lr.fit(split[0]); //Transformer
        
     // Print the coefficients and intercept for logistic regression
      //  System.out.println("Coefficients: "
     //     + lrModel.coefficients() + " Intercept: " + lrModel.intercept());
        
    	//now get the LogisticRegressionModel to predict the test data
        data = lrModel.transform(split[1]);
    	//data.select("*").filter("prediction = 0.0").show(20, false); 
    	data.show(10, false);
    	
    	//now use Random Forest Classifier by setting the parameters
    	//RandomForestClassifier rfc = new RandomForestClassifier().setFeaturesCol("features")
    			                       //  .setLabelCol("Sex")
    			                       //  .setMaxDepth(5);
    	
    	//fit the training set to get the model
    	//RandomForestClassificationModel rfcModel = rfc.fit(split[0]); //Transformer
        
    	//use the Random Forest Classification model with the test data to make the Sex predictions
    	//data = rfcModel.transform(split[1]);
    	//data.show(10, false);
    	
    	//use a basic metric called accuracy to see if the model is accurate
    	MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator().setLabelCol("Sex")
    			                                              .setPredictionCol("prediction")
    			                                              .setMetricName("accuracy");
    	double accuracy = evaluator.evaluate(data);
    	System.out.println("accuracy = " + accuracy);
        
    }
}
