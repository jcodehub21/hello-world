#!/bin/bash

day=$1
#day=20210907
converted_day=$(date -d "$day" +"%Y-%m-%d")
client=$2 #absa-f6 #
portfolio=$3 #none #
if [ $4 == 'credit' ] ||[ $4 == 'oil' ]
    then
      rectype='CRTRAN'
    else
      rectype='DBTRAN'
fi
# rectype='CRTRAN'
# Ping Oracle database for client files from given day
export ORACLE_HOME=/ptoan/shared/ORACLE/client19c
export CONNECT_STRING='prod/prod@//rhldatdms14001:1521/MDWP3.WORLD'
export ORAENV_ASK=NO
#export ORACLE_SID=sqlnet
. oraenv 2>&1 > /dev/null

export SQLPLUS=`ls -S ${ORACLE_HOME}/bin/sqlplus 2>/dev/null | head -1`
if [ "$SQLPLUS" = "" ]
then
        export SQLPLUS=`ls ${ORACLE_HOME}/bin/sqlplus 2>/dev/null | head -1` 2>/dev/null
fi

if [ "$SQLPLUS" = "" ]
then
        export SQLPLUS=`ls ${ORACLE_HOME}/bin/sqlplus | head -1`
fi

if [ -f "$SQLPLUS" ]
then
  ORABIN=`dirname $SQLPLUS`
  export PATH=/bin:/usr/bin:/usr/local/bin:/usr/sbin:/sbin:$ORABIN
  export ORACLE_HOME=${ORABIN%/bin}
  export LD_LIBRARY_PATH='/usr/lib:/usr/local/lib:/usr/openwin/lib:/usr/ccs/lib:$ORACLE_HOME'

  $SQLPLUS -silent /nolog << EOF
  connect ${CONNECT_STRING}
  set pagesize 10000;
  set head off;
  set linesize 200;
  set feedback off;
  set echo off;
  spool "client_files.txt";
  select ALL_P_FILES.FILENAME
  from ALL_P_FILES
  where ALL_P_FILES.RECCLASS = '${rectype}_Auth' AND ALL_P_FILES.CLIENT = '$client' AND ALL_P_FILES.PORTFOLIO = '$portfolio' AND ALL_P_FILES.FILESTATUS = '2' AND TO_CHAR(ALL_P_FILES.PROCESS_STOP,'YYYY-MM-DD') = '$converted_day';
EOF

#  where ALL_P_FILES.RECCLASS = '${rectype}_Auth' AND ALL_P_FILES.CLIENT = '$client' AND ALL_P_FILES.PORTFOLIO = '$portfolio' AND ALL_P_FILES.FILESTATUS = '2' AND TO_CHAR(ALL_P_FILES.PROCESS_STOP,'YYYY-MM-DD') = '$converted_day';
# echo "
  # set pagesize 10000;
  # set head off;
  # set linesize 200;
  # set feedback off;
  # set echo off;
  # spool "client_files.test2.txt";
  # select ALL_P_FILES.FILENAME
  # from ALL_P_FILES
  # where ALL_P_FILES.RECCLASS = '${rectype}_Auth' AND ALL_P_FILES.CLIENT = '$client' AND ALL_P_FILES.PORTFOLIO = '$portfolio' AND ALL_P_FILES.FILESTATUS = '2' AND TO_CHAR(ALL_P_FILES.PROCESS_STOP,'YYYY-MM-DD') = '$converted_day';
# EOF
# "

else
  echo "Oracle SQL*Plus is not found. Please correct script to point to the right place."
  exit 1
fi

