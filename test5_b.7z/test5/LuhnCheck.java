
public class LuhnCheck {

	public static void main(String[] args){
		LuhnCheck test = new LuhnCheck();
		//if result is true then it is a real credit card # or any type of number
		System.out.println("Is number valid? " + test.luhnCheck("581149215382308"));
	}
	
	/**
	 * returns the character at the specified index in a string
	 * The index of the first character is 0, the second character is 1, and so on
	 * @param word
	 */
	public void testCharAt(String word){
		for(int i = 0; i < word.length(); i++){
			//produces Unicode code points to for the characters '1', '2', '3' etc.
			int d = word.charAt(i);		
			System.out.println("Unicode " + i + ": " + d);
			
			//If you know that they'll be Western digits, you can just subtract '0':
			int w = word.charAt(i) - '0';
			//System.out.println("index " + i + ": " + (char)(word.charAt(i)));
			System.out.println("Western digit " + i + ": " + w);
			
			//take the values and then check that the results are in the range 0-9
			//This will return -1 if the character isn't an appropriate digit
			int y = Character.digit(word.charAt(i), 10);
			System.out.println("Is it a digit at " + i + ": " + y);
		}
	}
	
	/**
	 * Luhn check algorithm - also known as the modulus 10 or mod 10 algorithm, 
	 * is a simple checksum formula used to validate a variety of identification numbers, 
	 * such as credit card numbers, IMEI numbers, Canadian Social Insurance Numbers
	 * 
	 * includes the check digit (the first rightmost digit)
	 * Step 1 � Starting from the rightmost digit, double the value of every second digit
	 * Step 2 � If doubling of a number results in a two digit number i.e greater than 9(e.g., 6 � 2 = 12), 
	 * then add the digits of the product (e.g., 12: 1 + 2 = 3, 15: 1 + 5 = 6), to get a single digit number.
	 * Step 3 � Now take the sum of all the digits
	 * Step 4 � If the total modulo 10 is equal to 0 (if the total ends in zero or remainder is zero) then the number is valid according to the Luhn formula; 
	 * else it is not valid.
	 */
	public boolean luhnCheck(String number){
		int sum = 0;
		int digit;
		boolean secondDigitCount = false;  //start with false with first digit
		
		//loop through the number starting from the rightmost side and go left
		//since string starts at index 0 i need to start at the last right index number of the string which is one less than the string length
		for(int i = number.length()-1; i >= 0; i--){
			digit = Character.digit(number.charAt(i), 10);
			if(digit != -1){
				if(secondDigitCount){  //second digit
					digit = digit * 2;
				}
					sum += digit / 10; //returns the first digit; highest total is 9 * 2 = 18; 18 / 10 = 1 or single digit / 10 returns zero
					sum += digit % 10; //returns the remainder as second digit; example 18 % 10 = 8 or 9 % 10 = 9
				secondDigitCount = !secondDigitCount; //change from false to true for every second digit
			}
		}
		return (sum % 10) == 0;
		
	}
}
