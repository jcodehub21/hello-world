package jc.lambda.util;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.SystemPropertiesCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.athena.AmazonAthena;
import com.amazonaws.services.athena.AmazonAthenaClientBuilder;
import com.amazonaws.services.cloudtrail.AWSCloudTrail;
import com.amazonaws.services.cloudtrail.AWSCloudTrailClientBuilder;
import com.amazonaws.services.costexplorer.AWSCostExplorer;
import com.amazonaws.services.costexplorer.AWSCostExplorerClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.*;
//import com.amazonaws.services.kms.AWSKMS;
//import com.amazonaws.services.kms.AWSKMSClientBuilder;
import com.amazonaws.services.ec2.model.DeleteTagsRequest;
import com.amazonaws.services.ec2.model.Filter;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.resourcegroupstaggingapi.AWSResourceGroupsTaggingAPI;
import com.amazonaws.services.resourcegroupstaggingapi.model.GetResourcesRequest;
import com.amazonaws.services.resourcegroupstaggingapi.model.ResourceTagMapping;
import com.amazonaws.services.resourcegroupstaggingapi.model.TagFilter;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.AmazonS3EncryptionClientV2Builder;
import com.amazonaws.services.s3.AmazonS3EncryptionV2;
import com.amazonaws.services.s3.model.CryptoConfigurationV2;
import com.amazonaws.services.s3.model.KMSEncryptionMaterialsProvider;
import com.amazonaws.services.sagemaker.AmazonSageMaker;
import com.amazonaws.services.sagemaker.AmazonSageMakerClientBuilder;
import com.amazonaws.services.sagemaker.model.*;
//import com.amazonaws.services.sagemaker.model.Tag;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.*;
import jc.lambda.util.AWSProperties;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.*;

/**
 * 07/19/2021 - This class stores all common services that is used across
 * multiple classes
 * Sagemaker Studio AI tutorial: https://aws.amazon.com/tutorials/build-train-deploy-monitor-machine-learning-model-sagemaker-studio/
 * https://stackoverflow.com/questions/78153273/how-to-list-all-running-instances-from-sagemaker-studio
 */
public class CommonOps {
    static AWSStaticCredentialsProvider credentialsProvider;
    static AWSProperties p;
    static StringBuffer sb = new StringBuffer();
    static HashSet<String> mapTag = new HashSet<String>();
    public static AWSStaticCredentialsProvider getCredentialProvider(){
        return credentialsProvider;
    }

    //sets credentials using Java System properties
    public static void setCredentialProvider(){
        //below sets the aws access keys to Java System properties
        p = new AWSProperties();
        p.setProperties();
        //now have AWS credential provider retrieve the aws access keys by look at the Java system properties
        credentialsProvider = new AWSStaticCredentialsProvider(new SystemPropertiesCredentialsProvider().getCredentials());
    }

    //sets credentials using default credential profile file ~/.aws/credentials
    public static void setCredentialProvider(String IAMRole){
        //below uses my credential profile located at C:\Users\JaneCheng\.aws\credentials which did not work in lambda function
        credentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider(IAMRole).getCredentials());
    }

    /**
     * return the standard S3 client
     * with region passed in
     */
    public static AmazonS3 getS3Client(String region){
        return AmazonS3ClientBuilder.standard()
                    .withCredentials(CommonOps.getCredentialProvider())
                    .withRegion(Regions.valueOf(region.toUpperCase()))
                    .build();
    }

    /**
     * return the standard EC2 client
     */

    /**
     * return the standard S3 Encryption Client V2
     * with region and Customer Master Key passed in
     * @param cmkId Customer Master Key
     * @param region region
     */
    public static AmazonS3EncryptionV2 getS3EncryptionClient(String region, String cmkId) {

        /**
         * CryptoConfigurationV2 gave error:
         * The Bouncy castle library jar is required on the classpath to enable authenticated encryption
         * need Bouncy castle jar file
         * I need to specify .withRegion(Regions.US_WEST_2) in order to use my bucket
         * I also need to specify .withAwsKmsRegion(Region.getRegion(Regions.US_WEST_2)) in order to find my CMK under US_WEST_2
         * since it is created only for a Single Region; otherwise throws error saying it cannot find the CMK
         * both .withRegion and .withAwsKmsRegion uses com.amazonaws.regions.Region => Region here is a class
         * using com.amazonaws.services.s3.model.Region will throw errors because this is an Enum not class
         * below uses encryption with Amazon KMS managed keys (KMSEncryptionMaterialsProvider)
         * It also requires the Bouncy castle library jar for lambda function
         */
        return AmazonS3EncryptionClientV2Builder.standard()
                    .withCredentials(CommonOps.getCredentialProvider())
                    .withRegion(Regions.valueOf(region.toUpperCase()))
                    .withCryptoConfiguration(new CryptoConfigurationV2().withAwsKmsRegion(Region.getRegion(Regions.valueOf(region.toUpperCase()))))
                    .withEncryptionMaterialsProvider(new KMSEncryptionMaterialsProvider(cmkId))
                    .build();

            /**
             * below uses Amazon S3 client-side encryption with customer-managed client master keys
             * s3EncryptionClient = AmazonS3EncryptionClientV2Builder.standard()
             .withCredentials(credentialsProvider)
             .withRegion(Regions.valueOf(region.toUpperCase()))
             .withCryptoConfiguration(new CryptoConfigurationV2().withCryptoMode((CryptoMode.StrictAuthenticatedEncryption)))
             .withEncryptionMaterialsProvider(new StaticEncryptionMaterialsProvider(new EncryptionMaterials(cmkId)))
             .build();
             **/

    }

    /**
     * return the AWSKMS client
     * @param region
     */
    /**public static AWSKMS getKMSClient(String region){
        return AWSKMSClientBuilder.standard()
                              .withCredentials(CommonOps.getCredentialProvider())
                              .withRegion(Regions.valueOf(region.toUpperCase()))
                              .build();
    }**/

    /**
     * return standard DynamoDB client v2
     * with region passed in
     */
    public static DynamoDB getDynamoDBClient(String region){
        return new DynamoDB(getDynamoDBClientV1(region));
    }

    /**
     * return standard AmazonDynamoDB v.1
     * with credentials passed in
     */
    public static AmazonDynamoDB getDynamoDBClientV1(String region){
        return AmazonDynamoDBClientBuilder.standard()
                   .withCredentials(CommonOps.getCredentialProvider())
                   .withRegion(Regions.valueOf(region.toUpperCase()))
                   .build();
    }

    /**
     * return Athena client
     * with region passed in
     */
    public static AmazonAthena getAthena(String region){
        return AmazonAthenaClientBuilder.standard()
                    .withCredentials(CommonOps.getCredentialProvider())
                    .withRegion(Regions.valueOf(region.toUpperCase()))
                    .build();
    }

    public static AmazonEC2 getEC2(String region){
        return AmazonEC2ClientBuilder.standard()
                .withCredentials(CommonOps.getCredentialProvider())
                .withRegion(Regions.valueOf(region.toUpperCase()))
                .build();
    }

    public static AWSCloudTrail getCloudtrail(String region){
        return AWSCloudTrailClientBuilder.standard()
                .withCredentials(CommonOps.getCredentialProvider())
                .withRegion(Regions.valueOf(region.toUpperCase()))
                .build();
    }

    public static AWSCostExplorer getCostExplorer(String region){
        return AWSCostExplorerClientBuilder.standard()
                .withCredentials(CommonOps.getCredentialProvider())
                .withRegion(Regions.valueOf(region.toUpperCase()))
                .build();
    }

    public static AmazonSageMaker getSageMaker(String region){
        return AmazonSageMakerClientBuilder.standard()
                .withCredentials(CommonOps.getCredentialProvider())
                .withRegion(Regions.valueOf(region.toUpperCase()))
                .build();
    }

    public static AmazonSimpleEmailService getSES(String region){
        return AmazonSimpleEmailServiceClientBuilder.standard()
                .withCredentials(CommonOps.getCredentialProvider())
                .withRegion(Regions.valueOf(region.toUpperCase()))
                .build();
    }

    /*
     * sendEmail does not work inside of lambda function
     */
    public static void sendEmail(String sender, String recipient, String subject, String bodyHTML){
        String to = recipient;
        String from = sender;
        try
        {
            System.out.println("inside sendEmail method");
            System.out.println("Json string:  " + bodyHTML);
            //sb.append("<br> Thank you, <br> Jane Cheng");
            String host = "mail.fairisaac.com";

            //create properties to store host and get or set the default mail session object
            Properties props = new Properties();
            props.put("mail.smtp.host", host);
            Session session = Session.getInstance(props);
            //create the message object
            MimeMessage msg = new MimeMessage(session);

            //set the sender's email address
            msg.setFrom(new InternetAddress(from));

            //set the recipient's email address
            msg.setRecipients(javax.mail.Message.RecipientType.TO, to);

          /* if you have more than 1 recipient to send to then use this:
           InternetAddress[] address = {new InternetAddress(args[0])};
           msg.setRecipients(Message.RecipientType.TO, address);

          */
            //set the subject heading
            msg.setSubject(subject);

            //set the date of sending the email; new date() initializes to current date
            msg.setSentDate(new Date());

            //set the message body; setText method only uses text/plain
            // msg.setText(msgBody);
            Multipart mp = new MimeMultipart();

            //set the html body part
            MimeBodyPart htmlbody = new MimeBodyPart();
            htmlbody.setContent(bodyHTML.toString(), "text/html");
            mp.addBodyPart(htmlbody);

            //set the attachment part
            //MimeBodyPart attachment = new MimeBodyPart();
            // attachment.attachFile("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
            //--attachment.setFileName("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
            //--attachment.setContent(attachment, "application/vnd.ms-excel");
            // attachment.attachFile("/ana/mds/prd/data/FIS_Ind_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
            //mp.addBodyPart(attachment);

            //need to use setContent method if using text/html
            //  msg.setContent(sb.toString(), "text/html");
            msg.setContent(mp);

            //send the email
            Transport.send(msg);
        }
        catch(Exception e){
            System.out.println("Error in sending: ");
            e.printStackTrace();
        }
    }

    public static void sendSESEmail(AmazonSimpleEmailService ses, String sender, String recipients, String subject, String bodyHTML){
        try{
            List<String> to = new ArrayList<>();
            to.add(recipients);
            SendEmailResult sendEmailResult = ses.sendEmail(new SendEmailRequest(sender,
                    new Destination().withToAddresses(to),
                    new Message(new Content(subject), new Body().withHtml(new Content(bodyHTML)))));
        }catch(Exception e){
            System.out.println("Error in sending: ");
            e.printStackTrace();
        }
    }

    //https://github.com/awsdocs/aws-doc-sdk-examples/blob/main/javav2/example_code/ses/src/main/java/com/example/ses/SendMessageAttachment.java
    public static void sendSESEmailAttachment(AmazonSimpleEmailService ses, String sender, List<String> recipients, String subject, String bodyHTML, String workbook){
        try {
            InternetAddress[] address = new InternetAddress[recipients.size()];
            /**
             * ses.sendRawEmail(SendRawEmailRequest sendRawEmailRequest)
             * This operation is more flexible than the SendEmail operation. When you use the SendRawEmail operation, you can specify the headers of the message as well as its content. This flexibility is useful, for example, when you need to send a multipart MIME email (such a message that contains both a text and an HTML version).
             * You can also use this operation to send messages that include attachments.
             */
            //get or set the default mail session object
            Session session = Session.getInstance(new Properties());
            //create the message object
            MimeMessage msg = new MimeMessage(session);
            //set the sender's email address
            msg.setFrom(new InternetAddress(sender));

            //set to multiple recipient's email address
            for(int x = 0; x < recipients.size(); x++){
                address[x] = new InternetAddress(recipients.get(x).trim());
            }
            msg.setRecipients(javax.mail.Message.RecipientType.TO, address);

            //set the subject heading
            msg.setSubject(subject);

            //set the date of sending the email; new date() initializes to current date
            msg.setSentDate(new Date());

            // Create a multipart/alternative child container.
            Multipart mp = new MimeMultipart();

            //set the html body part
            MimeBodyPart htmlbody = new MimeBodyPart();
            htmlbody.setContent(bodyHTML, "text/html");
            mp.addBodyPart(htmlbody);

            //set the attachment part
            MimeBodyPart attachment = new MimeBodyPart();
            attachment.attachFile(workbook);;
            mp.addBodyPart(attachment);

            /**
             * // Define the attachment per SES Development Guide
             *  MimeBodyPart att = new MimeBodyPart();
             *  DataSource fds = new FileDataSource(ATTACHMENT);
             *  att.setDataHandler(new DataHandler(fds));
             *  att.setFileName(fds.getName());
             */

            //need to use setContent method if using text/html
            //  msg.setContent(sb.toString(), "text/html");
            msg.setContent(mp);

            // Send the email.
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            msg.writeTo(outputStream);
            RawMessage rawMessage = new RawMessage(ByteBuffer.wrap(outputStream.toByteArray()));
            SendRawEmailResult sendRawEmailResult = ses.sendRawEmail(new SendRawEmailRequest(rawMessage));

        }catch(Exception ex){
            System.out.println("Email Failed");
            System.err.println("Error message: " + ex.getMessage());
            ex.printStackTrace();}
    }

    public static boolean checkEC2Tags(AmazonEC2 ec2, String resourceId, String tagName){
        boolean result = false;
        //return ec2.describeTags(new DescribeTagsRequest().withFilters(new Filter().withName("resource-id").withValues(resourceId))).withTags(new TagDescription().withKey(tagName)) != null ? true : false;
        for(TagDescription tag : ec2.describeTags(new DescribeTagsRequest().withFilters(new Filter().withName("resource-id").withValues(resourceId))).getTags()){
            result = tag.getKey().equalsIgnoreCase(tagName) ? true : false;
        }
        return result;
    }

    //check if the tag value is different than the new user name
    public static boolean checkEC2Tags(AmazonEC2 ec2, String resourceId, String tagName, String newUserName){
        boolean result = false;
        //return ec2.describeTags(new DescribeTagsRequest().withFilters(new Filter().withName("resource-id").withValues(resourceId))).withTags(new TagDescription().withKey(tagName)) != null ? true : false;
        for(TagDescription tag : ec2.describeTags(new DescribeTagsRequest().withFilters(new Filter().withName("resource-id").withValues(resourceId))).getTags()){
            //result = tag.getKey().equalsIgnoreCase(tagName) ? true : false;
            if(tag.getKey().equalsIgnoreCase(tagName)){
                if(!tag.withKey(tagName).getValue().equalsIgnoreCase(newUserName)){
                    ec2.deleteTags(new DeleteTagsRequest().withResources(resourceId).withTags(new com.amazonaws.services.ec2.model.Tag().withKey(tagName)));
                }
                else{
                    result = true;
                }
            }
        }
        return result;
    }

    //https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_AttachVolume.html
    //https://github.com/aws/aws-cdk/issues/7930
    public static void checkEBSVolume(AmazonEC2 ec2, String resourceId, String tagName, String newUserName){
        boolean result = false;
        Map<String, com.amazonaws.services.ec2.model.Tag> tagList = new HashMap<String,com.amazonaws.services.ec2.model.Tag>();
        DescribeVolumesResult desVolResult = ec2.describeVolumes(new DescribeVolumesRequest().withFilters(new Filter().withName("attachment.instance-id").withValues(resourceId)));
        for(Volume volume : desVolResult.getVolumes()){
           for(com.amazonaws.services.ec2.model.Tag tag : volume.getTags()){
             if(tag.getKey().equalsIgnoreCase(tagName)){
                 if(!tag.withKey(tagName).getValue().contains(newUserName)){
                     ec2.deleteTags(new DeleteTagsRequest().withResources(volume.getVolumeId()).withTags(new com.amazonaws.services.ec2.model.Tag().withKey(tagName)));
                 }
                 else{
                     result = true; //has the tag fico:common:owner already
                 }
             }
           }
            if(!result){ //this volume needs to add fico:common:owner tag to EBS volume
               //tagList.put(volume.getVolumeId(), new com.amazonaws.services.ec2.model.Tag(tagName, newUserName));
               //Arrays.asList() returns a List<> which is a Collection<> based
                //volume.setTags() did not work
                //volume.setTags(Arrays.asList(new com.amazonaws.services.ec2.model.Tag(tagName, newUserName + "-" + volume.getSize())));
                //below works for tagging EBS volume on EC2 instance
                CreateTagsRequest cTagRequest = new CreateTagsRequest().withResources(volume.getVolumeId()).withTags(new com.amazonaws.services.ec2.model.Tag().withKey(tagName).withValue(newUserName + "-" + volume.getSize() + "GiB"));
                CreateTagsResult cTagResult = ec2.createTags(cTagRequest);
                System.out.println("EBS volume tagged: " + volume.getVolumeId());
                result = false;
            }
        }

    }

    public static boolean checkSageMakerTags(AmazonSageMaker sagemaker, String notebookInstanceName, String tagName){
        boolean result = false;
        String notebookInstanceArn = sagemaker.describeNotebookInstance(new DescribeNotebookInstanceRequest().withNotebookInstanceName(notebookInstanceName)).getNotebookInstanceArn();
        // return sagemaker.listTags(new ListTagsRequest().withResourceArn(notebookInstanceArn)).withTags(new Tag().withKey(tagName)) != null ? true : false;
        for(com.amazonaws.services.sagemaker.model.Tag tag : sagemaker.listTags(new ListTagsRequest().withResourceArn(notebookInstanceArn)).getTags()){
            result = tag.getKey().equalsIgnoreCase(tagName) ? true : false;
        }
        return result;
    }

    //check if the tag value is different than the new user name
    public static boolean checkSageMakerTags(AmazonSageMaker sagemaker, String notebookInstanceName, String tagName, String newUserName){
        boolean result = false;
        String notebookInstanceArn = sagemaker.describeNotebookInstance(new DescribeNotebookInstanceRequest().withNotebookInstanceName(notebookInstanceName)).getNotebookInstanceArn();
        // return sagemaker.listTags(new ListTagsRequest().withResourceArn(notebookInstanceArn)).withTags(new Tag().withKey(tagName)) != null ? true : false;
        for(com.amazonaws.services.sagemaker.model.Tag tag : sagemaker.listTags(new ListTagsRequest().withResourceArn(notebookInstanceArn)).getTags()){
            if(tag.getKey().equalsIgnoreCase(tagName)){
                if(!tag.withKey(tagName).getValue().equalsIgnoreCase(newUserName)){
                    sagemaker.deleteTags(new com.amazonaws.services.sagemaker.model.DeleteTagsRequest().withResourceArn(notebookInstanceArn).withTagKeys(tagName));
                }
                else{
                    result = true;
                }
            }
            //result = tag.getKey().equalsIgnoreCase(tagName) ? true : false;
        }
        return result;
    }

    public static String getSageMakerNotebookResourceARN(AmazonSageMaker sagemaker, String notebookInstanceName){
        return sagemaker.describeNotebookInstance(new DescribeNotebookInstanceRequest().withNotebookInstanceName(notebookInstanceName)).getNotebookInstanceArn();
    }

    //get Sagemaker Domain name with sagemaker and domainID as arguments
    public static String getSageMakerDomainName(AmazonSageMaker sagemaker, String domainID){
        System.out.println("CommonOps.getSagemakerDomainName:domainID: " + domainID);
        DescribeDomainResult ddr = null;
        String domainName = "";
        try{
            ddr = sagemaker.describeDomain(new DescribeDomainRequest().withDomainId(domainID));
            domainName = ddr.getDomainName();
        }catch(ResourceNotFoundException e){
            domainName = domainID;
            System.out.println("Resource Not Found Error because sagemaker domain no longer exist");
        }catch (Exception e) {
            domainName = domainID;
        }
        return domainName;
    }

    //get Sagemaker Domain name with domain ID as an argument
    public static String getSageMakerDomainName(String domainID){
        System.out.println("CommonOps.getSagemakerDomainName:domainID: " + domainID);
        AmazonSageMaker sagemaker = AmazonSageMakerClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        DescribeDomainResult ddr = null;
        String domainName = "";
        try{
            ddr = sagemaker.describeDomain(new DescribeDomainRequest().withDomainId(domainID));
            domainName = ddr.getDomainName();
        }catch(ResourceNotFoundException e){
            domainName = domainID;
            System.out.println("Resource Not Found Error because sagemaker domain no longer exist");
        }catch (Exception e) {
            domainName = domainID;
        }
        return domainName;
    }

    public static String getAWSAccountName(String accountNumber){
        String accountName = "";
        switch(accountNumber){
            case "709542126867":
                accountName = "PTO.StreamEngine.DevSand";
                break;
            case "171218618055":
                accountName = "Data Scientists - Analytics (Sandbox)";
                break;
            case "236423464058":
                accountName = "IML Build Service (Internal)";
                break;
            case "545403240825":
                accountName = "ATD Blockchain";
                break;
            case "142326806626":
                accountName = "ATD Blockchain (Prod)";
                break;
            case "011528274929":
                accountName = "AIID.NorthStarIMLAnalytics.DevManaged";
                break;
            case "902873844798":
                accountName = "Analytics.ModelAuthoring.Prod";
                break;
            default:
                accountName = "No AWS Account Name found";
                break;
        }
        return accountName;
    }

    //https://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/ResourceGroupsTaggingAPI.html
    //https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/resourcegroupstaggingapi/model/GetResourcesRequest.html
    public static String getResourceByTagKey(AWSResourceGroupsTaggingAPI rgtag, String keyName, String value){
        String service = "";
        String type = "";
       try{
           //System.out.println("keyName: " + keyName);
           //System.out.println("value: " + value);
           List<ResourceTagMapping> listRTM = rgtag.getResources(new GetResourcesRequest().withTagFilters(new TagFilter().withKey(keyName).withValues(value))).getResourceTagMappingList();
           if(listRTM.size() > 0) {
               for (ResourceTagMapping rtm : listRTM) {
                   //System.out.println("Resource ARN: " + rtm.getResourceARN());
                   if (!mapTag.contains(rtm.getResourceARN().split(":")[2])) { //get the 2nd item which is the service name
                       type = rtm.getResourceARN().split(":")[5];
                       if(type.contains("/")){
                           type = type.substring(0, type.indexOf("/"));
                       }
                       mapTag.add(rtm.getResourceARN().split(":")[2] + ":" + type);
                       //rtm.getResourceARN().split(":")[5] is the resource type ie instance, volume, route-table, etc.
                       // System.out.println("Resource ARN: " + rtm.getResourceARN());
                   }
               }
           }
           if(mapTag.size() > 0) {
               for (String key : mapTag) {
                   service += key + ",";
               }
               service = service.substring(0, service.lastIndexOf(","));
           }
          mapTag.clear();  //clear the hashset; otherwise, it will keep the keys from other users
       }catch(Exception e){e.printStackTrace();}
       return service;
    }
}
