import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Serializable;
import java.time.LocalDateTime;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;

/**
 * 01/10/2023 - this class updates a field value in the parquet file
 * SHK:
 * spark3-submit --master yarn --deploy-mode client --executor-memory 40g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --driver-class-path /home/janecheng/ojdbc6.jar --jars /home/janecheng/ojdbc6.jar --class ParquetFieldUtil /home/janecheng/RollingPISNMONv2.jar numberOfPaymentIds 001 /home/janecheng/cfg-f6_parquetupdate.txt > /home/janecheng/parquetfieldutil.log 2>&1 &
 * @author JaneCheng
 *
 */
public class ParquetFieldUtil implements Serializable{
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> df = null;
	String fieldName = "";
	String newValue = "";
	String parquetFile = "";
	
	public static void main(String[] args) {
		
		/**
		 * args[0] = field name to update
		 * args[1] = field value to update to
		 * args[2] = location of parquet file to update or file containing the list of files to read from
		 * args[3] = location of newly updated parquet file to write to
		
		 */
		String content = "";
		try {
		   ParquetFieldUtil field = new ParquetFieldUtil(args);
		   field.createSparkSession();
		
			BufferedReader br = new BufferedReader(new FileReader(args[2]));
			
			while((content = br.readLine()) != null){
                   field.updateParquetField(content);
                   System.out.println("Updated parquet file: " + content + " : " + LocalDateTime.now());
			   }
			   if(br != null){br.close();}  
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public ParquetFieldUtil(String[] args){
		fieldName = args[0];
		newValue = args[1];
	}
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("UpdateParquetField")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		}
		catch(Exception e){e.printStackTrace();}	
	}

    public void updateParquetField(String parquetPath){
    	try{
    		System.out.println("Starting udpateParquetField(): " + fieldName + " : " + LocalDateTime.now());
            df = spark.read().parquet(parquetPath);
            df = df.withColumn(fieldName + "Temp", functions.lit(newValue).cast(DataTypes.StringType));
            df = df.drop(fieldName).withColumnRenamed(fieldName + "Temp", fieldName);
            df.repartition(1)
            .write()
            .option("compression","gzip")
            .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
            .parquet(parquetPath.substring(0, parquetPath.lastIndexOf("/")) + "/update/");
    		
    	}catch(Exception e){e.printStackTrace();}
    }
}
