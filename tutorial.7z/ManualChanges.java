import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


/**
 * 10/4/2021:  This class creates the insert statements for the manual_changes table in 
 * mdwp2_rhldatdms14001 Oracle database after akbank-f6 none PAN mapping 
 * @author JaneCheng
 *
 */

public class ManualChanges {

	public static void main(String[] args) {
		String content;
		String[] split;
		String processedDate = "2021-10-04";  //eg. '2021-10-03' 'YYYY-MM-DD'
		try{
		  BufferedReader br = new BufferedReader(new FileReader("C:\\fmt-client\\akbank\\2108_dbtran25_Auths.txt"));
		  BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\fmt-client\\akbank\\2108_dbtran25_Auths_insert.txt"));
		  while((content = br.readLine()) != null){
			  //System.out.println(content);
			  if(content.indexOf("Complete") > -1){  //If no such value of k exists, then -1 is returned.
				continue;  
			  }
			  else{
				  split = content.substring(content.lastIndexOf("/") + 1).split("\\.");
				  bw.write("insert into manual_changes values ('" + split[4] + "', DATE '" + processedDate + "', 'akbank-f6(none) pan mapping', 'JaneCheng');");
				  bw.newLine();
			  }
		  }
		
		  br.close();
		  bw.close();
		
		}catch(Exception e){e.printStackTrace();}
	}

}
