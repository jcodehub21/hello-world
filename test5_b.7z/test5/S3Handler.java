package jc.lambda.util;
import com.amazonaws.encryptionsdk.AwsCrypto;
import com.amazonaws.encryptionsdk.CryptoInputStream;
import com.amazonaws.encryptionsdk.kms.KmsMasterKey;
import com.amazonaws.encryptionsdk.kms.KmsMasterKeyProvider;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.lambda.runtime.events.models.s3.S3EventNotification;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3EncryptionV2;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.util.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.net.URL;
import java.util.Collections;
import java.util.Map;


/**
 * 07/02/2021 - Created a maven project and regular java class called S3Handler
 * Added the aws lambda java core, lambda java events, aws-java-sdk and aws-java-sdk-s3 jars to pom.xml
 * implements RequestHandler gives the @Override handleRequest() method which is what it should do
 * Doing this way in Eclipse under AWS Java Project does not work for lambda function
 * https://javadoc.io/doc/com.amazonaws/aws-lambda-java-events/latest/index.html
 * https://docs.aws.amazon.com/lambda/latest/dg/java-handler.html
 * https://docs.aws.amazon.com/lambda/latest/dg/java-handler.html#java-handler-samples
 */
public class S3Handler implements RequestHandler<S3Event, String>{
    String bucket, key;
   // URL url;
    //AmazonS3EncryptionV2 s3EncryptionClientV2;
    AmazonS3 s3Client;
    static Logger logger = LogManager.getLogger(S3Handler.class);

   @Override
    public String handleRequest(S3Event s3Event, Context context) {

       //encrypt new file with CMK after upload to S3 bucket - does not work
       CommonOps.setCredentialProvider();
        //s3EncryptionClientV2 = CommonOps.getS3EncryptionClient("US_West_2", "arn:aws:kms:us-west-2:780944133628:key/43f7e67b-b756-40fd-8732-23ec51fdbc96");
        //s3EncryptionClientV2 = CommonOps.getS3EncryptionClient("US_WEST_2", "arn:aws:kms:us-west-2:780944133628:key/DMS-DEV-JC-TEST");
        //S3Event.getRecords() return List<S3EventNotification.S3EventNotificationRecord>
       s3Client = CommonOps.getS3Client("US_WEST_2");

       //encrypt new file using aws-encryption-sdk-java
       //instantiate the sdk
       final AwsCrypto crypto = AwsCrypto.builder().build();

       //Instantiate an AWS KMS master key provider in strict mode using buildStrict().
       final KmsMasterKeyProvider keyProvider =
               KmsMasterKeyProvider.builder().buildStrict("arn:aws:kms:us-west-2:780944133628:key/43f7e67b-b756-40fd-8732-23ec51fdbc96");

       //Create an encryption context
       final Map<String, String> encryptionContext =
               Collections.singletonMap("Example", "EncryptingFileStream");

        for(S3EventNotification.S3EventNotificationRecord record : s3Event.getRecords()){

                   bucket = record.getS3().getBucket().getName();
                   key = record.getS3().getObject().getKey();
                 //  url = s3Client.getUrl(bucket, key);
                   //https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/s3/AmazonS3.html#copyObject-com.amazonaws.services.s3.model.CopyObjectRequest-
                  //use copyObject instead of putObject; putObject is for upload; copyObject copies over with encryption
            /**
             * AmazonS3EncryptionClientBuilder returns an AmazonS3EncryptionClient which does not implement copyObject.
             * So I suspect it falls back to the default implementation in AmazonS3Client.
             * CopyObject works, but it copies file without encryption
             * PutObject also does not work
             */
           // s3EncryptionClientV2.copyObject(new CopyObjectRequest(bucket,key,"jcfunctiontest",key.substring(0, key.lastIndexOf(".")) + "-Encrypted.txt"));

           //encrypt the data; below works now in lambda
            try {
                //get the object content and read it into streams
                S3Object object = s3Client.getObject(new GetObjectRequest(bucket, key));
                InputStream is = object.getObjectContent();
                //FileInputStream in = new FileInputStream(bucket + "/" + key);
                CryptoInputStream<KmsMasterKey> encryptingStream = crypto.createEncryptingStream(keyProvider, is, encryptionContext);

                //LAMBDA_TASK_ROOT (/var/task) is the path to my lambda function and read-only filesystem
                //so have to create and encrypt the file at /tmp because only place have read-write permissions
                File encryptFile = new File("/tmp/" + key + ".encrypted");
                FileOutputStream out = new FileOutputStream(encryptFile);
                IOUtils.copy(encryptingStream, out);
                encryptingStream.close();
                out.close();
                is.close();
                //for PutObjectRequest I want the S3 key name to be only key + ".encrypted" without the /tmp/
                s3Client.putObject(new PutObjectRequest("jcfunctiontest", key + ".encrypted", encryptFile));
            }catch(FileNotFoundException e){
                logger.error("File to encrypt not found: {}", e.getMessage());
            }catch(IOException e){
                logger.error("Cannot copy encrypted stream to FileOutputStream: {}", e.getMessage());
            }

        }
        //created an AWS SNS topic on AWS Management console and used my fico email as a subscriber to the topic
        //the return key message below went to my SNS topic and sends an email to me if encryption was successful
        //after a file is uploaded to us-west-2/jc-uswest2-testbucket
        return "AWS_Region: " + System.getenv("AWS_REGION") + " " +
                "LAMBDA_TASK_ROOT: " + System.getenv("LAMBDA_TASK_ROOT") + " " +
                "AWS_ACCESS_KEY_ID: " + System.getenv("AWS_ACCESS_KEY_ID") + " " +
                "PATH: " + System.getenv("PATH") + " " +
                bucket + "/" + key + " is now encrypted";
    }

}
