import org.apache.spark.sql.api.java.UDF1;


public class UDF2 implements UDF1<String, String>{

	/**
	 * Java UserDefinedFunction for Spark SQLContext
	 * This UDF2 will hash customerAcctNumber
	 * @author JaneCheng
	 */
	private static final long serialVersionUID = 1L;
	HashingFields hf = new HashingFields();
	
	
	@Override
	public String call(String columnValue) throws Exception {
		
		return hf.hashingCustomerAcctNumber(columnValue);
	}
}
