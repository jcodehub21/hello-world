package org.jcservices;

import java.io.Serializable;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class RhlappmbSparkTest implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> df;
	public static void main(String[] args) {
		RhlappmbSparkTest test = new RhlappmbSparkTest();
		test.startSparkSession(args[0]);  //appname
		test.getData(args[1]);  //data location

	}
	
	public void startSparkSession(String appname) {
		spark = SparkSession
	  			  .builder()
	  			  .appName(appname)
	  			//  .master("local")
	  			  .config("spark.sql.debug.maxToStringFields", 2000)
	  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
	  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
	  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
	  			  .getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
	}
	
	public void getData(String location) {
		try {
			df = spark.read().parquet(location);
			df = df.select(df.col("pan")).groupBy(df.col("pan")).count();
			df.show(20, false);
			System.out.println("total pan record count: " + df.select(df.col("pan")).count());
			
		}catch(Exception e) {e.printStackTrace();}
	}

}
