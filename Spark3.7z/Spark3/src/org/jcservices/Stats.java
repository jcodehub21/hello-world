package org.jcservices;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.beust.jcommander.JCommander;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

/*
 * 8/31/2022 -  this class takes a client's field and gather stats from parquet files
 */
public class Stats implements Serializable{
	
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> ds = null;
	String client, portfolio, yymm, feed, field;
	List<StructField> fields = null;
	StructType binSchema = null;
	//private static Logger logger = LogManager.getLogger(Stats.class);
	
	public static void main(String[] args) {
		args = new String[] {"-c=rbs-f6", "-p=debit", "-d=2004-2006", "-t=frd15", "-f=pan"};
		Stats stat = new Stats();
		if(args.length == 5) {
			 CommonUtilParser cup = new CommonUtilParser();
			 JCommander parser = JCommander.newBuilder().addObject(cup).build();
		     parser.parse(args);  //parse the arguments from command-line
		     stat.setArgs(cup.getClient(), cup.getPortfolio(), cup.getYymm(), cup.getDatafeed(), cup.getField());
		     
		        
		}else {
			stat.usage();
		}
	}

	public void usage() {
		System.out.println("Usage: Gather statistics on a field per data feed. \n"
				+ "Parameters: -c client -p portfolio -d yymm-yymm -f datafeed -b fieldname\n"
				+ "Example: -c rbs-f6 -p debit -d 2004-2204 -r frd15 -f PAN");
		
		System.exit(-1);
	}
	
	public void setArgs(String client, String portfolio, String dateperiod, String feed, String field) {
		this.client = client;
		this.portfolio = portfolio;
		yymm = dateperiod;
		this.feed = feed;
		this.field = field;
		startSparkSession();
		getRecordCount();
	}
	
	public void startSparkSession() {
		try {
		spark = CommonUtil.getSparkSession(client + " Stats");
		spark.sparkContext().setLogLevel("WARN");
		//logger.info("Spark session started: " + LocalDateTime.now());
		}catch(Exception e) {e.printStackTrace();}
		
	}
	
	public String getPaths() {
		
		String path = "";
		if(yymm.contains("-")) {
			int start = Integer.parseInt(yymm.substring(0, yymm.indexOf("-")));
			int end = Integer.parseInt(yymm.substring(yymm.indexOf("-") + 1));
			
			while(start <= end) {
				path = path + "C:\\fmt-client\\" + client + "\\" + portfolio + "\\" + feed + "\\" + start + ",";
				//path = path + "/data/parquet_falcon/" + client + "/" + portfolio + "/" + feed + "/" + start + ",";
				//System.out.println((Integer.parseInt((String.valueOf(start)).substring(2)) / 12) == 1);
				
				if((Integer.parseInt((String.valueOf(start)).substring(2)) / 12) == 1) {
					start = Integer.parseInt((String.valueOf(start)).substring(0,2) + "01") + 100;
					//System.out.println("new year: " + start);
				}
				else {
					start++;
				}
			}
		}
		path = path.substring(0, path.lastIndexOf(","));
		System.out.println("Generate path list: " + path + ": " + LocalDateTime.now());
		//logger.info("Generate path list: " + path + ": " + LocalDateTime.now());
		return path;
			
	}
	
	public void getRecordCount() {
		try {
		   ds =	spark.read()
			  .format("parquet")
			  .load(getPaths().split(",")); //to load different file locations using strings
		   
		   fields = new ArrayList<>();
		   //create the BIN 
		   fields.add(DataTypes.createStructField("BIN", DataTypes.StringType, true));
		   binSchema = DataTypes.createStructType(fields);
		   
		   ds = ds.select(field).map((MapFunction<Row,Row>) row -> {
			return RowFactory.create(row.mkString().substring(0,6));
		   }, RowEncoder.apply(binSchema));
		   
		   ds = ds.select("BIN").groupBy(ds.col("BIN")).count();
		  // ds.select("BIN").groupBy(ds.col("BIN")).count().show(20);
			
		}catch(Exception e) {e.printStackTrace();}
			//logger.error("Exception: {}", e.getMessage());};
	}

}
