import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
//import org.apache.spark.sql.functions;

 // lbzcat /dmsdisk'*'/prd/arch/FALCON/GS-CLOUD/NONE/2204/2204.gs-cloud.none.pis12.109[45]* | colgrep 110 GS_BANK_JAZZ | lbzip2 > 202204.gs-cloud.none.pis12.part2.JAZZ.PROD.bz2"
 
 // rhlappfrd60005:
 // spark2-submit --master yarn --deploy-mode client --executor-memory 40g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --driver-memory 20g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --class ADEDataExtraction /home/janecheng/ADEUtilv7.jar '/dmsdisk*/prd/arch/FALCON/SCB-F6/NONE/2208/*crtran25*' scb-f6 none 2208 109-125 clientIdFromHeader SC_PHXSG_CR default > /home/janecheng/scb-f6_crtrancount.log 2>&1 &
 
 /**
 * @author JaneCheng
 *
 */
public class ADEDataExtraction implements Serializable{

	private static final long serialVersionUID = 1L;
	BufferedReader br = null;
	BufferedWriter bw = null;
    String client = "";
    String portfolio = "";
    String yymm = "";
    String compareTo = "";
    String compareFrom = "";
    String newFileName = "";
    int begPos = 0;
    int endPos = 0;
	SparkSession spark = null;
	List<StructField> fields = null;
	StructType rtSchema = null;
	StructType textSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	Dataset<Row> inputFile = null;
	Dataset<Row> newFile = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	
	public static void main(String[] args) {
		/**
		 * args[0] = list of files to read 
		 * args[1] = client
		 * args[2] = portfolio
		 * args[3] = yymm
		 * args[4] = byte position to extract
		 * args[5] = field to compare from
		 * args[6] = string to compare to for extraction
		 * args[7] = path to new filename - optional
		 */
		ADEDataExtraction driver = new ADEDataExtraction(args);
		driver.startSparkSession();
		driver.readSinglePath(args[0]);
	}
	
	public ADEDataExtraction(String[] args){
            
			this.client = args[1];
			this.portfolio = args[2];
			this.yymm = args[3];
			this.compareFrom = args[5];
			this.compareTo = args[6];
			String[] bytes = args[4].split("-");
			begPos = Integer.parseInt(bytes[0]);
			endPos = Integer.parseInt(bytes[1]);
			if(args[7] != null){
				this.newFileName = args[7];
			}
	}
	
	/**
	 * read the path entered by user input
	 * @param fdrlist
	 */
	public void readSinglePath(String singlePath){
		try{
			   System.out.println("single paths: " + singlePath);
			   loadFile("file://" + singlePath);
		}catch(Exception e){e.printStackTrace();}	
	}
	
	/**
	 * read from a text file containing list of paths
	 * @param fdrlist
	 */
	public void readList(String fdrlist){
		String content = "";
		String inputDirPaths = "";
		try{
			BufferedReader brMain = new BufferedReader(new InputStreamReader(fs.open(new Path(fdrlist))));
			while((content = brMain.readLine()) != null){
				   inputDirPaths = inputDirPaths + "file://" + content + ",";
			   }
			   if(brMain != null){brMain.close();}
			   System.out.println("input paths: " + inputDirPaths);
			   loadFile(inputDirPaths.substring(0, inputDirPaths.lastIndexOf(",")));
		}catch(Exception e){e.printStackTrace();}	
	}
	
    public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("ADE Data Extraction")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
		//store FieldObj into RecordTypeMapper so can separate the value
	    //in the text file into table columns
		fieldObj = new RecordTypeMapper<FieldObj>();
		fieldObj.addFieldObj(new FieldObj("filler1", 0, begPos));
		fieldObj.addFieldObj(new FieldObj(compareFrom, begPos, endPos));
		fieldObj.addFieldObj(new FieldObj("filler2", endPos));
		
		//create StructFields
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
			System.out.println("fieldName: " + f.fieldName + " begPos: " + f.begPos + " endPos: " + f.endPos);
		}
					
		//create the schema for the mapper file
	    rtSchema = DataTypes.createStructType(fields);
 
		 //Text data source supports only a single column, and you have 3 columns.
		//create the schema for the new text file
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		
		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		}catch(Exception e){e.printStackTrace();}
	}

    public void loadFile(String filename){
    	try{
 
    		if(filename.contains(",")){
    			inputFile = spark.read()
      				  .format("text")
  				      .option("inferSchema", false)
  				      .option("header", "false")
  				      .load(filename.split(","));
    		}
    		else{
    			System.out.println("filename loaded as single path: " + filename);
    			inputFile = spark.read()
      				  .format("text")
  				      .option("inferSchema", false)
  				      .option("header", "false")
  				      .load(filename);
    		}
    		
    		inputFile = inputFile.map((MapFunction<Row, Row>) row -> {
    			//System.out.println("row: " + row.mkString());
			   fieldObj.setFieldValue(row.mkString());
			   return fieldObj.getRow();
		   }, RowEncoder.apply(rtSchema)); //applies the schema to the row so dataset will know it is for row
    		
    		//inputFile.show(10, false);
    		inputFile.createOrReplaceTempView("input");
    		//spark.sql("select trim(" + compareFrom + ") trimmed from input").show(10, false); //this one works
    		inputFile = spark.sql("select trim(" + compareFrom + ") from input where trim(" + compareFrom + ") = '" + compareTo + "'");
    		inputFile.show(10, false);
    		
    		//inputFile = inputFile.select(functions.trim(inputFile.col(compareFrom)));
    		
    		//below got errors saying that it cannot resolve SC_PHXSG_CR because I forgot to implement Serializable class
    		//inputFile = inputFile.select(compareFrom).where(functions.trim(inputFile.col(compareFrom)) + " = " + compareTo);
    		//inputFile = inputFile.filter(compareFrom + " = " + compareTo);
    		System.out.println(client + "(" + portfolio + ") " + yymm + " count for " + compareTo + ": " + inputFile.count());
    		
    	}catch(Exception e){e.printStackTrace();}
    }
}
