import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class Triad9Linkage {
    Connection conn = null;
    Statement st = null;
    String query = "";
    String result = "";
	public static void main(String[] args) {
		/**
		 * args[0] = MMYYYY eg APR2019
		 */
		Triad9Linkage check = new Triad9Linkage();
		check.checkRRBILPST(args[0]); 
	}
	
	//connect to database
	public void connectDB(){
		try{
			  DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			  conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated from mdwp2 to mdwp3
			  st = conn.createStatement();
		   }catch(Exception e){e.printStackTrace();System.exit(-1);}
	}
	
	/**
	 * check if RRBILPST.BASE file has already been processed by DMS with done status
	 * @param mmyyyy
	 */
	public void checkRRBILPST(String mmyyyy){
		ResultSet rs;
		
		try{
			connectDB();
			query = "select filename from files where filename = 'TRIAD.FIS.US." + mmyyyy + ".RRBILPST.BASE.zip' and status = 'D'";
			rs = st.executeQuery(query);
			while(rs.next()){  //has a record
                result = rs.getString(1);
			}
			if(result.length() > 0){
				System.out.println("0");
			}
			if(conn != null){
				conn.close();
				rs.close();
			}
		}catch(Exception e){e.printStackTrace();System.exit(-1);}
	}

}
