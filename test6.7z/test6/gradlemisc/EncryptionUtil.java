/*
 * This material is the confidential, unpublished property
 * of Fair Isaac Corporation.  Receipt or possession
 * of this material does not convey rights to divulge,
 * reproduce, use, or allow others to use it without
 * the specific written authorization of Fair Isaac
 * Corporation and use must conform strictly to the
 * license agreement.
 *
 * Copyright (c) Fair Isaac Corporation, 2018
 * All Rights Reserved.
 */

package com.fico.fraud.aws.encryption.util;

import com.amazonaws.AmazonClientException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3Encryption;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.Transfer.TransferState;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.fico.fraud.aws.encryption.util.Common.*;

@Slf4j
public class EncryptionUtil {

    private static final String SEPARATOR = "/";
    private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private int interruptedFile = 0;
    private int retry = 0;
    private static String[] userArgs;

    public static void main(String[] args) {
        userArgs = args;
        EncryptionUtilArgsParser parsedArgs = getEncryptionUtilArgsParser(args);
        EncryptionUtil encryptionUtil = new EncryptionUtil();
        switch (parsedArgs.getProfile()) {
            case ENCRYPT:
                encryptionUtil.encrypt(parsedArgs);
                break;
            case DECRYPT:
                encryptionUtil.decrypt(parsedArgs);
                break;
            case METADATA:
                encryptionUtil.getSummary(parsedArgs);
                break;
            default:
                break;

        }
    }

    public static void deleteInputFiles(Path pathToBeDeleted, Set<String> filesToBeDeleted) {
        filesToBeDeleted.stream().forEach(file -> {
            if (new File(pathToBeDeleted + "/"+file).delete()) {
                log.info("Deleted: {}/{}", pathToBeDeleted, file);
            }else {
                throw new RuntimeException(String.format ("Unable to delete file %s/%s",pathToBeDeleted,file));
            }
        });
    }

    public static Set<String> waitForCompletion(MultipleFileUpload multipleFileUpload, String s3Path) {
        Set<String> uploadedFileNamesList;
        try {
            multipleFileUpload.waitForCompletion();
            uploadedFileNamesList = getUploadedFileNames(multipleFileUpload, s3Path);
        }
        catch (AmazonClientException | InterruptedException e) {
            log.error("Amazon service error. Unable to upload files {} ", e.getMessage(), e);
            uploadedFileNamesList = getUploadedFileNames(multipleFileUpload, s3Path);
        }
        return uploadedFileNamesList;
    }

    public static Set<String> getUploadedFileNames(MultipleFileUpload multiUpload, String s3Path) {
        Set<String> uploadedFileNamesSet = new HashSet<>();
        Collection<? extends Upload> subTransferList = multiUpload.getSubTransfers();
        subTransferList.forEach(upload -> {
            String fileName = upload.getDescription().substring(s3Path.length() + upload.getDescription().indexOf(s3Path));
            if (upload.getState() == TransferState.Completed && upload.isDone()) {
                log.info("DONE:{} ", fileName);
                uploadedFileNamesSet.add(fileName);
            } else if (upload.isDone()) {
                log.error("ERROR uploading {}. state: {}.", fileName, upload.getState());
            } else {
                log.error("Batch upload failed - {} will be retried in next batch", fileName);
            }
        });
        return uploadedFileNamesSet;
    }

    public Set<String> getFailedFileNames(MultipleFileUpload multiUpload, String s3Path) {
        return multiUpload.getSubTransfers().stream()
                .filter(upload -> upload.getState() != TransferState.Completed && upload.isDone())
                .map(upload -> upload.getDescription().substring(s3Path.length() + upload.getDescription().indexOf(s3Path)))
                .collect(Collectors.toSet());
    }

    public void encrypt(EncryptionUtilArgsParser parsedArgs) {

        AmazonS3Encryption s3Encryption = getAmazonS3Encryption(parsedArgs);
        TransferManager transferManager = getTransferManager(s3Encryption);
        String s3Path = parsedArgs.getBucketName() + SEPARATOR + parsedArgs.getS3Subdirectory();
        List<File> files = findFiles(parsedArgs.getInputFileDirectory(), parsedArgs.getFileExtension());

        try {
            while (!files.isEmpty()) {

                int filesToUploadCount = Math.min(parsedArgs.getNumberOfFilesToUpload(), files.size());
                List<File> filesToUpload = files.subList(0, filesToUploadCount);

                long start = System.currentTimeMillis();
                if (parsedArgs.isDisplayProgressBar()) {
                    filesToUpload.forEach(file -> log.info("Going to upload: {} ", file));
                }

                MultipleFileUpload multipleFileUpload = transferManager.uploadFileList(parsedArgs.getBucketName(), parsedArgs.getS3Subdirectory(), parsedArgs.getInputFileDirectory(), filesToUpload);

                Set<String> uploadedFilesList = waitForCompletion(multipleFileUpload, s3Path);
                if (uploadedFilesList.size() < filesToUploadCount) {
                    Set<String> failedUploads = getFailedFileNames(multipleFileUpload, s3Path);
                    failedUploads.forEach(failedUpload -> files.removeIf(file -> file.getAbsolutePath().endsWith(failedUpload)));
                }

                if (!uploadedFilesList.isEmpty()) {
                    uploadedFilesList.forEach(uploadedFileName -> files.removeIf(file -> file.getAbsolutePath().endsWith(uploadedFileName)));
                    deleteInputFiles(parsedArgs.getInputFileDirectory().toPath(), uploadedFilesList);
                    long transferTime = (System.currentTimeMillis() - start) / 1000;
                    long transferredBytes = multipleFileUpload.getProgress().getBytesTransferred();
                    long transferredMegaBytes = transferredBytes / 1000000;
                    if (transferTime <= 0) {
                        log.info("{} bytes uploaded in {} seconds @ {}", transferredBytes, transferTime, Instant.now());
                    } else {
                        Double uploadSpeed = BigDecimal.valueOf(transferredMegaBytes / transferTime).setScale(1, RoundingMode.HALF_UP).doubleValue();
                        log.info("{} bytes uploaded in {} seconds, {} MB/s @ {}", transferredBytes, transferTime, uploadSpeed, Instant.now());

                    }
                }
            }
            log.info("no more files to process ");
        } finally {
            transferManager.shutdownNow();
        }
    }

    public void decrypt(EncryptionUtilArgsParser parsedArgs) {
        //System.out.println("Entered into decrypt method");
        AmazonS3Encryption s3Encryption = getAmazonS3Encryption(parsedArgs);
        if(parsedArgs.isMissing()){
            //System.out.println("parsedArgs missing");
            getMissingFiles(parsedArgs, s3Encryption, false);
        }
        else {
            List<S3ObjectSummary> keyList = getS3ObjectSummaries(parsedArgs, s3Encryption);

            keyList.forEach(s3ObjectSummary -> {
                File file = new File(parsedArgs.getOutputFileDirectory() + SEPARATOR + s3ObjectSummary.getKey());
                file.getParentFile().mkdirs();
                //System.out.println("found this file: " + file.getAbsoluteFile());

                GetObjectRequest req = new GetObjectRequest(parsedArgs.getBucketName(), s3ObjectSummary.getKey());
                req.setRequesterPays(true);
                s3Encryption.getObject(req, new File(file.getPath()));

            });
        }

    }

    public void getSummary(EncryptionUtilArgsParser parsedArgs) {
        AmazonS3Encryption s3Encryption = getAmazonS3Encryption(parsedArgs);

        List<S3ObjectSummary> keyList = getS3ObjectSummaries(parsedArgs, s3Encryption);

        keyList.forEach(s3ObjectSummary -> {
            ObjectMetadata objectMetadata = s3Encryption.getObjectMetadata(parsedArgs.getBucketName(), s3ObjectSummary.getKey());
            if (objectMetadata.getUserMetadata().size() == 0) {
                log.info("s3ObjectSummary.getKey() {} metadata count {} ", s3ObjectSummary.getKey(), objectMetadata.getUserMetadata().size());
                objectMetadata.getUserMetadata().forEach((key, value) -> {
                    log.info("s3ObjectSummary.getKey() {} UserMetadata key {} RawMetadata value {}", s3ObjectSummary.getKey(), key, value);
                });
            }

        });

    }

    private List<S3ObjectSummary> getS3ObjectSummaries(final EncryptionUtilArgsParser parsedArgs, final AmazonS3Encryption s3Encryption) {
        //System.out.println("Enter getS3ObjectSummaries");
        //System.out.println("BucketName: " + parsedArgs.getBucketName());
        //System.out.println("Prefix: " + parsedArgs.getInputFileDirectory() + SEPARATOR);
        ListObjectsRequest listObjectsRequest =
                new ListObjectsRequest()
                        .withBucketName(parsedArgs.getBucketName())
                        .withPrefix(parsedArgs.getInputFileDirectory() + SEPARATOR);

        ObjectListing currentObjectsList = s3Encryption.listObjects(listObjectsRequest);
        List<S3ObjectSummary> keyList = currentObjectsList.getObjectSummaries();
        currentObjectsList = s3Encryption.listNextBatchOfObjects(currentObjectsList);
        while (currentObjectsList.isTruncated()) {
            keyList.addAll(currentObjectsList.getObjectSummaries());
            currentObjectsList = s3Encryption.listNextBatchOfObjects(currentObjectsList);
        }
        keyList.addAll(currentObjectsList.getObjectSummaries());
        return keyList;
    }

    //Download missing files
    private void getMissingFiles(final EncryptionUtilArgsParser parsedArgs, final AmazonS3Encryption s3Encryption, boolean timeout) {
        String fileName;
        int fileCount = 0;
        try {
            //System.out.println("Enter getMissingFiles");
            BufferedReader br = new BufferedReader(new FileReader(parsedArgs.getInputFileDirectory()));
            while((fileName = br.readLine()) != null) {
                fileCount++;
                if(!timeout) {
                    interruptedFile++;
                    File file = new File(parsedArgs.getOutputFileDirectory() + SEPARATOR + fileName);
                    //System.out.println("Full filename: " + file.getAbsoluteFile());
                    if (!file.getParentFile().exists()) {
                        //System.out.println("No Parent File: " + file.getParentFile());
                        file.getParentFile().mkdirs();
                    }
                    if (s3Encryption.doesObjectExist(parsedArgs.getBucketName(), fileName)) {
                        //System.out.println("object exists: " + fileName);
                        GetObjectRequest req = new GetObjectRequest(parsedArgs.getBucketName(), fileName);
                        s3Encryption.getObject(req, new File(file.getPath()));
                        log.info("Downloaded {} {}", fileName, Instant.now());
                    }
                }
                else{
                   if(fileCount >= interruptedFile - 1){
                       interruptedFile++;
                       File file = new File(parsedArgs.getOutputFileDirectory() + SEPARATOR + fileName);
                       if (!file.getParentFile().exists()) {
                           file.getParentFile().mkdirs();
                       }
                       if (s3Encryption.doesObjectExist(parsedArgs.getBucketName(), fileName)) {
                           GetObjectRequest req = new GetObjectRequest(parsedArgs.getBucketName(), fileName);
                           s3Encryption.getObject(req, new File(file.getPath()));
                           log.info("Downloaded {} {}", fileName, Instant.now());
                       }
                   }
                }
            }
            br.close();
        } catch(SdkClientException e){
              log.error("SdkClientException Thrown");
            scheduler.schedule(() -> {
                if(retry < 3) {
                    retry++;
                    log.info("Retry No: {}", retry);
                    getMissingFiles(getEncryptionUtilArgsParser(userArgs), getAmazonS3Encryption(getEncryptionUtilArgsParser(userArgs)),true);
                }
                else{
                    log.info("Exiting after three attempts");
                    System.exit(0);
                }
            }, 10, TimeUnit.SECONDS);

        } catch(IOException e){
            log.error("Other I/O Exception Thrown {}", e.getMessage());
        }

    }

    private void listFiles(File dir, List<File> results, String fileExtension) {
        File[] found = dir.listFiles();
        if (found != null) {
            for (File file : found) {
                if (file.isDirectory()) {
                    listFiles(file, results, fileExtension);
                } else {
                    if (file.getName().endsWith(fileExtension)) {
                        results.add(file);
                    }
                }
            }
        }
    }

    private List<File> findFiles(File dir, String fileExtension) {
        List<File> results = new LinkedList<>();
        listFiles(dir, results, fileExtension);
        return results;
    }
}






