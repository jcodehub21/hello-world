//import com.github.fracpete.rsync4j.RSync;
import com.github.fracpete.rsync4j.Ssh;
import com.github.fracpete.processoutput4j.output.CollectingProcessOutput;
//import com.github.fracpete.processoutput4j.output.ConsoleOutputProcessOutput;


/**
 * /Anton/jyc_temp/jdk1.8.0_231/bin/java -cp .:/Anton/jyc_temp:/Anton/jyc_temp/rsync4j-core-3.2.3-10.jar:/Anton/jyc_temp/processoutput4j-0.0.11.jar:/Anton/jyc_temp/argparse4j-0.9.0.jar:/Anton/jyc_temp/commons-io-2.11.0.jar:/Anton/jyc_temp/commons-lang-2.6.jar RsyncUtil /mdswork/prd/work/triad9.reportKT.5001.csv.gz /adapt5/FIS-US/202210
 * @author JaneCheng
 *
 */

public class RsyncUtil {
	
	public static void main(String[] args) {
		/**
		 * args[0] = source file or directory
		 * args[1] = destination file or directory
		 */
       try{
    	   
    	   Ssh ssh = new Ssh()
    	   .outputCommandline(false)
    	  // .verbose(1)
    	   .hostname("lux436.fairisaac.com")
    	   .command("/usr/bin/rsync -a " + args[0] + " rsync://rhldmsprd001" + args[1]);
    	   
    	   
    	  /** CollectingProcessOutput sshoutput = new CollectingProcessOutput();
    	   sshoutput.monitor(ssh.builder());
    	   if (sshoutput.getExitCode() > 0){
  		      System.err.println(sshoutput.getStdErr());
     		   //System.out.println("-1");  //return this result to bash script; 0 = success 
     	   }
     	   else{
     		   System.out.println("0");  //return this result to bash script; 0 = success
     	   }**/
    	   
    	   /**
    	    * below CollectingProcessOutput prints out 2 zeros
    	    */
    	   CollectingProcessOutput sshoutput = ssh.execute();
    	   if (sshoutput.getExitCode() > 0){
 		      System.err.println(sshoutput.getStdErr());
    		   //System.out.println("-1");  //return this result to bash script; 0 = success 
    	   }
    	   else{
    		   System.out.println("0");  //return this result to bash script; 0 = success
    	   }
    	   
    	  // ConsoleOutputProcessOutput sshoutput = new ConsoleOutputProcessOutput();
    	  // sshoutput.monitor(ssh.builder());
    	   
    		/**RSync rsync = new RSync()
	    	  .source(args[0])
		      .destination("rsync://rhldmsprd001" + args[1])
		      .archive(false)
		      .delete(false);  **/
		    //  .recursive(false);
    		  
		     // or if you prefer using commandline options:
		     // rsync.setOptions(new String[]{"-r", "/one/place/", "/other/place/"});
    		
    		//CollectingProcessOutput = only outputting the data from stdout/stderr after the process completes
		   /** CollectingProcessOutput rsyncoutput = rsync.execute();
		    System.out.println(rsyncoutput.getStdOut());
		    System.out.println("Exit code: " + rsyncoutput.getExitCode());
		    if (rsyncoutput.getExitCode() > 0)
		      System.err.println(rsyncoutput.getStdErr());  **/
		    
		    //This example outputs stdout/stderr from the rsync process as it occurs, rather than waiting till the end:
		    //ConsoleOutputProcessOutput output = new ConsoleOutputProcessOutput();
		  //  output.monitor(rsync.builder());
    	    
       }catch(Exception e){e.printStackTrace();}
	}
}
