import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * 05/24/2022 - this class will automate processing Permata Fraud CSV file on DMS using lux432-434 servers by
 * 1. shellscript to call my java program to hash Pan and Customeracctnumber
 * 2. my java program will then call /mdswork/prd/bin/getPermataFraudDMS.sh
 * 3. /mdswork/prd/bin/getPermataFraudDMS.sh will call /mdswork/prd/bin/convertFrd15.py to convert to FRD file
 * 4. Post FRD file will be stored on DMS disks
 * Log = ${LOGDIR}${FILEID}.${INCARNATION}.${WFID}.${STEPNUM}.log
 * @author JaneCheng
 */
public class PermataCSVDMS {

	String filename = "";
	String yymm = "";
	String fileid = "";
	BufferedReader br = null;
	BufferedWriter bw = null;
	BufferedWriter logger = null;
	String command = "";
	String[] commandArgs = null;
	ProcessBuilder builder = null;
	Process p = null; //process for Linux
	Connection conn = null;
	Statement st = null; //complete query without any input parameters needed; execute one time
	String updateFilesTable = "";
	String updateFilehistoryTable = "";
	int incarnation = 0;
	String wfid = "";
	int stepnum = 0;
	
	public static void main(String[] args) {
		/**
		 * args[0] = filename
		 * args[1] = fileid 
		 * args[2] = incarnation
		 * args[3] = wfid
		 * args[4] = stepnum
		 */
		PermataCSVDMS driver = new PermataCSVDMS(args);
        driver.processFRD();
	
	}
	
	public PermataCSVDMS(String[] args){
	   try{
		filename = args[0];
		fileid = args[1];
		incarnation = Integer.parseInt(args[2]);
		wfid = args[3];
		stepnum = Integer.parseInt(args[4]);
		logger = new BufferedWriter(new FileWriter("/mdswork/prd/logs/" + fileid + "." + incarnation + "." + wfid + "." + stepnum + ".log"));
		
		//insertQuery = "INSERT INTO FileHistory (fileid, incarnation, wfid, step#, status, record_date, agent_id, infilename, action_id)"
		//		+ "VALUES (" + fileid + "," + incarnation++ + ",\'ADEchildFile\',80, 'Q', SYSDATE, \'lux432-01\', ?, \'File2ClientDir\')";
		
		
		//month is the first 3 letters
		String month = filename.substring(filename.indexOf("FRD15") + 6, filename.indexOf("FRD15") + 9);  
		String year = filename.substring(filename.lastIndexOf("_") + 3, filename.lastIndexOf("_") + 5);
		switch (month){
		case "Jan": 
			yymm = year + "01";
		    break;
		case "Feb": 
			yymm = year + "02";
		    break;
		case "Mar": 
			yymm = year + "03";
		    break;
		case "Apr": 
			yymm = year + "04";
		    break;
		case "May": 
			yymm = year + "05";
		    break;
		case "Mei": 
			yymm = year + "05";
		    break;
		case "Jun": 
			yymm = year + "06";
		    break;
		case "Jul": 
			yymm = year + "07";
		    break;
		case "Aug": 
			yymm = year + "08";
		    break;
		case "Sep": 
			yymm = year + "09";
		    break;
		case "Oct": 
			yymm = year + "10";
		    break;
		case "Okt": 
			yymm = year + "10";
		    break;
		case "Nov": 
			yymm = year + "11";
		    break;
		//December
		default: 
			yymm = year + "12";
		    break;
		}

	   }catch(Exception e){e.printStackTrace();System.exit(-1);}
	}
	
	//connect to database
		public void connectDB(){
			
			 // boolean isClosed = true;
			  try{
				DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		        //conn = DriverManager.getConnection("jdbc:oracle:thin:@lux104:1521:mdwp1", "mdw", "mdw");
		        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated from mdwp2 to mdwp3
		      
			  }
			  catch(Exception e){e.printStackTrace();System.exit(-1);}
			}
		
	public void processFRD(){
		String[] data;
		String content;
		int header = 0;  
		try{
			br = new BufferedReader(new FileReader(filename));
			bw = new BufferedWriter(new FileWriter("/mdswork/prd/work/" + fileid + "." + yymm + ".fiTranIdRefs.txt"));
			while((content = br.readLine()) != null){
				if(header > 0){  //get rid of header
				   data = content.split(",");
				   //check if content is actual data
				   if(data.length > 10 && data[29].length() > 10){
					   bw.write(data[29]);
					   bw.newLine();
				   }		
			    }
				header++;
			}
			
			bw.close();
			br.close();
			
			File fitran = new File("/mdswork/prd/work/" + fileid + "." + yymm + ".fiTranIdRefs.txt");
			fitran.setReadable(true, false);
			//System.out.println("/mdswork/prd/work/" + fileid + "." + yymm + ".fiTranIdRefs.txt");
			//Fish the corresponding transacations and cut off header
			command = "lbzcat /dmsdisk*/prd/arch/FALCON/PERMATA-F6/NONE/" + yymm + "/*permata-f6.none.crtran25_Auths*.bz2 | /mdswork/prd/bin/fish.pl -u -b /mdswork/prd/work/" + fileid + "." + yymm + ".fiTranIdRefs.txt -c 1-16 -s 1-16 - | ufalcut -c 81- | gzip > /mdswork/prd/work/" + fileid + "_" + yymm + "_crtran_auths.gz";
			callProcessBuilder(command);
			command = "lbzcat /dmsdisk*/prd/arch/FALCON/PERMATA-F6/NONE/" + yymm + "/*permata-f6.none.dbtran25_Auths*.bz2 | /mdswork/prd/bin/fish.pl -u -b /mdswork/prd/work/" + fileid + "." + yymm + ".fiTranIdRefs.txt -c 1-16 -s 1-16 - | ufalcut -c 81- | gzip > /mdswork/prd/work/" + fileid + "_" + yymm + "_dbtran_auths.gz";
			callProcessBuilder(command);
			
			//Convert the crtran/dbtran into FRD15 format
			command = "zcat /mdswork/prd/work/" + fileid + "_" + yymm + "*auths.gz | /mdswork/prd/bin/convertFrd15.py | bzip2 > /mdswork/prd/work/" + fileid + "." + yymm + ".permata-f6.none.frd15.ascii.bz2";
			callProcessBuilder(command);
			
		    logger.close();
		    File finalFile = new File("/mdswork/prd/work/" + fileid + "." + yymm + ".permata-f6.none.frd15.ascii.bz2");
		    if(finalFile.exists() && finalFile.length() > 40){
		    	updateQuery();
		    	deleteFile(new File(filename));
		    	deleteFile(new File("/mdswork/prd/work/" + fileid + "_" + yymm + "_crtran_auths.gz"));		    	
		    	deleteFile(new File("/mdswork/prd/work/" + fileid + "_" + yymm + "_dbtran_auths.gz"));
		    	deleteFile(new File("/mdswork/prd/work/" + fileid + "." + yymm + ".fiTranIdRefs.txt"));		    	
		    	
		    	System.out.println("0");  //return this result to bash script; 0 = success
		    }
			
			/**
			 * In the bash shellscript you would have:
			 * output=$(java Java_Program)
			 * or 
			 * output=`java Java_Program`
			 */
			
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	public void callProcessBuilder(String commands){
		String results = "";
		try{
			commandArgs = new String[] {"/bin/bash", "-c", commands};
			builder = new ProcessBuilder(commandArgs);
			builder.redirectErrorStream(true); //redirect stderr to stdout 
			p = builder.start();  //start the bash process on linux
			
			//read process standard output to see if any errors
			br = new BufferedReader(new InputStreamReader(p.getInputStream()));
			while((results = br.readLine()) != null){
				logger.write(results);
				logger.newLine();
			}
			p.waitFor();
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void updateQuery(){
		try{
			connectDB();
			updateFilehistoryTable = "UPDATE filehistory SET result_filename = '/mdswork/prd/work/" + fileid + "." + yymm + ".permata-f6.none.frd15.ascii.bz2' WHERE step# = 20 and fileid = " + fileid;
			updateFilesTable = "UPDATE files SET reclen = 813, date_period = " + yymm + ",recordtype = 501 WHERE fileid = " + fileid;
			
			//updateFilehistoryTable = "UPDATE filehistory SET infilename = '/mdswork/prd/work/11103190.2204.permata-f6.none.frd15.ascii.bz2' WHERE step# = 20 and fileid = 11103190";
			//updateFilesTable = "UPDATE files SET reclen = 813, date_period = 2204,recordtype = 501 WHERE fileid = 11103190";
	        st = conn.createStatement();
	        st.executeUpdate(updateFilesTable);
	        st.executeUpdate(updateFilehistoryTable);
	        if(conn != null){
				conn.close();
			}
			
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	public void deleteFile(File filename){
		try{
			if(filename.exists()){
	    		filename.delete();
	    	}
		}catch(Exception e){e.printStackTrace();}
	}
	

}
