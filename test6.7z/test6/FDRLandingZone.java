import java.io.File;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FileUtil;

/**
 * 4/29/2025 - used in the FDR_LANDINGZONE workflow on DMS
 * java -cp /mdswork/prd/bin:/ptoan/shared/hadoop/spark-3.5.0-bin-hadoop3/jars/* FDRLandingZone 16033502.FDR.F6.PROF.PUD28.CN9999.DY01.20250428.133130.gz > /ptoan/dms_staging/parquet_logs/fdrlandingzone.log 2>&1 &
 * @author JaneCheng
 *
 */
public class FDRLandingZone {
	
	//args[0] = filename
	public static void main(String args[]){
		Configuration conf = new Configuration();
		FileSystem fs = null;
		Path fdrPath = null;
		
		try{
			
			conf.addResource(new Path("/ptoan/shared/hadoop/conf.cloudera.spark_on_yarn/core-site.xml"));
	    	conf.addResource(new Path("/ptoan/shared/hadoop/conf.cloudera.spark_on_yarn/hdfs-site.xml"));
	    	conf.setBoolean("fs.hdfs.impl.disable.cache", true);
	    	fs = FileSystem.get(conf);
	    	fdrPath = new Path("/work/falcon9/FALCON4-5_VALIDATION/FDR/" + args[0]);
	    	if(fs.exists(fdrPath)){
	    		fs.delete(fdrPath, false);
	    	}
	    	if(FileUtil.copy(new File("/mdswork/prd/work/" + args[0]),fs,new Path("/work/falcon9/FALCON4-5_VALIDATION/FDR/"),false,conf)){
	    		System.out.println("0");
	    	}
	    	else{
	    		System.out.println("1");
	    	}
	    	
		}catch(Exception e){e.printStackTrace();}
	}

}
