package jc.lambda.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.costexplorer.AWSCostExplorer;
import com.amazonaws.services.costexplorer.AWSCostExplorerClientBuilder;
import com.amazonaws.services.costexplorer.model.*;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClient;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.*;
import com.amazonaws.services.simpleemail.model.Message;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import java.time.LocalDate;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

/**
 * 03/08/2024 - This class will get the tag fico:common:owner costs under Cost Explorer
 * and send out email using SES to the user
 * https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/costexplorer/AWSCostExplorerClient.html
 * https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/simpleemail/AmazonSimpleEmailService.html
 * Cost Explorer - Date Range (StartDate and EndDate),Granularity (Hourly, Daily, Monthly), Dimension (Tag -> value = fico:common:owner)
 */
public class CostReportHandler implements RequestHandler<Map<String,Object>, String> {
    Expression expression;
    AWSCostExplorer costExplorer;
    AmazonSimpleEmailService ses;
    LocalDate today;
    String year, startDay, endDay, month;
    String sender, recipient, subject, bodyHTML;

    @Override
    public String handleRequest(Map<String, Object> stringObjectMap, Context context) {
        costExplorer = AWSCostExplorerClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        ses = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        //expression = new Expression();
       // expression.setTags(new TagValues().withKey("fico:common:owner"));
        // https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/costexplorer/model/GetCostAndUsageRequest.html
        GroupDefinition groupDefinition =
                new GroupDefinition().withType(GroupDefinitionType.TAG).withKey("fico:common:owner");
        today = LocalDate.now();
        year = String.valueOf(today.getYear());
        startDay = "01";  //always want the first day of each month
        month = String.valueOf(today.getMonthValue() - 1);  //from January to September, the month is single digit number; need to be double digit
        if(month.length() == 1){
            month = "0" + month;  //make month as 01, 02, etc..
        }
        if(month.equalsIgnoreCase("04") || month.equalsIgnoreCase("06")|| month.equalsIgnoreCase("09")|| month.equalsIgnoreCase("11")){
            endDay = "30";
        }
        else if(month.equalsIgnoreCase("02")){  //february
            if(today.isLeapYear()){
                endDay = "29";
            }
            else{
                endDay = "28";
            }
        }
        else{
            endDay = "31";
        }
        //change single month number to double digit if from January to September
        if(String.valueOf(month).length() == 1){

        }
        System.out.println("CE: Start Time: " + year + "-" + month + "-" + startDay);
        /**
         * Error Code: ValidationException:
         * com.amazonaws.services.costexplorer.model.AWSCostExplorerException:
         * Start time  is invalid. Valid format is: yyyy-MM-dd.
         * Somehow the unblended costs does not include the end time/date
         */
        GetCostAndUsageRequest request = new GetCostAndUsageRequest()
                .withTimePeriod(new DateInterval().withStart(year + "-" + month + "-" + startDay).withEnd(year + "-" + month + "-" + endDay))
                .withGranularity(Granularity.MONTHLY)
                .withMetrics("UnblendedCost")
                .withGroupBy(groupDefinition);  //similar to query where you do a group by

        GetCostAndUsageResult result = costExplorer.getCostAndUsage(request);
        System.out.println(result);

        //Create the email request; make sure that the sender and recipient email addresses are set up in SES console
        sender = "janecheng@fico.com";
        recipient = "janecheng@fico.com";
        bodyHTML = result.toString();
        subject = "Test Cost Report Handler";
        sendEmail(sender, recipient,subject,bodyHTML);
        /**
         * SendEmailRequest(String source, Destination destination, Message message)
         * source = sender
         * Destination is a class and sends to recipient
         * Message(Content subject, Body body) = a class
         * Content is a class => Content(String data)
         * Body is a class => Body(Content text)
         */
        //SendEmailResult sendEmailResult = ses.sendEmail(new SendEmailRequest(sender,
               // new Destination().withToAddresses(recipient),
               // new Message(new Content(subject), new Body().withHtml(new Content(bodyHTML)))));

        return "succesfully retrieve cost and usage report";
    }

    public void sendEmail(String sender, String recipient, String subject, String bodyHTML){
        String to = recipient;
        String from = sender;
        try
        {
            //sb.append("<br> Thank you, <br> Jane Cheng");
            String host = "mail.fairisaac.com";

            //create properties to store host and get or set the default mail session object
            Properties props = new Properties();
            props.put("mail.smtp.host", host);
            Session session = Session.getInstance(props);
            //create the message object
            MimeMessage msg = new MimeMessage(session);

            //set the sender's email address
            msg.setFrom(new InternetAddress(from));

            //set the recipient's email address
            msg.setRecipients(javax.mail.Message.RecipientType.TO, to);

          /* if you have more than 1 recipient to send to then use this:
           InternetAddress[] address = {new InternetAddress(args[0])};
           msg.setRecipients(Message.RecipientType.TO, address);

          */
            //set the subject heading
            msg.setSubject(subject);

            //set the date of sending the email; new date() initializes to current date
            msg.setSentDate(new Date());

            //set the message body; setText method only uses text/plain
            // msg.setText(msgBody);
            Multipart mp = new MimeMultipart();

            //set the html body part
            MimeBodyPart htmlbody = new MimeBodyPart();
            htmlbody.setContent(bodyHTML.toString(), "text/html");
            mp.addBodyPart(htmlbody);

            //set the attachment part
            //MimeBodyPart attachment = new MimeBodyPart();
            // attachment.attachFile("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
            //--attachment.setFileName("/ana/mds/prd/data/FIS_Data_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
            //--attachment.setContent(attachment, "application/vnd.ms-excel");
            // attachment.attachFile("/ana/mds/prd/data/FIS_Ind_Report_" + dateQuery.replaceAll("/", "_") + ".xls");
            //mp.addBodyPart(attachment);

            //need to use setContent method if using text/html
            //  msg.setContent(sb.toString(), "text/html");
            msg.setContent(mp);

            //send the email
            Transport.send(msg);
        }
        catch(Exception e){
            System.out.println("Error in sending: ");
            e.printStackTrace();
            System.exit(1);
        }
    }
}
