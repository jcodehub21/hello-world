package org.jc;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

public class CommonUtil {
    private static String tarCommand = "tar -xvf ";
    private static String[] commandArgs = null;
    private static ProcessBuilder builder = null;
    private static Process p = null; //process for RHEL
    private static BufferedReader br = null;
    private static BufferedReader errorBR = null;
    private static List<String> fieldsIndexes = new ArrayList<String>();
    public static String hashing(String input){

        byte[] twentyFourByte = new byte[24]; //32 symbols
        String base64encodedString = "";

        try {

            // Static getInstance method is called with hashing SHA
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            byte[] hashByte = md.digest(input.getBytes(StandardCharsets.UTF_8));

            //twentyFourByte will produce 32 symbols using Base64
            //copy 24 bytes from hashByte to twentyFourByte
            System.arraycopy(hashByte, 0, twentyFourByte, 0, 24);

            base64encodedString = Base64.getEncoder().encodeToString(twentyFourByte);

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
        return base64encodedString;
    }


    public static List<String> untar(String filename){
        /**
         * on Windows:
         * no extension recognized for ade_TRANSACTION.. on RHEL8 it said  POSIX tar archive (GNU)
         * System.out.println("ext: " + FilenameUtils.getExtension("C:\\\\software\\\\TDBANK\\\\ade_TRANSACTION-CAD-EXT-TDBANK-35607-STG_auto_20250304_100037_split_file_0_1_1_test"));
         * String filePath = "C:\\software\\TDBANK\\ade_TRANSACTION-CAD-EXT-TDBANK-35607-STG_auto_20250304_100037_split_file_0_1_1_test";
         */
        List<String> jsonList = new ArrayList<>();
        String tarChileFile = "";
        String error = "";
        try{
            /**
             * below works for Reading POSIX tar archive (GNU) on RHEL 8
             * rhldmsprd002-45001:/mdswork/prd/TEMP_LANDINGZONE/TDBANK/TestData > java -cp .:/mdswork/prd/TEMP_LANDINGZONE/TDBANK/TestData/TDBANKProcess-1.0-SNAPSHOT.jar org.jc.TDBANKUtil ade_TRANSACTION-CAD-EXT-TDBANK-35607-STG_auto_20250304_100037_split_file_0_1_2 tdbank_fields_need_hashing.txt > /mdswork/prd/TEMP_LANDINGZONE/TDBANK/TestData/test.log 2>&1 &
             * File: ade_TRANSACTION-CAD-EXT-TDBANK-35607-STG_auto_20250304_100037_split_file_0_1_2.jsonl
             * File: ade_TRANSACTION-CAD-EXT-TDBANK-35607-STG_auto_20250304_100037_split_file_0_1_2.ctl
             */
            InputStream fileInputStream = new FileInputStream(new File(filename));
            BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
            TarArchiveInputStream tarArchiveInputStream = new TarArchiveInputStream(bufferedInputStream);
            br = new BufferedReader(new InputStreamReader(tarArchiveInputStream));
            TarArchiveEntry entry;
            while ((entry = tarArchiveInputStream.getNextEntry()) != null) {
               // if(count < 2){
                    //br.readLine();  skipping lines
               // }
                if (entry.isDirectory()) {
                    System.out.println("Directory: " + entry.getName());
                } else {
                    tarChileFile = entry.getName();
                    System.out.println("Untar Child File: " + tarChileFile);
                    if(tarChileFile.endsWith(".jsonl")){  //extract the jsonl file
                       tarCommand += filename;
                        commandArgs = new String[] {"/bin/bash", "-c", tarCommand};
                        builder = new ProcessBuilder(commandArgs);
                        builder.redirectErrorStream(true); //redirect stderr to stdout
                        p = builder.start();  //start the bash process on linux
                        //read process standard output to see if any errors
                        errorBR = new BufferedReader(new InputStreamReader(p.getErrorStream()));
                        if((error = errorBR.readLine()) != null){
                           System.out.println("Error untar/extracting file: " + error);
                        }
                        tarCommand = "tar -xvf "; //start the string for next node
                        p.waitFor();
                        jsonList.add(new File(tarChileFile).getAbsolutePath());
                    }
                    // Process the file content if needed
                    // byte[] content = new byte[(int) entry.getSize()];
                    // tarArchiveInputStream.read(content, 0, (int) entry.getSize());
                }
            }
            br.close();
        }catch(Exception e){e.printStackTrace();}
        return jsonList;
    }

    /**
     * Found out that the input and output jason strings
     * have same field names but with different values
     * associated with it.  So have to find all the values
     * associated with the field names using findAllOccurences()
     * and store the found values in a list<String>
     * @param input
     * @return
     */
    public static String hashp2fieldv2(String input, List<String> fieldsToHash) {
        String jsonString = input;
        String originalWholeString = ""; //captures the field name : value
        String newString = "";
        //String[] fieldsToHash = new String[]{"customerIdFromHeader","customerAcctNumber","externalTransactionId"};

        try{
           // System.out.println("input string: " + input);
            //Following is hashing using String properties only
            for(String field : fieldsToHash){

                //find all indexes for each field
                findAllOccurences(field, input);

                for(String value : fieldsIndexes){

                    originalWholeString = "\"" + field + "\"" + ":\"" + value + "\"";
                    //System.out.println("original string: " + originalWholeString);
                    newString = "\"" + field + "\"" + ":\"" + hashing(value) + "\"";
                    //System.out.println("new string: " + newString);
                    //replace the original field of the string with the same field with new hashed value
                    jsonString = jsonString.replace(originalWholeString, newString);
                }

                fieldsIndexes.clear();  //clear so can store new values for next field

            }

        }
        catch(Exception e){e.printStackTrace();}
        return jsonString;
    }

    /**
     * capture all indexes of the field name within the json string
     * some field name can have different values
     * @param fieldName
     * @param json
     */
    public static void findAllOccurences(String fieldName, String json){

        /**
         * String.indexOf()
         * public int indexOf(String str,int fromIndex)
         * Returns the index within this string of the first occurrence of the specified substring, starting at the specified index
         * or -1 if there is no such occurrence
         */
        int index = 0;
        int fieldNameLength = 0; //start with 0 first
        String value = "";
        int indexOfField;
        int startPosition;
        int endPosition;
        Iterator<String> iterate = null;
        boolean foundValue = false;

        //clear out the fieldsIndexes before adding new ones
        if(fieldsIndexes.size() > 0){

            fieldsIndexes.clear();
        }

        while (index != -1) {

            index = json.indexOf(fieldName, index + fieldNameLength);
            //System.out.println(fieldName + " index: " + index);

             if (index > -1) {
                 if(json.substring(index - 1, index).equalsIgnoreCase("\"")){
                 //System.out.println("fieldname: " + json.substring(index, index + 15));
                 //indexOfField = json.indexOf(":", index) + 2;
                 startPosition = json.indexOf(':', index) + 2;

                 //find end position of the value where quotation mark is
                 endPosition = json.indexOf('"', startPosition);

                 value = json.substring(startPosition, endPosition);
                 //only store the non-empty values
                 if (value.length() > 0) {
                     //System.out.println("value: " + value);
                     if (fieldsIndexes.size() == 0) {
                         fieldsIndexes.add(value);
                     } else {
                         iterate = fieldsIndexes.iterator();
                         while (iterate.hasNext()) {
                             if (iterate.next().equalsIgnoreCase(value)) {
                                  foundValue = true;
                             }
                         } //while loop
                         if(!foundValue){
                             fieldsIndexes.add(value);
                         }
                     }
                 }
            }
        }
            fieldNameLength = fieldName.length() + 1;
        }//while loop
        //System.out.println("Finished finding values for fieldName: " + fieldName);
    }
}
