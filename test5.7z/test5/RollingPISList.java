import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;

import scala.reflect.ClassTag;

/**
 * 01/15/2024 - this class reads from a input list of pis and nmon files with different bytes to cut from 
 * due to client using different record types.  Example, Shazam has two PIS11 and two NMON11 record types
 * with different byte positions for each record type
 * @author JaneCheng
 *
 */
public class RollingPISList implements Serializable{
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	//static final List<Row> newRows = new ArrayList<>();
	RecordTypeMapperCSV rtm = null;
	StructType schema = null;
	RollingPISv2 driver2 = null;  //use RollingPISv2 methods to mapreduce pis and nmon
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
	String hdfsDest = "";
	String begPeriod = "";
	int pisBegPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	int pisEndPos = 0; //enter pis end position to extract text if using /dmsdisks files
	int nmonBegPos = 0; //enter nmon beginning position to extract text if using /dmsdisks files
	int nmonEndPos = 0; //enter nmon end position to extract text if using /dmsdisks files
	int pisPanEndPos = 0; //pis pan end position in bytes if using /dmsdisks files; some ts2_9330-f6 old files have no pans
	String pisRecordType = "";
	String nmonRecordType = "";
	String pisRecordTypeLength = "";
	String nmonRecordTypeLength = "";
	String fileformat = ""; // dd = source files from /dmsdisks
	String query = "";
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
	static BufferedReader br = null;

	String pis12List = "";
	String pis11List = ""; 
	String nmon20List = "";
	String nmon11List = "";
	String pisRecordCreationDateBytes = "";
	String nmonRecordCreationDateBytes = "";
	String tempWorkFolder = "";
	UDF1<String, Boolean> userdefinedfunction = null;
	String udfName = "checkValidDate";
   	
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> pis12 = null;
	Dataset<Row> nmon11 = null;
	Dataset<Row> nmon20 = null;
	Dataset<Row> rejectsPis = null;  //store pis reject records
	Dataset<Row> rejectsNmon = null;  //store nmon reject records
	Dataset<Row> resultPaths = null;
	Broadcast<NmonBroadcast> nmbc = null;
	StructType textSchema = null;
	
	public static void main(String[] args){
		/**
		 * args[0] = client
		 * args[1] = portfolio
		 * args[2] = date period
		 * args[3] = update only 'u' or roll-up 'r'
		 * args[4] = hdfs destinatin /data/hive_falcon
		 * args[5] = text file that contains the temp work folder and pis and nmon details
		 * args[6] = if roll-up then beginning period for roll-up query
		 */
		RollingPISList driver = new RollingPISList(args);
		driver.createSparkSession();
		driver.processDatePeriod(args[5]);
        //driver.readFile(args[5]);
		//driver.processDataset();
		driver.closeAll();
	}
	
    public RollingPISList(){}
    
	public RollingPISList(String[] args){
    	   	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		this.hdfsDest = args[4];
		if(action.equalsIgnoreCase("r")){
			this.begPeriod = args[6];
		}				
	}
	
	public void readFile(String fileList){
		/**
		 * The main file to read contains the following arguments
		 * args[0] = tempworkfolder
		 * args[1] = pisBegPos and pisEndPos
		 * args[2] = nmonBegPos and nmonEndPos
		 * args[3] = pisRecordType and pisRecordTypeLength
		 * args[4] = nmonRecordType and nmonRecordTypeLength
		 * args[5] = pisRecordCreationDateBytes
		 * args[6] = nmonRecordCreationDateBytes
		 */
		try{
			 System.out.println("inside readFile(): " + LocalDateTime.now());
			 String content = "";
			 String[] data = null;
		     BufferedReader br = new BufferedReader(new FileReader(fileList));
		     while((content = br.readLine()) != null){
		    	 System.out.println("Read this line: " + content);
		    	 data = content.split(",");
		    	 this.tempWorkFolder = data[0];		    	 
		    	 if(!data[1].equalsIgnoreCase("na")){
		    		 this.pisBegPos = Integer.parseInt(data[1].substring(0, data[1].lastIndexOf("-")));
			         this.pisEndPos = Integer.parseInt(data[1].substring(data[1].lastIndexOf("-") + 1));
		    	 }
		    	 else{
		    		 this.pisBegPos = 0;
		    		 this.pisEndPos = 0;
		    	 }
                 if(!data[2].equalsIgnoreCase("na")){
  		           this.nmonBegPos = Integer.parseInt(data[2].substring(0, data[2].lastIndexOf("-")));
  		           this.nmonEndPos = Integer.parseInt(data[2].substring(data[2].lastIndexOf("-") + 1));
		    	 }
                 else{
                	 this.nmonBegPos = 0;
    		    	 this.nmonEndPos = 0;
                 }
                 if(!data[3].equalsIgnoreCase("na")){
  		           this.pisRecordType = data[3].substring(0,data[3].lastIndexOf("-"));
  	        	   this.pisRecordTypeLength = data[3].substring(data[3].indexOf("-") + 1);
  	        	   System.out.println("pisRecordType: " + pisRecordType + " and pisRecordLength: " + pisRecordTypeLength);
		    	 }
                 else{
                	 this.pisRecordType = "";
    		    	 this.pisRecordTypeLength = "";
                 }
                 if(!data[4].equalsIgnoreCase("na")){
  	        	   this.nmonRecordType = data[4].substring(0,data[4].lastIndexOf("-"));
  	        	   this.nmonRecordTypeLength = data[4].substring(data[4].indexOf("-") + 1);
  	        	   System.out.println("nmonRecordType: " + nmonRecordType + " and nmonRecordLength: " + nmonRecordTypeLength);
		    	 }else{
			    	 this.nmonRecordType = "";
			    	 this.nmonRecordTypeLength = "";
		    	 }
                 if(!data[5].equalsIgnoreCase("na")){
  	        	   this.pisRecordCreationDateBytes = data[5];
  	        	 System.out.println("pis recordCreationDate bytes: " + pisRecordCreationDateBytes);
		    	 }else{
		    		 this.pisRecordCreationDateBytes = "";
		    	 }
                 if(!data[6].equalsIgnoreCase("na")){
  	        	   this.nmonRecordCreationDateBytes = data[6];
	        	   System.out.println("nmon recordCreationDate bytes: " + nmonRecordCreationDateBytes);
                 }else{
                	 this.nmonRecordCreationDateBytes = "";
                 }

		    	 createPISandNMONList();
		     }
		     br.close();
		     
		}catch(Exception e){e.printStackTrace();}
	}
	
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName(client + " PISRollup By Files")
		  			  .config("spark.dynamicAllocation.enabled", "false")
		  			  .config("spark.locality.wait", "0s")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  //.config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		      textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});	     
		      nmbc = spark.sparkContext().broadcast(new NmonBroadcast(pisRecordType), classTag(NmonBroadcast.class));
			  System.out.println("broadcast NmonBroadcast class");
			//UDF1<String, String> is an interface so need to create a class that implements the UDF1 interface
				//in order to be to instantiate
			    userdefinedfunction = new UDF();
			    //register the user defined funciton in spark
			    spark.udf().register(udfName, userdefinedfunction, DataTypes.BooleanType);
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    /**
     * input any class to broadcast in spark
     * returns the class T of ClassTag
     * @param clazz
     * @return 
     */
    public static <T> ClassTag<T> classTag(Class<T> clazz) {
  	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
 	 }
    
    /**
	 * set single date period or multiple date periods
	 * submitted by users
	 */
	public void processDatePeriod(String filepath){
		String[] split;
		System.out.println("processDatePeriod(): " + LocalDateTime.now());	
        processedOutputDir = CommonUtil.createDestinationDir(client, portfolio, hdfsDest);
        System.out.println("processedOutputDir: " + processedOutputDir);
		if(action.equalsIgnoreCase("u")){
			//multiple date periods submitted by users
        	if(dateFolder.contains("-")){
        		split = dateFolder.split("-");
        		dateFolder = split[0];  //first date period
        		while(Integer.parseInt(dateFolder) <= Integer.parseInt(split[1])){
        	       //have to catch January (01) month because the last month will be December (12)
			       //the lowest date period is 1901
        	       //if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       else{
        		      //date period greater than 1901
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        		   readFile(filepath);
        		   processDataset();
        	       dateFolder = String.valueOf((Integer.parseInt(dateFolder) + 1));
        		}
        	}
        	else{ //single date period submitted by users for update
        		//if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
         		   System.out.println("Date Period: " + datePeriod);
         	    }
         	    else{
         		   //date period greater than 1901
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
         		   System.out.println("Date Period: " + datePeriod);
         	    }
        	      readFile(filepath);
        	      processDataset();
        	}
        }
		else{ //roll-up
			System.out.println("Roll-up to Date Folder: " + dateFolder);
			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
      		   System.out.println("Date Period: " + datePeriod);
      	    }
			else{
      		   //date period greater than 1901
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
      		   System.out.println("Date Period: " + datePeriod);
      	    }	
			readFile(filepath);
			processDataset();
		}	
	}
	public void createPISandNMONList(){

		try{
			System.out.println("inside createPISandNMONList(): " + LocalDateTime.now());
			
			if(action.equalsIgnoreCase("r")){
				//query pis11 and pis12 files
				if(!pisRecordType.isEmpty()){
	            resultPaths = CommonUtil.connectDBForRollup(spark, client, portfolio, begPeriod, datePeriod, pisRecordType,  pisRecordTypeLength);
	            System.out.println("resultPath count: " + resultPaths.count());
	            	resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
	    				if(row.getString(0).equalsIgnoreCase("pis11")){
	    					//System.out.println("pis11 path: " + row.getString(1));
	    					pis11List += "file://" + row.getString(1) + ",";
	    				}
	    				if(row.getString(0).equalsIgnoreCase("pis12")){
	    					//System.out.println("pis12 path: " + row.getString(1));
	    					pis12List += "file://" + row.getString(1) + ",";
	    				}
	    			});
				}
				if(!nmonRecordType.isEmpty()){
				//query nmon11 and nmon20 files
				resultPaths = CommonUtil.connectDBForRollup(spark, client, portfolio, begPeriod, datePeriod, nmonRecordType, nmonRecordTypeLength);
					resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
						if(row.getString(0).equalsIgnoreCase("nmon11")){
							//System.out.println("nmon11 path: " + row.getString(1));
							nmon11List += "file://" + row.getString(1) + ",";
						}
						if(row.getString(0).equalsIgnoreCase("nmon20")){
							//System.out.println("nmon12 path: " + row.getString(1));
							nmon20List += "file://" + row.getString(1) + ",";
						}
					});
				}
			}
			else{  //update
				//query pis11 and pis12 files
				if(!pisRecordType.isEmpty()){
	            resultPaths = CommonUtil.connectDBForUpdate(spark, client, portfolio, datePeriod, pisRecordType,  pisRecordTypeLength);
	            	resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
	    				if(row.getString(0).equalsIgnoreCase("pis11")){
	    					//System.out.println("pis11 path: " + row.getString(1));
	    					pis11List += "file://" + row.getString(1) + ",";
	    				}
	    				if(row.getString(0).equalsIgnoreCase("pis12")){
	    					//System.out.println("pis12 path: " + row.getString(1));
	    					pis12List += "file://" + row.getString(1) + ",";
	    				}
	    			});
				}
				if(!nmonRecordType.isEmpty()){
				//query nmon11 and nmon20 files
				resultPaths = CommonUtil.connectDBForUpdate(spark, client, portfolio, datePeriod, nmonRecordType, nmonRecordTypeLength);
					resultPaths.takeAsList((int) resultPaths.count()).forEach(row -> {
						if(row.getString(0).equalsIgnoreCase("nmon11")){
							//System.out.println("nmon11 path: " + row.getString(1));
							nmon11List += "file://" + row.getString(1) + ",";
						}
						if(row.getString(0).equalsIgnoreCase("nmon20")){
							//System.out.println("nmon12 path: " + row.getString(1));
							nmon20List += "file://" + row.getString(1) + ",";
						}
					});
				}
			}			
			
			//make sure there are paths in pis11List or pis12List
			//it is require to have pis files before processing nmon files
			if(!pis11List.isEmpty()){
				pis11List = pis11List.substring(0, pis11List.lastIndexOf(","));
				System.out.println("pis11List: " + pis11List);
				transformParquet(pis11List, "pis11");
			}
				
				//make sure there are paths in nmon11List or nmon20List
				if(!nmon11List.isEmpty()){
					nmon11List = nmon11List.substring(0, nmon11List.lastIndexOf(","));
					System.out.println("nmon11List: " + nmon11List);
					transformParquet(nmon11List, "nmon11");
				}
			
			if(!pis12List.isEmpty()){
				pis12List = pis12List.substring(0, pis12List.lastIndexOf(","));
				System.out.println("pis12List: " + pis12List);
				transformParquet(pis12List, "pis12");
			}
				
				if(!nmon20List.isEmpty()){
					nmon20List = nmon20List.substring(0, nmon20List.lastIndexOf(","));
					System.out.println("nmon20List: " + nmon20List);
					transformParquet(nmon20List, "nmon20");
				}
		
			pis12List = "";
			pis11List = ""; 
			nmon20List = "";
			nmon11List = "";
		}
		catch(Exception e){e.printStackTrace();}
	}	
	
	public void createPISandNMONList(String listPath){
		try{
			System.out.println("inside createPISandNMONList(): " + LocalDateTime.now());
			String content = "";
			String inputPath = "";
			String[] temp = listPath.split(",");
			//set the pisBegPos, pisEndPos, nmonBegPos, and nmonEndPos
			pisBegPos = Integer.parseInt(temp[1]);
			pisEndPos = Integer.parseInt(temp[2]);
			nmonBegPos = Integer.parseInt(temp[4]);
			nmonEndPos = Integer.parseInt(temp[5]);
			pisRecordCreationDateBytes = temp[8];
			nmonRecordCreationDateBytes = temp[9];
			
			//read PIS Path is temp[0] and pis record type is temp[6]
			br = new BufferedReader(new FileReader(temp[0]));
			while((content = br.readLine()) != null){
				inputPath += "file://" + content + ",";
			}
			inputPath = inputPath.substring(0, inputPath.lastIndexOf(","));
			if(temp[6].equalsIgnoreCase("pis11")){  
				pis11List = inputPath;
				System.out.println("pis11List: " + pis11List);
				transformParquet(pis11List, "pis11");
			}
            if(temp[6].equalsIgnoreCase("pis12")){
            	pis12List = inputPath;
            	System.out.println("pis12List: " + pis12List);
            	transformParquet(pis12List, "pis12");
			}
            
            //read NMON Path is temp[3] and nmon record type is temp[7]
            inputPath = "";
            br = new BufferedReader(new FileReader(temp[3]));
			while((content = br.readLine()) != null){
				inputPath += "file://" + content + ",";
			}
			inputPath = inputPath.substring(0, inputPath.lastIndexOf(","));
			if(temp[7].equalsIgnoreCase("nmon11")){
				nmon11List = inputPath;
				System.out.println("nmon11List: " + nmon11List);
				transformParquet(nmon11List, "nmon11");
			}
            if(temp[7].equalsIgnoreCase("nmon20")){
            	nmon20List = inputPath;
            	System.out.println("nmon20List: " + nmon20List);
            	transformParquet(nmon20List, "nmon20");
			}
            
		}catch(Exception e){e.printStackTrace();}
	}
	
    public void transformParquet(String inputPaths, String recordtype){
    	try{
    		System.out.println("inside transformParquet(): " + LocalDateTime.now());
    		      df = spark.read()
  				         .format("text")
  				         .option("inferSchema", false)
  				         .option("header", false)
  				         .load(inputPaths.split(",")); //to load different file locations using strings   	
    		     
    			if(recordtype.equalsIgnoreCase("pis12") || recordtype.equalsIgnoreCase("pis11")){
    				System.out.println("Start filtering " + recordtype + " reject records");
    				rejectsPis = df.filter(row -> {
    					return checkRejectRecords(row, pisEndPos, pisRecordCreationDateBytes);
    				});
    				
    				System.out.println("Start filtering " + recordtype + " good records");
    			   df = df.filter(row -> {
					          return row.mkString().length() >= pisEndPos;}
        			        )
        			        .filter(row -> {
        			        	return !checkRecordCreationDatebyString(row, pisRecordCreationDateBytes);
        			        })
    					   .map(row -> {
    				          return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
    			   }, RowEncoder.apply(textSchema));
    			   
    			   df.repartition(1)
    			     .write()
    			     .format("text")
    			     .option("compression","gzip")
    			     .mode("append")
    			     .save(tempWorkFolder + client + "/" + portfolio + "/" + recordtype + "/" + dateFolder);
    			   
    			   System.out.println("Wrote " + recordtype + ":" + pisRecordTypeLength + " records to " + tempWorkFolder + client + "/" + portfolio + "/" + recordtype + "/" + dateFolder + ": " + LocalDateTime.now());
    			   
    			   System.out.println("Checking pis reject records: " + LocalDate.now());
               	   if(!rejectsPis.isEmpty()){
               		   rejectsPis.repartition(1)
               		   .write()
               	       .option("compression", "gzip")
               		   .mode("append")
               		   .parquet(processedOutputDir + "/current_PIS/" + dateFolder + "/rejects/PIS");
               		   System.out.println("Finished writing pis11 rejects: " + LocalDateTime.now());
                	}else{
               		   System.out.println("No pis11 rejects detected: " + LocalDateTime.now());
                	}
    			}
    			
    			if(recordtype.equalsIgnoreCase("nmon20") || recordtype.equalsIgnoreCase("nmon11")){
    				System.out.println("Start filtering " + recordtype + " reject records");
    				rejectsNmon = df.filter(row -> {
    					return checkRejectRecords(row, nmonEndPos, nmonRecordCreationDateBytes);
    				});
    				
    				System.out.println("Start filtering " + recordtype + " good records");
     			   df = df.filter(row -> {
					         return row.mkString().length() >= nmonEndPos;}
        			        )
        			        .filter(row -> {
        			        	return !checkRecordCreationDatebyString(row, nmonRecordCreationDateBytes);
        			        })
     					   .map(row -> {
     				         return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			   
     			  df.repartition(1)
 			     .write()
 			     .format("text")
 			     .option("compression","gzip")
 			     .mode("append")
 			     .save(tempWorkFolder + client + "/" + portfolio + "/" + recordtype + "/" + dateFolder);
     			  
     			 System.out.println("Wrote " + recordtype + ":" + nmonRecordTypeLength + " records to " + tempWorkFolder + client + "/" + portfolio + "/" + recordtype + "/" + dateFolder + ": " + LocalDateTime.now());
     			  
     			 System.out.println("Checking nmon reject records: " + LocalDate.now()); 
     			 if(!rejectsNmon.isEmpty()){
             		rejectsNmon.repartition(1)
             		.write()
             		.option("compression", "gzip")
             		.mode("append")
             		.parquet(processedOutputDir + "/current_PIS/" + dateFolder + "/rejects/NMON");
             		System.out.println("Finished writing nmon11 rejects: " + LocalDateTime.now());
             	}else{
             		System.out.println("No nmon11 rejects detected: " + LocalDateTime.now());
             	}
     		}   	   			
    	}catch(Exception e){e.printStackTrace(); System.exit(-1);}
    }
    
    public void processDataset(){
    	try{
    		System.out.println("inside processDataset(): " + LocalDateTime.now());
    		JavaRDD<Row> rdd = null;
    		//clear out pis and nmon object first in case you only have one recordtype
    		if(pis11 != null){
            	pis11 = null;
            }
            if(pis12 != null){
            	pis12 = null;
            }
            if(nmon11 != null){
                nmon11 = null;
            }
            if(nmon20 != null){
	            nmon20 = null;
            }
                //process pis files
    		    df = spark.read()
 				         .format("text")
 				         .option("inferSchema", false)
 				         .option("header", false)
 				         .load(tempWorkFolder + client + "/" + portfolio + "/" + pisRecordType + "/" + dateFolder + "/*.gz"); //to load different file locations using strings 
    		    
    		    if(pisRecordType.equalsIgnoreCase("pis12")){
    		    	df = df.persist(StorageLevel.MEMORY_ONLY());
                	rdd = CommonUtil.mapReducePIS(df.javaRDD(), nmbc, pisRecordType); 
                	df.unpersist();
                	rdd = rdd.coalesce(100).persist(StorageLevel.MEMORY_ONLY());
                    pis12 = createDataSet("pis12", rdd);
                    rdd.unpersist();
                    pis12 = pis12.persist(StorageLevel.MEMORY_ONLY());
    		    }
                if(pisRecordType.equalsIgnoreCase("pis11")){
                	df = df.persist(StorageLevel.MEMORY_ONLY());
        			rdd = CommonUtil.mapReducePIS(df.javaRDD(), nmbc, pisRecordType);
        			df.unpersist();
        			rdd = rdd.coalesce(100).persist(StorageLevel.MEMORY_ONLY());
                    pis11 = createDataSet("pis11", rdd);
                    rdd.unpersist();
                    pis11 = pis11.persist(StorageLevel.MEMORY_ONLY());
    		    }

                //process nmon files
                df = spark.read()
				         .format("text")
				         .option("inferSchema", false)
				         .option("header", false)
				         .load(tempWorkFolder + client + "/" + portfolio + "/" + nmonRecordType + "/" + dateFolder + "/*.gz");
                
                if(nmonRecordType.equalsIgnoreCase("nmon11")){
                	df = df.persist(StorageLevel.MEMORY_ONLY());
            		rdd = CommonUtil.mapReduceNMON11(df.javaRDD(), nmbc);
            		df.unpersist();
            		rdd = rdd.coalesce(160).persist(StorageLevel.MEMORY_ONLY());
                    nmon11 = createDataSet("pis11", rdd);
                    rdd.unpersist();
                    nmon11 = nmon11.persist(StorageLevel.MEMORY_ONLY());
    		    }
    		    
                if(nmonRecordType.equalsIgnoreCase("nmon20")){
                	df = df.persist(StorageLevel.MEMORY_ONLY());
            		rdd = CommonUtil.mapReduceNMON20(df.javaRDD(), nmbc);
            		df.unpersist();
            		rdd = rdd.coalesce(160).persist(StorageLevel.MEMORY_ONLY());
                    nmon20 = createDataSet("pis12", rdd);
                    rdd.unpersist();
                    nmon20 = nmon20.persist(StorageLevel.MEMORY_ONLY());
    		    }
         
              //now all transformations are done, merge the datasets 
               mergeDataset();
                
    	}catch(Exception e){e.printStackTrace(); System.exit(-1);}
    }
    
    public Dataset<Row> createDataSet(String rt, JavaRDD<Row> rdd){
		Dataset<Row> ds = null;
    	List<RollingObj> fieldnames = null;
    	List<StructField> fields = null;
		try{
			System.out.println("inside createDataset(): " + LocalDateTime.now());
			 rtm = new RecordTypeMapperCSV(rt);
		     fieldnames = rtm.getFieldInfo();
	         
	        //Store the StruckField object into a List
		    fields = new ArrayList<>();
		      
		    //create the StructFields for the Schema
		    for(int x = 0; x < fieldnames.size(); x++){
		    	  
		    	  fields.add(DataTypes.createStructField(fieldnames.get(x).fieldName, DataTypes.StringType, true));
		      }
		    
		    //create the schema
	  		schema = DataTypes.createStructType(fields);
	  		ds = spark.createDataFrame(rdd, schema);
	  		
	  		if(rt.equalsIgnoreCase("pis12")){
            	ds = ds.withColumn("dailyLimitType", functions.lit(null).cast(DataTypes.StringType));
                System.out.println("added field dailyLimitType to pis12 inside createDataset()");
            }
            
            if(rt.equalsIgnoreCase("pis11")){
            	ds = ds.withColumn("cashbackLimitMode", functions.lit(null).cast(DataTypes.StringType));
                System.out.println("added field cashbackLimitMode to pis11 inside createDataset()");
            }
			
		}catch(Exception e){e.printStackTrace();}
	 	return ds;		
	}
    
    public void mergeDataset(){
    	Dataset<Row> pastDF = null;
    	JavaRDD<Row> rdd = null;
    	try{
    		System.out.println("inside mergeDataset(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(pis11 != null){
            	if(nmon11 != null){  //make sure nmon11 has records            		
            	  //merge pis and nmon, pis11 still contains pandatetime field
            	  nmon11.createOrReplaceTempView("nmon");
            	  nmon11 = spark.sql("select * from nmon where nonmonCode in ('3001','3003', '3100', '3101', '3102', '3103', '3104', '3105', '3109','3114', '3115', '3121', '3122', '3123', '3124', '3201')");

              	  pis11 = pis11.union(nmon11);
                  System.out.println("pis11 unioned nmon11");
            	}
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			.withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis11 = pis11.union(pastDF);
                	System.out.println("pis11 unioned " + datePeriod);
                }
                
                rdd = CommonUtil.mapReducePIS(pis11.javaRDD(), nmbc, pisRecordType);    		
                pis11 = createDataSet("pis11", rdd);
                System.out.println("pis11 completed final round of mapReducePIS");
                
                pis11 = pis11.drop("nonmonCode");  //drop nonmonCode column
               // pis11 = pis11.drop("recordType").withColumn("recordType", functions.lit(pisRecordType.toUpperCase()).cast(DataTypes.StringType));
               // System.out.println("dropped old recordType and added back correct pis11 recordType");
                
                //remove empty pans
                pis11.createOrReplaceTempView("pis11");
                
                pis11 = spark.sql("select * from pis11 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                pis11 = spark.sql("select * from pis11 where checkValidDate(recordCreationDate) IS TRUE");
                System.out.println("removed invalid recordCreationDate");
        
                //drop the pandatetime before writing it back out as another parquet file
                pis11 = pis11.drop("pandatetime");
                System.out.println("dropped pandatetime field");
                pis11 = pis11.dropDuplicates();
                System.out.println("dropped duplicates");
                pis11.createOrReplaceTempView("temp"); //check one more time
                pis11 = spark.sql("select * from temp where trim(pan) != ''");

                  pis11.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);

                System.out.println("Completed " + processedOutputDir + "/current_PIS/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
                pis11.unpersist();
                nmon11.unpersist();           	
            }
            
            if(pis12 != null){
            	//pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
            	if(nmon20 != null){
            		//merge pis and nmon, pis11 still contains pandatetime field
              	  nmon20.createOrReplaceTempView("nmon");
              	  nmon20 = spark.sql("select * from nmon where nonmonCode in ('3000','3010', '3100', '3102', '3104','3201')");

            	   pis12 = pis12.union(nmon20);
            	   System.out.println("pis12 unioned nmon20");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			        .withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis12 = pis12.union(pastDF);
                	System.out.println("pis12 unioned " + datePeriod);
                }
                
                rdd = CommonUtil.mapReducePIS(pis12.javaRDD(), nmbc, pisRecordType);    		
                pis12 = createDataSet("pis12", rdd);
                System.out.println("pis12 completed final round of mapReducePIS");
                
                pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
               // pis12 = pis12.drop("recordType").withColumn("recordType", functions.lit(pisRecordType.toUpperCase()).cast(DataTypes.StringType));
              //  System.out.println("dropped old recordType and added back correct pis12 recordType");
                
              //remove empty pans
                pis12.createOrReplaceTempView("pis12");
                
                pis12 = spark.sql("select * from pis12 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                pis12 = spark.sql("select * from pis12 where checkValidDate(recordCreationDate) IS TRUE");
                System.out.println("removed incorrect recordCreationDate");

                //drop the pandatetime before writing it back out as another parquet file
            	pis12 = pis12.drop("pandatetime");
            	System.out.println("dropped pandatetime field");
                pis12 = pis12.dropDuplicates();
                System.out.println("dropped duplicates");
                pis12.createOrReplaceTempView("temp"); //check one more time
                pis12 = spark.sql("select * from temp where trim(pan) != ''");

            		pis12.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);
         
            	System.out.println("Completed " + processedOutputDir + "/current_PIS/" + dateFolder + " Parquet File: " + LocalDateTime.now());   
            	pis12.unpersist();
            	nmon20.unpersist();            	
            } 	
            
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
    /**
	  * Need to pass in the recordCreationDate bytes to validate
	  * @param record
	  * @param endPosition
	  * @return
	  */
	 public boolean checkRejectRecords(Row record, int endPosition, String recordCreationDateBytes){
		
		 return record.mkString().length() < (endPosition - 10) || checkRecordCreationDatebyString(record, recordCreationDateBytes);
	 }
	 
	 public boolean checkRecordCreationDatebyString(Row record, String recordCreationDateBytes){
		 String date = "";
		 try{
			 date = record.mkString().substring(Integer.parseInt(recordCreationDateBytes.substring(0, recordCreationDateBytes.lastIndexOf("-"))), Integer.parseInt(recordCreationDateBytes.substring(recordCreationDateBytes.indexOf("-") + 1)));
			 LocalDate.parse(date.trim(), DateTimeFormatter.ofPattern("yyyyMMdd"));
		 }catch(DateTimeParseException e){return true;}	
		 return false;
	 }
    
    public void closeAll(){
    	nmbc.destroy();
    	if(br != null){
    		try {
				br.close();
			} catch (IOException e) {e.printStackTrace();}
    	}
    }
    
    
}
