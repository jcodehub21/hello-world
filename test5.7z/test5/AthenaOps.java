package jc.lambda.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.athena.AmazonAthena;

//import Apache log4j 2
import com.amazonaws.services.athena.AmazonAthenaClientBuilder;
import com.amazonaws.services.athena.model.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

//https://docs.aws.amazon.com/code-samples/latest/catalog/code-catalog-javav2-example_code-athena.html
//https://docs.aws.amazon.com/athena/latest/ug/code-samples.html
//https://javadoc.io/static/com.amazonaws/aws-java-sdk-athena/1.11.235/com/amazonaws/services/athena/model/StartQueryExecutionRequest.html
//https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/athena/AmazonAthena.html
//https://www.oracle.com/java/technologies/downloads/?er=221886#java8
//https://github.com/awsdocs/aws-doc-sdk-examples/tree/main/javav2/example_code
//https://stackoverflow.com/questions/43577746/aws-lambda-task-timed-out
//https://stackoverflow.com/questions/61355607/lambda-function-to-query-aws-athena-gives-timeout
public class AthenaOps {

    AmazonAthena athena;
    String region;
    private static Logger logger = LogManager.getLogger(AthenaOps.class);
    private String database = "";
    /**
     * athena requires a S3 bucket
     * com.amazonaws.services.athena.model.InvalidRequestException: Unable to verify/create output bucket aws-athena-query-results-416721502314-us-west-2 (Service: AmazonAthena; Status Code: 400;
     * Error Code: InvalidRequestException; Request ID: c3054ade-6d67-4678-b76a-fd559128ec07; Proxy: null)
     */
    private static String ATHENA_OUTPUT_BUCKET = "s3://jcs3athenalambdarepo/";

    /**
     * Insufficient permissions to execute the query. User: arn:aws:sts::416721502314:assumed-role/jcAthenaLambdaRole/jcAthenaLambda is not authorized to perform: glue:GetDatabase on resource: arn:aws:glue:us-west-2:416721502314:catalog because no identity-based policy allows the glue:GetDatabase action
     */

    public AthenaOps(String region){
        this.region = region;
        //athena = CommonOps.getAthena(this.region);
        athena = AmazonAthenaClientBuilder.standard().withRegion(Regions.valueOf(region.toUpperCase())).build();
    }

    public AmazonAthena getAthena(){
        return athena;
    }
    //I don't think this one has anything to do with AmazonAthena
    public static void setDatabaseName(QueryExecutionContext qec, String database){
        //The QueryExecutionContext allows us to set the database
        qec.setDatabase(database);
    }

    public static StartQueryExecutionResult startQuery(AmazonAthena athena, QueryExecutionContext qec, String queryStatement){
        return athena.startQueryExecution(new StartQueryExecutionRequest().withQueryString(queryStatement
                ).withQueryExecutionContext(qec)
                .withWorkGroup("primary")
                 .withResultConfiguration(new ResultConfiguration().withOutputLocation(ATHENA_OUTPUT_BUCKET)));
    }

    /**
     * QUEUED indicates that the query has been submitted to the service, and
     * Athena will execute the query as soon as resources are available.
     * RUNNING indicates that the query is in execution phase.
     * SUCCEEDED indicates that the query completed without errors.
     * FAILED indicates that the query experienced an error and did not complete processing.
     * CANCELLED indicates that a user input interrupted query execution.
     * @param athena
     * @param executionId
     * @return
     */
    public static String getQueryStatus(AmazonAthena athena, String executionId){
        GetQueryExecutionResult getQER = athena.getQueryExecution(new GetQueryExecutionRequest().withQueryExecutionId(executionId));
        return getQER.getQueryExecution().getStatus().getState();
        /**
         * if (queryState.equals(QueryExecutionState.FAILED.toString())) {
         *  throw new RuntimeException("The Amazon Athena query failed to run with
         *  error message: " + getQueryExecutionResponse
         *  .queryExecution().status().stateChangeReason());
         *  } else if (queryState.equals(QueryExecutionState.CANCELLED.toString())) {
         *  throw new RuntimeException("The Amazon Athena query was cancelled.");
         *  } else if (queryState.equals(QueryExecutionState.SUCCEEDED.toString())) {
         *  isQueryStillRunning = false;
         *  } else {
         *  // Sleep an amount of time before retrying again
         *  Thread.sleep(ExampleConstants.SLEEP_AMOUNT_IN_MS);
         *  }
         */
    }

    public static GetQueryExecutionResult getQueryExecutionResult(AmazonAthena athena,String executionId){
        return athena.getQueryExecution(new GetQueryExecutionRequest().withQueryExecutionId(executionId));
    }

    //returns the whole resultset
    public static GetQueryResultsResult getQueryResultsRows(AmazonAthena athena, String executionId){
        // Max Results can be set but if its not set,
        // it will choose the maximum page size
        return athena.getQueryResults(new GetQueryResultsRequest().withQueryExecutionId(executionId));
    }

}
