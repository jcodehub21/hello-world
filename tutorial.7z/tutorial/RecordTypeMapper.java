import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;

public class RecordTypeMapper implements Serializable{

	private static final long serialVersionUID = 1L;
		//List represents an ordered sequence of objects
		List<RollingObj> fieldInfo = new ArrayList<RollingObj>();
		
		   /*Writable MUST has a default constructor*/
		   public RecordTypeMapper(){}
		
		   public RecordTypeMapper(String recordtype){
			  
			   if(recordtype.equalsIgnoreCase("pis12") || recordtype.equalsIgnoreCase("nmon20")){
				//the length for these fields are tailored to parquet project files (.parquet)
				//fieldInfo.add(new RollingObj(String fieldName, int begPos, int endPos)
				   fieldInfo.add(new RollingObj("workflow", 416,432));
					fieldInfo.add(new RollingObj("recordType", 432,440));
					fieldInfo.add(new RollingObj("dataSpecificationVersion", 440,445));
					fieldInfo.add(new RollingObj("clientIdFromHeader",445,461));
					fieldInfo.add(new RollingObj("recordCreationDate",461,469));
					fieldInfo.add(new RollingObj("recordCreationTime",469, 475));
					fieldInfo.add(new RollingObj("recordCreationMilliseconds",475,478));
					fieldInfo.add(new RollingObj("gmtOffset",478,484));
					fieldInfo.add(new RollingObj("customerIdFromHeader",484,504));
					fieldInfo.add(new RollingObj("customerAcctNumber",504,544));
					fieldInfo.add(new RollingObj("externalTransactionId",544, 576));
					fieldInfo.add(new RollingObj("pan",576, 595));
					fieldInfo.add(new RollingObj("type",595, 596));
					fieldInfo.add(new RollingObj("subType",596, 598));
					fieldInfo.add(new RollingObj("category",598, 599));
					fieldInfo.add(new RollingObj("association",599, 600));
					fieldInfo.add(new RollingObj("panOpenDate",600, 608));
					fieldInfo.add(new RollingObj("memberSinceDate",608, 616));
					fieldInfo.add(new RollingObj("issuingCountry",616, 619));  
					fieldInfo.add(new RollingObj("cardholderCity",619, 659));
					fieldInfo.add(new RollingObj("cardholderStateProvince",659, 664));
					fieldInfo.add(new RollingObj("cardholderPostalCode",664, 674));
					fieldInfo.add(new RollingObj("cardholderCountryCode",674, 677));
					fieldInfo.add(new RollingObj("numberOfPaymentIds",677, 680));
					fieldInfo.add(new RollingObj("paymentInstrumentId",680, 710));
					fieldInfo.add(new RollingObj("status",710, 712));
					fieldInfo.add(new RollingObj("statusDate",712, 720));
					fieldInfo.add(new RollingObj("pinLength",720, 722));
					fieldInfo.add(new RollingObj("pinSetDate",722, 730));
					fieldInfo.add(new RollingObj("pinType",730, 731));
					fieldInfo.add(new RollingObj("activeIndicator",731, 732));
					fieldInfo.add(new RollingObj("nameOnInstrument",732, 772));
					fieldInfo.add(new RollingObj("expirationDate",772, 780));
					fieldInfo.add(new RollingObj("lastIssueDate",780, 788));
					fieldInfo.add(new RollingObj("plasticIssueType",788, 789));
					fieldInfo.add(new RollingObj("incentive",789, 790));
					fieldInfo.add(new RollingObj("currencyCode",790, 793));
					fieldInfo.add(new RollingObj("currencyConversionRate",793, 806));
					fieldInfo.add(new RollingObj("creditLimit",806, 816));
					fieldInfo.add(new RollingObj("overdraftLimit",816,826));
					fieldInfo.add(new RollingObj("dailyPosLimit",826,836));
					fieldInfo.add(new RollingObj("dailyCashLimit",836,846));
					fieldInfo.add(new RollingObj("cashbackLimitMode",846,847));  //different
					fieldInfo.add(new RollingObj("mediaType",847,848));
					fieldInfo.add(new RollingObj("aipStatic",848,849));
					fieldInfo.add(new RollingObj("aipDynamic",849,850));
					fieldInfo.add(new RollingObj("aipVerify",850,851));
					fieldInfo.add(new RollingObj("aipRisk",851,852));
					fieldInfo.add(new RollingObj("aipIssuerAuthentication",852,853));
					fieldInfo.add(new RollingObj("aipCombined",853,854));
					fieldInfo.add(new RollingObj("chipSpecification",854,855));
					fieldInfo.add(new RollingObj("chipSpecVersion",855,858));
					fieldInfo.add(new RollingObj("offlineLowerLimit",858,860));
					fieldInfo.add(new RollingObj("offlineUpperLimit",860,862));
					fieldInfo.add(new RollingObj("userIndicator01",862,863));
					fieldInfo.add(new RollingObj("userIndicator02",863,864));
					fieldInfo.add(new RollingObj("userCode1",864,867));
					fieldInfo.add(new RollingObj("userCode2",867,870));
					fieldInfo.add(new RollingObj("userData01",870,876));
					fieldInfo.add(new RollingObj("userData02",876,882));
					fieldInfo.add(new RollingObj("userData03",882,892));
					fieldInfo.add(new RollingObj("userData04",892,902));
					fieldInfo.add(new RollingObj("userData05",902,917));
					fieldInfo.add(new RollingObj("userData06",917,937));
					fieldInfo.add(new RollingObj("userData07",937,977));
					fieldInfo.add(new RollingObj("pandatetime",977,1009));
				
		       }
			   if(recordtype.equalsIgnoreCase("pis11") || recordtype.equalsIgnoreCase("nmon11")){
				 //the length for these fields are tailored to parquet project files
					//fieldInfo.add(new RollingObj(String fieldName, int begPos, int endPos)
					fieldInfo.add(new RollingObj("workflow", 416,432));
					fieldInfo.add(new RollingObj("recordType", 432,440));
					fieldInfo.add(new RollingObj("dataSpecificationVersion", 440,445));
					fieldInfo.add(new RollingObj("clientIdFromHeader",445,461));
					fieldInfo.add(new RollingObj("recordCreationDate",461,469));
					fieldInfo.add(new RollingObj("recordCreationTime",469, 475));
					fieldInfo.add(new RollingObj("recordCreationMilliseconds",475,478));
					fieldInfo.add(new RollingObj("gmtOffset",478,484));
					fieldInfo.add(new RollingObj("customerIdFromHeader",484,504));
					fieldInfo.add(new RollingObj("customerAcctNumber",504,544));
					fieldInfo.add(new RollingObj("externalTransactionId",544, 576));
					fieldInfo.add(new RollingObj("pan",576, 595));
					fieldInfo.add(new RollingObj("type",595, 596));
					fieldInfo.add(new RollingObj("subType",596, 598));
					fieldInfo.add(new RollingObj("category",598, 599));
					fieldInfo.add(new RollingObj("association",599, 600));
					fieldInfo.add(new RollingObj("panOpenDate",600, 608));
					fieldInfo.add(new RollingObj("memberSinceDate",608, 616));
					fieldInfo.add(new RollingObj("issuingCountry",616, 619));  
					fieldInfo.add(new RollingObj("cardholderCity",619, 659));
					fieldInfo.add(new RollingObj("cardholderStateProvince",659, 664));
					fieldInfo.add(new RollingObj("cardholderPostalCode",664, 674));
					fieldInfo.add(new RollingObj("cardholderCountryCode",674, 677));
					fieldInfo.add(new RollingObj("numberOfPaymentIds",677, 680));
					fieldInfo.add(new RollingObj("paymentInstrumentId",680, 710));
					fieldInfo.add(new RollingObj("status",710, 712));
					fieldInfo.add(new RollingObj("statusDate",712, 720));
					fieldInfo.add(new RollingObj("pinLength",720, 722));
					fieldInfo.add(new RollingObj("pinSetDate",722, 730));
					fieldInfo.add(new RollingObj("pinType",730, 731));
					fieldInfo.add(new RollingObj("activeIndicator",731, 732));
					fieldInfo.add(new RollingObj("nameOnInstrument",732, 772));
					fieldInfo.add(new RollingObj("expirationDate",772, 780));
					fieldInfo.add(new RollingObj("lastIssueDate",780, 788));
					fieldInfo.add(new RollingObj("plasticIssueType",788, 789));
					fieldInfo.add(new RollingObj("incentive",789, 790));
					fieldInfo.add(new RollingObj("currencyCode",790, 793));
					fieldInfo.add(new RollingObj("currencyConversionRate",793, 806));
					fieldInfo.add(new RollingObj("creditLimit",806, 816));
					fieldInfo.add(new RollingObj("overdraftLimit",816,826));
					fieldInfo.add(new RollingObj("dailyPosLimit",826,836));
					fieldInfo.add(new RollingObj("dailyCashLimit",836,846));
					fieldInfo.add(new RollingObj("dailyLimitType",846,847));  //different
					fieldInfo.add(new RollingObj("mediaType",847,848));
					fieldInfo.add(new RollingObj("aipStatic",848,849));
					fieldInfo.add(new RollingObj("aipDynamic",849,850));
					fieldInfo.add(new RollingObj("aipVerify",850,851));
					fieldInfo.add(new RollingObj("aipRisk",851,852));
					fieldInfo.add(new RollingObj("aipIssuerAuthentication",852,853));
					fieldInfo.add(new RollingObj("aipCombined",853,854));
					fieldInfo.add(new RollingObj("chipSpecification",854,855));
					fieldInfo.add(new RollingObj("chipSpecVersion",855,858));
					fieldInfo.add(new RollingObj("offlineLowerLimit",858,860));
					fieldInfo.add(new RollingObj("offlineUpperLimit",860,862));
					fieldInfo.add(new RollingObj("userIndicator01",862,863));
					fieldInfo.add(new RollingObj("userIndicator02",863,864));
					fieldInfo.add(new RollingObj("userCode1",864,867));
					fieldInfo.add(new RollingObj("userCode2",867,870));
					fieldInfo.add(new RollingObj("userData01",870,876));
					fieldInfo.add(new RollingObj("userData02",876,882));
					fieldInfo.add(new RollingObj("userData03",882,892));
					fieldInfo.add(new RollingObj("userData04",892,902));
					fieldInfo.add(new RollingObj("userData05",902,917));
					fieldInfo.add(new RollingObj("userData06",917,937));
					fieldInfo.add(new RollingObj("userData07",937,977));
					fieldInfo.add(new RollingObj("pandatetime",977,1009));
			   }
	       }
		   
		   /**
		    * gets the List<RollingObj>
		    * @return fieldInfo
		    */
		   public List<RollingObj> getFieldInfo(){
			   
			   return fieldInfo;
		   }
		   
		   /**
		    * set values for each PIS field
		    */
		   public void setPISFieldValue(String record){  
			   
		    	//HDFS files have different positions than files stored on NFS disks (eg /Cardamon..)
		    	// List<E> starts from 0 to N-1 where N is size() of list.
			   for(int x=0; x < fieldInfo.size(); x++){
				   if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
					  // System.out.println("found pandatetime field: " + record.substring(576, 595) + record.substring(461,478));
					   fieldInfo.get(x).setNmonValue(record.substring(576, 595) + record.substring(461,478));
				   }
				   else{
				         fieldInfo.get(x).setValue(record);
				   }
			   }	   
		   }
		   
		   /**
		    * set values for Nmon20 depending upon 
		    */
		   public void setNMON20FieldValue(String record){
			 //get nonmonCode from record
			   String nonmonCode = record.substring(590, 594).trim();
			   
			   for(int x=0; x < fieldInfo.size(); x++){
		    		
				    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType")){  //set recordType value to PIS12
		    			fieldInfo.get(x).setNmonValue("PIS12");
		    		}
		    		
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate")){  //transactionDate becomes recordCreationDate
		    			fieldInfo.get(x).setNmonValue(record.substring(576, 584));
		    		}
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime")){  //transactionTime becomes recordCreationTime
		    			fieldInfo.get(x).setNmonValue(record.substring(584, 590));
		    		}
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds")){  //recordCreationMilliseconds becomes 000
		    			fieldInfo.get(x).setNmonValue("000");
		    		}
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan")){
		    			if(nonmonCode.equalsIgnoreCase("3000")){
		    				fieldInfo.get(x).setNmonValue(record.substring(766, 785));  //newPan value becomes pan
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue(record.substring(657, 676));  //get original pan
		    			}
		    		}
		    		
	                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType")){
		    			
		    			//newCode1 becomes subType for 3010
		    			if(nonmonCode.equalsIgnoreCase("3010")){
		    				fieldInfo.get(x).setNmonValue(record.substring(1917, 1920));
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue("   "); //subType empty
		    			}		
		    		}
	                
	                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode")){
		    			
		    			//newCountryCode becomes cardholderCountryCode for 3100
		    			if(nonmonCode.equalsIgnoreCase("3100")){
		    				fieldInfo.get(x).setNmonValue(record.substring(1623, 1626));
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue("   "); //cardholderCountryCode empty
		    			}		
		    		}
		    		
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("status")){
		    			
		    			//newCode1 becomes status for 3102
		    			if(nonmonCode.equalsIgnoreCase("3102")){
		    				fieldInfo.get(x).setNmonValue(record.substring(1917, 1920));
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue("   "); //status empty
		    			}   			
		    		} 
		    		
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
		    			if(nonmonCode.equalsIgnoreCase("3000")){
		    				fieldInfo.get(x).setNmonValue(record.substring(766, 785) + record.substring(461, 475) + "000"); 
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue(record.substring(657, 676) + record.substring(461, 475) + "000"); 
		    			}
		    		}
	                
	                //all other fields empty
	                if(!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan") && 
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("status") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
	                	
	                	fieldInfo.get(x).setNmonValue("   ");
	                }
		    		
			   }//for loop ends
		   }
		   
		   /**
		    * set values for Nmon11 depending upon 
		    */
		   public void setNMON11FieldValue(String record){
			   //get nonmonCode from record
			   String nonmonCode = record.substring(590, 594).trim();
			   for(int x=0; x < fieldInfo.size(); x++){
		    		
				    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType")){  //set recordType value to PIS12
		    			fieldInfo.get(x).setNmonValue("PIS11");
		    		}
		    		
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate")){  //transactionDate becomes recordCreationDate
		    			fieldInfo.get(x).setNmonValue(record.substring(576, 584));
		    		}
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime")){  //transactionTime becomes recordCreationTime
		    			fieldInfo.get(x).setNmonValue(record.substring(584, 590));
		    		}
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds")){  //recordCreationMilliseconds becomes 000
		    			fieldInfo.get(x).setNmonValue("000");
		    		}
		    		
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan")){
		    			if(nonmonCode.equalsIgnoreCase("3001")){
		    				fieldInfo.get(x).setNmonValue(record.substring(737, 756));  //newPan value becomes pan
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue(record.substring(628, 647));  //get original pan
		    			}
		    		}
		    		
	                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType")){
		    			
		    			//newCode becomes subType for 3109
		    			if(nonmonCode.equalsIgnoreCase("3109")){
		    				fieldInfo.get(x).setNmonValue(record.substring(1777, 1780));
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue("   "); //subType empty
		    			}		
		    		}
	                
	                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode")){
		    			
		    			//newCountryCode becomes cardholderCountryCode for 3100 and 3122
		    			if(nonmonCode.equalsIgnoreCase("3100") || nonmonCode.equalsIgnoreCase("3122")){
		    				fieldInfo.get(x).setNmonValue(record.substring(1587, 1590));
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue("   "); //cardholderCountryCode empty
		    			}		
		    		}
		    		
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("status")){
		    			
		    			//newCode becomes status for 3102
		    			if(nonmonCode.equalsIgnoreCase("3102")){
		    				fieldInfo.get(x).setNmonValue(record.substring(1777, 1780));
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue("   "); //status empty
		    			}   			
		    		}
		    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
		    			if(nonmonCode.equalsIgnoreCase("3001")){
		    				fieldInfo.get(x).setNmonValue(record.substring(737, 756) + record.substring(461, 475) + "000");  //newPan value becomes pan
		    			}
		    			else{
		    				fieldInfo.get(x).setNmonValue(record.substring(628, 647) + record.substring(461, 475) + "000");  //get original pan
		    			}
		    		}
		    		           
	                //all other fields empty
	                if(!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan") && 
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("status") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType") &&
	                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
	                	
	                	fieldInfo.get(x).setNmonValue("   ");
	                }
		    		
			   }//for loop ends
		   }
		   
			/**
			 *  The default output format from the driver is TextOutputFormat which writes records as lines of text.  Its keys and values may be of any type since 
			 *  TextOutputFormat turns them to fieldInfo.add(new RollingOjb("s by calling fieldInfo.add(new RollingObj("() method.  Each key-value pair is default separated by a tab character. 
			 *  Override the toString() so the output can be fieldInfo.add(new Ccm_Obj("s instead of strange symbols ex. FDR_Obj@27bc4ec8
			 */
		    @Override
			public String toString(){
		    	
				String results = fieldInfo.get(0).getValue(); //get the first RollingObj value
				
				for(int x = 1; x < fieldInfo.size(); x++){
					
				   //separated by tab delimiter
				   results = results + "," + fieldInfo.get(x).value;	//want the last string is value not tab
					
				}
				return results;
			}
		    /**
		     * create a row to return 
		     * @return row
		     */
		    public Row getRow(){
		    	Row row = null;
		    	try{
		    		row = RowFactory.create(fieldInfo.get(0).getValue(),
		    				fieldInfo.get(1).getValue(),
		    				fieldInfo.get(2).getValue(),
		    				fieldInfo.get(3).getValue(),
		    				fieldInfo.get(4).getValue(),
		    				fieldInfo.get(5).getValue(),
		    				fieldInfo.get(6).getValue(),
		    				fieldInfo.get(7).getValue(),
		    				fieldInfo.get(8).getValue(),
		    				fieldInfo.get(9).getValue(),
		    				fieldInfo.get(10).getValue(),
		    				fieldInfo.get(11).getValue(),
		    				fieldInfo.get(12).getValue(),
		    				fieldInfo.get(13).getValue(),
		    				fieldInfo.get(14).getValue(),
		    				fieldInfo.get(15).getValue(),
		    				fieldInfo.get(16).getValue(),
		    				fieldInfo.get(17).getValue(),
		    				fieldInfo.get(18).getValue(),
		    				fieldInfo.get(19).getValue(),
		    				fieldInfo.get(20).getValue(),
		    				fieldInfo.get(21).getValue(),
		    				fieldInfo.get(22).getValue(),
		    				fieldInfo.get(23).getValue(),
		    				fieldInfo.get(24).getValue(),
		    				fieldInfo.get(25).getValue(),
		    				fieldInfo.get(26).getValue(),
		    				fieldInfo.get(27).getValue(),
		    				fieldInfo.get(28).getValue(),
		    				fieldInfo.get(29).getValue(),
		    				fieldInfo.get(30).getValue(),
		    				fieldInfo.get(31).getValue(),
		    				fieldInfo.get(32).getValue(),
		    				fieldInfo.get(33).getValue(),
		    				fieldInfo.get(34).getValue(),
		    				fieldInfo.get(35).getValue(),
		    				fieldInfo.get(36).getValue(),
		    				fieldInfo.get(37).getValue(),
		    				fieldInfo.get(38).getValue(),
		    				fieldInfo.get(39).getValue(),
		    				fieldInfo.get(40).getValue(),
		    				fieldInfo.get(41).getValue(),
		    				fieldInfo.get(42).getValue(),
		    				fieldInfo.get(43).getValue(),
		    				fieldInfo.get(44).getValue(),
		    				fieldInfo.get(45).getValue(),
		    				fieldInfo.get(46).getValue(),
		    				fieldInfo.get(47).getValue(),
		    				fieldInfo.get(48).getValue(),
		    				fieldInfo.get(49).getValue(),
		    				fieldInfo.get(50).getValue(),
		    				fieldInfo.get(51).getValue(),
		    				fieldInfo.get(52).getValue(),
		    				fieldInfo.get(53).getValue(),
		    				fieldInfo.get(54).getValue(),
		    				fieldInfo.get(55).getValue(),
		    				fieldInfo.get(56).getValue(),
		    				fieldInfo.get(57).getValue(),
		    				fieldInfo.get(58).getValue(),
		    				fieldInfo.get(59).getValue(),
		    				fieldInfo.get(60).getValue(),
		    				fieldInfo.get(61).getValue(),
		    				fieldInfo.get(62).getValue(),
		    				fieldInfo.get(63).getValue(),
		    				fieldInfo.get(64).getValue(),
		    				fieldInfo.get(65).getValue());	//added pandatetime field	    		
		    	}catch(Exception e){e.printStackTrace();}
		    	return row;
		    }
}
