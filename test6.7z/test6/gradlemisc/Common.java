/*
 * This material is the confidential, unpublished property
 * of Fair Isaac Corporation.  Receipt or possession
 * of this material does not convey rights to divulge,
 * reproduce, use, or allow others to use it without
 * the specific written authorization of Fair Isaac
 * Corporation and use must conform strictly to the
 * license agreement.
 *
 * Copyright (c) Fair Isaac Corporation, 2018
 * All Rights Reserved.
 */

package com.fico.fraud.aws.encryption.util;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.regions.Region;
import com.amazonaws.services.s3.AmazonS3Encryption;
import com.amazonaws.services.s3.AmazonS3EncryptionClientBuilder;
import com.amazonaws.services.s3.model.CryptoConfiguration;
import com.amazonaws.services.s3.model.KMSEncryptionMaterialsProvider;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.beust.jcommander.JCommander;

public class Common {

    public static EncryptionUtilArgsParser getEncryptionUtilArgsParser(final String[] args) {
        EncryptionUtilArgsParser parsedArgs = new EncryptionUtilArgsParser();
        JCommander jCommander = JCommander.newBuilder().addObject(parsedArgs).build();
        jCommander.parse(args);

        if (parsedArgs.isHelp()) {
            jCommander.usage();
            System.exit(0);
        }
        return parsedArgs;
    }

    //java networking and proxies: https://docs.oracle.com/javase/8/docs/technotes/guides/net/proxies.html#:~:text=http.,http.
    public static AmazonS3Encryption getAmazonS3Encryption(final EncryptionUtilArgsParser parsedArgs) {
        int timeoutConnection = 80000;
        ClientConfiguration clientConfiguration = new ClientConfiguration();
       // clientConfiguration.setMaxErrorRetry(2);
       // clientConfiguration.setConnectionTimeout(timeoutConnection);
       // clientConfiguration.setSocketTimeout(timeoutConnection);
        clientConfiguration.setUseTcpKeepAlive(true);
        //07/19/2025 rhldmsgateway on SHK2 firewalls approved with direct access to AWS bucket; no more proxy server
        //clientConfiguration.setProtocol(Protocol.HTTPS);
       //clientConfiguration.setProxyHost("egressproxy.fairisaac.com");
        //clientConfiguration.setProxyPort(9480);
        KMSEncryptionMaterialsProvider materialProvider = new KMSEncryptionMaterialsProvider(parsedArgs.getKeyId());
        return AmazonS3EncryptionClientBuilder.standard()
                .withRegion(parsedArgs.getAwsRegion())
                .withEncryptionMaterials(materialProvider)
                .withClientConfiguration(clientConfiguration)
                .withCryptoConfiguration(new CryptoConfiguration().withAwsKmsRegion(Region.getRegion(parsedArgs.getAwsRegion())))
                .withAccelerateModeEnabled(parsedArgs.isAccelerationEnabled())
                .build();
    }

    public static TransferManager getTransferManager(final AmazonS3Encryption s3Encryption) {
        return TransferManagerBuilder.standard()
                .withS3Client(s3Encryption)
                .build();
    }
}

