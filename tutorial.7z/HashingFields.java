import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class HashingFields implements Serializable{
	
	/**
	 * java.io.Serializable - Marker Interface which does not have any methods in it.
	 * Purpose of Marker Interface - to tell the ObjectOutputStream that this object is a serializable object.
	 * Implements the Serializable because the string is a JSON string (inner class instance)
	 * so need the object to be broken down into bytes when calling this class methods
	 */
	private static final long serialVersionUID = 1L;
	List<String> fieldsIndexes = new ArrayList<String>();

	    
	public String hashingPan(String input){

		//System.out.println("pan: " + input);
        String base64encodedString = "";
        //want the first 6 bytes (BIN) in the clear so hash only the last 13 bytes for regular PANs
        String hashLast13bytes = input.substring(6);

        try {

            // Static getInstance method is called with hashing SHA
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            //MessageDigest.digest(SHA-256) produces 32 bytes
            byte[] hashByte = md.digest(hashLast13bytes.getBytes(StandardCharsets.UTF_8));

            //use Base64 to convert to characters 
            //Produces 44 characters total
            base64encodedString = Base64.getEncoder().encodeToString(hashByte);

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
        return input.substring(0,6) + base64encodedString.substring(0,13);
    }
	
	public String hashingCustomerAcctNumber(String input){
        
		//System.out.println("customeracctnumber: " + input);
		String base64encodedString = "";

        try {

            // Static getInstance method is called with hashing SHA
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            //MessageDigest.digest(SHA-256) produces 32 bytes
            byte[] hashByte = md.digest(input.getBytes(StandardCharsets.UTF_8));

            //use Base64 to convert to characters 
            //Produces 44 characters total
            base64encodedString = Base64.getEncoder().encodeToString(hashByte);

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
        return base64encodedString.substring(0,40);
	}
	
	//hash any strings and return the same amount of characters as original input string
	public String hashingAnyString(String input){
		String base64encodedString = "";

        try {

            // Static getInstance method is called with hashing SHA
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            //MessageDigest.digest(SHA-256) produces 32 bytes
            byte[] hashByte = md.digest(input.getBytes(StandardCharsets.UTF_8));

            //use Base64 to convert to characters 
            //Produces 44 characters total
            base64encodedString = Base64.getEncoder().encodeToString(hashByte);

        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
        return base64encodedString.substring(0,input.length());
	}
}
