import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDateTime;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;

import scala.reflect.ClassTag;

/**
 * 01/15/2024 - this class reads from a input list of pis and nmon files with different bytes to cut from 
 * due to client using different record types.  Example, Shazam has two PIS11 and two NMON11 record types
 * with different byte positions for each record type
 * @author JaneCheng
 *
 */
public class RollingPISList implements Serializable{
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	//static final List<Row> newRows = new ArrayList<>();
	RecordTypeMapperCSV rtm = null;
	StructType schema = null;
	RollingPISv2 driver2 = null;  //use RollingPISv2 methods to mapreduce pis and nmon
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
	String hdfsDest = "";
	String fileList = ""; // text file containing path of pis and nmon list
	String begPeriod = "";
	int pisBegPos = 0; //enter pis beginning position to extract text if using /dmsdisks files
	int pisEndPos = 0; //enter pis end position to extract text if using /dmsdisks files
	int nmonBegPos = 0; //enter nmon beginning position to extract text if using /dmsdisks files
	int nmonEndPos = 0; //enter nmon end position to extract text if using /dmsdisks files
	int pisPanEndPos = 0; //pis pan end position in bytes if using /dmsdisks files; some ts2_9330-f6 old files have no pans
	String query = "";
	static Path processedOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
	static BufferedReader br = null;

	String pis12List = "";
	String pis11List = ""; 
	String nmon20List = "";
	String nmon11List = "";
   	
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> pis12 = null;
	Dataset<Row> nmon11 = null;
	Dataset<Row> nmon20 = null;
	Dataset<Row> resultPaths = null;
	Broadcast<NmonBroadcast> nmbc = null;
	StructType textSchema = null;
	
	public static void main(String[] args){
		RollingPISList driver = new RollingPISList(args);
		driver.createSparkSession();
		driver.processDatePeriod();
		//driver.readFile();
		driver.createDataset();
		driver.closeAll();
	}
	
    public RollingPISList(){}
    
	public RollingPISList(String[] args){
    	   	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		this.hdfsDest = args[4];	
        this.fileList = args[5];
	}
	
	public void readFile(){
		try{
			 System.out.println("inside readFile(): " + LocalDateTime.now());
			 String content = "";
		     BufferedReader br = new BufferedReader(new FileReader(fileList));
		     while((content = br.readLine()) != null){
		    	 System.out.println("Read this line: " + content);
		    	 createPISandNMONList(content);
		     }
		     br.close();
		     
		}catch(Exception e){e.printStackTrace();}
	}
	
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("PISRollupTest")
		  			  .config("spark.dynamicAllocation.enabled", "false")
		  			  .config("spark.locality.wait", "0s")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  //.config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
		      textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		     // connectionProperties = new Properties();
		     // connectionProperties.put("user", "mdw");
		     // connectionProperties.put("password", "mdw");	     
		      nmbc = spark.sparkContext().broadcast(new NmonBroadcast(), classTag(NmonBroadcast.class));
			  System.out.println("broadcast NmonBroadcast class");
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    /**
     * input any class to broadcast in spark
     * returns the class T of ClassTag
     * @param clazz
     * @return 
     */
    public static <T> ClassTag<T> classTag(Class<T> clazz) {
  	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
 	 }
    
    /**
	 * set single date period or multiple date periods
	 * submitted by users
	 */
	public void processDatePeriod(){
		String[] split;
		System.out.println("processDatePeriod(): " + LocalDateTime.now());	
        processedOutputDir = CommonUtil.createDestinationDir(client, portfolio, hdfsDest);
        System.out.println("processedOutputDir: " + processedOutputDir);
		if(action.equalsIgnoreCase("u")){
			//multiple date periods submitted by users
        	if(dateFolder.contains("-")){
        		split = dateFolder.split("-");
        		dateFolder = split[0];  //first date period
        		while(Integer.parseInt(dateFolder) <= Integer.parseInt(split[1])){
        	       //have to catch January (01) month because the last month will be December (12)
			       //the lowest date period is 1901
        	       //if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       else{
        		      //date period greater than 1901
        		      this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
        		      System.out.println("Date Period: " + datePeriod);
        	       }
        	       dateFolder = String.valueOf((Integer.parseInt(dateFolder) + 1));
        		}
        	}
        	else{ //single date period submitted by users for update
        		//if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
        		if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
         		   System.out.println("Date Period: " + datePeriod);
         	    }
         	    else{
         		   //date period greater than 1901
         		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
         		   System.out.println("Date Period: " + datePeriod);
         	    }
        	        			
        	}
        }
		else{ //roll-up
			System.out.println("Roll-up to Date Folder: " + dateFolder);
			if(dateFolder.substring(2, 4).equalsIgnoreCase("01")){	
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
      		   System.out.println("Date Period: " + datePeriod);
      	    }
			else{
      		   //date period greater than 1901
      		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
      		   System.out.println("Date Period: " + datePeriod);
      	    }		
		}	
	}
	
	public void createPISandNMONList(String listPath){
		try{
			System.out.println("inside createPISandNMONList(): " + LocalDateTime.now());
			String content = "";
			String inputPath = "";
			String[] temp = listPath.split(",");
			//set the pisBegPos, pisEndPos, nmonBegPos, and nmonEndPos
			pisBegPos = Integer.parseInt(temp[1]);
			pisEndPos = Integer.parseInt(temp[2]);
			nmonBegPos = Integer.parseInt(temp[4]);
			nmonEndPos = Integer.parseInt(temp[5]);
			
			//read PIS Path is temp[0] and pis record type is temp[6]
			br = new BufferedReader(new FileReader(temp[0]));
			while((content = br.readLine()) != null){
				inputPath += "file://" + content + ",";
			}
			inputPath = inputPath.substring(0, inputPath.lastIndexOf(","));
			if(temp[6].equalsIgnoreCase("pis11")){  
				pis11List = inputPath;
				System.out.println("pis11List: " + pis11List);
				transformParquet(pis11List, "pis11");
			}
            if(temp[6].equalsIgnoreCase("pis12")){
            	pis12List = inputPath;
            	System.out.println("pis12List: " + pis12List);
            	transformParquet(pis12List, "pis12");
			}
            
            //read NMON Path is temp[3] and nmon record type is temp[7]
            inputPath = "";
            br = new BufferedReader(new FileReader(temp[3]));
			while((content = br.readLine()) != null){
				inputPath += "file://" + content + ",";
			}
			inputPath = inputPath.substring(0, inputPath.lastIndexOf(","));
			if(temp[7].equalsIgnoreCase("nmon11")){
				nmon11List = inputPath;
				System.out.println("nmon11List: " + nmon11List);
				transformParquet(nmon11List, "nmon11");
			}
            if(temp[7].equalsIgnoreCase("nmon20")){
            	nmon20List = inputPath;
            	System.out.println("nmon20List: " + nmon20List);
            	transformParquet(nmon20List, "nmon20");
			}
            
		}catch(Exception e){e.printStackTrace();}
	}
	
    public void transformParquet(String inputPaths, String recordtype){
    	try{
    		System.out.println("inside transformParquet(): " + LocalDateTime.now());

    		      df = spark.read()
  				         .format("text")
  				         .option("inferSchema", false)
  				         .option("header", false)
  				         .load(inputPaths.split(",")); //to load different file locations using strings   	
    		     
    			if(recordtype.equalsIgnoreCase("pis12")){
    			   df = df.filter(row -> {
					          return row.mkString().length() >= pisEndPos;}
        			        )
    					   .map(row -> {
    				          return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
    			   }, RowEncoder.apply(textSchema));
    			   
    			   df.repartition(1)
    			     .write()
    			     .format("text")
    			     .option("compression","gzip")
    			     .mode("append")
    			     .save("/work/mapping/2021/mapped/temp/pis12");
    			}
    			if(recordtype.equalsIgnoreCase("pis11")){				
    				//only keep records that have length greater than pisEndPos
    			  // df.createOrReplaceTempView("temp");
    			  // df = spark.sql("select * from temp where length(value) >= " + pisEndPos + " and value is not null");
     			  df = df.filter(row -> {
     					     return row.mkString().length() >= pisEndPos;}
     			          )
     			         .map(row -> {   
     				         return RowFactory.create(row.mkString().substring(pisBegPos, pisEndPos));
     			   }, RowEncoder.apply(textSchema));
     			  
     			 df.repartition(1)
			     .write()
			     .format("text")
			     .option("compression","gzip")
			     .mode("append")
			     .save("/work/mapping/2021/mapped/temp/pis11");
     			}
    			
    			if(recordtype.equalsIgnoreCase("nmon20")){
     			   df = df.filter(row -> {
					         return row.mkString().length() >= nmonEndPos;}
        			        )
     					   .map(row -> {
     				         return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			   
     			  df.repartition(1)
 			     .write()
 			     .format("text")
 			     .option("compression","gzip")
 			     .mode("append")
 			     .save("/work/mapping/2021/mapped/temp/nmon20");
     			}
    			
    			if(recordtype.equalsIgnoreCase("nmon11")){
    			   //df.createOrReplaceTempView("temp");
     			   //df = spark.sql("select * from temp where length(value) >= " + nmonEndPos + " and value is not null");
     			   df = df.filter(row -> {
				              return row.mkString().length() >= nmonEndPos;}
       			           )
     				       .map(row -> {
     				          return RowFactory.create(row.mkString().substring(nmonBegPos, nmonEndPos));
     			   }, RowEncoder.apply(textSchema));
     			   
     			  df.repartition(1)
 			     .write()
 			     .format("text")
 			     .option("compression","gzip")
 			     .mode("append")
 			     .save("/work/mapping/2021/mapped/temp/nmon11");
    			}		
	
    	}catch(Exception e){e.printStackTrace(); System.exit(-1);}
    }
    
    public void createDataset(){
    	try{
    		JavaRDD<Row> rdd = null;
                //process pis11 files
    		    df = spark.read()
 				         .format("text")
 				         .option("inferSchema", false)
 				         .option("header", false)
 				         .load("/work/mapping/2021/mapped/temp/pis11/*.gz"); //to load different file locations using strings 
    			df = df.persist(StorageLevel.MEMORY_ONLY());
    		    rdd = CommonUtil.mapReducePIS(df.javaRDD(), nmbc); 
    		    rdd = rdd.coalesce(80).persist(StorageLevel.MEMORY_ONLY());
                pis11 = CommonUtil.createDataSet(spark, "pis11", rdd);	
                pis11 = pis11.persist(StorageLevel.MEMORY_ONLY());
                df.unpersist();
                rdd.unpersist();
                
                //process nmon11 files
                df = spark.read()
				         .format("text")
				         .option("inferSchema", false)
				         .option("header", false)
				         .load("/work/mapping/2021/mapped/temp/nmon11/*.gz");
                df = df.persist(StorageLevel.MEMORY_ONLY());
        		rdd = CommonUtil.mapReduceNMON11(df.javaRDD(), nmbc);
        		rdd = rdd.coalesce(160).persist(StorageLevel.MEMORY_ONLY());
                nmon11 = CommonUtil.createDataSet(spark, "pis11", rdd);
                nmon11 = nmon11.persist(StorageLevel.MEMORY_ONLY());
                df.unpersist();
                rdd.unpersist();
                
              //now all transformations are done, merge the datasets 
                CommonUtil.mergeDatasetPIS11(pis11, nmon11, spark, nmbc, "r", processedOutputDir, dateFolder, datePeriod);
                nmbc.destroy();
                pis11.unpersist();
                nmon11.unpersist();
                
    	}catch(Exception e){e.printStackTrace(); System.exit(-1);}
    }
    
    public void mergeDataset(){
    	Dataset<Row> pastDF = null;
    	JavaRDD<Row> rdd = null;
    	try{
    		System.out.println("inside mergeDataset(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(pis11 != null){
            	if(nmon11 != null){  //make sure nmon11 has records            		
            	  //merge pis and nmon, pis11 still contains pandatetime field
            	  nmon11.createOrReplaceTempView("nmon");
            	  nmon11 = spark.sql("select * from nmon where nonmonCode in ('3001','3003', '3100', '3101', '3102', '3103', '3104', '3105', '3109','3114', '3115', '3121', '3122', '3123', '3124', '3201')");
  
              	  pis11 = pis11.union(nmon11);
                  System.out.println("pis11 unioned nmon11");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			.withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis11 = pis11.union(pastDF);
                	System.out.println("pis11 unioned " + datePeriod);
                }
                
                rdd = driver2.mapReducePIS(pis11.javaRDD());    		
                pis11 = driver2.createDataSet("pis11", rdd);
                System.out.println("pis11 completed final round of mapReducePIS");
                
                pis11 = pis11.drop("nonmonCode");  //drop nonmonCode column
                
                //remove empty pans
                pis11.createOrReplaceTempView("pis11");
                
                pis11 = spark.sql("select * from pis11 where trim(pan) <> ''");
                System.out.println("removed blank pans");
        
                //drop the pandatetime before writing it back out as another parquet file
                pis11 = pis11.drop("pandatetime");
                System.out.println("dropped pandatetime field");
                pis11 = pis11.dropDuplicates();
                System.out.println("dropped duplicates");

                  pis11.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);
            
                System.out.println("Completed " + processedOutputDir + "/current_PIS/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
            }
            
            if(pis12 != null){
            	//pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
            	if(nmon20 != null){
            		//merge pis and nmon, pis11 still contains pandatetime field
              	  nmon20.createOrReplaceTempView("nmon");
              	  nmon20 = spark.sql("select * from nmon where nonmonCode in ('3000','3010', '3100', '3102', '3104','3201')");
 
            	   //merge pis and nmon
            	   pis12 = pis12.union(nmon20);
            	   System.out.println("pis12 unioned nmon20");
            	}
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/current_PIS/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")))
                			        .withColumn("nonmonCode", functions.lit("    ").cast(DataTypes.StringType));
                	pis12 = pis12.union(pastDF);
                	System.out.println("pis12 unioned " + datePeriod);
                }
                
                rdd = driver2.mapReducePIS(pis12.javaRDD());    		
                pis12 = driver2.createDataSet("pis12", rdd);
                System.out.println("pis12 completed final round of mapReducePIS");
                
                pis12 = pis12.drop("nonmonCode");  //drop nonmonCode column
                
              //remove empty pans
                pis12.createOrReplaceTempView("pis12");
                
                pis12 = spark.sql("select * from pis12 where trim(pan) <> ''");
                System.out.println("removed blank pans");
                            
                //pis12.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
            	//pis12 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");

                //drop the pandatetime before writing it back out as another parquet file
            	pis12 = pis12.drop("pandatetime");
            	System.out.println("dropped pandatetime field");
                pis12 = pis12.dropDuplicates();
                System.out.println("dropped duplicates");

            		pis12.repartition(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/current_PIS/" + dateFolder);
           
            	System.out.println("Completed " + processedOutputDir + "/current_PIS/" + dateFolder + " Parquet File: " + LocalDateTime.now());           	
            } 	
            nmbc.destroy();
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
    public void closeAll(){
    	if(br != null){
    		try {
				br.close();
			} catch (IOException e) {e.printStackTrace();}
    	}
    }
    
    
}
