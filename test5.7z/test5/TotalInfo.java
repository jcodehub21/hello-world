package jc.lambda.util;

public class TotalInfo extends OwnerInfo{
}
