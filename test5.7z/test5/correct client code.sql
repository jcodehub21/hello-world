select * from files where portfolio = 'credit' and client = 'stgeorge' and filename like '%.Westpac.CREDIT%';

update files set client = 'westpac', portfolio = 'credit' where portfolio = 'credit' and client = 'stgeorge' and filename like '%.Westpac.CREDIT%';

select fileid, filename, client from files where client not like 'hsbc-uk_hfc' and filename like '%hsbc.hfc.cr.%';

update files set client = 'hsbc-uk_hfc' where client not like 'hsbc-uk_hfc' and filename like '%hsbc.hfc.cr.%';

--for suspended files:

select * from files where status = 'P' and portfolio = 'credit' and client = '~tbd~' and fileid between 2129939 and 2130382 and filename like 'UNTAR_2129078_1_data_Desjardins_Falcon_ascii_feed_CNDC101%';

select fileid, filename, client, portfolio, status from files where status = 'P' and filename like 'ADE-2022%';

--update suspended ADE tar.gz files
update files set client = 'tdbank-us-platform', portfolio = 'none', recordtype = 777, reclen = 100, nltype = 1 where status = 'P' and portfolio = 'credit' and client = '~tbd~' and filename like 'ade_FRAUD-ADE-TDBANK-35607-PROD%adhoc%';
update files set client = 'oxxo-f6', portfolio = 'none', recordtype = 777, reclen = 100, nltype = 1 where status = 'P' and portfolio = 'credit' and client = '~tbd~' and filename like 'CRMX.%.MEXICO.F6MF%';
update files set client = 'fdr-ar-f6', portfolio = 'none', recordtype = 777, reclen = 100, nltype = 1 where status = 'P' and portfolio = 'credit' and client = '~tbd~' and filename like '%.ARGURU.F6MF%';

update files set nltype = 1 where status = 'P' and client = 'fdr-b-f6-temp' and portfolio = 'none' and filename like '%FDR-B-F6-TEMP.NONE%';

update files set status = 'D' where status = '6' and portfolio = 'none' and client = 'ts2_9330-f6-bachist' and filename like 'TS2_C9330_%_BACHIST%';

select * from files where status = 'P' and portfolio = 'debit' and client = 'hsbc-uk_dub' and filename like '%hsbc.hbme.db%';

update files set client = 'fis-norcross-f6', portfolio = 'debit', recordtype = 377, reclen = 918, nltype = 1 where status = 'P' and portfolio = 'debit' and client = '~tbd~' and filename like 'UNTAR_%_1_data_FNFIS_%_ascii_feed_Decision%';

update files set client = 'fis-norcross-f6', portfolio = 'debit', recordtype = 341, reclen = 340, nltype = 1 where status = 'P' and portfolio = 'debit' and client = '~tbd~' and filename like 'UNTAR_2386972_1_data_FNFIS_PRD_ascii_feed_PUSXDGIP51%';

update files set recordtype = 653, reclen = 2722, nltype = 1 where status = 'P' and portfolio = 'none' and client = 'fdr-star-f6-temp' and filename like '%FDR-STAR-F6-TEMP.NONE.dbtran_auth%';

update files set recordtype = 689, reclen = 2305, nltype = 1 where status = 'P' and portfolio = 'none' and client = 'fdr-star-f6-temp' and filename like '%FDR-STAR-F6-TEMP.NONE.pis12%';

update files set recordtype = 652, reclen = 3877, nltype = 1 where status = 'P' and portfolio = 'none' and client = 'fdr-star-f6-temp' and filename like '%FDR-STAR-F6-TEMP.NONE.nmon20%';

update files set recordtype = 426, reclen = 2107, nltype = 1 where status = 'P' and portfolio = 'credit' and client = 'entercard-f6' and filename like 'UNTAR_%CRPMNT%';

update files set reclen = 2107  where status = 'P' and portfolio = 'credit' and client = 'entercard-f6' and filename like 'UNTAR_%CRTRAN24%';

--to update suspended files using fileids locked by me

update files set client = 'desj-f6', portfolio = 'debit', recordtype = 285, reclen = 340, nltype = 1 where fileid in (select f.fileid from files f, filelocks fl where f.status = 'P' and f.filename like 'UNTAR_2129078_1_data_Desjardins_Falcon_ascii_feed_CNDC101%' and f.fileid = fl.fileid and fl.username = 'JaneCheng');

select * from files where status = 'P' and portfolio = 'debit' and client = 'permata' and fileid between 2125864 and 2125898 and filename like '%.PERMATA.1.DEBIT.NONMON.%';

select * from newlines_codes;

--for suspended visa desj ade files

select * from files where status = 'P' and portfolio = 'none' and client = 'mastercard-multi-f6' and notes like 'Output%' and filename like 'FICO_ascii_feed_MastercardF6_Multi_DBTRAN23%';

update files set client = 'fis-norcross-f6', portfolio = 'debit', recordtype = 377, reclen = 918,  nltype = 1 where status = 'P' and portfolio = 'debit' and client = '~tbd~' and filename like 'UNTAR_2410859_1_data_FNFIS_PRD_ascii_feed_DecisionTrack_V2%';

update files set reclen = 2054 where status = 'P' and portfolio = 'none' and client = 'mastercard-multi-f6' and notes like 'Output%' and filename like 'UNTAR_2409930_1_data_MASTERCARD_MULTI_ascii_feed_DBTRAN23%';

update files set reclen = 1659 where status = 'P' and portfolio = 'none' and client = 'mastercard-multi-f6' and notes like 'Output%' and filename like 'UNTAR_2409930_1_data_MASTERCARD_MULTI_ascii_feed_DEMO10%';

update files set reclen = 1659 where status = 'P' and portfolio = 'none' and client = 'mastercard-single-f6' and notes like 'Output%' and filename like 'UNTAR_2410153_1_data_MASTERCARD_SINGLE_ascii_feed_DEMO10%';

update files set reclen = 2671 where status = 'P' and portfolio = 'credit' and client = 'ubs-f6' and notes like 'Output record length has changed from 2691 to 2671%' and filename like 'UNTAR_%_1_data_UCC_ascii_feed_CIS11%';

update files set reclen = 2619 where status = 'P' and portfolio = 'debit' and client = 'fis-norcross-f6' and notes like '%to 2619%' and filename like 'UNTAR_%_1_data_FNFIS_PRD_%_ascii_feed_CIS11%';

update files set reclen = 2669 where status = 'P' and portfolio = 'debit' and client = 'bem-f6' and filename like 'UNTAR_%_1_data_BEM_ascii_feed_CIS11%';

--for done files; change client code for visa desj falcon 6 ade
select * from files where status = 'D' and portfolio = 'none' and client = 'fdi-nbad-f6' and filename like 'FDI_FS8_%';

update files set portfolio = 'debit' where client = 'roa-f6' and portfolio = 'none';

select fileid, filename, client, portfolio from files where fileid = 8056130;

update files set client = 'gs-cloud', portfolio = 'none' where status = 'D' and portfolio = 'none' and client = 'elo-f6' and filename like 'rhlappffm4204%%';

--for done files; change client code for Child Files 

select fileid, filename, client, status from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'bpd-f6' and filename like 'FICO_ascii_%');

select fileid, filename, client, status from files where parent_fileid in (select fileid from files where fileid = 11430605);

update files set client = 'bpd-f6', portfolio = 'none' where fileid in (select fileid from files where parent_fileid = 11430605);

update files set client = 'gs-cloud', portfolio = 'none' where fileid in (select fileid from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'gs-cloud' and filename like 'rhlappffm4204%%'));

update filestorage set filename = REPLACE(filename,'.fdr-b-f6-temp.','.fdr-b-f6-test.') where filetype = 'O' and fileid in (select fileid from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdr-b-f6-test' and filename like 'FDR.PCPB.FRE41%'));

select 'mv '||fs.filename || ' ' || REPLACE(fs.filename,'.fdr-b-f6-temp.','.fdr-b-f6-test.') from filestorage fs, files f where fs.filestatus = 'O' and fs.filetype = 'O' and fs.fileid = f.fileid and f.fileid in (select fileid from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdr-b-f6-test' and filename like 'FDR.PCPB.FRE41%'));

--update status to Test Data for child files
update files set status = '4' where fileid in (select fileid from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'credit' and client = 'ads-f6' and filename like 'ADS_ADE_PROD%'));

select 'cp ' || filename || ' /work/falcon10/CUSTOM/Barclaycard_UK_Credit/FP_Barclaycard_UK_Credit_v5/DV/ADEFiles' from filestorage where filestatus = 'O' and filetype = 'O' and fileid in (select fileid from files where parent_fileid in (select fileid from files where status = '4' and portfolio = 'credit' and client = 'barclaycard-f6' and filename like '2009.BARCUKC%.TEST3.0911%%'));

--instr(string, substring_to_look_for, position of where in string the function begins the search, occurrence of string the function should search for)
select fs.filename, substr(fs.filename, 1, instr(fs.filename,'.',1,1)) || 'fdi-thinkmoney-f6' ||substr(fs.filename, instr(fs.filename, '.', 2, 2)) from filestorage fs, files f where fs.fileid = f.fileid and f.parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-thinkmoney-f6' and filename like 'FDI_FS1_%');

--substr(string, start_position, length)
select filename, substr(filename, 1, instr(filename, '.', 1, 1)) || 'FDR-UPGRADE-F6.NONE' || substr(filename, instr(filename, '.', 1, 3)) filename2 from files where status = 'P' and filename like '%~TBD~.CREDIT%';
update files set filename = substr(filename, 1, instr(filename, '.', 1, 1)) || 'FDR-UPGRADE-F6.NONE' || substr(filename, instr(filename, '.', 1, 3)) where status = 'P' and filename like '%~TBD~.CREDIT%';

--filehistory table contains all the workflow steps for files so need to update the infilename of the last step with status = E
select infilename,  substr(infilename, 1, instr(infilename, '.', 1, 2)) || 'FDR-UPGRADE-F6.NONE' || substr(infilename, instr(infilename, '.', 1, 4)) from filehistory where status = 'E' and infilename like '/mdswork/prd/work/700%~TBD~.CREDIT.%';

--updating recordytpe, reclen, encoding, nltype and ade_rt
update files set recordtype = 652, encoding = 'A', reclen = 3877, nltype = 1, ade_rt = 383 where status = 'P' and filename like '%FDR-UPGRADE-F6.NONE.nmon20';
update files set recordtype = 689, encoding = 'A', reclen = 2305, nltype = 1, ade_rt = 397 where status = 'P' and filename like '%FDR-UPGRADE-F6.NONE.pis12';
update files set recordtype = 653, encoding = 'A', reclen = 2722, nltype = 1, ade_rt = 177 where status = 'P' and filename like '%FDR-UPGRADE-F6.NONE.dbtran_auth';
update files set recordtype = 673, encoding = 'A', reclen = 2722, nltype = 1, ade_rt = 200 where status = 'P' and filename like '%FDR-UPGRADE-F6.NONE.crtran_auth';

update files set recordtype = 777, encoding = 'E', reclen = 100, nltype = 0 where status = 'P' and filename like 'FDR.PCPC.FRE107%';

update files set client = 'fdr-upgrade-f6' where parent_fileid in (6998226, 6998168, 6998167, 6998166, 6998102, 6998101, 6998100, 6998099, 6998098, 6997998,6997996); 

--for done files, change client code for Child Files for fdi-thinkmoney-f6
select fileid, filename, client from files where client = 'fdi-thinkmoney-f6' and filename like 'fdi-thinkmoney-f6.none.%';

update files set client = 'fdi-fs1-f6', portfolio = 'none' where client = 'fdi-thinkmoney-f6' and filename like '%.FDI_FS1_%';

update files set client = 'fdi-fs2-f6', portfolio = 'none' where client = 'fdi-nbad-f6' and filename like '%FDI_FS2_%';

update files set client = 'fdi-fs8-f6', portfolio = 'none' where client = 'fdi-f6' and filename like 'FDI_FS8_%';

update files set client = 'fdi-fs0-f6', portfolio = 'none' where client = 'fdi-nbad-f6' and filename like 'FDI_FS0_%';

--for done files; update the Child files Incoming/Original File name (not the online file storage file name)
select filename, substr(filename, 1, instr(filename, '.',1,1)-1), 'fdi-fs1-f6' || substr(filename, instr(filename, '.',1,1)) from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-fs1-f6' and filename like 'FDI_FS1_%');

update files set filename =  'fdi-fs1-f6' || substr(filename, instr(filename, '.',1,1)) where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-fs1-f6' and filename like '%.FDI_FS1_%');

select filename, substr(filename, 1, instr(filename, '.',1,1)-1), 'fdi-fs2-f6' || substr(filename, instr(filename, '.',1,1)) from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-fs2-f6' and filename like 'FDI_FS2_%');

update files set filename =  'fdi-fs2-f6' || substr(filename, instr(filename, '.',1,1)) where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-fs2-f6' and filename like '%.FDI_FS2_%');

select filename, substr(filename, 1, instr(filename, '.',1,1)-1), 'fdi-fs8-f6' || substr(filename, instr(filename, '.',1,1)) from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-f6' and filename like 'FDI_FS8_%');

update files set filename =  'fdi-fs8-f6' || substr(filename, instr(filename, '.',1,1)) where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-f6' and filename like 'FDI_FS8_%');

select filename, substr(filename, 1, instr(filename, '.',1,1)-1), 'fdi-fs0-f6' || substr(filename, instr(filename, '.',1,1)) from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-fs0-f6' and filename like 'FDI_FS0_%');

update files set filename =  'fdi-fs0-f6' || substr(filename, instr(filename, '.',1,1)) where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'fdi-fs0-f6' and filename like 'FDI_FS0_%');


--for done files; change client code for anz subclients
select * from files where status in ('D','U','0') and portfolio = 'credit' and client = 'equifax' and filename like '%.FIS.CREDIT.%';

update files set client = 'fis', portfolio = 'credit' where status in ('D','U','0') and portfolio = 'credit' and client = 'equifax' and filename like '%.FIS.CREDIT.%';

--update nltype for desj files from 1 (UNIXLF) to 0 (none)

update files set client = 'chase', portfolio = 'retail', nltype = 0 where status = 'P' and portfolio = 'credit' and client = '~tbd~' and filename like '%UNTAR%_FICO_ascii_feed%.ade.done%';

--update encoding and nltype field for anz

select * from files where encoding = 'A' and portfolio = 'credit' and client = 'anz' and filename like '%anz.gz';

update files set encoding = 'E', nltype = 0 where encoding = 'A' and portfolio = 'credit' and client = 'anz' and filename like '%anz.gz';

select * from files;

--update status to 'Test Data' for child files where parent files are already done and also set to 'Test Data'
select * from files where parent_fileid in (select fileid from files where status = '4' and filename like '2007.BARCUKC.%.TEST%');

update files set status = '4' where parent_fileid in (select fileid from files where status = '4' and filename like '2007.BARCUKC.%.TEST%');

--get count for ts1_usbank-fac
select date_yyyymmdd, sum(total_count) total from reccounts_raw where fileid in (select fileid from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'credit' and client = 'ts1_usbank-fac' and filename like 'TS1_%_CRTRAN25%')) group by date_yyyymmdd order by date_yyyymmdd;


select r.date_yyyymmdd, sum(r.total_count) total from reccounts_raw r, files f 
where f.filename like '%CRTRAN24%' and f.fileid = r.fileid and r.fileid in (select fileid from files where parent_fileid in (select fileid from files 
        where status = 'D' and portfolio = 'none' and client = 'entercard-cloud' and filename like 'ec-cloud_ec%')) 
        group by r.date_yyyymmdd order by r.date_yyyymmdd;
        
select r.date_yyyymmdd, sum(r.total_count) total, f.filename from reccounts_raw r, files f 
where f.fileid = r.fileid and r.fileid in (select fileid from files where parent_fileid in (select fileid from files 
        where status = 'D' and portfolio = 'none' and client = 'entercard-cloud' and filename like 'ec-cloud_ec%')) 
        group by f.filename, r.date_yyyymmdd order by r.date_yyyymmdd;

select filename, filesize, status, file_date from files where portfolio = 'credit' and client = 'ts1_usbank-fac' and filename like 'TS1_%_CRTRAN25%';

--delete parquet row from filestorage to allow it to regenerate tsv file
delete from filestorage where fileid = 11556689 and filetype = 'P';

-- update MPB clients
select client, portfolio, product, status from client where status = 'A' and product = 'MPB' and client like '%fac' order by client;

select client, product, status from client where product is null;

update client set product = null where client like '%-fac' and product = 'MPB';

select client, product, status from client where client like '%-fac';

--find cedge-f6 parquet files that are supposed to be idfc-f6 parquet files
select fs.fileid, fs.filename from filestorage fs, files f where fs.filetype = 'P' and fs.fileid = f.fileid and f.parent_fileid in (11664066, 11656455, 11661520, 11660886, 11656843) order by fs.filename;

update filestorage set yymm = 2403, filename = '/ptoan/datamgmt/dmsdisk4/prd/arch/FALCON/SINSYS-F6/NONE/2403/2403.sinsys-f6.none.crpmnt24.14233320.2106.ascii.bz2' where filetype = 'O' and fileid = 14233320;

update filestorage set yymm = 2301 where filetype = 'H' and fileid = 12055826;

select * from filestorage where fileid = 12055826;

select * from all_directories;
---------------------------------------------------------------------------------- 
--to move the LTA queue files in BP to SHK:  First you need to rsync the /mdswork/LTAqueue/*/* files on lux436 BP to SHK /mdswork/dev/work
--then create the YYMM directory in /mdswork/LTAqueue on SHK and move the files from /mdswork/dev/work to /mdswork/LTAqueue/YYMM
--then update the FILESTORAGE table
select * from filestorage where fileid = 3743647;

insert into filestorage(fileid, yymm, filename, filesize, filestatus, filetype) values(3743647, 1, '/mdswork/LTAqueue/0214/FDI_FS4_PIS11_F6MF_MAT_D16097', 280032, 'Q', 'L');

update filestorage set yymm = 2 where filestatus = 'D' and filetype = 'a' and fileid = 3743647;

------------------------------------------------------------------------------------ 

--update TD validation files for filehistory and files table
select * from files where fileid = 12863742;

select * from filehistory where fileid = 12863742;

update filehistory set status = 'D' where step# = 40 and fileid = 12863742;

update files set status = 'D' where fileid = 12863742;

------------------------------------------------------------------------------------
--get Sinopac files from hdfs
select 'hdfs dfs -get /work/falcon9/FALCON4-5_VALIDATION/OTHER_DIRECT/' || fileid || '.' || filename from files where filename like '%consortium_data_Sinopac_2023-09%' order by filename;

--------------------------------------------------------------------------------------

--find parent filename with child file record counts together

select L.filename, fs.numrows from (select fileid, filename from files where filename like 'FDI_FSA_%_F6MF_D23282%') L, filestorage fs, files f where fs.filestatus = 'O' and fs.filetype = 'O' and
 fs.fileid = f.fileid and f.parent_fileid = L.fileid order by L.filename;
 
---------------------------------------------------------------------------------------  
--to find parent files between certain dates on files table
select fileid, filename, file_date from files where file_date between to_date('14-OCT-23','DD-MON-YY') and to_date('28-OCT-23', 'DD-MON-YY') and filename like 'BPD_%_ascii_202310%' order by file_date;

--below queries filenames from /dmsdisks
select fs.filename from filestorage fs, files f where filestatus = 'O' and filetype = 'O' and fs.filename like '%.bpd-f6.none.ais%' and fs.fileid = f.fileid and f.parent_fileid in (select fileid from files where file_date between to_date('14-OCT-23','DD-MON-YY') and to_date('28-OCT-23', 'DD-MON-YY') and filename like 'BPD_%_ascii_202310%');

--below queries filenames from /data/parquet_falcon
select fs.filename from filestorage fs, files f where filestatus = '2' and filetype = 'P' and fs.filename like '%bpd-f6.none.ais%' and fs.fileid = f.fileid and f.parent_fileid in (select fileid from files where file_date between to_date('14-OCT-23','DD-MON-YY') and to_date('28-OCT-23', 'DD-MON-YY') and filename like 'BPD_%_ascii_202310%');

select fs.filename from filestorage fs, files f where filestatus = '2' and filetype = 'P' and fs.filename like '%bpd-f6.none.dbtran%' and fs.fileid = f.fileid and f.parent_fileid in (select fileid from files where filename like 'BPD_%_ascii_20231027%');

---------------------------------------------------------------------------------------
--to find online child files on filestorage from ADE files
select 'cp ' || filename || ' /ptoan/gad_transfers_atr/transfers/BancoPan/DDA/DV/20231229' from filestorage fs where filestatus = 'O' and filetype = 'O' and fileid in (
select fileid from files where parent_fileid in (select fileid from files where status = 'D' and portfolio = 'none' and client = 'bancopan-f6' and filename like 'SS%BancoPan_ascii_20231222%'))

--------------------------------------------------------------------------------------------

--query pis11 and nmon11 its-shazam-f6 files with different recordtypes
select filename from filestorage where filename like '/ptoan/datamgmt/%its-shazam-f6.none.pis11%' and filestatus = 'O' and filetype = 'O' and fileid between 9987398 and 10532348 order by fileid;