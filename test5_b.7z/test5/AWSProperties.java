package jc.lambda.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

//import Apache log4j 2
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AWSProperties {

      Properties p = System.getProperties();
      ClassLoader classLoader;
      private final static Logger logger = LogManager.getLogger(AWSProperties.class);

      public Properties getProperties(){return p;}

      public void setProperties(){
         try {
             //load this class to JVM
             classLoader = AWSProperties.class.getClassLoader();
             //read file as file input stream under src/main/resources
             /**
              * another way to read file under src/main/resources or target folder
              * InputStream is = getClass().getResourceAsStream("/awskey.properties");
              * String content = IOUtils.toString(is);  //IOUtils is from apache commons-io
              */
             File file = new File(classLoader.getResource("awskey.properties").getFile());
             FileInputStream fis = new FileInputStream(file);
             //load into Properties object
             getProperties().load(fis);
             //set the System properties
             System.setProperties(p);

         }catch(FileNotFoundException e){
             logger.error("Properties file not found: {}", e.getMessage());
         }catch(IOException e){
             logger.error("Cannot read Properties file: {}", e.getMessage());
         }

      }
}
