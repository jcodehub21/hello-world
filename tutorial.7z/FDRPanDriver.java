import java.io.BufferedReader;
//import java.io.BufferedWriter;
import java.io.InputStreamReader;
//import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.LocalDateTime;

/**
 * 07/13/2021 This class will replace old pans with new pans
 * using Spencer's mapping file for FDR B, C, E and N Fraud files (/ptoan/MSG1/spencer/FDR/mapping/{B,C,E,N,Z}/{yyyymm})
 * Pan bytes are 13-31
 * 
 * rhlappfrd60005 if using database file: 
 * spark2-submit --master yarn --deploy-mode client --driver-memory 50g --executor-memory 60g --conf spark.yarn.am.memory=2g --class FDRPanDriver /home/janecheng/ADEUtilv5.jar /work/fdrMapping/spencer/FDR/mapping/ /work/fdrMapping/spencer/FDR/mapping/rhlappfrd60005fdrlist.txt /work/fdrMapping/2021/mapped/ B 1912 2001 2022-01-10 update_fdr_pis_1912b_database > /apps/jyc/fdrpis.log 2>&1 &
 * 
 * rhlappfrd60005 no database file and client mode:
 * spark2-submit --master yarn --deploy-mode client --driver-memory 60g --executor-memory 60g --conf spark.yarn.am.memory=2g --class FDRPanDriver /home/janecheng/ADEUtilv5.jar /work/fdrMapping/spencer/FDR/mapping/ /work/fdrMapping/spencer/FDR/mapping/rhlappfrd60005fdrlist.txt /work/fdrMapping/2021/mapped/ B 1911 1912 > /apps/jyc/fdrpis7.log 2>&1 &
 * 
 * rhlappfrd60005 no database file and cluster mode:
 * spark2-submit --master yarn --deploy-mode client --driver-memory 60g --executor-memory 60g --conf spark.yarn.am.memory=2g --class FDRPanDriver /home/janecheng/ADEUtilv5.jar /work/fdrMapping/spencer/FDR/mapping/ /work/fdrMapping/spencer/FDR/mapping/rhlappfrd60005fdrbf6nmonlist1912.txt /work/fdrMapping/2021/mapped/ B 2001 > /apps/jyc/fdrnmon1912.log 2>&1 &
 * 
 * 1/24/2022 New command for rhlappfrd60005: spark.yarn.am.memory took almost 3.35TB of memory which is not good
 * spark2-submit --master yarn --deploy-mode cluster --driver-memory 60g --executor-memory 60g --conf spark.yarn.am.memory=2g --class FDRPanDriver /home/janecheng/ADEUtilv5.jar /work/fdrMapping/spencer/FDR/mapping/ /work/fdrMapping/spencer/FDR/mapping/fdref6nmonlist1808-1801.txt /work/fdrMapping/2021/mapped/ E 1912 > /apps/jyc/fdrenmon1806-1801.log 2>&1 &
 *
 * 5/3/2022 New command for rhlappfrd60005 as yarn was allocating over 300GB for each task
 * spark2-submit --master yarn --deploy-mode client --driver-memory 30g --executor-memory 50g --num-executors 2 --conf spark.network.timeout=10000001 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=2g --conf spark.executor.heartbeatInterval=10000000 --class FDRPanDriver /home/janecheng/ADEUtilv5.jar /work/fdrMapping/spencer/FDR/mapping/ /work/fdrMapping/spencer/FDR/mapping/fdrcf6nmonlist1803-1801.txt /work/fdrMapping/2021/mapped/ C 1912 > /apps/jyc/fdrcnmon1803-1801b.log 2>&1 &
 * 
 * @author JaneCheng
 *
 */
public class FDRPanDriver implements Serializable{
	
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> mapper = null; 
	Dataset<Row> sfx = null;
	Dataset<Row> newsfx = null;
	StructField sf = null;
	String yymm = ""; //date period to fix
	String clientCode = "";
	String filePath = "";
	String hdfsMapString = "";
	String hdfsMapperFile = "";
	List<StructField> fields = null; //store the mapper file two columns
	StructType mapperSchema = null;
	StructType rtSchema = null;
	StructType textSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static FileStatus[] list_files = null; 
	//static BufferedReader br = null;
	//static BufferedWriter bwDBFile = null;
	String pattern = "^part-.+\\.bz2$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	String dfPath = "";
	static Path newDFPath = null;
	String processedDate = "";
	String databaseFile = "";
	String recordtype = "";
	String fileid = "";
	int counter = 0; //let's me know it is first time loading mapper file
	String clientTemp = ""; //use to compare if same client code and yymm
	String yymmTemp = "";

	public static void main(String[] args) {		
		/**
		 * args[0] = hdfs mapper file location  args[0] - /work/fdrMapping/spencer/FDR/mapping/
		 * args[1] = file to read from    args[1]
		 * args[2] = main dfPath to write text file to  args[2] - /work/fdrMapping/2021/mapped/
		 * args[3] = client uppercase letter
		 * args[x] = yymm date period to process  <-- take this one out
		 * args[4] = yymm of the map file to use
		 * args[5] = optional: date of processing for the manual_changes table eg. '2021-10-03' 'YYYY-MM-DD'
		 * args[6] = optional: database file to write update and insert SQL statements
		 */
		try{
		   FDRPanDriver driver = new FDRPanDriver(args[0], args[2], args[3], args[4]);
		   driver.startSparkSession();
		   driver.readFDRList(args[1]); 
          // driver.closeAll();  //this caused spark error of not being able to flush 
		}catch(Exception e){e.printStackTrace();}

	}
	
    public FDRPanDriver(String hdfsMap, String df, String client, String yymmMapFile){		
		
    	dfPath = df;  //hdfsTA on rhldmsprd001 or /work/fdrMapping/2021/mapped on BP - newDFPath to write text file to
		clientCode = client;
		//this.yymm = yymm;
		hdfsMapString = hdfsMap; 		
	    //fdr mapper file main location
	    hdfsMapperFile = hdfsMapString + clientCode + "/20" + yymmMapFile;
	}
	
	public FDRPanDriver(String hdfsMap, String df, String client, String yymm, String yymmMapFile, String date, String dbFile){		
		
		dfPath = df;  //hdfsTA on rhldmsprd001 or /work/fdrMapping/2021/mapped on BP - newDFPath to write text file to
		clientCode = client;
		this.yymm = yymm;
		processedDate = date;
		databaseFile = dbFile;
		hdfsMapString = hdfsMap;  //fdr mapper file main location
		hdfsMapperFile = hdfsMapString + clientCode + "/20" + yymmMapFile;
	}
	
	public void readFDRList(String fdrlist){
		String content = "";		
		try{
			loadMapperFile();  //enter client code and yymmMapFile as arguments 
			BufferedReader brMain = new BufferedReader(new InputStreamReader(fs.open(new Path(fdrlist))));
			while((content = brMain.readLine()) != null){
				   setArgs("file://" + content);
				   //loadMapperFile();
				   loadFile();
			   }
			   if(brMain != null){brMain.close();}
			
		}catch(Exception e){e.printStackTrace();}	
	}
	
	public void setArgs(String filename){
		//clientCode = filename.substring(filename.indexOf("FDR-") + 4, filename.indexOf("FDR-") + 5);
		//this.yymm = filename.substring(filename.lastIndexOf("/") - 4, filename.lastIndexOf("/"));
		this.filePath = filename;
	    System.out.println("original filePath: " + filePath);
	    String[] metadata = filePath.substring(filePath.lastIndexOf("/") + 1).split("\\.");
	    this.yymm = metadata[0];
	    this.recordtype = metadata[3];
	    this.fileid = metadata[4];
		///work/fdrMapping/2021/C/1912 - 07/26/2021 
		///work/fdrMapping/spencer/FDR/mapping - 12/16/2021 contains newer months for fdr mapper files
		//hdfsMapperFile = hdfsMapString + clientCode + "/20" + yymm;  
	}
	
	public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("FDR Pan Mapper")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
		//mapper fields and schema is fixed so only need to define once
		// Store the StruckField object into a List
		fields = new ArrayList<>();			
		fields.add(DataTypes.createStructField("oldPan", DataTypes.StringType, true));
	    fields.add(DataTypes.createStructField("newPan", DataTypes.StringType, true));
					
		//create the schema for the mapper file
	    mapperSchema = DataTypes.createStructType(fields);
 
		 //Text data source supports only a single column, and you have 3 columns.
		//create the schema for the new text file
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		
		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		   //  newDFPath = new Path("/hdfsTA/work/fdrMapping/2021/mapped"); //rhldmsprd001
		     //newDFPath = new Path(dfPath);  //BP TA cluster
		}catch(Exception e){e.printStackTrace();}
	}
		
	//loadMapperFile only loads the mapper file with different locations
	public void loadMapperFile(){
		/**
		 * Need to use csv format in order for spark to read 
		 * the ! delimiter; 
		 * Using text format only gives one column called value 
		 * and will throw an error if used with delimiter and schema
		 */
		mapper = spark.read()
				      .format("csv")
				      .schema(mapperSchema)
				      .option("delimiter", "!")  //using ! delimiter to separate the data so don't need to create FieldObj
				      .option("header", "false")
				      .load(hdfsMapperFile + "/*.bz2");
		System.out.println("Load mapper file complete: " + hdfsMapperFile);
		
		try{
			  //bw = new BufferedWriter(new FileWriter(dfPath + databaseFile, true));
			//bwDBFile = new BufferedWriter(new OutputStreamWriter(fs.create(new Path(dfPath + databaseFile)), "UTF-8"));
			}catch(Exception e){e.printStackTrace();}
	}
	
	public void loadFile(){
		//load the record type schema
		fieldObj = ClientRecordType.getFDRRecordTypeMapper(recordtype);
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
		}
		
		//testing to make sure we got the right fields
		/**System.out.println("Fields size: " + fields.size());
		for(StructField fieldname : fields)
		{
			System.out.println("fieldname: " + fieldname.name());
		}**/
		
		
		rtSchema = DataTypes.createStructType(fields);
		   
		   try{
		   sfx = spark.read()
				      .format("text")
				      .option("inferSchema", false)
				      .option("header", "false")
				      .load(filePath);  //on rhldmsprd001;  remember to use file:// on input file if on BP cluster
		   
		   System.out.println("Load " + recordtype + " file complete: " + filePath);
		   /**
		    * Encoder.String() returns Dataset<String>
		    * RowEncoder.apply(StructType schema) returns Dataset<Row>
		    * MapFunction<Input, Output>
		    */
		   sfx = sfx.map((MapFunction<Row, Row>) row -> {
			   fieldObj.setFieldValue(row.mkString());
			   return fieldObj.getRow();
		   }, RowEncoder.apply(rtSchema)); //applies the schema to the row so dataset will know it is for row
		   
		   
		   /**use dataframe left join to get all rows from sfx and also include only rows from mapper that 
		    * sfx pan == mapper pan
		    * and then replace the null values under newPan column with sfx pan column using
		    * functions.when() <- make sure that you import org.apache.spark.sql.functions 
		    * If you use just when() then java will not recognize the function, must use 
		    * functions.when(); there is also functions.otherwise() condition
		    */
		   
		   newsfx = sfx.join(mapper, sfx.col("pan").equalTo(mapper.col("oldPan")), "left");
		   //newsfx.show(20, false);
		   newsfx = newsfx.select(newsfx.col("filler1"),
				   newsfx.col("pan"),
				   newsfx.col("filler2"),
				   newsfx.col("newPan"),
				       functions.when(newsfx.col("newPan").isNull(),newsfx.col("pan"))  //replace newPan with pan if newpan is null
				       .otherwise(newsfx.col("newPan")).alias("newPanNoNull"));  //otherwise keep newPan value as is and be under new column called newPanNoNUll
		 
		   System.out.println("Joined and dropped old pans and inserted new pans no nulls");
		   /**drop the original pan and newPan columns and then renamed the newPanNoNull to pan
		    * this produces the dataframe column order of filler1, filler2, pan which is the wrong order
		   **/
		   newsfx = newsfx.drop("pan").drop("newPan").withColumnRenamed("newPanNoNull", "pan");
		   
		   //have to reselect the columns to be in the correct order:  filler1, pan, filler2 so can be written out to text file
		   newsfx = newsfx.select(newsfx.col("filler1"), newsfx.col("pan"), newsfx.col("filler2"));
		   
		   //convert back from three columns to one column so can write in text file
		   newsfx = newsfx.map(row -> {
				  return RowFactory.create(row.mkString());				  
			  }, RowEncoder.apply(textSchema));
	  
			  //df.coalesce(1).write.option("compression","gzip").format("text").save("/path/to/save")
		   
		   //delete if /hdfsTA/work/fdrMapping/2021/mapped exists
		   newDFPath = new Path(dfPath + clientCode + "/" + recordtype + "/" + yymm + "/" + fileid + "/");
		   if(fs.exists(newDFPath))
	    	{
	    		fs.delete(newDFPath, true);
	    	}
		   
		   System.out.println("Start writing text file " + LocalDateTime.now());
		   //write back out as text file
		   newsfx.repartition(1)    // 4/22/2022 change from coalesce(1) to repartition(1)
			            .write()
			            .format("text")
			            .option("compression", "bzip2")  //.option("compression","bzip2")
			            .mode("overwrite")
			            .save(newDFPath.toString());
		   
			  System.out.println("finished writing text file " + LocalDateTime.now());
			  // Create a Pattern object
	  		  filePattern = Pattern.compile(pattern);
	  		    
	  		  list_files = fs.listStatus(newDFPath);
              for(FileStatus oldFilePath : list_files){
		    	
    	           m = filePattern.matcher(oldFilePath.getPath().getName());
    	           if(m.matches()){
    	        	   //fs.rename also moved the new filename to another path
    	        	   if(fs.rename(oldFilePath.getPath(), new Path(dfPath + clientCode + "/" + recordtype + "/" + yymm + "/" + filePath.substring(filePath.lastIndexOf("/") + 1)))){
    	        		     // bwDBFile.write("mv /hdfsTA" + dfPath + clientCode + "/" + recordtype + "/" + yymm + "/" + filePath.substring(filePath.lastIndexOf("/") + 1)  + " " + filePath.substring(filePath.indexOf("file://") + 7));
	    	        		//  bwDBFile.newLine();
	    	        		 // bwDBFile.write("update filestorage set filesize = " + oldFilePath.getLen() + " where fileid = " + fileid + " and filestatus = 'O' and filetype = 'O';");
	    	        		//  bwDBFile.newLine();
	    	        		//  bwDBFile.write("insert into manual_changes values ('" + fileid + "', DATE '" + processedDate + "', fdr-" + clientCode.toLowerCase() + "-f6(none) pan mapping', 'JaneCheng');");
	    	        		//  bwDBFile.newLine();
	    	        		  fs.delete(new Path(dfPath + clientCode + "/" + recordtype + "/" + yymm + "/" + fileid), true);
	    	        		  System.out.println("renamed " + oldFilePath.getPath() + " back to " + dfPath + clientCode + "/" + recordtype + "/" + yymm + "/" + filePath.substring(filePath.lastIndexOf("/") + 1) + " : " + LocalDateTime.now());  
    	        	   }
    	           }
    	        }
		   }catch(Exception e){e.printStackTrace();}
		   
	   }
	
	public void closeAll(){
		try{
			if(fs != null){
				fs.close();
			}
			//if(bwDBFile != null){
				//bwDBFile.close();
			//}
		}catch(Exception e){e.printStackTrace();}
	}

}
