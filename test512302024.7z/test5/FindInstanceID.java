package jc.lambda.util;

public class FindInstanceID {

    public static void test(String[] args) {
        try {
             JsonUtil test = new JsonUtil();
             test.setFactory();
             System.out.println("principalId returned: " + test.readJsonFile("C:\\software\\AWS_FCM\\LambdaUtil\\src\\main\\resources\\input.json", "principalId"));
            System.out.println("instanceId returned: " + test.readJsonFile("C:\\software\\AWS_FCM\\LambdaUtil\\src\\main\\resources\\input.json", "instanceId"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
