import java.net.URI;
import java.security.PrivilegedExceptionAction;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.security.UserGroupInformation;

/**
 * 01/13/2022 This class will change owner of files on HDFS when the original owner leaves company
 * 
 * rhlhddfrd206:
 * /apps/parquet_logs/jdk1.8.0_231/bin/java -cp .:/apps/parquet_logs:/opt/cloudera/parcels/CDH-5.14.2-1.cdh5.14.2.p0.3/jars/* HDFSChangeOwner nfs /hdfsTA/work/fdrMapping/2021/akbank janecheng fmtdata ipfrd > /apps/parquet_logs/HDFSChangeOwner.log 2>&1 &
 * 
 * @author JaneCheng
 */

public class HDFSChangeOwner {
	
	FileSystem fs = null;
	Configuration conf = null;
	FileStatus[] list_files = null; 
	String sourceOwner = "";
	String destOwner = "";
	String groupName = "";
	UserGroupInformation ugi = null;
	String hdfsURI = ""; //active namenode of the cluster
	int count = 0;
	
	public static void main(String[] args) {
		/**
		 * args[0] = filesystem: hdfs or nfs
		 * args[1] = directory to check for files
		 * args[2] = original owner of the files
		 * args[3] = new owner for the files
		 * args[4] = new group name for the files
		 */
		HDFSChangeOwner driver = new HDFSChangeOwner(args[0], args[2], args[3], args[4]);
        driver.checkHDFSDirectory(new Path(args[1]));
        driver.displayCount();
	}
	
	public HDFSChangeOwner(String filesystem, String source, String dest, String group){
		sourceOwner = source;
		destOwner = dest;
		groupName = group;
		conf = new Configuration();
		try{
			//need to add these resources because running a java class without spark 
	    	//does not know that /work/tsv is part of hdfs 
			if(filesystem.equalsIgnoreCase("hdfs")){  //hdfs file system
	    	  conf.addResource(new Path("/etc/hadoop/conf.cloudera.yarn/core-site.xml"));
	    	  conf.addResource(new Path("/etc/hadoop/conf.cloudera.yarn/hdfs-site.xml"));
	    	  conf.setBoolean("fs.hdfs.impl.disable.cache", true);
			}
	       //default for NFS or local file system
		   fs = FileSystem.get(conf);
		 
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void checkHDFSDirectory(Path dirName){
		try{
		   list_files = fs.listStatus(dirName);
		   for(FileStatus file : list_files){
			   if(file.isDirectory()){
				   checkHDFSDirectory(file.getPath());
			   }
			   if(file.isFile() && file.getOwner().equalsIgnoreCase(sourceOwner)){
				   fs.setOwner(file.getPath(), destOwner, groupName);
				   System.out.println("Changed owner from " + sourceOwner + " to " + destOwner + " for " + file.getPath());
				   count++;
			   }
		   }		   
		}catch(Exception e){e.printStackTrace();}
	}	
	
	public void displayCount(){
		System.out.println("Total ownership files changed: " + count);
	}
	
	/**
	 * Set user permission as hdfs so can execute actions for any user
	 * Method to access HDFS rhlhddfrd200 NameNode from a machine that does not have Hadoop installed
	 * @param action
	 * @throws Exception
	 */
	 public void setUserPermission() throws Exception{
		
		
		/**
		 * Create a user from a login name 
		 * user "hduser" makes hadoop user whatever username you want for connecting to remote hadoop cluster
		 * have to set String action to final because it is being called in a new class (PrivilegedExceptionAction<T>)
		 */
		ugi = UserGroupInformation.createRemoteUser("hdfs");
		
		/**
		 * You can create an instance of Void using reflections, but they are not useful for anything. 
		 * Void is a way to indicate a generic method returns nothing but wants to instantiate a class.
		 */
		ugi.doAs(new PrivilegedExceptionAction<Void>(){ //new PrivilegedExceptionAction<T> class; T = Object class, cannot be primitive types
			
			public Void run() throws Exception{
				
				conf = new Configuration();
				conf.set("hadoop.job.ugi", "hdfs");
				hdfsURI = "hdfs://rhldatdms24001.fairisaac.com:8020";
				fs = FileSystem.get(URI.create(hdfsURI), conf);
				//mainPath = new Path(hdfsURI);
				//fs.close();
				return null;
			}
			
		});	
	}
	
}
