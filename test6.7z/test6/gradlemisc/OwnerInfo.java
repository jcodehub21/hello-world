package jc.lambda.util;

import com.amazonaws.services.resourcegroupstaggingapi.AWSResourceGroupsTaggingAPI;
import com.amazonaws.services.sagemaker.AmazonSageMaker;

import java.util.HashMap;
import java.util.Map;

/**
 * 03/18/2024 - this class stores fico:common:owner name, each month's cost, and total for each month
 */
public class OwnerInfo {
    String ownerName = "";
    String service = "";
    String project = "";
    Map<String, Double> monthCost = new HashMap<String, Double>();
    //total for each owner or each row
    double total = 0.00;

    public OwnerInfo(){}
    public OwnerInfo(String name){
        ownerName = name;
    }
    public OwnerInfo(AWSResourceGroupsTaggingAPI rgtag, String name, String month, String year, String cost){
       if(name.contains("No tag")){
           service = "other services";
        } else{
           service = CommonOps.getResourceByTagKey(rgtag, "fico:common:owner", name);
       }
       if(service.isEmpty() && name.contains("-") && (name.contains("G") || name.contains("T"))){
           service = "ec2:volume";
       }
       if(service.isEmpty() && (!name.contains("G") || !name.contains("T"))){
           service = "ec2:instance";
       }
        if(name.contains("sagemaker")){
            ownerName = name.substring(0, name.indexOf("-"));
        }else{
            ownerName = name;
        }
        setMonthCost(month, year, cost);
    }

    public OwnerInfo(AWSResourceGroupsTaggingAPI rgtag, String name, String month, String year, String cost, String tagKey, AmazonSageMaker sagemaker){
        if(name.contains("No tag key")){
            service = "other services";
        } else{
            service = CommonOps.getResourceByTagKey(rgtag, tagKey, name);
        }
        if(service.isEmpty() && name.contains("-") && (name.contains("G") || name.contains("T"))){
            if(tagKey.contains("owner")) {
                service = "ec2:volume";
            }
        }
        if(service.isEmpty() && (!name.contains("G") || !name.contains("T"))){
            if(tagKey.contains("owner")) {
                service = "ec2:instance";
            }
        }
        if(!name.contains("No tag key") && name.contains("sagemaker") && tagKey.contains("fico:common:owner")){
            ownerName = name.substring(0, name.indexOf("-"));
        }else if(!name.contains("No tag key") && name.contains("domain/")){  //get sagemaker domain name
            System.out.println("Found domain-arn: " + name);
            ownerName = name;
            project = CommonOps.getSageMakerDomainName(sagemaker, name.substring(name.lastIndexOf("/") + 1));
            //project = CommonOps.getSageMakerDomainName(name);
        }else{
            ownerName = name;
        }
        setMonthCost(month, year, cost);
    }

    public void setOwnerName(String name){
        ownerName = name;
    }
    public void setMonthCost(String month, String year, String cost){
        double d = Math.round(Double.parseDouble(cost) * 100.0)/100.0;
        monthCost.put(CalendarOps.getMonthName(month) + year, d);
        setTotal(d);
    }

    public void setTotal(Double d){
        total = Math.round((total + d)*100.0)/100.0;
    }

    public String getOwnerName(){return ownerName;}
    public String getTotal(){return String.valueOf(total);}
    public Map<String, Double> getMonthCost(){return monthCost;}
}
