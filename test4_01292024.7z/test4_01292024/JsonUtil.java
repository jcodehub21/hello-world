
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.util.Iterator;

/**
 * 01/26/2024 - This is Json utility that will read the EventBridge details if it is a Json string
 */
public class JsonUtil {

    ObjectMapper mapper = null;
    JsonFactory factory = null;
    String field;
    int fieldID = 1;
    StringBuilder strBuilder = null;

    public void setFactory(){
        factory = JsonFactory.builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS).build();
    }

    public JsonFactory getFactory(){
        if(factory == null){
            factory = JsonFactory.builder().enable(JsonReadFeature.ALLOW_JAVA_COMMENTS).build();
        }
        return factory;
    }

    /**
     * read the json string and returns the root node
     * @param jsonString
     * @return JsonNode
     */
    public JsonNode getJsonNode(String jsonString) throws JsonProcessingException {
        mapper = new ObjectMapper(getFactory());
        return mapper.readTree(jsonString);
    }

    public ObjectMapper getObjectMapper(){
        if(mapper == null){
            mapper = new ObjectMapper();
        }
        return mapper;
    }

    /**
     * go down the tree to get all nodes and values
     * this method works to traverse down the nodes
     * https://javaee.github.io/tutorial/jsonp001.html
     * Objects are enclosed in braces ({}), their name-value pairs are separated by a comma (,), and the name and
     * value in a pair are separated by a colon (:). Names in an object are strings, whereas values may be of any of
     * the seven value types, including another object or an array.
     * Arrays are enclosed in brackets ([]), and their values are separated by a comma (,).
     * Each value in an array may be of a different type, including another array or an object
     * When objects and arrays contain other objects or arrays, the data has a tree-like structure
     * @param node
     */
    public void traverse(JsonNode node) {
        if (node.isObject()) {  //is an Object
            Iterator<String> iterator = node.fieldNames(); //get all field names of the object
            while (iterator.hasNext()) {
                field = iterator.next();  //gets the next element/node key name
                JsonNode value = node.get(field); //returns the node value
                // System.out.println("object: " + field);
                traverse(value); //it iterates the fields inside the object, get value and then keeps going to next field node
            }
        } else if (node.isArray()) {  //is an Array
            ArrayNode arrayNode = (ArrayNode) node;
            for (int i = 0; i < arrayNode.size(); i++) {
                JsonNode arrayElement = arrayNode.get(i);
                //System.out.println("Enter arrayNode");
                traverse(arrayElement); //goes down to all fields/nodes in an array
            }
        } else { //single field with value
            if (field.equalsIgnoreCase("workflow")) {
                fieldID = 1;
            } else {
                fieldID++;
            }
            if (node.isDouble()) {
                strBuilder.append("field: " + field + "=> value: " + String.valueOf(node.doubleValue()) + "\n");
            } else if (node.isInt()) {
                strBuilder.append("field: " + field + "=> value: " + String.valueOf(node.intValue()) + "\n");
            } else if (node.isNull()) { //null value
                strBuilder.append("field: " + field + "=> value: null \n");
            } else { //it is a string
                strBuilder.append("field: " + field + "=> value: " + String.valueOf(node.textValue()) + "\n");
            }
        }
    }
}
