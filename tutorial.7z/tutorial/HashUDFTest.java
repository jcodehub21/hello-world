package org.jc.udf.athena;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.jc.udf.athena.HashUDF;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
//import com.google.gson.Gson; 
//import com.google.gson.GsonBuilder; 
/**
 * A simple test harness for locally invoking your Lambda function handler.
 */
public class HashUDFTest {

    private static Map<String,Object> input; 
    //public Gson gson = GsonBuilder.setPrettyPrinting().create();
    
	@BeforeClass
    public static void createInput() throws IOException {
        // TODO: set up your sample input object here.
    	input  = new HashMap<String, Object>();
    	input.put("name", new String("hello"));
    }

    public Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("HashUDF");

        return ctx;
    }

    @Test
    public void testHashUDF() {
        HashUDF handler = new HashUDF();
        Context ctx = createContext();
        
        
        String output = handler.handleRequest(input, ctx);

        // TODO: validate output here if needed.
       Assert.assertEquals("hello", output);
    }
}
