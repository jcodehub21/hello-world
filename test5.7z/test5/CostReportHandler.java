package jc.lambda.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.costexplorer.AWSCostExplorer;
import com.amazonaws.services.costexplorer.AWSCostExplorerClientBuilder;
import com.amazonaws.services.costexplorer.model.*;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.*;
import com.amazonaws.services.simpleemail.model.Message;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 03/08/2024 - This class will get the tag fico:common:owner costs under Cost Explorer
 * and send out email using SES to the user
 * https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/costexplorer/AWSCostExplorerClient.html
 * https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/simpleemail/AmazonSimpleEmailService.html
 * Cost Explorer - Date Range (StartDate and EndDate),Granularity (Hourly, Daily, Monthly), Dimension (Tag -> value = fico:common:owner)
 */
public class CostReportHandler implements RequestHandler<Map<String,Object>, String> {
    Expression expression;
    AWSCostExplorer costExplorer;
    AmazonSimpleEmailService ses;
    LocalDate today;
    String year, startDay, endDay, currentMonth, lastMonth;
    String sender, recipient, subject;
    String bodyHTML = "";
    GeneralLinkList<OwnerInfo> ownerInfo = new GeneralLinkList<OwnerInfo>();
    StringBuffer sb = new StringBuffer();
    int priorMonthsToGoBack = 6;
    List<String> monthNames = new ArrayList<String>();
    List<String> recipients = new ArrayList<String>();
    LambdaLogger logger;

    @Override
    public String handleRequest(Map<String, Object> event, Context context) {
        costExplorer = AWSCostExplorerClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        ses = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
        logger = context.getLogger();

        //expression = new Expression();
       // expression.setTags(new TagValues().withKey("fico:common:owner"));
        // https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/services/costexplorer/model/GetCostAndUsageRequest.html
        GroupDefinition groupDefinition =
                new GroupDefinition().withType(GroupDefinitionType.TAG).withKey("fico:common:owner");
        today = LocalDate.now();
        startDay = "01";  //always want the first day of each month
        currentMonth = CalendarOps.convertSingleDigitToString(today.getMonthValue());
        //going back 6 months so start date will be last year around September 2023
        //from January to September, the month is single digit number; need to be double digit
        lastMonth = CalendarOps.convertSingleDigitToString(today.minusMonths(priorMonthsToGoBack).getMonthValue());
        endDay = CalendarOps.convertSingleDigitToString(today.getDayOfMonth());

        System.out.println("CE: Start Time: " + today.minusMonths(priorMonthsToGoBack).getYear() + "-" + lastMonth + "-" + startDay);
        /**
         * Error Code: ValidationException:
         * com.amazonaws.services.costexplorer.model.AWSCostExplorerException:
         * Start time  is invalid. Valid format is: yyyy-MM-dd.
         * Somehow the unblended costs does not include the end time/date
         */
        GetCostAndUsageRequest request = new GetCostAndUsageRequest()
                .withTimePeriod(new DateInterval().withStart(today.minusMonths(priorMonthsToGoBack).getYear() + "-" + lastMonth + "-" + startDay).withEnd(today.getYear() + "-" + currentMonth + "-" + endDay))
                .withGranularity(Granularity.MONTHLY)
                .withMetrics("UnblendedCost")
                .withGroupBy(groupDefinition);  //similar to query where you do a group by

        //GetCostAndUsageResult does not give total cost
        GetCostAndUsageResult result = costExplorer.getCostAndUsage(request);
        //results.getResultsByTime() return List<ResultByTime>
        if(result.getResultsByTime().size() > 0) {
            result.getResultsByTime().forEach(x -> {
                logger.log("ResultByTime: " + x);
               // logger.log("getTotal: " + x.getTotal());  x.getTotal() returns zero
                //bodyHTML = bodyHTML + parseCEReport(x.toString());
                parseCEReportList(x.toString());
            });
        }
        else{
            logger.log("no results from " + today.minusMonths(priorMonthsToGoBack).getYear() + "-" + lastMonth + "-" + startDay + " to " + today.getYear() + "-" + currentMonth + "-" + endDay);
        }

        //now go through linklist and create a table with cost details
        //check to make sure linklist captured the info
        if(ownerInfo.size > 0){
            OwnerInfo temp;
            String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
            String endTable = "</table></br>";
            sb.append("The table below shows the cost of resources owned by users or groups.</br></br>");
            sb.append("Note: </br>");
            sb.append("&emsp;1. EC2 instances are owned by user's name. </br>");
            sb.append("&emsp;2. JaneChengLambda tracks lambda cost for tagging EC2 instances. </br>");
            sb.append("&emsp;3. JaneChengCRLambda tracks lambda cost for generating the cost report. </br>");
            sb.append("&emsp;4. Empty value indicates the resource did not exist for a particular month. </br>");
            sb.append("&emsp;5. No tag owner means the resources are using other tag names or do not have tags. </br></br>");
            sb.append(beginTable);
            sb.append("<tr><td><b>fico:common:owner</b></td><td><b>Total</b></td>");
            //now iterate to add Months header row
            while(priorMonthsToGoBack >= 0){
                monthNames.add(CalendarOps.getMonthName(lastMonth) + today.minusMonths(priorMonthsToGoBack).getYear());
                sb.append("<td><b>" + CalendarOps.getMonthName(lastMonth) + " " + today.minusMonths(priorMonthsToGoBack).getYear() + "</b></td>");
                priorMonthsToGoBack--;
                lastMonth = CalendarOps.convertSingleDigitToString(today.minusMonths(priorMonthsToGoBack).getMonthValue());
            }
            sb.append("</tr>"); //add
            //now insert owner = Total to find the column totals for each month
            Map<String, Double> total = new HashMap<String, Double>();
            ownerInfo.setIterator();
            while(ownerInfo.hasNext()){
                temp = ownerInfo.getNode();
                if(!temp.ownerName.isEmpty()){
                    //String.format("%,.2f", d) => % is the placeholder for the double 'd' number; .2f means two decimal places; $, means use comma to separate the digits in dollars
                    sb.append("<tr><td>" + temp.ownerName + "</td><td>" + String.format("$%,.2f",temp.total) + "</td>");
                    if(!total.containsKey("Total")){
                        total.put("Total", temp.total);
                    }
                    else{
                        //hashmap = the remove() method returns the value removed from the map.
                        total.put("Total", total.remove("Total") + temp.total);
                    }
                    for(String k : monthNames){
                        //logger.log("get month value for " + k +  ": value: " + temp.monthCost.get(k));
                        //check if key is present in hashmap first
                        if(temp.monthCost.containsKey(k)) {
                            sb.append("<td>" + String.format("$%,.2f",temp.monthCost.get(k)) + "</td>");
                            if (!total.containsKey(k)) {
                                total.put(k, temp.monthCost.get(k));
                            } else {
                                total.put(k, total.remove(k) + temp.monthCost.get(k));
                            }
                        }else{
                            sb.append("<td></td>");  //no value for key
                        }
                    }
                    sb.append("</tr>");
                }
            }
            sb.append("<tr><td><b>Total</b></td><td>" + String.format("$%,.2f", Math.round(total.get("Total")*100.0)/100.0) +"</td>");
            for(String k : monthNames){
                sb.append("<td>" + String.format("$%,.2f",Math.round(total.get(k)*100.0)/100.0) + "</td>");
            }
            sb.append("</tr>" + endTable);
        }else{
            sb.append("No cost report available as of " + CalendarOps.getMonthName(currentMonth) + " " + endDay +", " + year);
            logger.log("No owner information found in ownerInfo List");
        }
        //Create the email request; make sure that the sender and recipient email addresses are set up in SES console
        sender = "janecheng@fico.com";
        //recipient = "janecheng@fico.com";
        //recipients.add("jehangirathwal@fico.com");
        recipients.add("janecheng@fico.com");
        bodyHTML = sb.toString();
        subject = "PTO.StreamEngine.DevSand Cost Report as of " + CalendarOps.getMonthName(currentMonth) + " " + endDay +", " + year;
        //sendEmail(sender, recipient,subject,bodyHTML);
        /**
         * SendEmailRequest(String source, Destination destination, Message message)
         * source = sender
         * Destination is a class and sends to recipient
         * Destination.withToAddresses takes in Collection<String> Addresses
         * public Destination withToAddresses(Collection<String> toAddresses)
         * Message(Content subject, Body body) = a class
         * Content is a class => Content(String data)
         * Body is a class => Body(Content text)
         */
        SendEmailResult sendEmailResult = ses.sendEmail(new SendEmailRequest(sender,
                new Destination().withToAddresses(recipients),
                new Message(new Content(subject), new Body().withHtml(new Content(bodyHTML)))));

        return "succesfully retrieve cost and usage report";
    }

    public String parseCEReport(String costDetail){
        Map<String, String> costMap = new HashMap<String, String>();
        //https://stackoverflow.com/questions/3964211/when-to-use-atomicreference-in-java
        /**
         * Atomic reference should be used in a setting where you need to do simple atomic (i.e. thread-safe, non-trivial)
         * operations on a reference, for which monitor-based synchronization is not appropriate.
         */
        AtomicReference<Double> totalCost = new AtomicReference<>(0.0);
        String startPeriod = "";
        String endPeriod = "";
        String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
        String endTable = "</table></br>";
        String[] splitData = costDetail.split(",");
        for(int x = 0; x < splitData.length; x++){
            if(splitData[x].contains("Start")){
                startPeriod = splitData[x].substring(splitData[x].indexOf("Start:") + 7);
            }
            if(splitData[x].contains("End")){
                endPeriod = splitData[x].substring(splitData[x].indexOf("End:") + 5, splitData[x].indexOf("}"));
            }
            if(splitData[x].contains("fico:common:owner")){
                //check if any tag values for key fico:common:owner
                String ownerName = splitData[x].substring(splitData[x].indexOf("$"), splitData[x].indexOf("]"));
                 if(ownerName.length() == 0){
                     costMap.put("No tag key: fico:common:owner", splitData[x+1].substring(splitData[x+1].indexOf("Amount:") + 7));
                 }
                 else{  //has an owner name
                     costMap.put(splitData[x].substring(splitData[x].indexOf("$") + 1), splitData[x+1].substring(splitData[x+1].indexOf("Amount:") + 7));
                 }
                 x++;
            }
        }
        sb.append("Date Period: " + startPeriod + " to " + endPeriod + "<br>");
        sb.append(beginTable);
        sb.append("<tr><td><b>fico:common:owner</b></td><td><b>Total</b></td></tr>");
        costMap.forEach((k,v) -> {
            double cost = Math.round(Double.parseDouble(v) * 100.0)/100.0;
            //Atomically updates the current value with the results of applying the given function to the current and given values, setting the updated value.
            totalCost.set(totalCost.get() + cost);
            sb.append("<tr><td>" + k + "</td><td>" + String.valueOf(cost) + "</td></tr>");
        });
        sb.append("<tr><td><b>Total</b></td><td>" + totalCost + "</td></tr>");
        sb.append(endTable);
        return sb.toString();
    }

    /**
     * parseCEReportList uses GeneralLinkList to store cost information
     * @param costDetail
     */
    public void parseCEReportList(String costDetail){
        String[] splitData = costDetail.split(",");
        String year = "";
        String month = "";
        String ownerName = "";
        String amount = "";
        OwnerInfo temp;
        for(int x = 0; x < splitData.length; x++){
            if(splitData[x].contains("Start")){
                year = splitData[x].substring(splitData[x].indexOf("Start:") + 7).substring(0,4);
                //logger.log("year: " + year);
                month = splitData[x].substring(splitData[x].indexOf("Start:") + 7).substring(5,7);
               // logger.log("month: " + month);
            }
            if(splitData[x].contains("fico:common:owner")){
                //check if any tag values for key fico:common:owner
                if(splitData[x].substring(splitData[x].indexOf("$") + 1).equalsIgnoreCase("]")){
                    ownerName = "No tag owner";
                }else{
                    ownerName = splitData[x].substring(splitData[x].indexOf("$") + 1, splitData[x].indexOf("]"));
                }

                amount = splitData[x + 1].substring(splitData[x + 1].indexOf("Amount:") + 7);
                if(amount == null){
                    amount = "0.00";
                }
                //logger.log("ownerName: " + ownerName);
                if(ownerInfo.size == 0) { //linklist size is 0
                        //logger.log("added first new owner: " + ownerName + ": " + amount);
                        ownerInfo.addNode(new OwnerInfo(ownerName, month, year, amount));
                }
                else{  //linklist already has owner info
                    boolean hasOwner = false;
                    ownerInfo.setIterator();
                    while(ownerInfo.hasNext()){
                        temp = ownerInfo.getNode();
                        if(temp.ownerName.equalsIgnoreCase(ownerName)){  //found existing owner
                            hasOwner = true;
                           // logger.log("found existing owner: " + temp.ownerName);
                           // logger.log("check if it has monthyear key: " + temp.monthCost.get(CalendarOps.getMonthName(month) + " " + year));
                            //add month, year, and cost if do not have it
                            if(temp.monthCost.get(CalendarOps.getMonthName(month) + year) == null){
                                temp.setMonthCost(month, year, amount);
                            }
                        }
                    }
                    if(!hasOwner){
                        //logger.log("linklist size: " + ownerInfo.size);
                        //logger.log("added new owner: " + ownerName + ": " + amount);
                        ownerInfo.addNode(new OwnerInfo(ownerName, month, year, amount));
                    }
                }
            }
        }
       /** ownerInfo.setIterator();
        logger.log("now check linklist data");
        while(ownerInfo.hasNext()){
            temp2 = ownerInfo.getNode();
            logger.log("ownername: " + temp2.ownerName);
            temp2.monthCost.forEach((k,v) -> {
                logger.log("key: " + k + ", value: " + v);
            });
            logger.log("total: " + temp2.total);
        } **/
    }
}
