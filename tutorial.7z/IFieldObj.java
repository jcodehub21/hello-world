/**
 * 07/12/2021 Interface for FieldObj
 * so T can extend it in the RecordTypeMapper generic class to 
 * be able to call T.method()
 * @author JaneCheng
 *
 */
public interface IFieldObj {
	public void setValueByRecord(String record);
	public void setValueByBancolumbia(String record);
	public void setValueByADS(String record);
	public String getValue();
}
