package jc.lambda.util;

public enum EnumDay {
    /**
     * 03/17/2024 - each constants is a mini-object of EnumDay class
     * that needs it's own constructor
     * Enum is similar to:
     * class EnumDay
     * public static final EnumDay Day1 = new EnumDay(some args here);
     * public static finale EnumDay Day2 = new EnumDay(some args here);
     */
    Day1("01"),
    Day2("02"),
    Day3("03"),
    Day4("04"),
    Day5("05"),
    Day6("06"),
    Day7("07"),
    Day8("08"),
    Day9("09");

    private final String day;
    //enum constructor; require for each enum object
    EnumDay(String day) {
        this.day = day;
    }

    public String getDay(){
        return day;  //returns 01, 02, etc..
    }
}
