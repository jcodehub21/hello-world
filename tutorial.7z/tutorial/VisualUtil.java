package com.jc.spark.mllib.MLlibUtil;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.spark.sql.Dataset;

//import tech.tablesaw.api.DoubleColumn;
//import tech.tablesaw.api.Table;
import tech.tablesaw.plotly.Plot;
import tech.tablesaw.plotly.api.ScatterPlot;

public class VisualUtil implements Serializable{
	
	static double[] col1; 
	static double[] col2;
	/**public static void main(String[] args) {
		
		double[] firstCol = {2.0, 3.0, 4.0};
		double[] secondCol = {1.0, 2.0, 3.0};
		Table table = Table.create("Test")
				      .addColumns(DoubleColumn.create("x-axis", firstCol),
				    		  DoubleColumn.create("y-axis", secondCol));
		Plot.show(ScatterPlot.create("ScatterPlot", table, "x-axis", "y-axis"));
	}**/
	
	private static final long serialVersionUID = 1L;

	/**
	 * takes in any type of dataframe that contains the data for the axis
	 * require to pass the axis names
	 * In this example we will deal with x-axis and y-axis only
	 * @param df
	 * @param axis
	 */
	public static void scatterPlot(Dataset<?> df, String[] axis) {
		long rowCount = df.count();
		//need to make it col1 and col2 as static; otherwise the map function thinks they are new objects
    	col1 = new double[(int) rowCount];   
    	col2 = new double[(int) rowCount]; 
    	
    	//https://stackoverflow.com/questions/30026824/modifying-local-variable-from-inside-lambda/30026897
    	AtomicInteger x = new AtomicInteger(0);
    	df.select(axis[0], axis[1]).foreach(row -> {
    		//System.out.println("x before: " + x);
    		int y = x.getAndIncrement();
    		//System.out.println(row.get(0) + " " + row.get(1));
    		col1[y] = (double) row.get(0);
    		col2[y] = (double) row.get(1);
    		//System.out.println("y after: " + x);
    	});
    	
		Plot.show(ScatterPlot.create("ScatterPlot Example", axis[0], col1, axis[1], col2));
	}

}
