package com.jc.spark.mllib.MLlibUtil;

import java.util.Arrays;

import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class CommonUtil {
	
	static SparkSession spark = null;
	
	//return SparkSession instance and then can set configuration using the instance in other classes
	public static void startSparkSession(String name) {

    	spark = SparkSession.builder().appName(name)
 			   .master("local")
 			   .config("spark.debug.maxToStringFields", 5000)
 			   .getOrCreate();
 	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
	    spark.sparkContext().setLogLevel("WARN");
	   // return spark;
	    
	}
    
	/**
	 * read a csv file
	 * @param filename
	 * @param format
	 * @param inferschema
	 * @param header
	 * @return Dataset<Row>
	 */
	public static Dataset<Row> loadData(String filename, String format, boolean inferschema, boolean header) {
	    return spark.read().format(format).option("inferSchema", inferschema).option("header", header).load(filename);
	}
	
	/**
	 * read the data stored in LIBSVM format as a DataFrame.
	 * libsvm package implements Spark SQL data source API for loading LIBSVM data as DataFrame. 
	 * The loaded DataFrame has two columns: label containing labels stored as doubles and features 
	 * containing feature vectors stored as Vectors.
	 * To use LIBSVM data source, you need to set "libsvm" as the format in DataFrameReader 
	 * and optionally specify options such as numFeatures (the largest index number for feature column)
	 * Class org.apache.spark.ml.source.libsvm.LibSVMDataSource
	 * 
	 * The LibSVM format is quite simple. The first row contains the class label, in this case 0 or 1. Following that are 
	 * the features, here there are two values for each one; the first one is the feature index (i.e. which feature it is) 
	 * and the second one is the actual value.  The feature indices starts from 1 (there is no index 0) and 
	 * are in ascending order. The indices not present on a row are 0.
	 * Each row looks like: <label> <index1>:<value1> <index2>:<value2> ... <indexN>:<valueN>
	 * 
	 * @param filename
	 * @param format
	 * @return Dataset<Row>
	 */
	public static Dataset<Row> loadLibSVMData(String filename, String format){
		//get warning if don't set numFeatures
		//you need to know the largest index number of feature column in order to use numFeatures option
		//return spark.read().format(format).option("numFeatures", "692").load(filename);  
		return spark.read().format(format).load(filename);
	}
	
	//take in already converted arrays and splits out a new column called features containing all data
	public static VectorAssembler getVectorAssembler(String[] array) {
		return new VectorAssembler().setInputCols(array).setOutputCol("features").setHandleInvalid("skip");
	}
	
	//take in dataframe that already contains selected columns and splits out a new column called features
    public static VectorAssembler getVectorAssembler(Dataset<Row> df) {
        return new VectorAssembler().setInputCols(Arrays.copyOf(df.columns(), df.columns().length)).setOutputCol("features").setHandleInvalid("skip");
	}
}
