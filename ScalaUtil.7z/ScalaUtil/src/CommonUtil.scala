package org.jc.scala

class CommonUtil {

}
