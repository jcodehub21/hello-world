package org.jc.scala

//https://www.oreilly.com/library/view/scala-cookbook/9781449340292/ch04s08.html
/**class HelloWorld {

}**/

object HelloWorld extends App {

  /**
   * declaring immutable variables/constants meaning once declared it cannot be changed unless you use val keyword again
   * val <variableName> : <Scala type> = <Some literal>
   *   OR
   * val <variableName> = value
   */
  val donutsToBuy: Int = 5 //same as val donutsToBuy = 5

  /**
   * declaring a mutable variable that allows you to change the value using the "var" keyword
   * Always strive to use "val" and avoid using "var" if possible
   */
  var favoriteDonutName: String = "Glazed Donut" //same as var favoriteDonut = "Glazed Donut"
  favoriteDonutName = "Vanilla Donut"  //value can be changed

  /**
   * lazy initialization - to delay the initialization of some variable until at the point where it is consumed by your application
   * using the "lazy" keyword
   */
  lazy val donutService = "initialize some donut service"

  /**
   * Scala does not have built-in types! Instead, it was designed from the ground up to
   * have a set of classes for representing its supporting types as shown below
   */
  val donutsBought: Int = 5
  val bigNumberOfDonuts: Long = 100000000L
  val smallNumberOfDonuts: Short = 1
  val priceOfDonut: Double = 2.50
  val donutPrice: Float = 2.50f
  val donutStoreName: String = "all about scala Donut Store"
  val donutByte: Byte = 0xa
  val donutFirstLetter: Char = 'D'
  val nothing: Unit = ()

  /**
   * declare variable with no initialization
   * Sometimes you may not know the value of your variable immediately.
   * You can only assign your variable's value at some later point in time during the execution of your application
   */
  var leastFavoriteDonut: String = _
  leastFavoriteDonut = "Plain Donut"

  /**
   * define a function with no return type
   * "Unit" is similar as void keyword in Java
   */
  def run(): Unit ={
    val ages = Seq(42, 75, 29, 64)  //don't need semicolon (;) if only one line.  Muse use ; if multiple commands in one line
    println(s"The oldest person is ${ages.max}")
  }

  //muti-line method
  //The curly braces can be added or removed automatically, based on indents.
  def walkThenRun() = {
    println("walk")
    println("run")
  }

  /**
   * To define a function in Scala, you need to use the keyword def.
   * You can also use "val" to define a function
   * Then add the name of your function which in our case will be favoriteDonut followed by an empty pair of parenthesis ().
   * To specify the return type you need to use the colon : followed by the return type which in our case is a String.
   */
  def myFavoriteDonut(): String = {
    "Glazed Donut"  //The last line within the body of the function is the one that will be returned back to the caller.
  }

  //def function(variable:type): return type
  def square(x: Int): Int = x * x * x

  val favoriteDonut = myFavoriteDonut()
  println(s"My favorite donut is $favoriteDonut")

  /**
   * define a function with no parenthesis ()
   * In general, you should define your functions without parenthesis if you are defining a function
   * that does not have any side effects.
   */
  def leastFavoriteMyDonut = "Plain Donut"
  println(s"My least favorite donut is $leastFavoriteMyDonut")

  //Seq and List are two types of linear collections. In Scala these collection classes are preferred over Array
  def loop(): Unit = {
    val ints = Seq(1,2,3)
    for (i <- ints) println(i)
  }

  /** For the purpose of iterating over a collection of elements and
   * printing its contents you can also use the foreach method that’s available to Scala collections classes.
   * foreach is available on most collections classes, including sequences, maps, and sets.
   */
  val ratings = Map(
    "Lady in the Water" -> 3.0,
    "Snakes on a Plane" -> 4.0,
    "You, Me and Dupree" -> 3.5
  )
  for ((name,rating) <- ratings) println(s"Movie: $name, Rating: $rating")
  ratings.foreach {
    case (movie, rating) => println(s"key: $movie, value: $rating")
  }

  for
  (i <- 1 to 2)
    for (j <- 'a' to 'b')
      for (k <- 1 to 10 by 5 )
        println(s"i = $i, j = $j, k = $k")

  run()
}



