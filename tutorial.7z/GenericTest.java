
public class GenericTest {
	
	public static void main(String[] args){
		
		GenericTest gt = new GenericTest();
		gt.addfieldobj();
	}
	
	/**
	 * generic methods must be used only in other methods or main  
	 */
	public void addfieldobj(){
		
		FieldObj test = new FieldObj("pan", 1, 13);
		RecordTypeMapper<FieldObj> rt = new RecordTypeMapper<FieldObj>();
		rt.addFieldObj(test);
	}
	
	

}
