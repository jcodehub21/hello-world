import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
//import org.apache.spark.api.java.function.PairFunction; //needed if want to do a new PairFunction<>()
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.functions; //have to use functions.concat()
import org.joda.time.LocalDateTime;

import scala.Tuple2;

/**
 * This class uses Oracle JDBC to connect to DMS database
 * before starting the spark session
 * Can only execute with single date period each time 
 * @author JaneCheng
 *
 */
public class RollingPIS implements Serializable{
	
	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	//static final List<Row> newRows = new ArrayList<>();
	RecordTypeMapper rtm = null;
	StructType schema = null;
	String client = "";
	String portfolio = "";
	String dateFolder = "";
	String datePeriod = "";  //prior month for processing
	String action = "";
    Connection conn = null;
	ResultSet rs = null;
	PreparedStatement ps = null; //complete query without recordtype input parameters needed
	String query = "";
	Path processedOutputDir = null;
	//list represents an ordered sequence of objects
	String pis12List = "";
	String pis11List = ""; 
	String nmon20List = "";
	String nmon11List = "";
   	
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> pis12 = null;
	Dataset<Row> nmon11 = null;
	Dataset<Row> nmon20 = null;
	
	public static void main(String[] args){
		/**
    	 * args[0] = client ex: ts2_8167-f6
    	 * args[1] = portfolio  ex: debit
    	 * args[2] = date period  ex: 1901
    	 * args[3] = action (r = rollup, u = update)
    	 * args[4] = main hdfs destination to store parquet files
    	 */
		if(args.length == 5){
		   RollingPIS test = new RollingPIS(args);
		   //connect to DB once
		   test.connectDB();

		}
		else{
			System.out.println("Usage: RollingPIS tool to roll up nmon pans to pis files from 1901 to present. \n"
					+ "Parameters separated by a space: client portfolio date_period action main_hdfs_destination\n"
					+ "Action: r for rollup and u for update \n" 
					+ "Example: ts2_8167-f6 debit 1901 r /data/rollingPIS_test");
			
		}
		//test.createTestPIS();
	}
	
    public RollingPIS(){}
    
	public RollingPIS(String[] args){
		Configuration config = new Configuration();
    	FileSystem fs = null;
    	
		this.client = args[0];
		this.portfolio = args[1];
		this.dateFolder = args[2];
		this.action = args[3]; //r = rollup, u = update
		
		processedOutputDir = new Path(args[4] + "/" + client + "/" + portfolio);
		
		try{		
			fs = FileSystem.get(config);
		    if(!fs.exists(processedOutputDir)){
			   fs.mkdirs(processedOutputDir);
	    	}
		
		    if(action.equalsIgnoreCase("u")){
     	       //have to catch January (01) month because the last month will be December (12)
			   //the lowest date period is 1901
        		if(Integer.parseInt(dateFolder.substring(0, 2)) > 19 && dateFolder.substring(2, 4).equalsIgnoreCase("01")){
          		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder.substring(0, 2)) - 1) + "12";   
          		   System.out.println("Date Period: " + datePeriod);
          	    }
          	    else{
          		   //date period greater than 1901
          		   this.datePeriod = String.valueOf(Integer.parseInt(dateFolder) - 1); 
          		   System.out.println("Date Period: " + datePeriod);
          	    }
		    }
		    
		    if(action.equalsIgnoreCase("r")){
		    //nmon rollup files < 1901
		    	query = "select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r"; 
		    	query += " where r.alt_file_name_suffix like ? and r.recordtype = f.recordtype and f.client = \'" + client + "\'"; 
		    	query += " and f.portfolio = \'" + portfolio + "\' and f.date_period < \'1901\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)";
		    	query += " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1))";
		    }
		    else{
		    //update query
		    	query = "select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, \'/\', -1)) || \'*.bz2\' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r"; 
		    	query += " where r.alt_file_name_suffix like ? and r.recordtype = f.recordtype and f.client = \'" + client + "\'"; 
		    	query += " and f.portfolio = \'" + portfolio + "\' and f.date_period = \'" + datePeriod + "\') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid)";
		    	query += " group by substr(fs.filename, 0, instr(fs.filename, \'/\', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, \'/\', -1))";
		    }
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
     * connect to rhldatdms14001 database
     * it works on rhlappfrd60005 server
     */
	public void connectDB(){
		
		 // boolean isClosed = true;
		  try{
			System.out.println("connectDB(): " + LocalDateTime.now());
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	        //conn = DriverManager.getConnection("jdbc:oracle:thin:@lux104:1521:mdwp1", "mdw", "mdw");
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms14001:1521/MDWP3.WORLD", "mdw", "mdw");  //06272019 database migrated
	        ps = conn.prepareStatement(query);
	        createPISandNMONList();
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}
		//  return isClosed;
		}
	
	/**
	 * execute query and return resultset
	 * ResultSet object is automatically closed when the 
	 * Statement object that generated it is closed, re-executed, or used 
	 * to retrieve the next result from a sequence of multiple results.
	 */
	public void executeRollingQuery(String recordtype){
		try{	
			//had to use % because used the key word "like ?" in rollupQuery statement
			ps.setString(1, recordtype + "%");
			rs = ps.executeQuery();				
		}
		catch(Exception e){e.printStackTrace();}		
	}
	
	/**
	 * fill out the pis and nmon list from resultset
	 */
	
	public void createPISandNMONList(){
		String rt = "";
		try{
			System.out.println("inside createPISandNMONList(): " + LocalDateTime.now());
			//query pis11 and pis12 files
			executeRollingQuery("pis");
			if(rs != null){
				
				while(rs.next()){
					//ResultSet starts at index 1
					rt = rs.getString(1);
					if(rt.equalsIgnoreCase("pis11")){
						
						pis11List += rs.getString(2) + ",";
					}
                    if(rt.equalsIgnoreCase("pis12")){
						
                    	pis12List += rs.getString(2) + ",";
					}
				}//end of while loop
			}//end if
			
			//query nmon11 and nmon20 files
		  	executeRollingQuery("nmon");
			if(rs != null){
				
				while(rs.next()){
					//ResultSet starts at index 1
					rt = rs.getString(1);
					if(rt.equalsIgnoreCase("nmon11")){
						
						nmon11List += rs.getString(2) + ",";
					}
                    if(rt.equalsIgnoreCase("nmon20")){
						
                    	nmon20List += rs.getString(2) + ",";
					}
				}//end of while loop
			}//end if
			
			
			//close database connection
			if(conn != null){
				
				conn.close();
				ps.close();
			}	
			//start the spark session
			createSparkSession();
			
			//make sure there are paths in pis11List or pis12List
			if(!pis11List.isEmpty()){
				pis11List = pis11List.substring(0, pis11List.lastIndexOf(","));
				System.out.println("pis11List: " + pis11List);
				transformParquet(pis11List, "pis11");
			}
			if(!pis12List.isEmpty()){
				pis12List = pis12List.substring(0, pis12List.lastIndexOf(","));
				transformParquet(pis12List, "pis12");
			}
			//make sure there are paths in nmon11List or nmon20List
			if(!nmon11List.isEmpty()){
				nmon11List = nmon11List.substring(0, nmon11List.lastIndexOf(","));
				System.out.println("nmon11List: " + nmon11List);
				transformParquet(nmon11List, "nmon11");
			}
			if(!nmon20List.isEmpty()){
				nmon20List = nmon20List.substring(0, nmon20List.lastIndexOf(","));
				transformParquet(nmon20List, "nmon20");
			}
	        //now all transformations are done, merge the datasets 
			mergeDataset();
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	public void createTestPIS(){
		try{
			System.out.println("inside createTestPIS()");
			pis11List = "/data/raw_falcon/ts2_8167-f6/debit/PIS/1512/*.bz2,/data/raw_falcon/ts2_8167-f6/debit/PIS/1604/*.bz2"; 
			nmon11List = "/data/raw_falcon/ts2_8167-f6/debit/NMON/1604/*.bz2,/data/raw_falcon/ts2_8167-f6/debit/NMON/1605/*.bz2";
			
			//start the spark session
			createSparkSession();
			
			//make sure there are paths in pis11List or pis12List
			if(!pis11List.isEmpty()){
				transformParquet(pis11List, "pis11");
			}

			//make sure there are paths in nmon11List or nmon20List
			if(!nmon11List.isEmpty()){
				transformParquet(nmon11List, "nmon11");
			}
			
			//now all transformations are done, merge the datasets 
			mergeDataset();
		}catch(Exception e){e.printStackTrace();}
	}
    
    public void createSparkSession(){
		
		try{
			/**create a spark session
			 * remember to remove .config("spark.master", "local") when 
			 * running the jar in rhlappfrd60005 (use master yarn, deploy-mode client)
			 */
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("PISRollup")
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .getOrCreate();
		  			  
		  	         //.config("spark.network.timeout", "800000") 
		  			 // .config("spark.sql.parquet.compression.codec","bzip2")
		  			  
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
			
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    public void transformParquet(String inputPaths, String recordtype){
    	try{
    		JavaRDD<Row> rdd = null;
    		System.out.println("inside transformParquet(): " + LocalDateTime.now());
    		df = spark.read()
  				  .format("text")
  				  .option("inferSchema", false)
  				  .option("header", false)
  				  .load(inputPaths.split(",")); //to load different file locations using strings
    		
    		if(recordtype.equalsIgnoreCase("pis11")){
    			rdd = mapReducePIS(df.javaRDD());    		
                pis11 = createDataSet("pis11", rdd);			
    		}
            if(recordtype.equalsIgnoreCase("pis12")){
            	rdd = mapReducePIS(df.javaRDD());    		
                pis12 = createDataSet("pis12", rdd);		
    		}
            if(recordtype.equalsIgnoreCase("nmon11")){
        		rdd = mapReduceNMON(df.javaRDD());
                nmon11 = createDataSet("pis11", rdd);
            }
            if(recordtype.equalsIgnoreCase("nmon20")){
        		rdd = mapReduceNMON(df.javaRDD());
                nmon20 = createDataSet("pis12", rdd); 			
    		}	
    	}catch(Exception e){e.printStackTrace();}
    }
    
    public void mergeDataset(){
    	Dataset<Row> pastDF = null;
    	try{
    		System.out.println("inside mergeDataset(): " + LocalDateTime.now());
            //assuming that they always send pis with nmon
            if(pis11 != null && nmon11 != null){
            	//merge pis and nmon, pis11 still contains pandatetime field
                pis11 = pis11.union(nmon11);
                System.out.println("pis11 unioned nmon11");
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/PIS11/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")));
                	pis11 = pis11.union(pastDF);
                	System.out.println("pis11 unioned " + datePeriod);
                }
                
                pis11.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
                pis11 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");
                System.out.println("created max pandatetime with inner join");
        
                //drop the pandatetime before writing it back out as another parquet file
                pis11 = pis11.drop("pandatetime");
                System.out.println("dropped pandatetime field");
                
                if(action.equalsIgnoreCase("r")){
                   pis11.coalesce(1)
                        .write()
                        .option("compression","gzip")
                        .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                        .parquet(processedOutputDir + "/PIS11/1901");
                }
                else{//update
                  pis11.coalesce(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/PIS11/" + dateFolder);
                }
                System.out.println("Completed " + processedOutputDir + "/PIS11/"+ dateFolder + " Parquet File: " + LocalDateTime.now());
            }
            
            if(pis12 != null && nmon20 != null){
            	//merge pis and nmon
            	pis12 = pis12.union(nmon20);
            	System.out.println("pis12 unioned nmon20");
                
                /** if action is update then load last months parquet file
                 * and merge to current date period dataframe
                 */
                
                if(action.equalsIgnoreCase("u")){
                	
                	pastDF = spark.read().parquet(processedOutputDir + "/PIS12/" + datePeriod + "/*.parquet");
                	//add back pandatetime field before union to current pis
                	pastDF = pastDF.withColumn("pandatetime", functions.concat(pastDF.col("pan"),pastDF.col("recordCreationDate"),pastDF.col("recordCreationTime"),pastDF.col("recordCreationMilliseconds")));
                	pis12 = pis12.union(pastDF);
                	System.out.println("pis12 unioned " + datePeriod);
                }
                             
            	pis12.createOrReplaceTempView("pis");
               
                //get the max(pandatetime) for each grouped by pan
            	pis12 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");

                //drop the pandatetime before writing it back out as another parquet file
            	pis12 = pis12.drop("pandatetime");
            	
            	if(action.equalsIgnoreCase("r")){
            	   pis12.coalesce(1)
                        .write()
                        .option("compression","gzip")
                        .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                        .parquet(processedOutputDir + "/PIS12/1901");
            	}
            	else{//update
            		pis12.coalesce(1)
                    .write()
                    .option("compression","gzip")
                    .mode("overwrite") //be careful using overwrite because spark removes all files from that directory before writing it
                    .parquet(processedOutputDir + "/PIS12/" + dateFolder);
            	}
            	System.out.println("Completed " + processedOutputDir + "/PIS12/" + dateFolder + " Parquet File: " + LocalDateTime.now());
            } 		
    	}catch(Exception e){e.printStackTrace();}  	
    }
    
	public Dataset<Row> createDataSet(String rt, JavaRDD<Row> rdd){
		Dataset<Row> ds = null;
    	List<RollingObj> fieldnames = null;
    	List<StructField> fields = null;
		try{
			System.out.println("inside createDataset(): " + LocalDateTime.now());
			 rtm = new RecordTypeMapper(rt);
		     fieldnames = rtm.getFieldInfo();
	         
	        //Store the StruckField object into a List
		    fields = new ArrayList<>();
		      
		    //create the StructFields for the Schema
		    for(int x = 0; x < fieldnames.size(); x++){
		    	  
		    	  fields.add(DataTypes.createStructField(fieldnames.get(x).fieldName, DataTypes.StringType, true));
		      }
		    
		    //create the schema
	  		schema = DataTypes.createStructType(fields);
	  		
   		  //to create an empty dataset<row> use spark.createDataFrame(new ArrayList<>(), schema)
	  		//ds = spark.createDataFrame(newRows, schema);
	  		ds = spark.createDataFrame(rdd, schema);
			//newRows.clear();
		}catch(Exception e){e.printStackTrace();}
	 	return ds;		
	}
	
	public JavaRDD<Row> mapReducePIS(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;

		System.out.println("inside mapReducePIS(): " + LocalDateTime.now());
		javaPairRdd = rdd.mapToPair(row -> {
                  //sortkey = pan
			       return new Tuple2<String, String>(row.mkString().substring(160, 179).trim(), row.mkString());
	            }).reduceByKey((v1, v2) -> {
	    			
	    			String record = "";
	    			String value1 = "";
	    			String value2 = "";
	    			//don't need the pandatefield in RecordTypeMapper class anymore 
	    			//because use it here to reduceByKey when PIS records
	    			
	    			value1 = v1.substring(160, 179).trim() + v1.substring(45, 62).trim();
	    			value2 = v2.substring(160, 179).trim() + v2.substring(45, 62).trim();
	    			//if value1 > value2 then returns positive value
	                //if value1 == value2 then returns 0
	                //if value1 < value2 then returns negative value
	    			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
	    				record = v1;  //return whole string
	    			}
	                if(value1.compareTo(value2) < 0){
	    				record = v2;
	    			}
	    			return record; 
	    		});
	    		
		   /** javaPairRdd.values().foreach(f -> {
		    	    RecordTypeMapperCSV rt = null;
		    	   // System.out.println("foreach: rt: " + f.substring(16,24).trim());
	    			rt = new RecordTypeMapperCSV(f.substring(16,24).trim());
	    			rt.setPISFieldValue(f);	
	    			//System.out.println("row: " + rt.getRow().mkString());
	                newRows.add(rt.getRow());  //this is what we care about
	                
	    		});	 **/
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
	    	   // System.out.println("foreach: rt: " + f.substring(16,24).trim());
			//f._2 = scala.Tuple2._2 or the value from Tuple2<K,V>
			//f._1 = scala.Tuple2._1 = the key from Tuple2<K,V>
 			rt = new RecordTypeMapperCSV(f._2.substring(16,24).trim());  //gets the recordtype value
 			rt.setPISFieldValue(f._2);	
			return rt.getRow();
		});
		return newJavaRDD;
	}
	
	public JavaRDD<Row> mapReduceNMON(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		System.out.println("inside mapReduceNMON(): " + LocalDateTime.now());
		javaPairRdd = rdd.mapToPair(row -> {
			
			String recordtype = row.mkString().substring(16,24).trim();
			Tuple2<String, String> tuple2 = null;

			if(recordtype.equalsIgnoreCase("nmon20")){
				if(row.mkString().substring(241, 260).trim() == null){
				  tuple2 = new Tuple2<String, String>(row.mkString().substring(350, 369).trim(), row.mkString());
				}
				else{
					tuple2 = new Tuple2<String, String>(row.mkString().substring(241, 260).trim(), row.mkString());
				}
			}
			else{  //assume nmon11
				if(row.mkString().substring(212, 231) == null){
					//System.out.println("nmon11 pan mapper: " + row.mkString().substring(737, 756));
				  tuple2 = new Tuple2<String, String>(row.mkString().substring(321, 340).trim(), row.mkString());
				}
				else{
					//System.out.println("nmon11 pan mapper: " + row.mkString().substring(628, 647));
					tuple2 = new Tuple2<String, String>(row.mkString().substring(212, 231).trim(), row.mkString());
				}
			}
			return tuple2;
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String recordtype1 = v1.substring(16,24).trim();
  			String recordtype2 = v2.substring(16,24).trim();
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			if(recordtype1.equalsIgnoreCase("nmon20")){
  				if(v1.substring(241, 260).trim() == null){
  					value1 = v1.substring(350, 369).trim() + v1.substring(160, 174).trim() + "000";
  				}
  				else{
  				   value1 = v1.substring(241, 260).trim() + v1.substring(160, 174).trim() + "000";
  				}
  			}
  			else{ //assume nmon11
  				if(v1.substring(212, 231).trim() == null){
  					value1 = v1.substring(321, 340).trim() + v1.substring(160, 174).trim() + "000";
  				}
  				else{
  				  value1 = v1.substring(212, 231).trim() + v1.substring(160, 174).trim() + "000";
  				}
  			}
  			
  			if(recordtype2.equalsIgnoreCase("nmon20")){
  				if(v2.substring(241, 260).trim() == null){
  				  value2 = v2.substring(350, 369).trim() + v2.substring(160, 174).trim() + "000";
  				}
  				else{
  					value2 = v2.substring(241, 260).trim() + v2.substring(160, 174).trim() + "000";
  				}
  			}
  			else{ //assume nmon11
  				if(v2.substring(212, 231).trim() == null){
  				  value2 = v2.substring(321, 340).trim() + v2.substring(160, 174).trim() + "000";
  				}
  				else{
  				  value2 = v2.substring(212, 231).trim() + v2.substring(160, 174).trim() + "000";
  				}
  			}
  			//if value1 > value2 then returns positive value
              //if value1 == value2 then returns 0
              //if value1 < value2 then returns negative value
  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				record = v1;  //return whole string
  			}
              if(value1.compareTo(value2) < 0){
  				record = v2;
  			}
  			return record; 
  		});
		/**javaPairRdd.values().foreach(f -> {
			RecordTypeMapperCSV rt = null;
			String recordtype = f.substring(16,24).trim();
		    if(recordtype.equalsIgnoreCase("nmon20")){
				rt = new RecordTypeMapperCSV("pis12");
				rt.setNMON20FieldValue(f);
			}
			else{  //assume nmon11
				rt = new RecordTypeMapperCSV("pis11");
				rt.setNMON11FieldValue(f);
			}
            newRows.add(rt.getRow());  //this is all we need to create dataframe
		}); **/
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
			String recordtype = f._2.substring(16,24).trim();
		    if(recordtype.equalsIgnoreCase("nmon20")){
				rt = new RecordTypeMapperCSV("pis12");
				rt.setNMON20FieldValue(f._2);
			}
			else{  //assume nmon11
				rt = new RecordTypeMapperCSV("pis11");
				rt.setNMON11FieldValue(f._2);
			}
            return rt.getRow();  //this is all we need to create dataframe
		});  
		return newJavaRDD;
	}

}
