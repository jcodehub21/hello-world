import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.text.SimpleDateFormat;
import java.time.Instant;
//import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Comparator;

/**
 * 05/28/2025 - This class will remove CSV files at /ptoan/adapt5/<client>/incoming/csv that are 
 * 3 months old after the client group processing
 * /ptoan/adapt5/FDR-Monthly/YYYYMM  <-- contains the grouped processed data files
 * /ptoan/adapt5/FDR/YYYYMM
 * /ptoan/adapt5/TSYS-US/YYYYMM
 * /ptoan/adapt5/TSYS-UK/YYYYMM
 * /ptoan/adapt5/FDI/YYYYMM
 * /ptoan/adapt5/FIS-US/YYYYMM
 * 
 * java -cp .:/mdswork/prd/bin:/ptoan/dms_staging/parquet_logs TriadFileRemoval /ptoan/dms_staging/parquet_logs/triadclientlist.txt > /ptoan/dms_staging/parquet_logs/triadfileremoval06272025.log 2>&1 &
 * 
 * @author JaneCheng
 *
 */
public class TriadFileRemoval implements FilenameFilter{
	
	LocalDateTime mainDirDate = null;  //main folder date
	LocalDateTime fileLastModifiedDate = null;
	File[] dirStatus = null;
	File currentYYYYMM = null;
	File checkFile = null;
	FilenameFilter files = null; //14056685.6075.csv.gz
	long months = 4;
	SimpleDateFormat sdf = null;
	
	
	public static void main(String[] args){
		TriadFileRemoval driver = new TriadFileRemoval();
		driver.readFile(args[0]);
	}
	
	public TriadFileRemoval(){}
	
	public TriadFileRemoval(LocalDateTime maindirdate){
		this.mainDirDate = maindirdate;
		this.sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	}
	
		
	public void readFile(String filename){
		String content = "";
		//path to client eg /ptoan/adapt5/FDR-Monthly
		File clientMainDir = null;
		String dirToCheckForFileRemoval = "";
		try{
			System.out.println("List of files past 3 months and ready to delete: ");
			BufferedReader br = new BufferedReader(new FileReader(filename));
			while((content = br.readLine()) != null){
				clientMainDir = new File(content.split(",")[0]);
				dirToCheckForFileRemoval = content.split(",")[1];
				checkLatestGroupProcessing(clientMainDir, dirToCheckForFileRemoval);
			}
			br.close();
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void checkLatestGroupProcessing(File clientDir, String dirToCheckForFileRemoval){
		//most recent folder after sort		
		try{
			System.out.println("clientDir: " + clientDir);
			//get the subdirectories of client eg YYYYMM and incoming
			dirStatus = clientDir.listFiles();
			if(dirStatus.length > 0){
			  //Arrays.sort(T, Comparator.comparing(Class::method).reversed())
     		  Arrays.sort(dirStatus, Comparator.comparing(File::getPath).reversed());

     		  currentYYYYMM = checkCurrentYYYYMM(dirStatus);  // example: /ptoan/adapt5/FDR-Monthly/incoming
     		  //System.out.println("Most recent client directory found: " + currentYYYYMM);
     		  if(currentYYYYMM.isDirectory()){
     				System.out.println("Most recent client directory found: " + currentYYYYMM.getAbsolutePath());
     				 checkFile(clientDir, dirToCheckForFileRemoval);
     		  }
			}
		}catch(Exception e){e.printStackTrace();}
	}
	
	public File checkCurrentYYYYMM(File[] status){
		File result = null;
		try{
			for(int y = 0; y < status.length; y++){
				if(status[y].getName().matches("[0-9]+")){
					if(status[y].listFiles().length > 0){
						System.out.println("y: " + y + " => status[x]: " + status[y].getName());
						result = status[y].getAbsoluteFile();
						break;
					}else{
						continue;
					}
				}				
			}
		}catch(Exception e){e.printStackTrace();}
		return result;
	}
	
	public void checkFile(File clientDir, String dirToCheckForFileRemoval){
		File[] csvFiles = null;
		File csvDir = null;
		long milli = 0;
		LocalDateTime maindirectorydate = null;
		try{
			if(currentYYYYMM.listFiles().length > 0){
				    milli = currentYYYYMM.lastModified();
				    //System.out.println(currentYYYYMM + " : Modified Date: " + milli);
					//mainDirDate = LocalDate.parse(String.valueOf(currentYYYYMM.lastModified()));
				    maindirectorydate = LocalDateTime.ofInstant(Instant.ofEpochMilli(milli),ZoneId.systemDefault());
					//initialize the FilenameFilter object
					files = new TriadFileRemoval(maindirectorydate);
					csvDir = new File(dirToCheckForFileRemoval);
					csvFiles = csvDir.listFiles(files);
					for(File file : csvFiles){
						System.out.println(file.getAbsolutePath() + " (" + file.lastModified() + ") deleted");
						file.delete();
					}
                    System.out.println("Total files deleted from " + dirToCheckForFileRemoval + ": " + csvFiles.length);
				 }
		}catch(Exception e){e.printStackTrace();}	
	}

	@Override
	public boolean accept(File dir, String filename) {
		boolean result = false;
		if(filename.endsWith(".csv.gz")){
			//dir = /ptoan/adapt5/FDR-Monthly/incoming/csv
			//filename = 14056685.6075.csv.gz
			checkFile = new File(dir + "/" + filename);
			//checkFile.lastModified() required full path or else it comes out 0 => 1969-12-31
			//fileLastModifiedDate = LocalDate.parse(String.valueOf(checkFile.lastModified()));
			fileLastModifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(checkFile.lastModified()),ZoneId.of("America/Chicago"));
			//System.out.println(checkFile + " => last modified date: " + fileLastModifiedDate);
			//Date lastmodified = new Date(checkFile.lastModified());
			//System.out.println("csv modified date using Date: " + sdf.format(lastmodified));
			//System.out.println("mainDirDate modified date: " + mainDirDate);
			//check if the file is 3 months before today's date
			if(fileLastModifiedDate.isBefore(mainDirDate.minusMonths(months))){
				result = true;
			}
		}
		return result;
	}

}
