import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.LocalDateTime;

/**
 * 4/18/2022 - ADS Pan mapping for old files
 * 1. one mapper file for all record types located at /ptoan/MSG2/edward/builds/2022_US_Build/credit/ads-final-builds/pan-mapping-driver/ADS_mapper.bz2
 * 2. have to map crtran25, frd13, nmon20 and pis12
 * 
 * rhlappfrd60005:
 * spark2-submit --master yarn --deploy-mode client --driver-memory 10g --executor-memory 20g --num-executors 10 --conf spark.dynamicAllocation.enabled=false --conf spark.network.timeout=10000001 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=2g --conf spark.executor.heartbeatInterval=10000000 --class ADSDriver /home/janecheng/ADEUtilv6.jar /work/fdrMapping/2021/ads/ADS_mapper.bz2 /work/fdrMapping/spencer/FDR/mapping/adscrtran.txt /work/fdrMapping/2021/ > /apps/jyc/ads.log 2>&1 &
 * 
 * @author JaneCheng
 *
 */
public class ADSDriver implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> mapper = null;
	List<StructField> fields = null; //store the mapper file two columns
	StructType mapperSchema = null;
	StructType rtSchema = null;
	StructType textSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	Dataset<Row> inputFile = null;
	Dataset<Row> newFile = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static FileStatus[] list_files = null; 
	String pattern = "^part-.+\\.bz2$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	String dfPath = "";
	static Path newDFPath = null;
	String yymm = "";
	String recordtype = "";
	String fileid = "";
	String filePath = "";
	String hdfsMapperFile = "";
	String client = "ads";
	
	public static void main(String[] args) {
		/**
		 * args[0] = mapperfile
		 * args[1] = ads file list
		 * args[2] = main dfPath to write text file to - /work/fdrMapping/2021/
		 */
		if(args.length != 3){
			System.out.println("Please provide 3 arguments: <mapperfile> <fileList> <tempWorkDirectory>");
			System.exit(-1);
		}
		ADSDriver driver = new ADSDriver(args[0], args[2]);
        driver.startSparkSession();
        driver.readList(args[1]);
	}
	
	public ADSDriver(String mapper, String dfpath){
		hdfsMapperFile = mapper;
		dfPath = dfpath;
	}
	
	public void readList(String fdrlist){
		String content = "";		
		try{
			loadMapperFile();
			BufferedReader brMain = new BufferedReader(new InputStreamReader(fs.open(new Path(fdrlist))));
			while((content = brMain.readLine()) != null){
				   setArgs("file://" + content);
				   loadFile();
			   }
			   if(brMain != null){brMain.close();}
			
		}catch(Exception e){e.printStackTrace();}	
	}
	
	public void setArgs(String filename){
		this.filePath = filename;
	    System.out.println("original filePath: " + filePath);
	    String[] metadata = filePath.substring(filePath.lastIndexOf("/") + 1).split("\\.");
	    this.yymm = metadata[0];
	    this.recordtype = metadata[3];
	    this.fileid = metadata[4]; 
	}
	
    public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("ADS Pan Mapper")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("WARN");
		
		//mapper fields and schema is fixed so only need to define once
		// Store the StruckField object into a List
		fields = new ArrayList<>();			
		fields.add(DataTypes.createStructField("oldPan", DataTypes.StringType, true));
	    fields.add(DataTypes.createStructField("newPan", DataTypes.StringType, true));
					
		//create the schema for the mapper file
	    mapperSchema = DataTypes.createStructType(fields);
 
		 //Text data source supports only a single column, and you have 3 columns.
		//create the schema for the new text file
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		
		try{
		     conf = new Configuration();
		     fs = FileSystem.get(conf);
		}catch(Exception e){e.printStackTrace();}
	}

    //loadMapperFile only loads the mapper file with different locations
	public void loadMapperFile(){
		mapper = spark.read()
				      .format("csv")
				      .schema(mapperSchema)
				      .option("delimiter", "!")  //using ! delimiter to separate the data so don't need to create FieldObj
				      .option("header", "false")
				      .load(hdfsMapperFile);
		System.out.println("Load mapper file complete: " + hdfsMapperFile + " : " + LocalDateTime.now());
	}
	
	public void loadFile(){
		//load the record type schema
		fieldObj = ClientRecordType.getADSRecordTypeMapper(recordtype);
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
		}
		
		rtSchema = DataTypes.createStructType(fields);
		   
		   try{
			   inputFile = spark.read()
				      .format("text")
				      .option("inferSchema", false)
				      .option("header", "false")
				      .load(filePath);  //on rhldmsprd001;  remember to use file:// on input file if on BP cluster
		   
		   System.out.println("Load " + recordtype + " file complete: " + filePath);
		   /**
		    * Encoder.String() returns Dataset<String>
		    * RowEncoder.apply(StructType schema) returns Dataset<Row>
		    * MapFunction<Input, Output>
		    */
		   inputFile = inputFile.map((MapFunction<Row, Row>) row -> {
			   fieldObj.setFieldValueADS(row.mkString());
			   return fieldObj.getRow();
		   }, RowEncoder.apply(rtSchema)); //applies the schema to the row so dataset will know it is for row
		   
		   
		   /**use dataframe left join to get all rows from sfx and also include only rows from mapper that 
		    * sfx pan == mapper pan
		    * and then replace the null values under newPan column with sfx pan column using
		    * functions.when() <- make sure that you import org.apache.spark.sql.functions 
		    * If you use just when() then java will not recognize the function, must use 
		    * functions.when(); there is also functions.otherwise() condition
		    */
		   
		   newFile = inputFile.join(mapper, inputFile.col("pan").equalTo(mapper.col("oldPan")), "left");
		   //newsfx.show(20, false);
		   newFile = newFile.select(newFile.col("filler1"),
				   newFile.col("pan"),
				   newFile.col("filler2"),
				   newFile.col(fieldObj.getFieldObj(3).fieldName),  //can be userData or expandedBIN
				   newFile.col("filler3"),
				   newFile.col("newPan"),
				   functions.when(newFile.col("newPan").isNull(),newFile.col("pan"))  //replace newPan with pan if newpan is null
				   .otherwise(newFile.col("newPan")).alias("newPanNoNull"));  //otherwise keep newPan value as is and be under new column called newPanNoNUll
				       
		 
		   System.out.println("Joined and dropped old pans and inserted new pans no nulls");
		   /**drop the original pan and newPan columns and then renamed the newPanNoNull to pan
		    * this produces the dataframe column order of filler1, filler2, pan which is the wrong order
		   **/
		   newFile = newFile.drop("pan").drop("newPan").withColumnRenamed("newPanNoNull", "pan");
		   
		   //have to reselect the columns to be in the correct order:  filler1, pan, filler2 so can be written out to text file
		   newFile = newFile.select(newFile.col("filler1"), newFile.col("pan"), newFile.col("filler2"),newFile.col(fieldObj.getFieldObj(3).fieldName),newFile.col("filler3"));
		   
		   //convert back from three columns to one column so can write in text file
		   newFile = newFile.map(row -> {
				  return RowFactory.create(row.mkString());				  
			  }, RowEncoder.apply(textSchema));
	  
			  //df.coalesce(1).write.option("compression","gzip").format("text").save("/path/to/save")
		   
		   //delete if /hdfsTA/work/fdrMapping/2021/mapped exists
		   newDFPath = new Path(dfPath + client + "/" + recordtype + "/" + yymm + "/" + fileid + "/");
		   if(fs.exists(newDFPath))
	    	{
	    		fs.delete(newDFPath, true);
	    	}
		   
		   System.out.println("Start writing text file " + LocalDateTime.now());
		   //write back out as text file
		   newFile.repartition(1) //repartition(1) works better than coalesce(1); coalesce(1) gave sparkOutOfMemory error even with small files
			            .write()
			            .format("text")
			            .option("compression", "bzip2")  //.option("compression","bzip2")
			            .mode("overwrite")
			            .save(newDFPath.toString());
		   
			  System.out.println("finished writing text file " + LocalDateTime.now());
			  // Create a Pattern object
	  		  filePattern = Pattern.compile(pattern);
	  		    
	  		  list_files = fs.listStatus(newDFPath);
              for(FileStatus oldFilePath : list_files){
		    	
    	           m = filePattern.matcher(oldFilePath.getPath().getName());
    	           if(m.matches()){
    	        	   //fs.rename also moved the new filename to another path
    	        	   if(fs.rename(oldFilePath.getPath(), new Path(dfPath + client + "/" + recordtype + "/" + yymm + "/" + filePath.substring(filePath.lastIndexOf("/") + 1)))){
	    	        		  fs.delete(new Path(dfPath + client + "/" + recordtype + "/" + yymm + "/" + fileid), true);
	    	        		  System.out.println("renamed " + oldFilePath.getPath() + " back to " + dfPath + client + "/" + recordtype + "/" + yymm + "/" + filePath.substring(filePath.lastIndexOf("/") + 1) + " : " + LocalDateTime.now());  
    	        	   }
    	           }
    	        }
		   }catch(Exception e){e.printStackTrace();}
		   
	   }
	
	public void closeAll(){
		try{
			if(fs != null){
				fs.close();
			}
		}catch(Exception e){e.printStackTrace();}
	}

}
