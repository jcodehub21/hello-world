package org.jc;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.io.FilenameUtils;

import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

//https://stackoverflow.com/questions/6780678/run-class-in-jar-file
public class TDBANKUtil {

    public static void main(String[] args){
        //JsonUtil driver = new JsonUtil();
       // driver.readJSONL(CommonUtil.untar(args[0]), args[1]);
        TDBANKUtil driver = new TDBANKUtil();
        driver.testTarArchiveEntry(args[0], args[1]);
    }

    public void test(){
        JsonUtil driver = new JsonUtil();
        // driver.readJSONL(CommonUtil.untar(args[0]), args[1]);
        List<String> keyNames = new ArrayList<>();
        keyNames.add("customerIdFromHeader");
        keyNames.add("customerAcctNumber");
        keyNames.add("externalTransactionId");
        String jsonString = "{\"inputs\":{\"transactionDecision\":{\"type\":\"defaulttermlibrary.TransactionDecision\",\"data\":{\"header\":{\"customerIdFromHeader\":\"0040785086011\",\"customerAcctNumber\":\"09999-5086011\",\"externalTransactionId\":\"004078508601120250303135443037N110001\"}}}}}";
        //String encryptedString = CommonUtil.hashp2fieldv2(jsonString, keyNames);
        driver.readJSONLWindows(jsonString);
        //System.out.println("Encrypted: " + CommonUtil.hashp2fieldv2(jsonString, keyNames));
        //driver.readJSONLWindows(jsonString, "inputs.transactionDecision.data.header.customerIdFromHeader");
    }

    public void testTarArchiveEntry(String tarFileName, String keyFileName){
        JsonUtil jsonUtil = new JsonUtil();
        BufferedReader br = null;
        String tarChileFile = "";
        String content = "";
        try{
            /**
             * below works for Reading POSIX tar archive (GNU) on RHEL 8
             * rhldmsprd002-45001:/mdswork/prd/TEMP_LANDINGZONE/TDBANK/TestData > java -cp .:/mdswork/prd/TEMP_LANDINGZONE/TDBANK/TestData/TDBANKProcess-1.0-SNAPSHOT.jar org.jc.TDBANKUtil ade_TRANSACTION-CAD-EXT-TDBANK-35607-STG_auto_20250304_100037_split_file_0_1_2 tdbank_fields_need_hashing.txt > /mdswork/prd/TEMP_LANDINGZONE/TDBANK/TestData/test.log 2>&1 &
             */
            jsonUtil.setKeyFieldNames(new File(tarFileName).getAbsolutePath(), keyFileName);
            InputStream fileInputStream = Files.newInputStream(new File(tarFileName).toPath());
            BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
            TarArchiveInputStream tarArchiveInputStream = new TarArchiveInputStream(bufferedInputStream);
            //read directly from tar archive file; it works on RHEL
            br = new BufferedReader(new InputStreamReader(tarArchiveInputStream));
            TarArchiveEntry entry;
            while ((entry = tarArchiveInputStream.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    System.out.println("Directory: " + entry.getName());
                } else {
                    tarChileFile = entry.getName();
                    System.out.println("Untar Child File: " + tarChileFile);
                    if(tarChileFile.endsWith(".jsonl")){
                        //br.readLine() works on RHEL; skip the first two header row
                        br.readLine();
                        br.readLine();
                        while((content = br.readLine()) != null){
                            jsonUtil.readJSONL(content);
                        }
                        //jsonUtil.readJSONL(br.readLine());  //test the third line
                    }
                    // Process the file content if needed
                    // byte[] content = new byte[(int) entry.getSize()];
                    // tarArchiveInputStream.read(content, 0, (int) entry.getSize());
                }
            }
            jsonUtil.closeAll();
            br.close();
        }catch(Exception e){e.printStackTrace();}
    }
}
