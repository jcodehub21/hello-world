import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
//import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.LocalDateTime;

/**
 * 09/17/2021 This class will replace old pans with new pans
 * using Spencer's mapping file for AKBANK-F6 (none) CRTRAN, DBTRAN, FRD, NMON and PIS
 * PIS pan bytes 241:259
 * NMON pan bytes 322:340
 * CRTRAN pan bytes 241:259
 * DBTRAN pan bytes 241:259
 * FRD pan bytes 241:259
 * @author JaneCheng
 *
 */

public class AKBANKPanDriver implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> mapper = null; 
	Dataset<Row> dataFile = null;
	Dataset<Row> newDataFile = null;
	String yymm = ""; //date period to fix
	String fileid = "";
	String recordtype = "";
	String hdfsMapString = "";
	String mapperFile = "";
	String filePath = "";
	List<StructField> fields = null; //store the mapper file two columns
	StructType mapperSchema = null;
	StructType rtSchema = null;
	StructType textSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	static BufferedReader br = null;
	static BufferedWriter bw = null;
	static BufferedWriter bwFile = null;
	static File file = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static FileStatus[] list_files = null; 
	String pattern = "^part-.+\\.bz2$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	String dfPath = "";  //lux432 temporary work area = /Anton/jyc_temp/akbank-f6/none/
	String tempSparkDir = "";
	static Path newDFPath = null;
	static Path temp = null;
	String processedDate = "";
	String databaseFile = "";
	
	public static void main(String[] args){
		/**
		 * args[0] = mapper file location
		 * args[1] = list of akbank files
		 * args[2] = temp work area for files /Anton/jyc_temp/akbank-f6/none/ on lux432
		 * args[3] = temp spark folders (needs to enter path or null); /ana/mds/prd/data/files/INCOMING/temp
		 * args[4] = date of processing for the manual_changes table eg. '2021-10-03' 'YYYY-MM-DD'
		 * args[5] = database file to write update and insert SQL statements
		 */
		String content = "";
		try{
		   AKBANKPanDriver driver = new AKBANKPanDriver(args[0], args[2], args[3], args[4], args[5]);
		   driver.startSparkSession();
		   driver.loadMapperFile();
		   BufferedReader brMain = new BufferedReader(new FileReader(args[1]));
		   while((content = brMain.readLine()) != null){
			   driver.setArgs(content);
		   }
		   if(brMain != null){brMain.close();}
		   driver.closeBWFile();
		  // driver.deleteSparkTempDir();
		}catch(Exception e){e.printStackTrace();}
	}
	
	public AKBANKPanDriver(String mapperFile, String dfPath, String temp, String date, String dbFile){
		this.mapperFile = mapperFile;
		this.dfPath = dfPath;
		tempSparkDir = temp;
		processedDate = date;
		databaseFile = dbFile;
	}
	
	public void setArgs(String filename){
      this.filePath = filename;
      System.out.println("original filePath: " + filePath);
      String[] metadata = filePath.substring(filePath.lastIndexOf("/") + 1).split("\\.");
      this.yymm = metadata[0];
      this.recordtype = metadata[3];
      this.fileid = metadata[4];
      processDataFile();
	}
	
	public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("AKBANK-F6 Pan Mapper")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("ERROR");
		
		//mapper fields and schema is fixed so only need to define once
		// Store the StruckField object into a List
		fields = new ArrayList<>();			
		fields.add(DataTypes.createStructField("oldPan", DataTypes.StringType, true));
	    fields.add(DataTypes.createStructField("newPan", DataTypes.StringType, true));
					
		//create the schema for the mapper
	    mapperSchema = DataTypes.createStructType(fields);
 
		 //Text data source supports only a single column, and you have 3 columns.
		//create the schema for the new text file
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		
		try{
		 conf = new Configuration();
	     fs = FileSystem.get(conf);
	     
	     //12/17/2021 commented the below part out because might be causing issues
	     /**if(!tempSparkDir.equalsIgnoreCase("null")){
	         temp = new Path(tempSparkDir);
			   if(!fs.exists(temp)){
				 fs.mkdirs(temp);  //create an empty one
			   }
	     }**/
		}catch(Exception e){e.printStackTrace();}
	}
	
	//loadMapperFile only loads the mapper file with different locations
	public void loadMapperFile(){
		/**
		 * Need to use csv format in order for spark to read 
		 * the ! delimiter; 
		 * Using text format only gives one column called value 
		 * and will throw an error if used with delimiter and schema
		 */
		mapper = spark.read()
				      .format("csv")
				      .schema(mapperSchema)
				      .option("delimiter", " ")  //using space delimiter to separate the data so don't need to create FieldObj
				      .option("header", "false")
				      .load(mapperFile);
		System.out.println("Load mapper file " + mapperFile +  " complete");
		try{
		  bwFile = new BufferedWriter(new FileWriter(dfPath + databaseFile, true));
		}catch(Exception e){e.printStackTrace();}
	}

	//load the original data file
	public void processDataFile(){

		try{
			
			//load the record type schema
			fieldObj = ClientRecordType.getAkbankRecordTypeMapper(recordtype);
			fields = new ArrayList<>();	
			for(FieldObj f : fieldObj.getFieldObjList()){
				
				fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
			}
			rtSchema = DataTypes.createStructType(fields);

		     
		     //create directory for csv 
		     if(fs.exists(new Path(dfPath + recordtype + "/" + yymm + "/" + fileid + "/"))){
		    	 fs.delete(new Path(dfPath + recordtype + "/" + yymm + "/" + fileid + "/"), true);
		     }
		     fs.mkdirs(new Path(dfPath + recordtype + "/" + yymm + "/" + fileid + "/"));
		     
		     //newDFPath = new Path("/Anton/jyc_temp/akbank-f6/none/"); //lux432
		     newDFPath = new Path(dfPath + recordtype + "/" + yymm + "/" + fileid + "/temp/");
		     
			   if(fs.exists(newDFPath))
		    	{
		    		fs.delete(newDFPath, true);
		    	}
			
			//create csv file in case 
			String content;
			String csvFile;
			   if(filePath.endsWith(".bz2")){
				   br = new BufferedReader(new InputStreamReader(new BZip2CompressorInputStream(new FileInputStream(filePath))));
				   csvFile = dfPath + recordtype + "/" + yymm + "/" + fileid + "/" + filePath.substring(filePath.lastIndexOf("/") + 1, filePath.lastIndexOf(".bz2")) + ".csv";
				   bw = new BufferedWriter(new FileWriter(csvFile));
			   }else if(filePath.endsWith(".gz")){
				   br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(filePath))));
				   csvFile = dfPath + recordtype + "/" + yymm + "/" + fileid + "/" + filePath.substring(filePath.lastIndexOf("/") + 1, filePath.lastIndexOf(".gz")) + ".csv";
				   bw = new BufferedWriter(new FileWriter(csvFile));
			   }else{  //plain ascii file or other
				   br = new BufferedReader(new FileReader(filePath));
				   csvFile = dfPath + recordtype + "/" + yymm + "/" + fileid + "/" + filePath.substring(filePath.lastIndexOf("/") + 1) + ".csv";
				   bw = new BufferedWriter(new FileWriter(csvFile));
			   }
			   
			  // br = new BufferedReader(new FileReader("C:\\software\\Andrew_Manual_report\\mastercard-multi-f6\\none\\DBTRAN_Auth\\2003\\2003.mastercard-single-f6.none.dbtran25_Auths.7974714.2130.ascii"));
			   while((content = br.readLine()) != null){
				   //content = content.replace('\u00ef', ' ').replace('\u00bf', ' ').replace('\u00bd', ' ');  //have to replaced up here in new csv
				   content = content.replace("\uFFFD", " "); //changed on 10/15/2021 to fix pis 1601 files
				   fieldObj.setFieldValue(content);
				   bw.write(fieldObj.toString());
				   bw.newLine();
			   }
			   br.close();
			   bw.close();
			System.out.println("created CSV file: " + csvFile);
			
			//read in csv file
			/**dataFile = spark.read()
				      .format("text")
				      .option("inferSchema", false)
				      .option("header", "false")
				      .load(filePath);  // remember to use file:// if on BP cluster
				      **/
			   dataFile = spark.read()
					      .format("csv")
					      .schema(rtSchema)
					      .option("delimiter", "\t")
					      .option("header", "false")
					      .load(csvFile);
		   
		   System.out.println("Load data file " + csvFile + " complete");
		   
		  /** dataFile = dataFile.map((MapFunction<Row, Row>) row -> {
			   fieldObj.setFieldValue(row.mkString());
			   return fieldObj.getRow();
		   }, RowEncoder.apply(rtSchema)); //applies the schema to the row so dataset will know it is for row
			**/
		   newDataFile = dataFile.join(mapper, dataFile.col("pan").equalTo(mapper.col("oldPan")), "left");
		   //newsfx.show(20, false);
		   newDataFile = newDataFile.select(newDataFile.col("filler1"),
				   newDataFile.col("pan"),
				   newDataFile.col("filler2"),
				   newDataFile.col("newPan"),
				       functions.when(newDataFile.col("newPan").isNull(),newDataFile.col("pan"))  //replace newPan with pan if newpan is null and be under new column called newPanNoNUll
				       .otherwise(newDataFile.col("newPan")).alias("newPanNoNull"));  //otherwise keep newPan value as is and be under new column called newPanNoNUll
		 
		   System.out.println("Joined and dropped old pans and inserted new pans no nulls");
		   /**drop the original pan and newPan columns and then renamed the newPanNoNull to pan
		    * this produces the dataframe column order of filler1, filler2, pan which is the wrong order
		   **/
		   newDataFile = newDataFile.drop("pan").drop("newPan").withColumnRenamed("newPanNoNull", "pan");
		   
		   //have to reselect the columns to be in the correct order:  filler1, pan, filler2 so can be written out to text file
		   newDataFile = newDataFile.select(newDataFile.col("filler1"), newDataFile.col("pan"), newDataFile.col("filler2"));
		   
		   //convert back from three columns to one column so can write in text file
		   newDataFile = newDataFile.map(row -> {
				  return RowFactory.create(row.mkString());				  
			  }, RowEncoder.apply(textSchema));
			   
			   System.out.println("Start writing text file to " + newDFPath + " : " + LocalDateTime.now());
			   //write back out as text file
			   newDataFile.coalesce(1)
				            .write()
				            .format("text")
				            .option("compression", "bzip2")  //.option("compression","bzip2")
				            .mode("overwrite")
				            .save(newDFPath.toString());
			   
				  System.out.println("finished writing text file to " + newDFPath + " : " + LocalDateTime.now());
				  
				  //change the new text file name back to original filename
				// Create a Pattern object
		  		  filePattern = Pattern.compile(pattern);
		  		    
		  		  list_files = fs.listStatus(newDFPath);
		  		  
		  		for(FileStatus oldFilePath : list_files){
			    	
	    	           m = filePattern.matcher(oldFilePath.getPath().getName());
	    	           if(m.matches()){
	    	        	   //fs.rename also moved the new filename to another path
	    	        	   //System.out.println("Rename result: " + fs.rename(oldFilePath.getPath(), new Path(filePath)));
	    	        	   if(FileUtil.copy(fs,oldFilePath.getPath(),fs,new Path(filePath),false,true,conf)){
	    	        		  fs.delete(new Path(dfPath + recordtype + "/" + yymm + "/" + fileid), true);
	    	        		  file = new File(filePath);
	    	        		  bwFile.write("update filestorage set filesize = " + file.length() + " where fileid = " + fileid + " and filestatus = 'O' and filetype = 'O';");
	    	        		  bwFile.newLine();
	    	        		  bwFile.write("insert into manual_changes values ('" + fileid + "', DATE '" + processedDate + "', 'akbank-f6(none) pan mapping', 'JaneCheng');");
	    	        		  bwFile.newLine();
	    	        		   System.out.println("mapped and moved " + oldFilePath.getPath() + " back to " + filePath);  
	    	        	   }
	    	        	   
	    	           }
	    	        }	  				   
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void closeBWFile(){
		try{
			if(bwFile != null){
				bwFile.close();
			}		
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**public void stopSparkSession(){
		if(spark != null){
			spark.close();
		}
	}**/

}
