package org.jc

object ScalaLogger {

  def main(args: Array[String]): Unit = {

    println()
  }

}
