import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions; //have to use functions.concat()
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

//if put static here then you can just type concat() instead of functions.concat()
//import static org.apache.spark.sql.functions.*;  

import scala.Tuple2;


public class RollingPISWindows implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	static List<Row> newRows = new ArrayList<>();
	RecordTypeMapper rtm = null;
	StructType schema = null;
	Dataset<Row> df = null;
	Dataset<Row> pis11 = null;
	Dataset<Row> nmon11 = null;
	
	public static void main(String[] args){

		RollingPISWindows test = new RollingPISWindows();
		test.createSparkSession();
		test.readParquet();
	}
	
	public RollingPISWindows(){}
	
    public void createSparkSession(){
		
		try{
			//create a spark session
		  	  spark = SparkSession
		  			  .builder()
		  			  .appName("PISRollup")
		  			  .config("spark.master", "local")  //only used on Eclipse
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
		  			  .getOrCreate();
		  			  
		  	         //.config("spark.network.timeout", "800000") 
		  			 // .config("spark.sql.parquet.compression.codec","bzip2")
		  			  
		  	  
		  	// Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
			
		}
		catch(Exception e){e.printStackTrace();}	
	}
    
    public void readParquet(){
    	 
    	JavaRDD<Row> rdd = null;   	
    	
    	try{
    		String inputpath = "C:\\software\\RollingPIS\\ts2_8167-f6.debit.PIS.20160419.3755096.bz2,C:\\software\\RollingPIS\\ts2_8167-f6.debit.PIS.20160420.3758243.bz2";
  
    		//pis files
    		df = spark.read()
    				  .format("text")
    				  .option("inferSchema", false)
    				  .option("header", false)
    				 // .load("C:\\software\\RollingPIS\\ts2_8167-f6.debit.PIS.20160419.3755096.bz2");
    				  .load(inputpath.split(",")); //to load different file locations using strings
  
    		//df.javaRDD() returns JavaRDD<Row>;    		
    		rdd = mapReducePIS2(df.javaRDD());    		
            pis11 = createDataSet("pis11", rdd);
	  		//pis.select("pan", "recordCreationDate", "recordCreationTime", "recordCreationMilliseconds", "subType", "cardholderCountryCode", "status", "pandatetime").orderBy("pan").show(20, false);
	  		
	  		//nmon files
	  		df = spark.read()
	  				.format("text")
  				    .option("inferSchema", false)
  				    .option("header", false)
	  				.load("C:\\software\\RollingPIS\\ts2_8167-f6.debit.NMON.20160430.3770649.bz2");
    		rdd = mapReduceNMON2(df.javaRDD());
            nmon11 = createDataSet("pis11", rdd);
           // nmon.select("pan", "recordCreationDate", "recordCreationTime", "recordCreationMilliseconds", "subType", "cardholderCountryCode", "status", "pandatetime").orderBy("pan").show(10, false);
            
            //merge pis and nmon
            pis11 = pis11.union(nmon11);
            pis11.createOrReplaceTempView("pis");
           
            //get the max(pandatetime) for each grouped by pan
            pis11 = spark.sql("SELECT a.* FROM pis a INNER JOIN (SELECT pan, MAX(pandatetime) maxpdt FROM pis GROUP BY pan) b ON a.pan = b.pan AND a.pandatetime = b.maxpdt");
            //pis.select("pan", "recordCreationDate", "recordCreationTime", "recordCreationMilliseconds", "subType", "cardholderCountryCode", "status", "pandatetime").where("pan == '431947VpVWmoOKOCELW'").show(20, false);
            pis11.select("pan", "recordCreationDate", "recordCreationTime", "recordCreationMilliseconds", "subType", "cardholderCountryCode", "status", "pandatetime").orderBy("pan").show(5, false);
            //drop the pandatetime before writing it back out as another parquet file
            pis11 = pis11.drop("pandatetime");
            //pis.show(2, false); **/
            
            /**
             * You need to import functions class (or rather, static methods of it) in your class in order to achieve it
             * import static org.apache.spark.sql.functions.*;
             * Dataset<Row> data = //get data
             * data.withColumn("new_Column", concat(data.col("col1"), lit("_"), data.col("col2")));
             */
            pis11 = pis11.withColumn("pandatetime", functions.concat(pis11.col("pan"),pis11.col("recordCreationDate"),pis11.col("recordCreationTime"),pis11.col("recordCreationMilliseconds")));
            pis11.select("pan", "recordCreationDate", "recordCreationTime", "recordCreationMilliseconds", "subType", "cardholderCountryCode", "status", "pandatetime").orderBy("pan").show(5, false);
            /**remember that after merging pis and nmon, the record length is different for 
             * each row when trying to mapToPair for JavaPairRDD<String, String>
             **/
            
           // pis.coalesce(1)
             //  .write()
             //  .option("compression","gzip")
              // .mode("overwrite") be careful using overwrite because spark removes all files from that directory before writing it
              // .parquet("C:\\software\\RollingPIS\\test\\");
   		  		
    	}catch(Exception e){e.printStackTrace();}
    }
    
	public Dataset<Row> createDataSet(String rt, JavaRDD<Row> rdd){
		Dataset<Row> ds = null;
    	List<RollingObj> fieldnames = null;
    	List<StructField> fields = null;
		try{
			 rtm = new RecordTypeMapper(rt);
		     fieldnames = rtm.getFieldInfo();
	         
	        //Store the StruckField object into a List
		    fields = new ArrayList<>();
		      
		    //create the StructFields for the Schema
		    for(int x = 0; x < fieldnames.size(); x++){
		    	  
		    	  fields.add(DataTypes.createStructField(fieldnames.get(x).fieldName, DataTypes.StringType, true));
		      }
		    
		    //create the schema
	  		schema = DataTypes.createStructType(fields);
	  		
   		  //to create an empty dataset<row> use spark.createDataFrame(new ArrayList<>(), schema)
	  		//ds = spark.createDataFrame(newRows, schema);
	  		ds = spark.createDataFrame(rdd, schema);  //createDataFrame(JavaRDD<Row>, schema)
			newRows.clear();
		}catch(Exception e){e.printStackTrace();}
	 	return ds;		
	}
	
	public void mapReducePIS(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		/**rdd.foreach(f -> {
			
			System.out.println(f.mkString());
		});**/
		javaPairRdd = rdd.mapToPair(row -> {
                  //sortkey = pan
			       return new Tuple2<String, String>(row.mkString().substring(160, 179).trim(), row.mkString());
	            }).reduceByKey((v1, v2) -> {
	    			
	    			String record = "";
	    			String value1 = "";
	    			String value2 = "";
	    			//don't need the pandatefield in RecordTypeMapper class anymore 
	    			//because use it here to reduceByKey when PIS records
	    			
	    			value1 = v1.substring(160, 179).trim() + v1.substring(45, 62).trim();
	    			value2 = v2.substring(160, 179).trim() + v2.substring(45, 62).trim();
	    			//if value1 > value2 then returns positive value
	                //if value1 == value2 then returns 0
	                //if value1 < value2 then returns negative value
	    			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
	    				record = v1;  //return whole string
	    			}
	                if(value1.compareTo(value2) < 0){
	    				record = v2;
	    			}
	    			return record; 
	    		});
	    		
		    javaPairRdd.values().foreach(f -> {
		    	    RecordTypeMapperCSV rt = null;
	    			rt = new RecordTypeMapperCSV(f.substring(16,24).trim());
	    			rt.setPISFieldValue(f);		
	                newRows.add(rt.getRow());  //this is what we care about
	    		});
	}
	
	public JavaRDD<Row> mapReducePIS2(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		/**rdd.foreach(f -> {
			
			System.out.println(f.mkString());
		});**/
		javaPairRdd = rdd.mapToPair(row -> {
                  //sortkey = pan
			       return new Tuple2<String, String>(row.mkString().substring(160, 179).trim(), row.mkString());
	            }).reduceByKey((v1, v2) -> {
	    			
	    			String record = "";
	    			String value1 = "";
	    			String value2 = "";
	    			//don't need the pandatefield in RecordTypeMapper class anymore 
	    			//because use it here to reduceByKey when PIS records
	    			
	    			value1 = v1.substring(160, 179).trim() + v1.substring(45, 62).trim();
	    			value2 = v2.substring(160, 179).trim() + v2.substring(45, 62).trim();
	    			//if value1 > value2 then returns positive value
	                //if value1 == value2 then returns 0
	                //if value1 < value2 then returns negative value
	    			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
	    				record = v1;  //return whole string
	    			}
	                if(value1.compareTo(value2) < 0){
	    				record = v2;
	    			}
	    			return record; 
	    		});
	    		
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
	    	   // System.out.println("foreach: rt: " + f.substring(16,24).trim());
 			rt = new RecordTypeMapperCSV(f._2.substring(16,24).trim());
 			rt.setPISFieldValue(f._2);	
			return rt.getRow();
		});
		return newJavaRDD;
	}
	
	public void mapReduceNMON(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		javaPairRdd = rdd.mapToPair(row -> {
			
			String recordtype = row.mkString().substring(16,24).trim();
			Tuple2<String, String> tuple2 = null;

			if(recordtype.equalsIgnoreCase("nmon20")){
				if(row.mkString().substring(241, 260).trim() == null){
				  tuple2 = new Tuple2<String, String>(row.mkString().substring(350, 369).trim(), row.mkString());
				}
				else{
					tuple2 = new Tuple2<String, String>(row.mkString().substring(241, 260).trim(), row.mkString());
				}
			}
			else{  //assume nmon11
				if(row.mkString().substring(212, 231) == null){
					//System.out.println("nmon11 pan mapper: " + row.mkString().substring(737, 756));
				  tuple2 = new Tuple2<String, String>(row.mkString().substring(321, 340).trim(), row.mkString());
				}
				else{
					//System.out.println("nmon11 pan mapper: " + row.mkString().substring(628, 647));
					tuple2 = new Tuple2<String, String>(row.mkString().substring(212, 231).trim(), row.mkString());
				}
			}
			return tuple2;
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String recordtype1 = v1.substring(16,24).trim();
  			String recordtype2 = v2.substring(16,24).trim();
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			if(recordtype1.equalsIgnoreCase("nmon20")){
  				if(v1.substring(241, 260).trim() == null){
  					value1 = v1.substring(350, 369).trim() + v1.substring(160, 174).trim() + "000";
  				}
  				else{
  				   value1 = v1.substring(241, 260).trim() + v1.substring(160, 174).trim() + "000";
  				}
  			}
  			else{ //assume nmon11
  				if(v1.substring(212, 231).trim() == null){
  					value1 = v1.substring(321, 340).trim() + v1.substring(160, 174).trim() + "000";
  				}
  				else{
  				  value1 = v1.substring(212, 231).trim() + v1.substring(160, 174).trim() + "000";
  				}
  			}
  			
  			if(recordtype2.equalsIgnoreCase("nmon20")){
  				if(v2.substring(241, 260).trim() == null){
  				  value2 = v2.substring(350, 369).trim() + v2.substring(160, 174).trim() + "000";
  				}
  				else{
  					value2 = v2.substring(241, 260).trim() + v2.substring(160, 174).trim() + "000";
  				}
  			}
  			else{ //assume nmon11
  				if(v2.substring(212, 231).trim() == null){
  				  value2 = v2.substring(321, 340).trim() + v2.substring(160, 174).trim() + "000";
  				}
  				else{
  				  value2 = v2.substring(212, 231).trim() + v2.substring(160, 174).trim() + "000";
  				}
  			}
  			//if value1 > value2 then returns positive value
              //if value1 == value2 then returns 0
              //if value1 < value2 then returns negative value
  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				record = v1;  //return whole string
  			}
              if(value1.compareTo(value2) < 0){
  				record = v2;
  			}
  			return record; 
  		});
		javaPairRdd.values().foreach(f -> {
			RecordTypeMapperCSV rt = null;
			String recordtype = f.substring(16,24).trim();
		    if(recordtype.equalsIgnoreCase("nmon20")){
				rt = new RecordTypeMapperCSV("pis12");
				rt.setNMON20FieldValue(f);
			}
			else{  //assume nmon11
				rt = new RecordTypeMapperCSV("pis11");
				rt.setNMON11FieldValue(f);
			}
            newRows.add(rt.getRow());  //this is all we need to create dataframe
		});  
	}
	
	public JavaRDD<Row> mapReduceNMON2(JavaRDD<Row> rdd){
		JavaPairRDD<String, String> javaPairRdd = null;
		JavaRDD<Row> newJavaRDD = null;
		javaPairRdd = rdd.mapToPair(row -> {
			
			String recordtype = row.mkString().substring(16,24).trim();
			Tuple2<String, String> tuple2 = null;

			if(recordtype.equalsIgnoreCase("nmon20")){
				if(row.mkString().substring(241, 260).trim() == null){
				  tuple2 = new Tuple2<String, String>(row.mkString().substring(350, 369).trim(), row.mkString());
				}
				else{
					tuple2 = new Tuple2<String, String>(row.mkString().substring(241, 260).trim(), row.mkString());
				}
			}
			else{  //assume nmon11
				if(row.mkString().substring(212, 231) == null){
					//System.out.println("nmon11 pan mapper: " + row.mkString().substring(737, 756));
				  tuple2 = new Tuple2<String, String>(row.mkString().substring(321, 340).trim(), row.mkString());
				}
				else{
					//System.out.println("nmon11 pan mapper: " + row.mkString().substring(628, 647));
					tuple2 = new Tuple2<String, String>(row.mkString().substring(212, 231).trim(), row.mkString());
				}
			}
			return tuple2;
		  }).reduceByKey((v1, v2) -> {
  			
  			String record = "";
  			String recordtype1 = v1.substring(16,24).trim();
  			String recordtype2 = v2.substring(16,24).trim();
  			String value1 = "";
  			String value2 = "";
  			//don't need the pandatefield in RecordTypeMapper class anymore 
  			//because use it here to reduceByKey when merging PIS and NMON records
  			if(recordtype1.equalsIgnoreCase("nmon20")){
  				if(v1.substring(241, 260).trim() == null){
  					value1 = v1.substring(350, 369).trim() + v1.substring(160, 174).trim() + "000";
  				}
  				else{
  				   value1 = v1.substring(241, 260).trim() + v1.substring(160, 174).trim() + "000";
  				}
  			}
  			else{ //assume nmon11
  				if(v1.substring(212, 231).trim() == null){
  					value1 = v1.substring(321, 340).trim() + v1.substring(160, 174).trim() + "000";
  				}
  				else{
  				  value1 = v1.substring(212, 231).trim() + v1.substring(160, 174).trim() + "000";
  				}
  			}
  			
  			if(recordtype2.equalsIgnoreCase("nmon20")){
  				if(v2.substring(241, 260).trim() == null){
  				  value2 = v2.substring(350, 369).trim() + v2.substring(160, 174).trim() + "000";
  				}
  				else{
  					value2 = v2.substring(241, 260).trim() + v2.substring(160, 174).trim() + "000";
  				}
  			}
  			else{ //assume nmon11
  				if(v2.substring(212, 231).trim() == null){
  				  value2 = v2.substring(321, 340).trim() + v2.substring(160, 174).trim() + "000";
  				}
  				else{
  				  value2 = v2.substring(212, 231).trim() + v2.substring(160, 174).trim() + "000";
  				}
  			}
  			//if value1 > value2 then returns positive value
              //if value1 == value2 then returns 0
              //if value1 < value2 then returns negative value
  			if(value1.compareTo(value2) > 0 || value1.compareTo(value2) == 0){
  				record = v1;  //return whole string
  			}
              if(value1.compareTo(value2) < 0){
  				record = v2;
  			}
  			return record; 
  		});
		newJavaRDD = javaPairRdd.map(f -> {
			RecordTypeMapperCSV rt = null;
			String recordtype = f._2.substring(16,24).trim();
		    if(recordtype.equalsIgnoreCase("nmon20")){
				rt = new RecordTypeMapperCSV("pis12");
				rt.setNMON20FieldValue(f._2);
			}
			else{  //assume nmon11
				rt = new RecordTypeMapperCSV("pis11");
				rt.setNMON11FieldValue(f._2);
			}
            return rt.getRow();  //this is all we need to create dataframe
		});  
		return newJavaRDD;
	}

}
