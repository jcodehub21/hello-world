import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
/**
 * 07/12/2021 This class contains the property for old and new Pan
 * Implements the IFieldObj interface so I can overwrite the setValueByRecord method
 * and be able to call the setValueByRecord method in the Generic RecordTypeMapper class
 * 11/29/2021 Added setValueByBancolumbia method to fix PIS PAN and ClientID Plus Service field
 * @author JaneCheng
 *
 */
@Getter @Setter
public class FieldObj implements IFieldObj,Serializable{

	private static final long serialVersionUID = 1L;
	String fieldName;
	String value;
	int begPos;
	int endPos;
	
	public FieldObj(String field, int start, int end){
		
		fieldName = field;
		begPos = start;
		endPos = end;
	}
	
	//this constructor just want the beginning of the position to the end
     public FieldObj(String field, int start){
		
		fieldName = field;
		begPos = start;
		endPos = 0; //use this as a condition to check so I know I only need the begPos 
	}
	
    public FieldObj(String field, String value, int start, int end){
		
		fieldName = field;
		this.value = value;
		begPos = start;
		endPos = end;
	}
	
    @Override
    public void setValueByRecord(String record){
		
		//substring(x,y) starts at 0;  x=inclusive y=exclusive
    	if(endPos == 0){
    		value = record.substring(begPos);
    	}
    	else{
    		value = record.substring(begPos, endPos);
    	}		
		//System.out.println("value: " + value);  //testing purposes
	}
    
    @Override
    public String getValue(){  //override the lombok Getter method of getValue
    	return value;
    }

	@Override
	public void setValueByBancolumbia(String record) {
		
		if(this.fieldName.equalsIgnoreCase("clientID")){
			HashingFields hashing = new HashingFields();
			value = record.substring(278, 335);
			value = value.substring(0, value.indexOf("000") + 9) + hashing.hashingAnyString(value.substring(value.indexOf("000") + 9, value.indexOf("000") + 19)) + value.substring(value.indexOf("000") + 19);
		}
		else if(this.fieldName.equalsIgnoreCase("pan")){
			value = record.substring(278, 335); //first get the clientId plus service field value
			value = value.substring(value.indexOf("000"), value.indexOf("000") + 9) + record.substring(1910,1920);
		}
		else{  //filler1, filler2, and filler3
			value = record.substring(begPos, endPos);
		}		
	}
	
	@Override
	public void setValueByADS(String record){
		switch(this.fieldName){
		case "userData06":
			value = addSpaces(record.substring(1901, 1920));
			break;
		case "userData11":
		    value = addSpaces(record.substring(1982, 2001));
		    break;
		case "RESERVED_01":
			value = addSpaces(record.substring(1901, 1920));
			break;
		case "userData05":
			value = addSpaces(record.substring(1901, 1920));
			break;
		default:
			setValueByRecord(record);
			break;	    
		}
	}
	
	public String addSpaces(String panvalue){
		String newValue = panvalue;
		int spacesToAdd = (endPos - begPos) - panvalue.length();
		for(int x = 0; x < spacesToAdd; x++){
			newValue = newValue + " ";
		}
		return newValue;
	}

}
