import java.io.BufferedReader;
import java.io.FileReader;


public class TestRecordLength {

	public static void main(String[] args) {
		
		String content = "";
		int counter = 0;
		try{
		  BufferedReader br = new BufferedReader(new FileReader(args[0]));
		  while((content = br.readLine()) != null){
			  if(counter > 9){
				  break;
			  }
			  else{
				  System.out.println("record length: " + content.length());
			  }
			  counter++;
		  }
		  if(br != null){
			  br.close();
		  }
		}catch(Exception e){e.printStackTrace();}

	}

}
