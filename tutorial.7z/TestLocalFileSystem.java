import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;

import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocalFileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.SparkSession;


public class TestLocalFileSystem implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	static BufferedReader br = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static LocalFileSystem lfs = null;
	static Path path = null;
	
	public static void main(String[] args) {
		TestLocalFileSystem test = new TestLocalFileSystem();
		test.startSparkSession();
        test.readLocalFile();
	}
	
    public void startSparkSession(){
		
		spark = SparkSession.builder()
				.appName("Test")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("ERROR");
		
	}
    
    public void readLocalFile(){
    	String content = "";
    	int counter = 0;
		try{
			
			path = new Path("file:///dmsdisk7/prd/arch/FALCON/AKBANK-F6/NONE/1802/1802.akbank-f6.none.nmon20.5683063.3285.ascii.bz2");
			 conf = new Configuration();
		     lfs = FileSystem.getLocal(conf);  //gets the local file system f:///
		     
		     //had to use BZip2CompressorInputStream to read the streams because the file is bzip2 compressed
		     br = new BufferedReader(new InputStreamReader(new BZip2CompressorInputStream(lfs.open(path)), "utf-8"));
		     while((content = br.readLine()) != null){
		    	 if(counter < 20){  //only want to print out 20 records
		    	 System.out.println("content: " + content.substring(0, 19));
		    	 }
		    	 else{
		    		 break;
		    	 }
		    	 counter++;
		     }
		     if(br != null){br.close();}
			}catch(Exception e){e.printStackTrace();}
    	
    }

}
