package jc.lambda.util;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.*;
import com.amazonaws.services.s3.model.*;
// Import log4j classes.
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import java.io.*;
import java.util.List;

public class S3Ops {
    //AWSCredentials credentials = null;  //store your credentials
    AWSStaticCredentialsProvider credentialsProvider = null;  //provides the stored aws user credential
    String bucketName;
    String region;
    AmazonS3 s3Client = null; //regular S3 client
    //S3Object s3Object = null; //objects inside the bucket
    AmazonS3EncryptionV2 s3EncryptionClient = null; //Interface for s3 encryption client to encrypt and decrypt files

    // Define a static logger variable so that it references the
    // Logger instance named "S3Ops".
    private static Logger logger = LogManager.getLogger(S3Ops.class);

    public static void main(String[] args){
        /**
         * Got warnings when run as java application
         * log4j:WARN No appenders could be found for logger (com.amazonaws.AmazonWebServiceClient).
         * log4j:WARN Please initialize the log4j system properly.
         *log4j:WARN See http://logging.apache.org/log4j/1.2/faq.html#noconfig for more info.
         */
        //BasicConfigurator.configure();  //log4j
        //can only pass in the bucket name; not the folders underneath the bucket
        //S3Data test = new S3Data("dmp-dms-k8s-int-fico-pto-tenant");
        //"jc-uswest2-testbucket" is located in DMS INT (Engineering) <= AWS Non-Production Internal
        S3Ops test = new S3Ops("jc-uswest2-testbucket", "us_west_2");
        test.createS3EncryptionClient("us_west_2","arn:aws:kms:us-west-2:780944133628:key/43f7e67b-b756-40fd-8732-23ec51fdbc96");
        //test.encryptFile("alone.txt");
        test.decryptFile("aloneEncrypted.txt");
        //test.putObjects("alone.txt","","plain/text");
        // test.downloadObject("jc-uswest2-testbucket","alone.txt");
    }

    /**
     * set bucket name and region
     * @param bn bucket name
     * @param region region to use
     */
    public S3Ops(String bn, String region){
        bucketName = bn;
        this.region = region;
    }

    /**
     * Find the IAMRole in user's IAM account on AWS or
     * look for the credentials under the aws location
     * located at C:\\Users\\JaneCheng\\.aws\\credentials
     * @param IAMRole aws user role
     */
    public void setCredentialsProvider(String IAMRole){
        try {
            //credentialsProvider = new AWSStaticCredentialsProvider(new ProfileCredentialsProvider(IAMRole).getCredentials());
            CommonOps.setCredentialProvider(IAMRole);
        }
        catch(Exception e){
            logger.info("Cannot load credential file");
            throw new AmazonClientException(
                    "Cannot load the credentials from the credential profiles file. " +
                            "Please make sure that your credentials file is at the correct " +
                            "location (C:\\Users\\JaneCheng\\.aws\\credentials), and is in valid format.",
                    e);
        }
    }

    /**
     * create the standard S3 client
     * with credentials passed in
     */
    private void createS3Client(String region){
        try {
            s3Client = CommonOps.getS3Client(region);
        }catch(Exception e){e.printStackTrace();}
    }

    /**
     * create the standard S3 Encryption Client V2
     * with Customer Master Key passed in
     * @param cmkId Customer Master Key
     */
    private void createS3EncryptionClient(String region, String cmkId){

        /**
         * CryptoConfigurationV2 gave error:
         * The Bouncy castle library jar is required on the classpath to enable authenticated encryption
         * need Bouncy castle jar file
         * I need to specify .withRegion(Regions.US_WEST_2) in order to use my bucket
         * I also need to specify .withAwsKmsRegion(Region.getRegion(Regions.US_WEST_2)) in order to find my CMK under US_WEST_2
         * since it is created only for a Single Region; otherwise throws error saying it cannot find the CMK
         * both .withRegion and .withAwsKmsRegion uses com.amazonaws.regions.Region => Region here is a class
         * using com.amazonaws.services.s3.model.Region will throw errors because this is an Enum not class
         * below uses encryption with Amazon KMS managed keys (KMSEncryptionMaterialsProvider)
         */
        try{
            s3EncryptionClient = CommonOps.getS3EncryptionClient(region, cmkId);

            /**
             * below uses Amazon S3 client-side encryption with customer-managed client master keys
             * s3EncryptionClient = AmazonS3EncryptionClientV2Builder.standard()
                    .withCredentials(credentialsProvider)
                    .withRegion(Regions.valueOf(region.toUpperCase()))
                    .withCryptoConfiguration(new CryptoConfigurationV2().withCryptoMode((CryptoMode.StrictAuthenticatedEncryption)))
                    .withEncryptionMaterialsProvider(new StaticEncryptionMaterialsProvider(new EncryptionMaterials(cmkId)))
                    .build();
             **/
        }catch(Exception e){e.printStackTrace();}

    }

    public boolean createBucket(){
        boolean result = false;
        if(!s3Client.doesBucketExistV2(bucketName)){
            s3Client.createBucket(bucketName);
            result = true;
        }
        return result;

    }

    /**
     * loop through all the files in bucket to see if the file exists or not
     * Object names are also referred to as key names
     * return the key info/metadata (aka filename)
     * @param key  file name
     * @return S3ObjectSummary
     */
    public S3ObjectSummary getObjectSummary(String bucket, String key){
        S3ObjectSummary keySummary = null;
        if(s3Client.doesBucketExistV2(bucket)){
            ObjectListing objectListing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucket));
            for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
                if(objectSummary.getKey().matches(key)){
                    System.out.println("Object ey found: " + objectSummary.getKey() + " (size = " + objectSummary.getSize() + ")");
                    keySummary = objectSummary;
                }
            }
        }
        return keySummary;
    }

    /**
     * return a list of the object summaries describing the objects stored in the S3 bucket
     * @param bucket  bucket name
     * @return summaries
     */
    public List<S3ObjectSummary> listObjectsSummaries(String bucket){
        List<S3ObjectSummary> summaries = null;
        ObjectListing objectListing;
        try{
            if(s3Client.doesBucketExistV2(bucket)){
                objectListing = s3Client.listObjects(new ListObjectsRequest().withBucketName(bucket));
                while(objectListing.isTruncated()) {  //returns true if the object listing is not complete.
                    summaries = objectListing.getObjectSummaries();
                }
            }

        }
        catch (AmazonServiceException ase) {
            logger.info("Caught an AmazonServiceException, which means your request made it "
                    + "to Amazon S3, but was rejected with an error response for some reason.");
            logger.info("Error Message {}:", ase.getMessage());
            logger.info("HTTP Status Code: {}", ase.getStatusCode());
            logger.info("AWS Error Code: {}", ase.getErrorCode());
            logger.info("Error Type: {}", ase.getErrorType());
            logger.info("Request ID: {}", ase.getRequestId());
        } catch (AmazonClientException ace) {
            logger.info("Caught an AmazonClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with S3, "
                    + "such as not being able to access the network.");
            logger.info("Error Message: {}", ace.getMessage());
        }
        return summaries;
    }

    /**
     * download objects from S3 bucket; key is the filename
     * @param key file name
     */
    public void downloadObject(String bucket, String key, File dir){


        if(s3Client.doesObjectExist(bucket, key)){

            if(hasSpace(getObjectSummary(bucket, key).getSize(), dir.getFreeSpace())) {
                GetObjectRequest objGetRequest = new GetObjectRequest(bucket, key);
                /**
                 * getObject(GetObjectRequest getObjectRequest, File destinationFile) = Gets the object metadata for the object stored in Amazon S3
                 * under the specified bucket and key, and saves the object contents to the specified file location.
                 */
                s3Client.getObject(objGetRequest, new File("C:\\software\\AWS_Developer\\S3_Test\\test.txt"));
            }
            else{
                logger.info("Not enough space to download {}", key);
            }
        }
        else{

            logger.info("Object {} does not exist at {}", key, bucket);
        }
    }

    /**
     * Uploads the specified file to Amazon S3 under the specified bucket and key name.
     * key name = filename
     */
    public void putObjects(String key, String bucket, String bucketPathToStoreFile, String fileType){

        //create the metadata object and set metadata info
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentType(fileType);
        //create PutObjectRequest as a request to upload the object by s3client
        PutObjectRequest objPutRequest;

        if(s3Client.doesObjectExist(bucket, key)){
            //delete existing file
            s3Client.deleteObject(bucket, key);
        }
        objPutRequest = new PutObjectRequest(bucket, bucketPathToStoreFile + key, new File("C:\\software\\eclipse_luna_4.4_projects\\" + key));
        objPutRequest.setMetadata(metadata);
        s3Client.putObject(objPutRequest);
    }

    /**
     * Delete an object - Unless versioning has been turned on for your bucket,
     * there is no way to undelete an object, so use caution when deleting objects.
     * key = filename
     */
    public void deleteObject(String bucket, String key){

        if(s3Client.doesObjectExist(bucket, key)){
            s3Client.deleteObject(bucket, key);
        }
        logger.info("Deleted {}", key);
    }

    /** Delete a bucket - A bucket must be completely empty before it can be
     * deleted, so remember to delete any objects from your buckets before
     * you try to delete them.
     */

    public void deleteBuckets(String bucket){
        List<S3ObjectSummary> summaries;
        //check if bucket is empty
        if((summaries = listObjectsSummaries(bucket)) != null){
            //need to delete all objects first
            for(S3ObjectSummary summary : summaries){

                deleteObject(bucket, summary.getKey());
            }
            //now delete the bucket
        }
        s3Client.deleteBucket(bucket);
        logger.info("Bucket {} deleted", bucket);
    }

    /**
     * read the key/file content directly from s3 bucket
     */
    public void readFileContent(String bucket, String key){

        String content;
        /**
         * getObject(String bucketName, String key) =
         * Gets the object stored in Amazon S3 under the specified bucket and key.
         */
        S3Object object = s3Client.getObject(bucket, key);
        try {
            /**
             * InputStreamReader(InputStream in) = Creates an InputStreamReader that uses the default charset.
             * S3Object.getObjectContent() returns S3ObjectInputStream which is a subclass of java.io.InputStream
             */
            BufferedReader reader = new BufferedReader(new InputStreamReader(object.getObjectContent()));

            while((content = reader.readLine()) != null){
                System.out.println(content);
            }
            reader.close();
        }
        catch (IOException e) {e.printStackTrace();}

    }

    /**
     * create a sample file on demand
     * An OutputStreamWriter is a bridge from character streams to byte streams;
     * subclass of java.io.Writer
     * Characters written to it are encoded into bytes using a specified charset
     * For top efficiency, consider wrapping an OutputStreamWriter within a BufferedWriter
     * using Writer
     */
    public File createSampleFile() throws IOException{

        File file = File.createTempFile("aws-java-sdk-", ".txt");
        file.deleteOnExit();

        Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
        writer.write("abcdefghijklmnopqrstuvwxyz\n");
        writer.write("01234567890112345678901234\n");
        writer.write("!@#$%^&*()-=[]{};':',.<>/?\n");
        writer.write("01234567890112345678901234\n");
        writer.write("abcdefghijklmnopqrstuvwxyz\n");
        writer.close();

        return file;
    }

    /**
     * encrypt single file using the AWS Customer Master Key (CMK) before uploading to S3 bucket
     * CMK created on AWS Key Management Service (KMS) console
     * Cryptography - practice of protecting info via use of primitives (tools)
     * primitves tools include encryption algorithms, digital signature algorithms, hashes, etc.
     * CryptoConfigurationV2 class - Stores configuration parameters that will be used during encryption and decryption by the Amazon S3 Encryption Client V2 AmazonS3EncryptionClientV2.
     * KMSEncryptionMaterialsProvider class - Simple implementation of EncryptionMaterialsProvider that just wraps static EncryptionMaterials.
     * EncryptionMaterials class - The "key encrypting key" materials used in encrypt/decryption. These materials may be either an asymmetric key pair or a symmetric key but not both.
     */

    public void encryptFile(String key){

        //String keyMetaDataDesc = "Encrypted using CMK";

        try{
            //System.out.println("key: " + key);
            key = key.substring(0, key.lastIndexOf(".")) + "Encrypted.txt";

            /**
             * upload file to same location with different key name
             * PutObjectRequest(String bucketName, String keyNameToBeStoredInBucket, File sourceFile)
             */
            PutObjectRequest objPutRequest = new PutObjectRequest(bucketName, key, new File("C:\\software\\eclipse_luna_4.4_projects\\alone.txt"));
            //putObject will encrypt and upload the file to S3 Bucket
            s3EncryptionClient.putObject(objPutRequest);

            logger.info("Encrypted file content {}",s3EncryptionClient.getObjectAsString(bucketName, key));
            s3EncryptionClient.shutdown();
        }
        catch(SdkClientException e){
            e.printStackTrace();
        }
    }

    /**
     * decrypt a single file
     * @param key file name
     */
    public void decryptFile(String key){
        try{
            GetObjectRequest objGetRequest= new GetObjectRequest(bucketName, key);
            //getObject will download and decryt the file
            /**
             * getObject(GetObjectRequest getObjectRequest, File destinationFile) = Gets the object metadata for the object stored in Amazon S3
             * under the specified bucket and key, and saves the object contents to the specified file location.
             */
            s3EncryptionClient.getObject(objGetRequest, new File("C:\\software\\AWS_Developer\\S3_Test\\aloneDecrypted.txt"));

            s3EncryptionClient.shutdown();
        }
        catch(SdkClientException e){
            e.printStackTrace();
        }
    }

    public boolean hasSpace(long objSize, long destDirSize){
        return objSize < (destDirSize * .9) ? true : false;
    }
}
