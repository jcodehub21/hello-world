package jc.lambda.util;

import java.time.LocalDate;

public class CalendarOps {

    public static String convertSingleDigitToString(int x){
        String result;
        if(String.valueOf(x).length() == 1){
            result = "0" + String.valueOf(x);  //make month as 01, 02, etc..
        }else{
            result = String.valueOf(x);
        }
        return result;
    }

    public static String getLastDayOfMonth(String month){
        String lastDayOfMonth;
        if(month.equalsIgnoreCase("04") || month.equalsIgnoreCase("06")|| month.equalsIgnoreCase("09")|| month.equalsIgnoreCase("11")){
            lastDayOfMonth = "30";
        }
        else if(month.equalsIgnoreCase("02")){  //february
            if(LocalDate.now().isLeapYear()){
                lastDayOfMonth = "29";
            }
            else{
                lastDayOfMonth = "28";
            }
        }
        else{
            lastDayOfMonth = "31";
        }
        return lastDayOfMonth;
    }

    public static String getMonthName(String monthNumber){
        String monthName;
        switch(monthNumber){
            case "01": monthName = "January";
            break;
            case "02": monthName = "February";
            break;
            case "03": monthName = "March";
            break;
            case "04": monthName = "April";
            break;
            case "05": monthName = "May";
            break;
            case "06": monthName = "June";
            break;
            case "07": monthName = "July";
            break;
            case "08": monthName = "August";
            break;
            case "09": monthName = "September";
            break;
            case "10": monthName = "October";
            break;
            case "11": monthName = "November";
            break;
            default: monthName = "December";
            break;
        }
        return monthName;
    }
}
