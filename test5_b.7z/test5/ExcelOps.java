package jc.lambda.util;

import com.amazonaws.services.athena.model.ColumnInfo;
import com.amazonaws.services.athena.model.Datum;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.List;

/**
 * 09/05/2024
 * https://poi.apache.org/components/spreadsheet/quick-guide.html
 * https://medium.com/@olayiwolafunsho/serverless-with-aws-lambda-and-java-generate-an-excel-file-and-upload-to-s3-a21005a015a2
 * https://stackoverflow.com/questions/23080945/java-lang-classnotfoundexception-org-apache-xmlbeans-xmlexception
 * java.lang.ClassNotFoundException: org.apache.xmlbeans.XmlException
 * https://stackoverflow.com/questions/39670382/apache-poi-error-loading-xssfworkbook-class
 * java.lang.NoClassDefFoundError: org/apache/commons/collections4/ListValuedMap
 * https://stackoverflow.com/questions/77256330/java-lang-nosuchmethoderror-org-apache-commons-io-output-unsynchronizedbytearr
 * java.lang.NoSuchMethodError: org.apache.commons.io.output.UnsynchronizedByteArrayOutputStream.builder
 * https://stackoverflow.com/questions/21925560/number-stored-as-text-warning-in-excel-using-poi
 * @author JaneCheng
 */
public class ExcelOps {

    private XSSFWorkbook workbook;
    private String workbookName;
    private Row row;
    private Sheet sheet;
    private DecimalFormat decFormat = new DecimalFormat("0.00");
    private DataFormat df; //to format the cell
    private XSSFCellStyle style;
    private Cell cell;;
    int rowCounter = 0; //row counts

    public ExcelOps(String name){
        try {
            workbook = new XSSFWorkbook();
            File file = new File(name);
            if(file.exists()){
                file.delete();
            }
            df = workbook.createDataFormat();
            style = workbook.createCellStyle();
            // 0.00 allows for leading or trailing zeros; using #.## does not allow leading or trailing zeros
            style.setDataFormat(df.getFormat("0.00"));
            workbookName = name;
        }catch(Exception e){e.printStackTrace();}
    }

    public void createWorkbook(String name) {
        try {
            workbook = new XSSFWorkbook(new File(name));
        }catch(Exception e){e.printStackTrace();}
    }

    public void createSheet(String sheetName){
           sheet = workbook.createSheet(sheetName);
    }

    public void createColumn(List<ColumnInfo> columnInfo){
        int cellNumber = 0;
        // Create a row and put some cells in it. Rows are 0 based.
        row = this.sheet.createRow(rowCounter);
        // Create a cell and put a value in it.
        for(ColumnInfo column : columnInfo){
            row.createCell(cellNumber).setCellValue(column.getName());
            cellNumber++;
        }
        rowCounter++;
    }
    public void createRow(int x){
           row = this.sheet.createRow(x);
    }

    public void addData(List<Datum> record){
        int cellNumber = 0;
        row = this.sheet.createRow(rowCounter);
        for(Datum data : record){
            if(cellNumber == 3 && !data.getVarCharValue().equalsIgnoreCase("Cost")){
                //row.createCell(cellNumber).setCellValue(decFormat.format(Double.parseDouble(data.getVarCharValue())));
                cell = row.createCell(cellNumber, CellType.NUMERIC);
                cell.setCellValue(Double.parseDouble(data.getVarCharValue()));
                cell.setCellStyle(style);

            }else{
                row.createCell(cellNumber).setCellValue(data.getVarCharValue());
            }
              cellNumber++;
          }
        rowCounter++;
    }

    public XSSFWorkbook getWorkbook(){
        try {
            workbook.write(new FileOutputStream(workbookName));
            workbook.close();
        }catch(Exception e){e.printStackTrace();}
        return workbook;
    }

    public void saveWorkbook(){
        try {
            workbook.write(new FileOutputStream(workbookName));
            workbook.close();
        }catch(Exception e){e.printStackTrace();}
    }

    public String getWorkbookName(){
        return workbookName;
    }
}
