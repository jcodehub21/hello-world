import org.apache.spark.sql.api.java.UDF1;

/**
 * Java UserDefinedFunction for Spark SQLContext
 * This UDF2 will hash Pan
 * @author JaneCheng
 *
 */
public class UDF implements UDF1<String, String>{

	private static final long serialVersionUID = 1L;
	HashingFields hf = new HashingFields();
	
	
	@Override
	public String call(String columnValue) throws Exception {
		
		return hf.hashingPan(columnValue);
	}

}
