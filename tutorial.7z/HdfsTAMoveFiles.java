import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * 1/10/2022 -  This class will create two bash scripts to move and update the database of Akbank 
 * nmon20 pan mapped files located at /hdfsTA/work/fdrMapping/2021/akbank.
 * 
 * lux432: 
 * 
 * /Anton/jyc_temp/jdk1.8.0_231/bin/java -cp .:/ana/mds/prd/data/files/INCOMING/jane_temp HdfsTAMoveFiles <list_of_files_to_read> <hdfsTA_Location> 2022-01-19 <clientcode> <portfolio> <moveScriptName> <updteScriptName>
 * 
 * Example:
 * /Anton/jyc_temp/jdk1.8.0_231/bin/java -cp .:/ana/mds/prd/data/files/INCOMING/jane_temp HdfsTAMoveFiles akbanklist.txt /hdfsTA/work/fdrMapping/2021/akbank/ 2022-01-19 akbank-f6 none akbankMoveScript.sh akbankUpdateScript.sh > hdfsMoveFiles.log 2>&1 &
 * 
 * @author JaneCheng
 *
 */
public class HdfsTAMoveFiles {

	public static void main(String[] args){
		String hdfsTA = args[1];
		String content = "";
		File file = null;
		BufferedWriter bwMoveScript = null;
		BufferedWriter bwUpdateScript = null;
		String[] metadata = null;
		String processedDate = args[2];

		try{
			
			bwMoveScript = new BufferedWriter(new FileWriter(hdfsTA + args[5]));
			bwUpdateScript = new BufferedWriter(new FileWriter(hdfsTA + args[6]));
			bwMoveScript.write("#!/bin/bash");
			bwMoveScript.newLine();
			//read in the file which contains list of akbank original file paths
            BufferedReader br = new BufferedReader(new FileReader(args[0]));  
            while((content = br.readLine()) != null){
            	metadata = content.substring(content.lastIndexOf("/") + 1).split("\\.");
            	file = new File(hdfsTA + content.substring(content.lastIndexOf("/")));
            	bwMoveScript.write("mv " + file.toString() + " " + content);
            	bwMoveScript.newLine();
            	bwUpdateScript.write("update filestorage set filesize = " + file.length() + " where fileid = " + metadata[4] + " and filestatus = 'O' and filetype = 'O';");
            	bwUpdateScript.newLine();
            	bwUpdateScript.write("insert into manual_changes values ('" + metadata[4] + "', DATE '" + processedDate + "', '" + args[3] + "(" + args[4] + ") pan mapping', 'JaneCheng');");
            	bwUpdateScript.newLine();
            }
            
            if(br != null){br.close();}
            if(bwMoveScript != null){bwMoveScript.close();}
            if(bwUpdateScript != null){bwUpdateScript.close();}

		}catch(Exception e){e.printStackTrace();}
	}

}
