package org.jcservices;

import java.io.Serializable;

import com.beust.jcommander.Parameter;
import com.beust.jcommander.Parameters;
import lombok.Getter;
import lombok.NoArgsConstructor;


/**
 * 8/30/2022 Parser for user inputs
 * @author JaneCheng
 *
 */
//no constructor needed;  Getter will allow you to use get<FieldName>() method
@NoArgsConstructor
@Getter
@Parameters(separators = "=")
public class CommonUtilParser implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Parameter(names = { "-c", "--client"}, description = "client", required = true, order = 0)
    private String client;

    @Parameter(names = { "-p", "--portfolio"}, description = "portfolio", required = true, order = 1)
    private String portfolio;

    @Parameter(names = { "-d", "--dateperiod"}, description = "yymm", required = true, order = 2)
    private String yymm;
    
    @Parameter(names = { "-t", "--type"}, description = "record type", required = true, order = 3)
    private String datafeed;
    
    @Parameter(names = { "-f", "--field"}, description = "field name", required = true, order = 3)
    private String field;

}
