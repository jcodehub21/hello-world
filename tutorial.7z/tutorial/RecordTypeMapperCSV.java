import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;

/**
 * 2/25/2021 - this class is for reading hdfs bz2 client files 
 * and processing directly in Spark
 * @author JaneCheng
 *
 */

public class RecordTypeMapperCSV implements Serializable{

	private static final long serialVersionUID = 1L;

	//List represents an ordered sequence of objects
	List<RollingObj> fieldInfo = new ArrayList<RollingObj>();
	
	   /*Writable MUST has a default constructor*/
	   public RecordTypeMapperCSV(){}
	
	   public RecordTypeMapperCSV(String recordtype){
		  /**
		   * all the byte positions here are from hdfs bz files which are different from bz2 files on DMS
		   */
		   if(recordtype.equalsIgnoreCase("pis12") || recordtype.equalsIgnoreCase("nmon20")){
			
			//fieldInfo.add(new RollingObj(String fieldName, int begPos, int endPos)
			fieldInfo.add(new RollingObj("workflow", 0,16));
			fieldInfo.add(new RollingObj("recordType", 16,24));
			fieldInfo.add(new RollingObj("dataSpecificationVersion", 24,29));
			fieldInfo.add(new RollingObj("clientIdFromHeader",29,45));
			fieldInfo.add(new RollingObj("recordCreationDate",45,53));
			fieldInfo.add(new RollingObj("recordCreationTime",53, 59));
			fieldInfo.add(new RollingObj("recordCreationMilliseconds",59,62));
			fieldInfo.add(new RollingObj("gmtOffset",62,68));
			fieldInfo.add(new RollingObj("customerIdFromHeader",68,88));
			fieldInfo.add(new RollingObj("customerAcctNumber",88,128));
			fieldInfo.add(new RollingObj("externalTransactionId",128, 160));
			fieldInfo.add(new RollingObj("pan",160, 179));
			fieldInfo.add(new RollingObj("type",179, 180));
			fieldInfo.add(new RollingObj("subType",180, 182));
			fieldInfo.add(new RollingObj("category",182, 183));
			fieldInfo.add(new RollingObj("association",183, 184));
			fieldInfo.add(new RollingObj("panOpenDate",184, 192));
			fieldInfo.add(new RollingObj("memberSinceDate",192, 200));
			fieldInfo.add(new RollingObj("issuingCountry",200, 203));  
			fieldInfo.add(new RollingObj("cardholderCity",203, 243));
			fieldInfo.add(new RollingObj("cardholderStateProvince",243, 248));
			fieldInfo.add(new RollingObj("cardholderPostalCode",248, 258));
			fieldInfo.add(new RollingObj("cardholderCountryCode",258, 261));
			fieldInfo.add(new RollingObj("numberOfPaymentIds",261, 264));
			fieldInfo.add(new RollingObj("paymentInstrumentId",264, 294));
			fieldInfo.add(new RollingObj("status",294, 296));
			fieldInfo.add(new RollingObj("statusDate",296, 304));
			fieldInfo.add(new RollingObj("pinLength",304, 306));
			fieldInfo.add(new RollingObj("pinSetDate",306, 314));
			fieldInfo.add(new RollingObj("pinType",314, 315));
			fieldInfo.add(new RollingObj("activeIndicator",315, 316));//
			fieldInfo.add(new RollingObj("nameOnInstrument",316, 356));
			fieldInfo.add(new RollingObj("expirationDate",356, 364));
			fieldInfo.add(new RollingObj("lastIssueDate",364, 372));
			fieldInfo.add(new RollingObj("plasticIssueType",372, 373));
			fieldInfo.add(new RollingObj("incentive",373, 374));
			fieldInfo.add(new RollingObj("currencyCode",374, 377));
			fieldInfo.add(new RollingObj("currencyConversionRate",377, 390));
			fieldInfo.add(new RollingObj("creditLimit",390, 400));
			fieldInfo.add(new RollingObj("overdraftLimit",400,410));
			fieldInfo.add(new RollingObj("dailyPosLimit",410,420));
			fieldInfo.add(new RollingObj("dailyCashLimit",420,430));
			fieldInfo.add(new RollingObj("cashbackLimitMode",430,431));  //different
			fieldInfo.add(new RollingObj("mediaType",431,432));
			fieldInfo.add(new RollingObj("aipStatic",432,433));
			fieldInfo.add(new RollingObj("aipDynamic",433,434));
			fieldInfo.add(new RollingObj("aipVerify",434,435));
			fieldInfo.add(new RollingObj("aipRisk",435,436));
			fieldInfo.add(new RollingObj("aipIssuerAuthentication",436,437));
			fieldInfo.add(new RollingObj("aipCombined",437,438));
			fieldInfo.add(new RollingObj("chipSpecification",438,439));
			fieldInfo.add(new RollingObj("chipSpecVersion",439,442));
			fieldInfo.add(new RollingObj("offlineLowerLimit",442,444));
			fieldInfo.add(new RollingObj("offlineUpperLimit",444,446));
			fieldInfo.add(new RollingObj("userIndicator01",446,447));
			fieldInfo.add(new RollingObj("userIndicator02",447,448));
			fieldInfo.add(new RollingObj("userCode1",448,451));
			fieldInfo.add(new RollingObj("userCode2",451,454));
			fieldInfo.add(new RollingObj("userData01",454,460));
			fieldInfo.add(new RollingObj("userData02",460,466));
			fieldInfo.add(new RollingObj("userData03",466,476));
			fieldInfo.add(new RollingObj("userData04",476,486));
			fieldInfo.add(new RollingObj("userData05",486,501));
			fieldInfo.add(new RollingObj("userData06",501,521));
			fieldInfo.add(new RollingObj("userData07",521,561));
			fieldInfo.add(new RollingObj("pandatetime",561,597));
			fieldInfo.add(new RollingObj("nonmonCode",597,601));
			
	       }
		   if(recordtype.equalsIgnoreCase("pis11") || recordtype.equalsIgnoreCase("nmon11")){
			   
				//fieldInfo.add(new RollingObj(String fieldName, int begPos, int endPos)
				fieldInfo.add(new RollingObj("workflow", 0,16));
				fieldInfo.add(new RollingObj("recordType", 16,24));
				fieldInfo.add(new RollingObj("dataSpecificationVersion", 24,29));
				fieldInfo.add(new RollingObj("clientIdFromHeader",29,45));
				fieldInfo.add(new RollingObj("recordCreationDate",45,53));
				fieldInfo.add(new RollingObj("recordCreationTime",53, 59));
				fieldInfo.add(new RollingObj("recordCreationMilliseconds",59,62));
				fieldInfo.add(new RollingObj("gmtOffset",62,68));
				fieldInfo.add(new RollingObj("customerIdFromHeader",68,88));
				fieldInfo.add(new RollingObj("customerAcctNumber",88,128));
				fieldInfo.add(new RollingObj("externalTransactionId",128, 160));
				fieldInfo.add(new RollingObj("pan",160, 179));
				fieldInfo.add(new RollingObj("type",179, 180));
				fieldInfo.add(new RollingObj("subType",180, 182));
				fieldInfo.add(new RollingObj("category",182, 183));
				fieldInfo.add(new RollingObj("association",183, 184));
				fieldInfo.add(new RollingObj("panOpenDate",184, 192));
				fieldInfo.add(new RollingObj("memberSinceDate",192, 200));
				fieldInfo.add(new RollingObj("issuingCountry",200, 203));  
				fieldInfo.add(new RollingObj("cardholderCity",203, 243));
				fieldInfo.add(new RollingObj("cardholderStateProvince",243, 248));
				fieldInfo.add(new RollingObj("cardholderPostalCode",248, 258));
				fieldInfo.add(new RollingObj("cardholderCountryCode",258, 261));
				fieldInfo.add(new RollingObj("numberOfPaymentIds",261, 264));
				fieldInfo.add(new RollingObj("paymentInstrumentId",264, 294));
				fieldInfo.add(new RollingObj("status",294, 296));
				fieldInfo.add(new RollingObj("statusDate",296, 304));
				fieldInfo.add(new RollingObj("pinLength",304, 306));
				fieldInfo.add(new RollingObj("pinSetDate",306, 314));
				fieldInfo.add(new RollingObj("pinType",314, 315));
				fieldInfo.add(new RollingObj("activeIndicator",315, 316));
				fieldInfo.add(new RollingObj("nameOnInstrument",316, 356));
				fieldInfo.add(new RollingObj("expirationDate",356, 364));
				fieldInfo.add(new RollingObj("lastIssueDate",364, 372));
				fieldInfo.add(new RollingObj("plasticIssueType",372, 373));
				fieldInfo.add(new RollingObj("incentive",373, 374));
				fieldInfo.add(new RollingObj("currencyCode",374, 377));
				fieldInfo.add(new RollingObj("currencyConversionRate",377, 390));
				fieldInfo.add(new RollingObj("creditLimit",390, 400));
				fieldInfo.add(new RollingObj("overdraftLimit",400,410));
				fieldInfo.add(new RollingObj("dailyPosLimit",410,420));
				fieldInfo.add(new RollingObj("dailyCashLimit",420,430));
				fieldInfo.add(new RollingObj("dailyLimitType",430,431));  //different
				fieldInfo.add(new RollingObj("mediaType",431,432));
				fieldInfo.add(new RollingObj("aipStatic",432,433));
				fieldInfo.add(new RollingObj("aipDynamic",433,434));
				fieldInfo.add(new RollingObj("aipVerify",434,435));
				fieldInfo.add(new RollingObj("aipRisk",435,436));
				fieldInfo.add(new RollingObj("aipIssuerAuthentication",436,437));
				fieldInfo.add(new RollingObj("aipCombined",437,438));
				fieldInfo.add(new RollingObj("chipSpecification",438,439));
				fieldInfo.add(new RollingObj("chipSpecVersion",439,442));
				fieldInfo.add(new RollingObj("offlineLowerLimit",442,444));
				fieldInfo.add(new RollingObj("offlineUpperLimit",444,446));
				fieldInfo.add(new RollingObj("userIndicator01",446,447));
				fieldInfo.add(new RollingObj("userIndicator02",447,448));
				fieldInfo.add(new RollingObj("userCode1",448,451));
				fieldInfo.add(new RollingObj("userCode2",451,454));
				fieldInfo.add(new RollingObj("userData01",454,460));
				fieldInfo.add(new RollingObj("userData02",460,466));
				fieldInfo.add(new RollingObj("userData03",466,476));
				fieldInfo.add(new RollingObj("userData04",476,486));
				fieldInfo.add(new RollingObj("userData05",486,501));
				fieldInfo.add(new RollingObj("userData06",501,521));
				fieldInfo.add(new RollingObj("userData07",521,561));
				fieldInfo.add(new RollingObj("pandatetime",561,597));
				fieldInfo.add(new RollingObj("nonmonCode",597,601));
		   }  
       }
	   
	   /**
	    * gets the List<RollingObj>
	    * @return fieldInfo
	    */
	   public List<RollingObj> getFieldInfo(){
		   
		   return fieldInfo;
	   }
	   
	   /**
	    * set values for each PIS field
	    */
	   public void setPISFieldValue(String record){  
		   
	    	//HDFS files have different positions than files stored on NFS disks (eg /Cardamon..)
	    	// List<E> starts from 0 to N-1 where N is size() of list.
		   for(int x=0; x < fieldInfo.size(); x++){
			   
			   if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
				   
				   fieldInfo.get(x).setNmonValue(record.substring(160, 179) + record.substring(45,53) + record.substring(53, 59) + record.substring(59,62));
			   }
			   else if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
				   fieldInfo.get(x).setNmonValue("    ");   
			   }
			   else{
			         fieldInfo.get(x).setValue(record);
			   }
		   }	   
	   }
	   
	   /**
	    * set values for Nmon20 depending upon 
	    */
	   public void setNMON20FieldValue(String record){
		   
		   String nonmonCode = record.substring(174,178);
		   String result = "";
		   for(int x=0; x < fieldInfo.size(); x++){
	    		
			   if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("workflow")){
	    			fieldInfo.get(x).setNmonValue(record.substring(0, 16));
	    		}
			   
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType")){  //set recordType value to PIS12
	    			fieldInfo.get(x).setNmonValue("PIS12   ");
	    		}
			    
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dataSpecificationVersion")){
	    			fieldInfo.get(x).setNmonValue("1.2  ");
	    		}
			    
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("clientIdFromHeader")){
	    			fieldInfo.get(x).setNmonValue(record.substring(29, 45));
	    		}
			    
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate")){  //transactionDate becomes recordCreationDate
	    			fieldInfo.get(x).setNmonValue(record.substring(160, 168));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime")){  //transactionTime becomes recordCreationTime
	    			fieldInfo.get(x).setNmonValue(record.substring(168, 174));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds")){  //recordCreationMilliseconds becomes 000
	    			fieldInfo.get(x).setNmonValue("000");
	    		}
			    
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("gmtOffset")){  
	    			fieldInfo.get(x).setNmonValue("      ");
	    		}
	    		
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("customerIdFromHeader")){
	    			fieldInfo.get(x).setNmonValue(record.substring(68, 88));
	    		}
			    
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("customerAcctNumber")){
	    			fieldInfo.get(x).setNmonValue(record.substring(88, 128));
	    		}
			    
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("externalTransactionId")){  
	    			fieldInfo.get(x).setNmonValue("                                ");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan")){
	    			if(nonmonCode.equalsIgnoreCase("3000") && !record.substring(350, 369).trim().isEmpty()){
	    			   fieldInfo.get(x).setNmonValue(record.substring(350, 369));  //newPan value becomes pan
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(record.substring(241, 260));  //get original pan
	    	    	}
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("type")){
	    			
	    			//newIndiator1 becomes Type for 3010
	    			if(nonmonCode.equalsIgnoreCase("3010")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1519, 1520));  //newIndicator1
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType")){
	    			
	    			//newCode1 becomes subType for 3010
	    			if(nonmonCode.equalsIgnoreCase("3010")){
	    				result = record.substring(1501, 1504).trim();
	    				if(result.length() == 3){
	    					result = result.substring(0,2);
	    				}
	    				if(result.length() < 2){
	    					result = result + " ";
	    				}
	    				
	    				fieldInfo.get(x).setNmonValue(result);
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("  "); //subType empty
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("numberOfPaymentIds")){  //numberOfPaymentIds
	    			
	    			if(nonmonCode.equalsIgnoreCase("3010")){
	    				result = record.substring(1581, 1591).trim();
	    				if(result.length() > 3){
	    					result = result.substring(0,3);
	    				}
	    				if(result.length() < 2){
	    					result = result + "  ";
	    				}
	    				
	    				fieldInfo.get(x).setNmonValue(result);
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("   "); //numberOfPaymentIds empty
	    			}		
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("category")){
	    			
	    			//newIndicator2 becomes category for 3010
	    			if(nonmonCode.equalsIgnoreCase("3010")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1521, 1522));  //newIndicator2
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("association")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("panOpenDate")){
	    			
	    			//newDate2 becomes subType for 3010
	    			if(nonmonCode.equalsIgnoreCase("3010")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1405, 1413));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("        "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("memberSinceDate")){  
	    			fieldInfo.get(x).setNmonValue("        ");
	    		}
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("issuingCountry")){
	    			if(nonmonCode.equalsIgnoreCase("3000")){
    				   fieldInfo.get(x).setNmonValue(record.substring(1207, 1210));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("   ");
	    			}
    		    }
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCity")){  
	    			fieldInfo.get(x).setNmonValue("                                        ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderStateProvince")){  
	    			fieldInfo.get(x).setNmonValue("     ");
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderPostalCode")){
	    			
	    			//newCountryCode becomes cardholderCountryCode for 3100
	    			if(nonmonCode.equalsIgnoreCase("3100")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1187, 1197));  //newPostalCode
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("          ");
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode")){
	    			
	    			//newCountryCode becomes cardholderCountryCode for 3100
	    			if(nonmonCode.equalsIgnoreCase("3100")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1207, 1210));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("   "); //cardholderCountryCode empty
	    			}		
	    		}
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("paymentInstrumentId")){
	    			if(nonmonCode.equalsIgnoreCase("3000")){
    				   fieldInfo.get(x).setNmonValue(record.substring(369, 399));	
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("                              ");
	    			}
    		    }
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("status")){
	    			
	    			//newCode1 becomes status for 3102
	    			if(nonmonCode.equalsIgnoreCase("3102")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1501, 1503));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("  "); //status empty
	    			}   			
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("statusDate")){  
	    			fieldInfo.get(x).setNmonValue("        ");
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pinLength")){  
	    			fieldInfo.get(x).setNmonValue("  ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pinSetDate")){  
	    			fieldInfo.get(x).setNmonValue("        ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pinType")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("activeIndicator")){
	    			
	    			//newIndicator1 becomes activeIndicator for 3104
	    			if(nonmonCode.equalsIgnoreCase("3104")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1519, 1520));  //newIndicator1
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nameOnInstrument")){  
	    			fieldInfo.get(x).setNmonValue("                                        ");
	    		}
                
	    		 if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("expirationDate")){
	    			 if(nonmonCode.equalsIgnoreCase("3000")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1405, 1413));
	    			 }
	    			 else{
		    				fieldInfo.get(x).setNmonValue("        ");
		    			}
	    		 }
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("lastIssueDate")){
	    			if(nonmonCode.equalsIgnoreCase("3000")){
    				   fieldInfo.get(x).setNmonValue(record.substring(1389, 1397));	
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("        ");
	    			}
    		    }
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("plasticIssueType")){
	    			if(nonmonCode.equalsIgnoreCase("3000")){
    				   fieldInfo.get(x).setNmonValue(record.substring(1519, 1520));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" ");
	    			}
    		    }
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("incentive")){
	    			
	    			//newIndicator4 becomes incentive for 3010
	    			if(nonmonCode.equalsIgnoreCase("3010")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1525, 1526));  //newIndicator4
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("currencyCode")){
	    			
	    			//newCode1 becomes status for 3102
	    			if(nonmonCode.equalsIgnoreCase("3201")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1565, 1568));  //currencyCode
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("   ");
	    			}   			
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("currencyConversionRate")){
	    			
	    			//newCode1 becomes status for 3102
	    			if(nonmonCode.equalsIgnoreCase("3201")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1568, 1581));  //currencyConversionRate
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("             ");
	    			}   			
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("creditLimit")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("overdraftLimit")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dailyPosLimit")){
	    			
	    			//newCode1 becomes status for 3102
	    			if(nonmonCode.equalsIgnoreCase("3201")){
	    				result = record.substring(1527, 1546).trim();
	    				if(result.length() > 10){
	    					result = result.substring(0, 10);
	    				}
	    				while(result.length() < 10){
	    					result = result + " ";
	    				}
	    				fieldInfo.get(x).setNmonValue(result);  //newMonetaryValue
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("          ");
	    			}   			
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dailyCashLimit")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cashbackLimitMode")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("mediaType")){
	    			if(nonmonCode.equalsIgnoreCase("3000")){
    				   fieldInfo.get(x).setNmonValue(record.substring(1521, 1522));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" ");
	    			}
    		    }
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipStatic")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipDynamic")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipVerify")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipRisk")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipIssuerAuthentication")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipCombined")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("chipSpecification")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("chipSpecVersion")){  
	    			fieldInfo.get(x).setNmonValue("   ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("offlineLowerLimit")){  
	    			fieldInfo.get(x).setNmonValue("  ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("offlineUpperLimit")){  
	    			fieldInfo.get(x).setNmonValue("  ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userIndicator01")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userIndicator02")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userCode1")){  
	    			fieldInfo.get(x).setNmonValue("   ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userCode2")){  
	    			fieldInfo.get(x).setNmonValue("   ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData01")){  
	    			fieldInfo.get(x).setNmonValue("      ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData02")){  
	    			fieldInfo.get(x).setNmonValue("      ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData03")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData04")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData05")){  
	    			fieldInfo.get(x).setNmonValue("               ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData06")){  
	    			fieldInfo.get(x).setNmonValue("                    ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData07")){  
	    			fieldInfo.get(x).setNmonValue("                                        ");
	    		}                
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
	    			if(nonmonCode.equalsIgnoreCase("3000")){
	    				fieldInfo.get(x).setNmonValue(record.substring(350, 369) + record.substring(160, 168) + record.substring(168, 174) + "000"); 
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(record.substring(241, 260) + record.substring(160, 168) + record.substring(168, 174) + "000"); 
	    			}
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
	    			fieldInfo.get(x).setNmonValue(nonmonCode);
	    		}
                
                //all other fields empty - does not work
               /** if(!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("workflow") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("dataSpecificationVersion") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("clientIdFromHeader") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("customerIdFromHeader") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("customerAcctNumber") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("status") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("panOpenDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("type") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("expirationDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("issuingCountry") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("mediaType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("plasticIssueType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("lastIssueDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("paymentInstrumentId") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("category") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("incentive") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("activeIndicator") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderPostalCode") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("dailyPosLimit") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("currencyCode") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("currencyConversionRate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
                	
                	fieldInfo.get(x).setNmonValue("   ");
                } **/
	    		
		   }//for loop ends
	   }
	   
	   /**
	    * set values for Nmon20 nmonCode 3000
	    */
	   public void setNMON20FieldValue3000(String record){
		   
		   String nonmonCode = record.substring(174,178);
		   for(int x=0; x < fieldInfo.size(); x++){
	    		
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType")){  //set recordType value to PIS12
	    			fieldInfo.get(x).setNmonValue("PIS12");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate")){  //transactionDate becomes recordCreationDate
	    			fieldInfo.get(x).setNmonValue(record.substring(160, 168));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime")){  //transactionTime becomes recordCreationTime
	    			fieldInfo.get(x).setNmonValue(record.substring(168, 174));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds")){  //recordCreationMilliseconds becomes 000
	    			fieldInfo.get(x).setNmonValue("000");
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan")){
	    				fieldInfo.get(x).setNmonValue(record.substring(350, 369));  //newPan value becomes pan
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("paymentInstrumentId")){
    				fieldInfo.get(x).setNmonValue(record.substring(369, 399));	
    		    }
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("lastIssueDate")){
    				fieldInfo.get(x).setNmonValue(record.substring(1389, 1397));	
    		    }
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("plasticIssueType")){
    				fieldInfo.get(x).setNmonValue(record.substring(1519, 1520));	
    		    }
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("mediaType")){
    				fieldInfo.get(x).setNmonValue(record.substring(1521, 1522));	
    		    }
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("issuingCountry")){
    				fieldInfo.get(x).setNmonValue(record.substring(1207, 1210));	
    		    }
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("expirationDate")){
    				fieldInfo.get(x).setNmonValue(record.substring(1405, 1413));	
    		    }
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
	    				fieldInfo.get(x).setNmonValue(record.substring(350, 369) + record.substring(160, 168) + record.substring(168, 174) + "000"); 
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
	    			fieldInfo.get(x).setNmonValue(nonmonCode);
	    		}
                
                //all other fields empty
                if(!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan") && 
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("paymentInstrumentId") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("lastIssueDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("plasticIssueType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("mediaType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("issuingCountry") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("expirationDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
                	
                	fieldInfo.get(x).setNmonValue("   ");
                }
	    		
		   }//for loop ends
	   }
	   
	   /**
	    * set values for Nmon11 depending upon 
	    */
	   public void setNMON11FieldValue(String record){
		   
		   String nonmonCode = record.substring(174,178);
		   String result = "";
		   for(int x=0; x < fieldInfo.size(); x++){
	    		
			   if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("workflow")){
	    			fieldInfo.get(x).setNmonValue(record.substring(0, 16));
	    		}
			   
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType")){  //set recordType value to PIS12
	    			fieldInfo.get(x).setNmonValue("PIS11   ");
	    		}
	    		
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dataSpecificationVersion")){
	    			fieldInfo.get(x).setNmonValue("1.1  ");
	    		}
			    
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("clientIdFromHeader")){
	    			fieldInfo.get(x).setNmonValue(record.substring(29, 45));
	    		}
			    
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate")){  //transactionDate becomes recordCreationDate
	    			fieldInfo.get(x).setNmonValue(record.substring(160, 168));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime")){  //transactionTime becomes recordCreationTime
	    			fieldInfo.get(x).setNmonValue(record.substring(168, 174));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds")){  //recordCreationMilliseconds becomes 000
	    			fieldInfo.get(x).setNmonValue("000");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("gmtOffset")){  
	    			fieldInfo.get(x).setNmonValue("      ");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("customerIdFromHeader")){
	    			fieldInfo.get(x).setNmonValue(record.substring(68, 88));
	    		}
			    
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("customerAcctNumber")){
	    			fieldInfo.get(x).setNmonValue(record.substring(88, 128));
	    		}
			    
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("externalTransactionId")){  
	    			fieldInfo.get(x).setNmonValue("                                ");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan")){
	    			if(nonmonCode.equalsIgnoreCase("3001") && !record.substring(321, 340).trim().isEmpty()){
		    			   fieldInfo.get(x).setNmonValue(record.substring(321, 340));  //newPan value becomes pan
		    			}
	    			else{
		    			fieldInfo.get(x).setNmonValue(record.substring(212, 231));  //get original pan
		    		}
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("type")){
	    				fieldInfo.get(x).setNmonValue(" "); 	
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType")){
	    			
	    			//newCode becomes subType for 3109
	    			if(nonmonCode.equalsIgnoreCase("3109")){
	    				result = record.substring(1361,1364).trim(); //newCode
	    				if(result.length() == 3){
	    					result = result.substring(0,2);
	    				}
	    				if(result.length() < 2){
	    					result = result + " ";
	    				}
	    				
	    				fieldInfo.get(x).setNmonValue(result);
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("  "); //subType empty
	    			}		
	    		}
                
              if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("category")){
	    			
	    			// becomes category for 3123
	    			if(nonmonCode.equalsIgnoreCase("3123")){
	    				result = record.substring(1361, 1364).trim();
	    				if(result.length() > 1){
	    					result = result.substring(0,1);
	    				}
	    				if(result.length() < 1){
	    					result = result + " ";
	    				}  
	    				fieldInfo.get(x).setNmonValue(result);  //newCode
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("association")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("panOpenDate")){
	    			
	    			// becomes subType for 3101
	    			if(nonmonCode.equalsIgnoreCase("3101")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1310, 1318));  //need new numbers
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("        "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("memberSinceDate")){  
 	    			fieldInfo.get(x).setNmonValue("        ");
 	    		}
                 
 	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("issuingCountry")){
 	    			if(nonmonCode.equalsIgnoreCase("3124")){ //need nonmonCode
     				   fieldInfo.get(x).setNmonValue(record.substring(1171, 1174));  //newCountryCode
 	    			}
 	    			else{
 	    				fieldInfo.get(x).setNmonValue("   ");
 	    			}
     		    }
                 
                 if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCity")){  
 	    			fieldInfo.get(x).setNmonValue("                                        ");
 	    		}
                 
                 if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderStateProvince")){  
 	    			fieldInfo.get(x).setNmonValue("     ");
 	    		}
                
                 if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderPostalCode")){
 	    			
 	    			// becomes cardholderCountryCode for 3100
 	    			if(nonmonCode.equalsIgnoreCase("3100") || nonmonCode.equalsIgnoreCase("3121")){
 	    				fieldInfo.get(x).setNmonValue(record.substring(1161, 1171));  //need new numbers
 	    			}
 	    			else{
 	    				fieldInfo.get(x).setNmonValue("          ");
 	    			}		
 	    		}
                 
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode")){
	    			
	    			//newCountryCode becomes cardholderCountryCode for 3100 and 3122
	    			if(nonmonCode.equalsIgnoreCase("3100") || nonmonCode.equalsIgnoreCase("3122")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1171,1174));
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("   "); //cardholderCountryCode empty
	    			}		
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("numberOfPaymentIds")){  
                	if(nonmonCode.equalsIgnoreCase("3003")){
	    				result = record.substring(1406, 1414).trim();
	    				if(result.length() > 3){
	    					result = result.substring(0,3);
	    				}
	    				if(result.length() < 2){
	    					result = result + "  ";
	    				}
	    				
	    				fieldInfo.get(x).setNmonValue(result);
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("   "); //numberOfPaymentIds empty
	    			}		
	    		}
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("paymentInstrumentId")){
	    				fieldInfo.get(x).setNmonValue("                              ");
    		    }
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("status")){
	    			
	    			//newCode becomes status for 3102
	    			if(nonmonCode.equalsIgnoreCase("3102")){
	    				result = record.substring(1361, 1364).trim();
	    				if(result.length() > 2){
	    					result = result.substring(0,2);
	    				}
	    				if(result.length() < 1){
	    					result = result + " ";
	    				}  
	    				fieldInfo.get(x).setNmonValue(result);  //newCode
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("  "); //status empty
	    			}   			
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("statusDate")){
	    			if(nonmonCode.equalsIgnoreCase("3102")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1310, 1318));  //date2
	    			}
	    			else{
	    			    fieldInfo.get(x).setNmonValue("        ");
	    			}
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pinLength")){  
	    			fieldInfo.get(x).setNmonValue("  ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pinSetDate")){  
	    			fieldInfo.get(x).setNmonValue("        ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pinType")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("activeIndicator")){
	    			
	    			// becomes activeIndicator for 3104
	    			if(nonmonCode.equalsIgnoreCase("3104")){
	    				fieldInfo.get(x).setNmonValue("Y");
	    			}
	    			else if(nonmonCode.equalsIgnoreCase("3114")){
	    				fieldInfo.get(x).setNmonValue("N");
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nameOnInstrument")){  
	    			fieldInfo.get(x).setNmonValue("                                        ");
	    		}
                
	    		 if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("expirationDate")){
	    			 if(nonmonCode.equalsIgnoreCase("3105")){
	    				fieldInfo.get(x).setNmonValue(record.substring(1310, 1318));  //date2
	    			 }
	    			 else{
		    				fieldInfo.get(x).setNmonValue("        ");
		    			}
	    		 }
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("lastIssueDate")){
	    			if(nonmonCode.equalsIgnoreCase("3103")){
    				   fieldInfo.get(x).setNmonValue(record.substring(1310, 1318));	 //date2
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue("        ");
	    			}
    		    }
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("plasticIssueType")){  //only need 1 byte
	    			if(nonmonCode.equalsIgnoreCase("3103")){
	    				result = record.substring(1361, 1364).trim();
	    				if(result.length() > 1){
	    					result = result.substring(0,1);
	    				} 
	    				if(result.length() == 0){
	    					result = " ";
	    				}
	    				fieldInfo.get(x).setNmonValue(result);  //newCode
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" ");
	    			}
    		    }
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("incentive")){
	    			
	    			// becomes incentive for 3115
	    			if(nonmonCode.equalsIgnoreCase("3115")){
	    				result = record.substring(1361, 1364).trim();
	    				if(result.length() > 1){
	    					result = result.substring(0,1);
	    				} 
	    				if(result.length() == 0){
	    					result = " ";
	    				}
	    				fieldInfo.get(x).setNmonValue(result);  //newCode
	    			}
	    			else{
	    				fieldInfo.get(x).setNmonValue(" "); 
	    			}		
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("currencyCode")){
	    				fieldInfo.get(x).setNmonValue("   ");			
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("currencyConversionRate")){
	    				fieldInfo.get(x).setNmonValue("             "); 			
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("creditLimit")){
                	if(nonmonCode.equalsIgnoreCase("3201")){
                		result = record.substring(1377, 1390).trim();
	    				if(result.length() > 10){
	    					result = result.substring(0,10);
	    				} 
	    				if(result.length() < 10){
	    					while(result.length() < 10){
	    						result = result + " ";
	    					}
	    				}
	    				fieldInfo.get(x).setNmonValue(result); 
                	}
                    else{
	    			fieldInfo.get(x).setNmonValue("          ");
                    }
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("overdraftLimit")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dailyPosLimit")){
	    				fieldInfo.get(x).setNmonValue("          "); 			
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dailyCashLimit")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("dailyLimitType")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("mediaType")){
	    				fieldInfo.get(x).setNmonValue(" ");
    		    }
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipStatic")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipDynamic")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipVerify")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipRisk")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipIssuerAuthentication")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("aipCombined")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("chipSpecification")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("chipSpecVersion")){  
	    			fieldInfo.get(x).setNmonValue("   ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("offlineLowerLimit")){  
	    			fieldInfo.get(x).setNmonValue("  ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("offlineUpperLimit")){  
	    			fieldInfo.get(x).setNmonValue("  ");
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userIndicator01")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userIndicator02")){  
	    			fieldInfo.get(x).setNmonValue(" ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userCode1")){  
	    			fieldInfo.get(x).setNmonValue("   ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userCode2")){  
	    			fieldInfo.get(x).setNmonValue("   ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData01")){  
	    			fieldInfo.get(x).setNmonValue("      ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData02")){  
	    			fieldInfo.get(x).setNmonValue("      ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData03")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData04")){  
	    			fieldInfo.get(x).setNmonValue("          ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData05")){  
	    			fieldInfo.get(x).setNmonValue("               ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData06")){  
	    			fieldInfo.get(x).setNmonValue("                    ");
	    		}
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("userData07")){  
	    			fieldInfo.get(x).setNmonValue("                                        ");
	    		}                
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
	    				fieldInfo.get(x).setNmonValue(record.substring(212, 231) + record.substring(160, 168) + record.substring(168, 174) + "000");  //get original pan
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
	    			fieldInfo.get(x).setNmonValue(nonmonCode);
	    		}
	    		           
                //all other fields empty
               /** if(!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan") && 
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("status") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
                	
                	fieldInfo.get(x).setNmonValue("   ");
                }**/
	    		
		   }//for loop ends
	   }
	   
	   /**
	    * set values for Nmon11 nmonCode 3001
	    */
	   public void setNMON11FieldValue3001(String record){
		   
		   String nonmonCode = record.substring(174,178);
		   for(int x=0; x < fieldInfo.size(); x++){
	    		
			    if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType")){  //set recordType value to PIS12
	    			fieldInfo.get(x).setNmonValue("PIS11");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate")){  //transactionDate becomes recordCreationDate
	    			fieldInfo.get(x).setNmonValue(record.substring(160, 168));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime")){  //transactionTime becomes recordCreationTime
	    			fieldInfo.get(x).setNmonValue(record.substring(168, 174));
	    		}
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds")){  //recordCreationMilliseconds becomes 000
	    			fieldInfo.get(x).setNmonValue("000");
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan")){
	    				fieldInfo.get(x).setNmonValue(record.substring(321, 340));  //newPan value becomes pan
	    		}
	    		
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType")){
	    				fieldInfo.get(x).setNmonValue("   "); //subType empty	
	    		}
                
                if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode")){
	    				fieldInfo.get(x).setNmonValue("   "); //cardholderCountryCode empty	
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("status")){
	    				fieldInfo.get(x).setNmonValue("   "); //status empty 			
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime")){
	    				fieldInfo.get(x).setNmonValue(record.substring(321, 340) + record.substring(160, 168) + record.substring(168, 174) + "000");  //newPan value becomes pan
	    		}
	    		
	    		if(fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
	    			fieldInfo.get(x).setNmonValue(nonmonCode);
	    		}
	    		           
                //all other fields empty
                if(!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pan") && 
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationDate") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationTime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("recordCreationMilliseconds") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("status") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("cardholderCountryCode") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("subType") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("pandatetime") &&
                		!fieldInfo.get(x).getFieldName().equalsIgnoreCase("nonmonCode")){
                	
                	fieldInfo.get(x).setNmonValue("   ");
                }
	    		
		   }//for loop ends
	   }
	   
	   //override default toString(); want to use this toString() method
	   @Override
		public String toString(){
	    	
			String results = fieldInfo.get(0).getValue(); //get the first RollingObj value
			
			for(int x = 1; x < fieldInfo.size(); x++){
				
			   //separated by tab delimiter
			   results = results + "," + fieldInfo.get(x).value;	//want the last string is value not tab
				
			}
			return results;
		}
	   
	   /**
	     * create a row to return 
	     * @return row
	     */
	    public Row getRow(){
	    	Row row = null;
	    	try{
	    		row = RowFactory.create(fieldInfo.get(0).getValue(),
	    				fieldInfo.get(1).getValue(),
	    				fieldInfo.get(2).getValue(),
	    				fieldInfo.get(3).getValue(),
	    				fieldInfo.get(4).getValue(),
	    				fieldInfo.get(5).getValue(),
	    				fieldInfo.get(6).getValue(),
	    				fieldInfo.get(7).getValue(),
	    				fieldInfo.get(8).getValue(),
	    				fieldInfo.get(9).getValue(),
	    				fieldInfo.get(10).getValue(),
	    				fieldInfo.get(11).getValue(),
	    				fieldInfo.get(12).getValue(),
	    				fieldInfo.get(13).getValue(),
	    				fieldInfo.get(14).getValue(),
	    				fieldInfo.get(15).getValue(),
	    				fieldInfo.get(16).getValue(),
	    				fieldInfo.get(17).getValue(),
	    				fieldInfo.get(18).getValue(),
	    				fieldInfo.get(19).getValue(),
	    				fieldInfo.get(20).getValue(),
	    				fieldInfo.get(21).getValue(),
	    				fieldInfo.get(22).getValue(),
	    				fieldInfo.get(23).getValue(),
	    				fieldInfo.get(24).getValue(),
	    				fieldInfo.get(25).getValue(),
	    				fieldInfo.get(26).getValue(),
	    				fieldInfo.get(27).getValue(),
	    				fieldInfo.get(28).getValue(),
	    				fieldInfo.get(29).getValue(),
	    				fieldInfo.get(30).getValue(),
	    				fieldInfo.get(31).getValue(),
	    				fieldInfo.get(32).getValue(),
	    				fieldInfo.get(33).getValue(),
	    				fieldInfo.get(34).getValue(),
	    				fieldInfo.get(35).getValue(),
	    				fieldInfo.get(36).getValue(),
	    				fieldInfo.get(37).getValue(),
	    				fieldInfo.get(38).getValue(),
	    				fieldInfo.get(39).getValue(),
	    				fieldInfo.get(40).getValue(),
	    				fieldInfo.get(41).getValue(),
	    				fieldInfo.get(42).getValue(),
	    				fieldInfo.get(43).getValue(),
	    				fieldInfo.get(44).getValue(),
	    				fieldInfo.get(45).getValue(),
	    				fieldInfo.get(46).getValue(),
	    				fieldInfo.get(47).getValue(),
	    				fieldInfo.get(48).getValue(),
	    				fieldInfo.get(49).getValue(),
	    				fieldInfo.get(50).getValue(),
	    				fieldInfo.get(51).getValue(),
	    				fieldInfo.get(52).getValue(),
	    				fieldInfo.get(53).getValue(),
	    				fieldInfo.get(54).getValue(),
	    				fieldInfo.get(55).getValue(),
	    				fieldInfo.get(56).getValue(),
	    				fieldInfo.get(57).getValue(),
	    				fieldInfo.get(58).getValue(),
	    				fieldInfo.get(59).getValue(),
	    				fieldInfo.get(60).getValue(),
	    				fieldInfo.get(61).getValue(),
	    				fieldInfo.get(62).getValue(),
	    				fieldInfo.get(63).getValue(),
	    				fieldInfo.get(64).getValue(),
	    				fieldInfo.get(65).getValue(),  //added pandatetime field
	    				fieldInfo.get(66).getValue());	//added nonmonCode field	    		
	    	}catch(Exception e){e.printStackTrace();}
	    	return row;
	    }   
}
