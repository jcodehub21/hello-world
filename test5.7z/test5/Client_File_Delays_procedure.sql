
--iDelayGap is the number of days the user inputs
SELECT /*+ RESULT_CACHE */ client, portfolio, recClass, recordtype, notes, reclen, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (iDelayGap + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass, reclen, notes, recordtype) rn
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date, t.notes, t.reclen, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND (c.primary_internal_contact LIKE pOwner||'%' OR c.secondary_internal_contact LIKE pOwner||'%' OR DataMan.vIs_Admin = 'Y')
                      )
                 WHERE set_interval IS NULL OR set_interval > 0
                 GROUP BY client, portfolio, recClass, recordtype, notes, reclen
                 HAVING (COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(iDelayGap + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                        OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0
                 ORDER BY client, portfolio, recClass, reclen, notes, recordtype;

--------------------------------------- 
SELECT f.client, f.portfolio, recClass, file_date, t.notes, t.reclen, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND (c.primary_internal_contact LIKE pOwner||'%' OR c.secondary_internal_contact LIKE pOwner||'%' OR DataMan.vIs_Admin = 'Y');
------------------------------------------- 
select L.client, L.portfolio, L.recClass, L.delivery_interval, L.set_interval from (SELECT f.client, f.portfolio, recClass, file_date, t.notes, t.reclen, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND (c.primary_internal_contact LIKE 'Ezra'||'%' OR c.secondary_internal_contact LIKE 'Spencer'||'%')) L, client_hdfs_destinations d
                           where L.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS') and L.client = d.client AND L.portfolio = d.portfolio and hdfsdestid = 5;
---------------------------------------------------------------------------------------------------------------------------------------  
--substituted iDelayGap = 10, pOwner = Ezra and Spencer
--used below query in MPB client delayed report
SELECT /*+ RESULT_CACHE */ primary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date, primary_internal_contact,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND c.product = 'MPB'
                      )
                 WHERE set_interval IS NULL OR set_interval > 0
                  GROUP BY primary_internal_contact, client, portfolio, recClass
                  HAVING (COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                        OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0
                -- ORDER BY client, portfolio, recClass
                 UNION
       SELECT /*+ RESULT_CACHE */ secondary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date, secondary_internal_contact,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND c.product = 'MPB'
                      )
                 WHERE set_interval IS NULL OR set_interval > 0
                 GROUP BY secondary_internal_contact, client, portfolio, recClass
                 HAVING (COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                        OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0
                 ORDER BY client, portfolio, recClass;
        
--modified version of MPB report on 11/14/2021
--see below 01/24/2023 for updated query to use
SELECT primary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       ROUND(AVG(delivery_interval)) del_interval,
                       TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                       from (SELECT f.client, f.portfolio, recClass, t.recordtype, primary_internal_contact, file_date,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND c.product = 'MPB')
                          WHERE delivery_interval > 0
                          GROUP BY primary_internal_contact, client, portfolio, recClass
                         HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14)
                         AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3)
                         UNION
                         SELECT secondary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       ROUND(AVG(delivery_interval)) del_interval,
                       TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                       from (SELECT f.client, f.portfolio, recClass, t.recordtype, secondary_internal_contact, file_date,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND c.product = 'MPB')
                          WHERE delivery_interval > 0
                          GROUP BY secondary_internal_contact, client, portfolio, recClass
                         HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14)
                         AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3)
                         ORDER BY client desc, portfolio, recClass;
                         
------------------------------------------------------------------------------------------------------------------------------------------
--1/23/2023:  trying to add the client_decom_data_feeds table to the query to not retrieve old recordtypes

SELECT client, portfolio, recordtype FROM client_decom_data_feeds_old where client = 'fis-WLD-f6';

--to insert client with decom recordtype
insert into client_decom_data_feeds values ('fis-CAP-f6', 'none', 959);

--below query to find the clients that are not in the client_decom_data_feeds table works
select distinct x.client, x.portfolio, x.recordtype from files x where (x.client, x.portfolio, x.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds) order by x.client;

--below query you can see which recordtype the query is picking up for client barclaycard-f6(credit)
SELECT f.client, f.portfolio, t.recClass, t.recordtype, c.primary_internal_contact, f.file_date,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM (select * from files x where (x.client, x.portfolio, x.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds)) f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND t.recClass = 'ADAP'
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND c.product = 'MPB'
                           AND c.client = 'barclaycard-f6';

--01/24/2023:  Below is the udpated query to include the client_decom_data_feeds table to exclude no longer recordtype used
--In procedure Report.ClientFileDelays in the main SELECT SQL you will see line AND (f.client, f.portfolio, f.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds)
--03/05/2024 Anton changed the table client_decom_data_feeds to client_decom_data_feeds_old because he no longer uses it but I kept it in my query below
--use the below query in MBP clients delayed report
SELECT primary_internal_contact, client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       ROUND(AVG(delivery_interval)) del_interval,
                       TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                       from (SELECT f.client, f.portfolio, t.recClass, f.recordtype, c.primary_internal_contact, f.file_date,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM (select * from files x where (x.client, x.portfolio, x.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds_old)) f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND c.product = 'MPB')
                           WHERE delivery_interval > 0
                          GROUP BY primary_internal_contact, client, portfolio, recClass
                         HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14)
                         AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3);
------------------------------------------------------------------------------------------------------------------------------------------ 
--03/06/2023:  use below query for AWS Delayed delivery report; includes the client_decom_data_feeds table to exclude no longer recordtype used
--03/05/2024 Anton changed his AWS delayed delivery report by changing the table client_decom_data_feeds to client_decom_data_feeds_old
-- Anton also took out client_decom_data_feeds_old table from his code and change the subquery to below by adding Data.is_number(key_value) = 1
-- SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype AND Data.is_number(key_value)=1) set_interval
-- He also increased the aging off months to less than 6:  example: MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 6

SELECT client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery, ROUND(AVG(delivery_interval)) grace_period,
TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,
COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn FROM (SELECT f.client, f.portfolio, recClass, file_date,
TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
(SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval 
FROM (select * from files x where (x.client, x.portfolio, x.recordtype) NOT IN (SELECT client, portfolio, recordtype FROM client_decom_data_feeds_old)) f, recordtypes t, client c WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0') 
AND f.recordtype NOT IN (-1, 41, 114) AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1' 
AND EXISTS (SELECT 1 FROM client_hdfs_destinations d, hdfsdestinations h WHERE d.enabled = 'Y' AND d.client=f.client AND d.portfolio=f.portfolio 
AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid = 5 AND t.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS'))) a 
WHERE delivery_interval > 0 GROUP BY client, portfolio, recClass HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14) 
AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 7) ORDER BY client desc, portfolio, recClass;


SELECT client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND EXISTS (SELECT 1 FROM client_hdfs_destinations d, hdfsdestinations h
                                         WHERE d.enabled = 'Y' AND d.client=f.client AND d.portfolio=f.portfolio
                                           AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid = 5
                                           AND t.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS'))
                      ) a
                 WHERE set_interval IS NULL OR set_interval > 0
                  GROUP BY client, portfolio, recClass
                  HAVING ((COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                        OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0) AND (MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3)
                ORDER BY client desc, portfolio, recClass;
                
                
--to insert client and record type into the client_decom_data_feeds table:
insert into client_decom_data_feeds values ('ts2_2420-f6', 'none', 835);


--below query gets the correct average delivery_interval for client hlbb-f6 (none)
--I used the below query in AWS clients in my report to Caroline 10/13/2021; order client desc because my linklist head was pointing to the last record

SELECT client, portfolio, recClass, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       ROUND(AVG(delivery_interval)) del_interval,
                       TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass) rn
                       from (SELECT f.client, f.portfolio, recClass, t.recordtype, file_date,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio 
                           AND c.status = 'A' 
                           AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                         -- AND c.client = 'hlbb-f6' AND c.portfolio = 'none'
                           --AND c.client in (select client from client cl where cl.status = 'A')
                           AND EXISTS (SELECT 1 FROM client_hdfs_destinations d, hdfsdestinations h
                                         WHERE d.enabled = 'Y' AND d.client=f.client AND d.portfolio=f.portfolio
                                           AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid = 5
                                           AND t.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS')))L
                                           
                          --WHERE set_interval IS NULL OR set_interval > 0
                          WHERE delivery_interval > 0
                          GROUP BY client, portfolio, recClass
                         HAVING (COUNT(*) > 4 AND (TRUNC(SYSDATE) - (TRUNC(MAX(file_date)) + ROUND(AVG(delivery_interval))) > 14)
                         AND MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3)
                         ORDER BY client desc, portfolio, recClass;
                
--below query to use in AWS clients with delayed file delivery report only for Caroline; don't use this one
SELECT client, portfolio, recClass, recordtype, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (14 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass, recordtype) rn
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND EXISTS (SELECT 1 FROM client_hdfs_destinations d, hdfsdestinations h
                                         WHERE d.enabled = 'Y' AND d.client=f.client AND d.portfolio=f.portfolio
                                           AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid = 5
                                           AND t.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS'))
                      ) a
                 WHERE set_interval IS NULL OR set_interval > 0
                  GROUP BY client, portfolio, recClass, recordtype
                  HAVING ((COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(14 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                        OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0) AND (MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3)
                ORDER BY client, portfolio, recClass, recordtype;
                
--below AWS query also works by me
SELECT client, portfolio, recClass, recordtype, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       --TRUNC(SYSDATE) - TRUNC(MAX(file_date)) AS last_file,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (14 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass, recordtype) rn
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND f.client in (SELECT d.client FROM files f, client_hdfs_destinations d, hdfsdestinations h
                                         WHERE d.enabled = 'Y' AND d.client=f.client AND d.portfolio=f.portfolio
                                           AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid = 5
                                           group by d.client, d.portfolio)
                          AND t.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS')
                      ) a
                 WHERE set_interval IS NULL OR set_interval > 0
                 GROUP BY client, portfolio, recClass, recordtype
                 HAVING ((COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(14 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                          OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0)
                        AND (MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3) /* Ignore if older than 3 months */
                 ORDER BY client, portfolio, recClass;

------------------------------------------------------------------------------------------------------------  
--below AWS query from Anton's 
SELECT client, portfolio, falcon_customer_id, recClass, recordtype, notes, 
                       reclen, TO_CHAR(MAX(file_date),'YYYY-MM-DD') last_delivery,
                       NVL(MAX(set_interval), 1 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) grace_period,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) AS last_file,
                       TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - NVL(MAX(set_interval),
                                                                    (14 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval)))) past_due,
                       COUNT(*) OVER (PARTITION BY client, portfolio) rows_per_client,
                       ROW_NUMBER() OVER (PARTITION BY client, portfolio ORDER BY recClass, reclen, notes, recordtype) rn,
                       (SELECT short_name FROM client_hdfs_destinations d, hdfsdestinations h
                         WHERE d.enabled = 'Y' AND d.client=a.client AND d.portfolio=a.portfolio AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid=3) AS AWS3,
                       (SELECT short_name FROM client_hdfs_destinations d, hdfsdestinations h
                         WHERE d.enabled = 'Y' AND d.client=a.client AND d.portfolio=a.portfolio AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid=5) AS AWS5
                  FROM
                      ( SELECT f.client, f.portfolio, recClass, file_date, t.notes, t.reclen, t.recordtype, c.falcon_customer_id,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1'
                           AND EXISTS (SELECT 1 FROM client_hdfs_destinations d, hdfsdestinations h
                                         WHERE d.enabled = 'Y' AND d.client=f.client AND d.portfolio=f.portfolio
                                           AND d.hdfsdestid=h.hdfsdestid AND d.hdfsdestid = 5
                                           AND t.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS'))
                      ) a
                 WHERE set_interval IS NULL OR set_interval > 0
                 GROUP BY client, portfolio, falcon_customer_id, recClass, recordtype, notes, reclen
                 HAVING ((COUNT(*) > 4 AND MAX(set_interval) IS NULL AND TRUNC(SYSDATE) - TRUNC(MAX(file_date)) -(14 + ROUND(AVG(delivery_interval)) + ROUND(STDDEV(delivery_interval))) > 0)
                          OR
                        (TRUNC(SYSDATE) - TRUNC(MAX(file_date)) - MAX(set_interval)) > 0)
                        AND (MONTHS_BETWEEN(SYSDATE, MAX(file_date)) < 3) /* Ignore if older than 3 months */
                 ORDER BY client, portfolio, recClass, reclen, notes, recordtype;
    
------------------------------------------------------------------------------------------------------------  
--below partial query works with client_hdfs_destinations for AWS
select L.client, L.portfolio, L.recClass, L.delivery_interval, L.set_interval from (SELECT f.client, f.portfolio, recClass, file_date, t.notes, t.reclen, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1') L, client_hdfs_destinations d
                           where L.recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS') and L.client = d.client AND L.portfolio = d.portfolio and hdfsdestid = 5;
----------------------------------------------------------------------------------------------------------------------------  

SELECT f.client, f.portfolio, recClass, file_date, t.notes, t.reclen, t.recordtype,
                                TRUNC(file_date) - TRUNC(LAG(file_date) OVER (PARTITION BY f.client, f.portfolio, f.recordtype ORDER BY file_date)) delivery_interval,
                               (SELECT key_value FROM client_data_setup s WHERE flag = 'C' AND s.client = f.client AND s.portfolio = f.portfolio AND s.recordtype = f.recordtype) set_interval
                          FROM files f, recordtypes t, client c, client_hdfs_destinations d
                         WHERE f.recordtype = t.recordtype AND file_date > SYSDATE-365*2 AND f.status IN ('D','M','0')  /* AND recClass <> 'Other'*/
                           AND f.recordtype NOT IN (-1, 41, 114)
                           AND f.client = c.client AND f.portfolio = c.portfolio AND c.status = 'A' AND inventory# NOT LIKE 'S%' AND f.project_id='1' and recClass IN ('CRTRAN_Auth','DBTRAN_Auth', 'FRD','NMON','PIS') and c.client = d.client AND c.portfolio = d.portfolio and hdfsdestid = 5;
------------------------------------------------------------------------------------------------------------
select product from client where client = 'ts1_AE-f6';

update client set product = 'MPB' where client in ('ts1_AE-f6', 'ts1_C1-f6', 'ts1_C4-f6', 'ts1_C8-f6', 'ts1_CB-f6', 'ts1_CE-f6');