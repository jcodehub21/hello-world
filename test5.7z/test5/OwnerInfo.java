package jc.lambda.util;

import java.util.HashMap;
import java.util.Map;

/**
 * 03/18/2024 - this class stores fico:common:owner name, each month's cost, and total for each month
 */
public class OwnerInfo {
    String ownerName;
    Map<String, Double> monthCost = new HashMap<String, Double>();
    //total for each owner or each row
    double total = 0.00;

    public OwnerInfo(){}
    public OwnerInfo(String name){
        ownerName = name;
    }
    public OwnerInfo(String name, String month, String year, String cost){
        ownerName = name;
        setMonthCost(month, year, cost);
    }
    public void setOwnerName(String name){
        ownerName = name;
    }

    public void setMonthCost(String month, String year, String cost){
        double d = Math.round(Double.parseDouble(cost) * 100.0)/100.0;
        monthCost.put(CalendarOps.getMonthName(month) + year, d);
        setTotal(d);
    }

    public void setTotal(Double d){
        total = Math.round((total + d)*100.0)/100.0;
    }

    public String getOwnerName(){return ownerName;}
    public String getTotal(){return String.valueOf(total);}
    public Map<String, Double> getMonthCost(){return monthCost;}
}
