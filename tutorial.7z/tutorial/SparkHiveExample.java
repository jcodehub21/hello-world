import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.List;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
//import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
//import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
//import org.apache.spark.sql.types.StructType;
/**
 * 05/13/2021 Test spark 3.0.1 enableHiveSupport() in TA ATR cluster
 * https://jaceklaskowski.gitbooks.io/mastering-spark-sql/content/spark-sql-hive-metastore.html
 * https://sparkbyexamples.com/apache-hive/connect-to-hive-using-jdbc-connection/
 * https://spark.apache.org/docs/latest/sql-data-sources-hive-tables.html
 * https://spark.apache.org/docs/3.2.0/sql-data-sources-hive-tables.html
 * https://spark.apache.org/docs/latest/sql-ref-syntax-ddl-create-table-hiveformat.html
 * https://kontext.tech/article/294/spark-save-dataframe-to-hive-table
 * https://stackoverflow.com/questions/37433986/how-to-load-data-into-hive-external-table-using-spark
 * https://stackoverflow.com/questions/42261701/how-to-create-hive-table-from-spark-data-frame-using-its-schema
 * 
 * on SHK:
 * export JAVA_HOME=/ptoan/dms_staging/parquet/jdk1.8.0_231
 * export SPARK_HOME=/ptoan/shared/opt/spark/spark-3.2.1-bin-without-hadoop
 * export PATH=$SPARK_HOME/bin:$JAVA_HOME/bin:$PATH
 * spark3-submit --master yarn --deploy-mode client --driver-memory 8g --executor-memory 16g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --class SparkHiveExample /home/janecheng/SparkHive.jar /user/janecheng/sparkhivedata.txt /user/janecheng/sparkhive/ > /home/janecheng/sparkhivetest.log 2>&1 &
 * @author JaneCheng
 *
 */
public class SparkHiveExample implements Serializable{

	private static final long serialVersionUID = 1L;
	SparkSession spark = null;
	Dataset<Row> df = null;
	static BufferedReader br = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	List<StructField> fields = null; //store the mapper file two columns
	StructType mapperSchema = null;
	
	public static void main(String[] args){
		//args[0] = action: cp = createParquet; lp = loadParquetIntoHive; lc = loadCSVIntoHive
		//args[1] = input data file eg csv or parquet
		//args[2] = input schema file with field names
		//args[3] = hdfs destination for creating parquet file
		SparkHiveExample test = new SparkHiveExample();
		test.createSparkSession();
        switch(args[0]){
        case "cp":
        	test.createParquet(args);
        	break;
        case "lp":
        	test.loadParquetIntoHive(args);
        	break;
        case "dt":
        	test.dropTable(args);
        	break;
        case "dd":
        	test.dropDatabase(args);
        	break;
        case "xt":
        	test.createExternalTable(args);
        	break;
        default:
        	test.loadCSVIntoHive(args);
        	break;
        }		
	}
	
	public void createSparkSession(){
       try{
			/**
			 * sparkConf.set("spark.speculation", "false");
             * sparkConf.set("spark.hadoop.mapreduce.map.speculative", "false");
             * sparkConf.set("spark.hadoop.mapreduce.reduce.speculative", "false")
			 */
			spark = SparkSession
				  .builder()
				  .appName("Spark Hive Test")
				 // .master("local")
				  //spark.sql.warehouse.dir = hive.metastore.directory.external;  default = hive.metastore.directory = /warehouse/tablespace/managed/hive
				  //.config("spark.sql.warehouse.dir", "hdfs://nameservice1/warehouse/tablespace/external/hive")
				  .config("spark.sql.warehouse.dir", "hdfs://nameservice1/user/janecheng/sparkhive")
				  .config("spark.debug.maxToStringFields", 2000)
		  		  .config("spark.sql.debug.maxToStringFields", 4000)
		  		  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  		  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  		  .config("parquet.enable.summary-metadata", "false")  //gets rid of .crc files after parquet
				  .enableHiveSupport()  //to test if can use hive sql and communicate with hive tables
				  .getOrCreate();
			if(spark != null){
				
				System.out.println("Successfully enable hive support");
			}
			 conf = new Configuration();
		     fs = FileSystem.get(conf);
			//df = spark.read().format("text").load("file:///ptoan/telecom8/IDMv15_RetuningPOC/GID_15.0_FFM_finalRelease/devel_out/v15_TF_FRD_Scale_CP/06_prescale_B4/prescale.15nordea_000-1.a1.b4CustomFilter.gz");
			//System.out.println("First row value: " + df.select("value").first().mkString());
		}
		catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * spark3-submit --master yarn --deploy-mode client --driver-memory 8g --executor-memory 16g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --class SparkHiveExample /home/janecheng/SparkHive.jar dt jane2 janetable > /home/janecheng/sparkhivetest_droptable_02092023.log 2>&1 &
	 * @param args
	 * dropTable worked
	 */
	public void dropTable(String[] args){
		try{
			//args[0] = action
			//args[1] = database name
			//args[2] = table name
			spark.sql("DROP TABLE IF EXISTS " + args[1] + "." + args[2]);
			System.out.println(args[2] + " dropped");
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 *  spark3-submit --master yarn --deploy-mode client --driver-memory 8g --executor-memory 16g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --class SparkHiveExample /home/janecheng/SparkHive.jar dd jane2 > /home/janecheng/sparkhivetest_dropdatabase_02092023.log 2>&1 &
	 * @param args
	 * dropDatabase worked
	 */
	public void dropDatabase(String[] args){
		try{
			//args[0] = action
			//args[1] = database name
			spark.sql("DROP DATABASE IF EXISTS " + args[1]);
			System.out.println(args[1] + " dropped");
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * spark3-submit --master yarn --deploy-mode client --driver-memory 8g --executor-memory 16g --conf spark.network.timeout=10000001 --conf spark.executor.memoryOverhead=2048 --conf spark.kryoserializer.buffer.max=1024 --conf spark.rpc.message.maxSize=2047 --conf spark.driver.maxResultSize=3g --conf spark.executor.heartbeatInterval=10000000 --conf spark.sql.debug.maxToStringFields=4000 --class SparkHiveExample /home/janecheng/SparkHive.jar lp /user/janecheng/sparkhive/part-00000-62665da3-f24c-4b86-94bb-00b9c8967c47-c000.gz.parquet > /home/janecheng/sparkhivetest_loadparquet_b_02092023.log 2>&1 &
	 * @param args
	 */
	public void loadParquetIntoHive(String[] args){
		
		try{  //args[0] = action
			  //args[1] = full path of parquet file
			
			// Create database at hdfs://nameservice1/warehouse/tablespace/external/hive
		    spark.sql("CREATE DATABASE IF NOT EXISTS jane2");
		   
			df = spark.read().parquet(args[1]);
			//org.apache.spark.sql.AnalysisException: CREATE EXTERNAL TABLE must be accompanied by LOCATION
			String query = "CREATE TABLE IF NOT EXISTS jane2.janetable (";
			String fieldquery = "";
			StructType schema = df.schema();
			for(String fieldname : schema.fieldNames()){
				fieldquery = fieldquery + fieldname + " STRING, ";
			}
			fieldquery = fieldquery.substring(0, fieldquery.lastIndexOf(","));
			//query = query + fieldquery + ") STORED AS PARQUET LOCATION '" + args[1] + "'";
			
			//CREATE TABLE src(id int) USING hive OPTIONS(fileFormat 'parquet')
			//query = query + fieldquery + ") USING hive";  //this worked when creating table at hdfs://nameservice1/warehouse/tablespace/external/hive
			
			query = query + fieldquery + ") STORED AS PARQUET";  //this worked without the EXTERNAL TABLE
			System.out.println("query: " + query);
			spark.sql(query);  //spark.sql cannot create external tables in hive when you already specify the spark.sql.warehouse.dir at hive.metastore.directory.external location
			
			df.write()
			  .format("parquet")
			  .mode("overwrite")
			  .option("compression","gzip")
			  .saveAsTable("jane2.janetable"); //this works if using create table instead of create external table
			
			
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	/**
	 * change spark.sql.warehouse.dir to hdfs://nameservice1/user/janecheng/sparkhive
	 */
	public void createExternalTable(String[] args){
		try{
			  //args[0] = action
			  //args[1] = parquet file to load to get schema
			  //args[2] = directory of where you want to store table
		    spark.sql("CREATE DATABASE IF NOT EXISTS jane3");
		   
			df = spark.read().parquet(args[1]);
			//org.apache.spark.sql.AnalysisException: CREATE EXTERNAL TABLE must be accompanied by LOCATION
			String query = "CREATE TABLE IF NOT EXISTS jane3.janetable (";
			String fieldquery = "";
			StructType schema = df.schema();
			for(String fieldname : schema.fieldNames()){
				fieldquery = fieldquery + fieldname + " STRING, ";
			}
			fieldquery = fieldquery.substring(0, fieldquery.lastIndexOf(","));
			
			/**
			 * MetaException(message:Got exception: org.apache.hadoop.fs.FileAlreadyExistsException Path is not a directory: 
			 * /user/janecheng/sparkhive/part-00000-62665da3-f24c-4b86-94bb-00b9c8967c47-c000.gz.parquet
			 */
			query = query + fieldquery + ") STORED AS PARQUET LOCATION '" + args[2] + "'";

			System.out.println("query: " + query);
			spark.sql(query);  
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void loadCSVIntoHive(String[] args){
		try{
			//br = new BufferedReader(new InputStreamReader(fs.open(new Path(args[0]))));
			//String header = br.readLine();
			//if(header != null && header.contains(",")){
			//	String[] fields = header.split(",");
				//create table only if you want to insert data into table manually
				//spark.sql("CREATE EXTERNAL TABLE IF NOT EXISTS janetable(" + fields[0] + " STRING, " + fields[1] + " STRING, " + fields[2] + " STRING, " + fields[3] + " STRING) STORED AS PARQUET LOCATION '" + args[1] + "'");
		//	}
			
			// Create database at hdfs://nameservice1/warehouse/tablespace/external/hive
			//spark.sql("CREATE DATABASE IF NOT EXISTS jane_db");
			
			//create database at the specify location
			spark.sql("CREATE DATABASE IF NOT EXISTS janetest_db LOCATION '/user/janecheng/sparkhive/'");
			
			//create table only if you want to insert data into table manually
		//	spark.sql("CREATE EXTERNAL TABLE IF NOT EXISTS janetest_db.janetable(id STRING, date STRING, time STRING, amount STRING) STORED AS PARQUET LOCATION '/user/janecheng/ts2_8167-f6.debit.nmon11.202001.7703513.gz.parquet'");
			
			//below created the hive table 'hdfs://nameservice1/warehouse/tablespace/external/hive/jane_db/testtable' but in regular file; not parquet
			/**df.write()
			  .format("hive")
			  .mode("overwrite")
			  .option("compression","gzip")
			  .saveAsTable("jane_db.testtable");**/
		
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void createParquet(String[] args){
		try{
			br = new BufferedReader(new InputStreamReader(fs.open(new Path(args[2]))));
			String header = br.readLine();
			if(header != null && header.contains(",")){
				String[] fieldnames = header.split(",");
				
				//mapper fields and schema is fixed so only need to define once
				// Store the StruckField object into a List
				fields = new ArrayList<>();		
				for(String name: fieldnames){
					fields.add(DataTypes.createStructField(name, DataTypes.StringType, true));
				}
				mapperSchema = DataTypes.createStructType(fields);
				
				df = spark.read().format("csv")
						.schema(mapperSchema)
						.option("delimiter", ",")  //using comma delimiter to separate the data so don't need to create FieldObj
					  //  .option("header", "true")
					  //  .option("inferSchema", "true")
					    .load(args[1]);
				
			    df.repartition(1)
			        .write()
				  //.format("parquet")
				    .mode("overwrite")
				    .option("compression","gzip")
				  //.option("path", args[1]) //this will save the external table to your location
				  //.insertInto("janetest_db.janetable");
				    .parquet(args[3]);
			}
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	
}
