import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.Path;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.catalyst.encoders.RowEncoder;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.joda.time.LocalDateTime;


/**
 * 11/29/2021 - This class does two things for client Bancolumbia-f6:
 * 1. Take first 9 bytes from �CLIENT ID PLUS SERVICE ID AND �� as the official BIN and use it to replace the first 9 bytes of PAN 
 * 2. Hash the last 10 bytes from �CLIENT ID PLUS SERVICE ID AND �� after the first 9 bytes if unencrypted 
 * @author JaneCheng
 *
 */
public class BanColumbiaPAN implements Serializable{

	private static final long serialVersionUID = 1L;
	static BufferedReader br = null;
	static BufferedWriter bw = null;
	SparkSession spark = null;
	Dataset<Row> pis = null;
	StructType textSchema = null;
	StructType pisSchema = null;
	RecordTypeMapper<FieldObj> fieldObj = null;
	static Configuration conf = null;
	static FileSystem fs = null;
	static FileStatus[] list_files = null;
	List<StructField> fields = null; //store the mapper file two columns
	String pattern = "^part-.+\\.bz2$"; 
	static Pattern filePattern = null; 
	static Matcher m = null; //match the pattern of part-m-#### files only
	String dfPath = "";  //lux432 temporary work area = /Anton/jyc_temp/akbank-f6/none/
	String tempSparkDir = "";
	static Path newDFPath = null;
	static Path temp = null;
	String processedDate = "";
	String yymm = ""; //date period to fix
	String fileid = "";
	String recordtype = "";
	static File file = null;
	String databaseFile = "";
	
	public static void main(String[] args){
		String content = "";
		try{
			BanColumbiaPAN driver = new BanColumbiaPAN(args[1], args[2], args[3], args[4]);
			driver.startSparkSession();
			BufferedReader brMain = new BufferedReader(new FileReader(args[0]));
			while((content = brMain.readLine()) != null){
				   driver.fixFile(content);
			   }
			if(brMain != null){brMain.close();}
			driver.closeAll();
		}catch(Exception e){e.printStackTrace();}
	}
	
	public BanColumbiaPAN(String dfPath, String temp, String date, String dbFile){
		this.dfPath = dfPath;
		tempSparkDir = temp;
		processedDate = date;
		databaseFile = dbFile;
		
	}
	public void startSparkSession(){
		spark = SparkSession.builder()
				.appName("Bancolumbia-F6 PAN fix")
				.config("spark.debug.maxToStringFields", 2000)
				.config("parquet.summary.metadata.level", "NONE")
				.config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  	    .config("dfs.client.read.shortcircuit.skip.checksum", "true")
				.getOrCreate();
		
		spark.sparkContext().setLogLevel("ERROR");
		
		//create the PIS12 schema since they are all the same
		//store FieldObj into RecordTypeMapper so can separate the value
	    //in the text file into table columns
		fieldObj = new RecordTypeMapper<FieldObj>();
		fieldObj.addFieldObj(new FieldObj("filler1", 0, 278));
		fieldObj.addFieldObj(new FieldObj("clientID", 278, 335));  //client id plus service id 
		fieldObj.addFieldObj(new FieldObj("filler2", 335, 1901));
		fieldObj.addFieldObj(new FieldObj("pan", 1901, 1920));
		fieldObj.addFieldObj(new FieldObj("filler3", 1920, 2305));
		
		//create the schema for the PIS file
		fields = new ArrayList<>();	
		for(FieldObj f : fieldObj.getFieldObjList()){
			
			fields.add(DataTypes.createStructField(f.fieldName, DataTypes.StringType, true));
		}
		
		pisSchema = DataTypes.createStructType(fields);
 
		 //Text data source supports only a single column, and you have 3 columns.
		//create the schema for the new text file
		textSchema = DataTypes.createStructType(new StructField[]{DataTypes.createStructField("value", DataTypes.StringType, true)});
		
		System.out.println("Created pisSchema and textSchema");
		try{
			 bw = new BufferedWriter(new FileWriter(dfPath + databaseFile, true));
			 conf = new Configuration();
		     fs = FileSystem.get(conf);
		     if(!tempSparkDir.equalsIgnoreCase("null")){
		         temp = new Path(tempSparkDir);
				   if(!fs.exists(temp)){
					 fs.mkdirs(temp);  //create an empty one
				   }
		     }
			}catch(Exception e){e.printStackTrace();}
	}
	

	public void fixFile(String filename){
		
		try{
			System.out.println("inside fixFile method: original file: " + filename + " " + LocalDateTime.now());
		    String[] metadata = filename.substring(filename.lastIndexOf("/") + 1).split("\\.");
		    this.yymm = metadata[0];
		    this.recordtype = metadata[3];
		    this.fileid = metadata[4];
		    
		    
		  //newDFPath = new Path("/Anton/jyc_temp/bancolombia-f6/none/"); //lux432
		   newDFPath = new Path(dfPath + recordtype + "/" + yymm + "/" + fileid + "/");
		     
			if(fs.exists(newDFPath))
		      {
		    	 fs.delete(newDFPath, true);
		      }
		      
			pis = spark.read()
				      .format("text")
				      .option("inferSchema", false)
				      .option("header", "false")
				      .load(filename);  
			System.out.println("Loaded pis file complete");
			
			/**
			    * Encoder.String() returns Dataset<String>
			    * RowEncoder.apply(StructType schema) returns Dataset<Row>
			    * MapFunction<Input, Output>
			    */
			   pis = pis.map((MapFunction<Row, Row>) row -> {
				   fieldObj.setFieldValueBancolumbia(row.mkString());
				   return fieldObj.getRow();
			   }, RowEncoder.apply(pisSchema));
			  
			   System.out.println("set field value for pan and clientID complete");
			   
			 //have to reselect the columns to be in the correct order:  filler1, clientID, filler2, pan, filler3 so can be written out to text file
			pis = pis.select(pis.col("filler1"), pis.col("clientID"), pis.col("filler2"), pis.col("pan"), pis.col("filler3"));
			
			//convert back from three columns to one column so can write in text file
			   pis = pis.map(row -> {
					  return RowFactory.create(row.mkString());				  
				  }, RowEncoder.apply(textSchema));
			   
			   System.out.println("Start writing text file to " + newDFPath + " : " + LocalDateTime.now());
			   //write back out as text file
			   pis.coalesce(1)
				            .write()
				            .format("text")
				            .option("compression", "bzip2")  //.option("compression","bzip2")
				            .mode("overwrite")
				            .save(newDFPath.toString());
			   
				  System.out.println("finished writing text file to " + newDFPath + " : " + LocalDateTime.now());
				  
				//change the new text file name back to original filename
					// Create a Pattern object
			  		  filePattern = Pattern.compile(pattern);
			  		    
			  		  list_files = fs.listStatus(newDFPath);
			  		  
			  		for(FileStatus oldFilePath : list_files){
				    	
		    	           m = filePattern.matcher(oldFilePath.getPath().getName());
		    	           if(m.matches()){
		    	        	   //fs.rename also moved the new filename to another path
		    	        	   //System.out.println("Rename result: " + fs.rename(oldFilePath.getPath(), new Path(filePath)));
		    	        	   if(FileUtil.copy(fs,oldFilePath.getPath(),fs,new Path(filename),false,true,conf)){
		    	        		  fs.delete(new Path(dfPath + recordtype + "/" + yymm + "/" + fileid), true);
		    	        		  file = new File(filename);
		    	        		  bw.write("update filestorage set filesize = " + file.length() + " where fileid = " + fileid + " and filestatus = 'O' and filetype = 'O';");
		    	        		  bw.newLine();
		    	        		  bw.write("insert into manual_changes values ('" + fileid + "', DATE '" + processedDate + "', 'bancolumbia-f6(none) pan fix', 'JaneCheng');");
		    	        		  bw.newLine();
		    	        		   System.out.println("mapped and moved " + oldFilePath.getPath() + " back to " + filename);  
		    	        	   }
		    	        	   
		    	           }
		    	        }	  		
			   
		}catch(Exception e){e.printStackTrace();}
		
	}
	
	public void closeAll(){
		try{
			if(br != null){
				br.close();
			}
			if(bw != null){
				bw.close();
			}
		}catch(Exception e){e.printStackTrace();}
	}

}
