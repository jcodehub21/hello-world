import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;


public class Fix_rhlhddfrd200_2004_files {

	public static void main(String[] args) {
		
		Fix_rhlhddfrd200_2004_files test = new Fix_rhlhddfrd200_2004_files();
		//test.writeCorrectFilesRhldatdms14002();
		//test.writeCondorUsers();
		//test.writeCSVPaths();
		//test.listForDirectory();
		test.analyzeMappedFiles(args[0], args[1]);
		//test.removeSparkTempDirs();
		//test.extractFileIDs();
		//test.selectStatements();
          //test.deleteHDFSdirectory();
		//test.deleteHDFS1801();
		//test.moveScotiaFiles();
		//test.findCCSProblemChild(args[0], args[1], args[2]); //input file, word to find, output file
	}
	
	public void writeCorrectFiles(){  //this is for /Anton/jyc_temp
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		String hdfs = "/hdfsTA/data/parquet_falcon/";
		String[] data = null;
		
		try{
			fileToRead = new File("C:\\software\\Parquet_Project\\read_anton_jyc_temp_files_08252020.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\Parquet_Project\\cp_rhlhddfrd200_2004_files_part10.sh"));
			br = new BufferedReader(new FileReader(fileToRead));
			bw.write("#!/bin/bash");
			bw.newLine();
			while((read = br.readLine()) != null){
				
				//when split with / the first data[0] index is a blank space
				data = read.split("/");
                //got java.lang.ArrayIndexOutOfBoundsException: 3 because had empty lines at the end of the read file
			/**	for(int x = 0; x < data.length; x++){
					
					System.out.println("Data " + x + " = " + data[x]);
				}**/
				bw.write("mv " + read + "/*.parquet " + hdfs + data[3] + "/" + data[4] + "/" + data[5] + "/" + data[6] + "/" + data[3] + "." + data[4] + "." + data[5] + ".202004." + data[7] + ".gz.parquet");
				bw.newLine();
				//bw.write("rm -r " + read);
				//bw.newLine();
				
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	//this is for /ana/mds/prd/data/files
	public void writeCorrectFilesRhldatdms14002(){
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		String hdfs = "/hdfsTA/data/parquet_falcon/";
		String[] data = null;
		
		try{
			fileToRead = new File("C:\\software\\Parquet_Project\\read_rhldatdms14002_2004_files.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\Parquet_Project\\rm_rhldatdms14002_2004_files_part1.sh"));
			br = new BufferedReader(new FileReader(fileToRead));
			bw.write("#!/bin/bash");
			bw.newLine();
			while((read = br.readLine()) != null){
				
				//when split with / the first data[0] index is a blank space
				data = read.split("/");
                //got java.lang.ArrayIndexOutOfBoundsException: 3 because had empty lines at the end of the read file
				//bw.write("mv " + read + "/*.parquet " + hdfs + data[6] + "/" + data[7] + "/" + data[8] + "/" + data[9] + "/" + data[6] + "." + data[7] + "." + data[8] + ".202004." + data[10] + ".gz.parquet");
				//bw.newLine();
				bw.write("rm -r " + read);
				bw.newLine();
				
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	//rename tsv files from temp back to original at /mds_files68/tsv
	public void writeTSVFiles(){  //this is for /Anton/jyc_temp
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		String[] inputs = null;
		//String tsvPath = "/ptoan/dms_staging/tsv/";
		
		try{
			fileToRead = new File("C:\\software\\usbank_mapping\\usbank_credit_frddatabase12222024a_damaged.txt");
			//fileToRead = new File("/export/home/janecheng/2008CRCFiles.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\usbank_mapping\\usbank_credit_frddatabase12222024a_update2.txt"));
			//bw = new BufferedWriter(new FileWriter("/export/home/janecheng/remove2008CRCFiles.sh"));
			br = new BufferedReader(new FileReader(fileToRead));
			bw.write("#!/bin/bash");
			bw.newLine();
			while((read = br.readLine()) != null){
				System.out.println(read);
				//System.out.println(read.indexOf("temp"));
				//inputs = read.substring(read.indexOf("/")).split("/");
				
				//bw.write("mv " + read.substring(read.indexOf("/")) + " " + "/hdfsTA/data/parquet_falcon/" + inputs[4] + "/" + inputs[5] + "/" + inputs[6] + "/" + inputs[7] + "/" + read.substring(read.lastIndexOf("/")+ 1));
				//bw.write("hdfs dfs -mv " + read.substring(read.indexOf("/")) + " " + read.substring(read.indexOf("/"), read.lastIndexOf("temp")) + read.substring(read.lastIndexOf("temp") + 5));
				//bw.write("cp " + read.substring(read.indexOf("/")) + " /ptoan/shared/hadoop/spark-3.0.1-bin-without-hadoop/jars");
				//bw.write("mv " + read + " " + read.substring(0,read.lastIndexOf("ascii")) + "ascii.old.bz2");
				//bw.write(read.substring(0,read.lastIndexOf("ascii")) + "ascii.old.bz2");
				//bw.write("ln -s " + read + " " + read.substring(0, read.indexOf("ABSA")) + "ABSA-F6/NONE/" + read.substring(read.lastIndexOf("/") - 4));
				/**if(read.contains("update")){
					bw.write(read.substring(0, read.indexOf("where") - 1) + ",filestatus = 'O' " + read.substring(read.indexOf("where")));
					bw.newLine();
				}
				else{
					bw.write(read);
					bw.newLine();
				}**/
				//bw.newLine();
				//bw.write("rm " + read);
				//bw.write("hdfs dfs -get " + read.substring(read.indexOf("/")) + " /ptoan/frd04/aml/SinoPac_1.0/data/raw/consortium");
				fileToRead = new File(read.substring(0, read.indexOf("bz2")) + ".old.bz2");
				if(!fileToRead.exists()){
					bw.write(read);
					bw.newLine();
				}							
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	public void analyzeMappedFiles(String fileName, String outputFileName){  //this is for RHEL
		File fileToRead = null;
		File analyzeFile = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		
		try{
			fileToRead = new File(fileName);
			bw = new BufferedWriter(new FileWriter(outputFileName));
			br = new BufferedReader(new FileReader(fileToRead));
			while((read = br.readLine()) != null){
				analyzeFile = new File(read.substring(0, read.indexOf("bz2")) + ".old.bz2");
				if(!analyzeFile.exists()){
					bw.write(read);
					bw.newLine();
				}							
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	/**
	 * remove all the blockmgr and spark directories under the spark temp location
	 */
	public void removeSparkTempDirs(){  //this is for /Anton/jyc_temp
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		//String tsvPath = "/ptoan/dms_staging/tsv/";
		
		try{
			fileToRead = new File("C:\\fmt-client\\sinopac\\sparkblocktempdirectories.txt");
			//fileToRead = new File("/export/home/janecheng/2008CRCFiles.txt");
			bw = new BufferedWriter(new FileWriter("C:\\fmt-client\\sinopac\\rm_sparkblocktempdirectories.txt"));
			//bw = new BufferedWriter(new FileWriter("/export/home/janecheng/remove2008CRCFiles.sh"));
			br = new BufferedReader(new FileReader(fileToRead));
			bw.write("#!/bin/bash");
			bw.newLine();
			while((read = br.readLine()) != null){
				System.out.println(read);
                if(read.indexOf("block") > 1){
                	bw.write("rm -r /opt/amapps/spark-3.2.1-bin-hadoop3.2/temp/" + read.substring(read.indexOf("block")));
                }
                else if(read.indexOf("spark") > 1){
                	bw.write("rm -r /opt/amapps/spark-3.2.1-bin-hadoop3.2/temp/" + read.substring(read.indexOf("spark")));
                }
                else{
                	continue;
                }
				
				bw.newLine();
				
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	//delete hdfs clients under /data/parquet_falcon and data/raw_falcon
		public void deleteHDFSdirectory(){  
			File fileToRead = null;
			BufferedReader br = null;
			BufferedWriter bw = null;
			String read = "";
			
			try{
				fileToRead = new File("C:\\software\\Parquet_Project\\Parquet_Project_ATR\\dms_inactive_clients.txt");
				bw = new BufferedWriter(new FileWriter("C:\\software\\Parquet_Project\\Parquet_Project_ATR\\deleteInactiveClientsBP.sh"));
				br = new BufferedReader(new FileReader(fileToRead));
				bw.write("#!/bin/bash");
				bw.newLine();
				while((read = br.readLine()) != null){
					System.out.println(read);
					//bw.write("hdfs dfs -rm -r /data/raw_falcon/" + read);
					//bw.newLine();
					bw.write("hdfs dfs -rm -r /data/parquet_falcon/" + read);
					bw.newLine();
					
				}
				bw.close();
				br.close();
				
			}
			catch(Exception e){
				
				e.printStackTrace();
			}
		}
		
		//delete hdfs 1801 directory under /data/parquet_falcon
				public void deleteHDFS1801(){  
					File fileToRead = null;
					BufferedReader br = null;
					BufferedWriter bw = null;
					String read = "";
					String path = "";
					
					try{
						fileToRead = new File("C:\\fmt-client\\edward\\BP_fraud_tagging_2000.txt");
						bw = new BufferedWriter(new FileWriter("C:\\fmt-client\\edward\\edwardfraudtaggingcopyBP.sh"));
						br = new BufferedReader(new FileReader(fileToRead));
						bw.write("#!/bin/bash");
						bw.newLine();
						while((read = br.readLine()) != null){
							System.out.println(read);
							if(read.indexOf("/") < 0  || read.indexOf("SUCCESS") > 0){
								continue;
							}
							read = read.substring(read.indexOf("/"), read.lastIndexOf("/"));
							if(!path.equalsIgnoreCase(read)){
								path = read;
								//bw.write("hdfs dfs -rm -r " + read);
								bw.write("hadoop distcp hdfs://rhlhdmfrd204:8020" + path + "/20* hdfs://rhldatdms22004:8020" + path);
								bw.newLine();
							}
							else{
								continue;
							}
						}
						bw.close();
						br.close();
						
					}
					catch(Exception e){
						
						e.printStackTrace();
					}
				}
	
	public void extractFileIDs(){
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		String[] inputs = null;
		//String tsvPath = "/ptoan/dms_staging/tsv/";
		
		try{
			fileToRead = new File("C:\\software\\Parquet_Project\\Parquet_Project_ATR\\ts1_E4_markAsTest.txt");
			//fileToRead = new File("/export/home/janecheng/2008CRCFiles.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\Parquet_Project\\Parquet_Project_ATR\\SQL_Update_ts1_E4.txt"));
			//bw = new BufferedWriter(new FileWriter("/export/home/janecheng/remove2008CRCFiles.sh"));
			br = new BufferedReader(new FileReader(fileToRead));
            bw.write("update files set status = '4' where fileid in (");
			while((read = br.readLine()) != null){
				System.out.println(read);
                inputs = read.substring(read.lastIndexOf("/") + 1).split("\\.");
				bw.write(inputs[4] + ",");
				
			}
			bw.write(")");
			bw.newLine();
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	public void moveScotiaFiles(){
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bwcis = null;
		BufferedWriter bwpis = null;
		BufferedWriter bwais = null;
		BufferedWriter bwnmon = null;
		BufferedWriter bwfrd = null;
		BufferedWriter bwcrtran = null;
		
		String read = "";
		String[] inputs = null;
		
		try{
			fileToRead = new File("C:\\fmt-client\\scotia-f6\\scotia-f6_all_files2.txt");
			//fileToRead = new File("/export/home/janecheng/2008CRCFiles.txt");
			bwcis = new BufferedWriter(new FileWriter("C:\\fmt-client\\scotia-f6\\scotia-f6_cis2.txt"));
			bwpis = new BufferedWriter(new FileWriter("C:\\fmt-client\\scotia-f6\\scotia-f6_pis2.txt"));
			bwais = new BufferedWriter(new FileWriter("C:\\fmt-client\\scotia-f6\\scotia-f6_ais2.txt"));
			bwnmon = new BufferedWriter(new FileWriter("C:\\fmt-client\\scotia-f6\\scotia-f6_nmon2.txt"));
			bwfrd = new BufferedWriter(new FileWriter("C:\\fmt-client\\scotia-f6\\scotia-f6_frd2.txt"));
			bwcrtran = new BufferedWriter(new FileWriter("C:\\fmt-client\\scotia-f6\\scotia-f6_crtran2.txt"));
			
			br = new BufferedReader(new FileReader(fileToRead));
            
			while((read = br.readLine()) != null){
				System.out.println(read);
                inputs = read.substring(read.lastIndexOf("/") + 1).split("\\.");
                if(inputs[3].contains("cis")){
                	bwcis.write(read);
                	bwcis.newLine();
                }
                else if(inputs[3].contains("pis")){
                	bwpis.write(read);
                	bwpis.newLine();
                }
                else if(inputs[3].contains("ais")){
                	bwais.write(read);
                	bwais.newLine();
                }
                else if(inputs[3].contains("nmon")){
                	bwnmon.write(read);
                	bwnmon.newLine();
                }
                else if(inputs[3].contains("frd")){
                	bwfrd.write(read);
                	bwfrd.newLine();
                }
                else{  //crtran
                	bwcrtran.write(read);
                	bwcrtran.newLine();
                }
				
				
			}
			bwcis.close();
			bwais.close();
			bwpis.close();
			bwfrd.close();
			bwnmon.close();
			bwcrtran.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	public void selectStatements(){
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		String inputs = "";
		//String tsvPath = "/ptoan/dms_staging/tsv/";
		
		try{
			fileToRead = new File("C:\\software\\RollingPIS\\nmon20.txt");
			//fileToRead = new File("/export/home/janecheng/2008CRCFiles.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\RollingPIS\\SQL_select.txt"));
			//bw = new BufferedWriter(new FileWriter("/export/home/janecheng/remove2008CRCFiles.sh"));
			br = new BufferedReader(new FileReader(fileToRead));
            bw.write("select ");
			while((read = br.readLine()) != null){
				System.out.println(read);
                inputs = read.substring(read.lastIndexOf("(") + 2, read.lastIndexOf('"'));
				bw.write(inputs + ",");
				
			}
			bw.write(" from ");
			bw.newLine();
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
	}
	
	
	//check on hdfsTA directory only once
	public void listForDirectory(){
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		String temp = "";
		String[] inputs = null;
		//String tsvPath = "/ptoan/dms_staging/tsv/";
		
		try{
			fileToRead = new File("C:\\software\\Parquet_Project\\Parquet_Project_ATR\\removeParquet.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\Parquet_Project\\Parquet_Project_ATR\\checkDirectory.txt"));
			br = new BufferedReader(new FileReader(fileToRead));
			//bw.write("#!/bin/bash");
			//bw.newLine();
			while((read = br.readLine()) != null){
				//System.out.println(read);
				//System.out.println(read.indexOf("temp"));
				inputs = read.substring(read.lastIndexOf("/") + 1).split("\\.");  //need to escape the period in order to split based on period
				if(!temp.equalsIgnoreCase(inputs[0] + "." + inputs[1] + "." + inputs[2] + "." + inputs[3])){
				//bw.write("mv " + tsvPath + read + " " + tsvPath + read.substring(0, read.indexOf("temp")) + read.substring(read.indexOf("temp") + 5));
				//bw.write("hdfs dfs -mv " + read + " " + read.substring(0, read.indexOf("temp")) + read.substring(read.indexOf("temp") + 5));
				bw.write("/hdfsTA/data/parquet_falcon/" + inputs[0] + "/" + inputs[1] + "/" + inputs[2] + "/" + inputs[3].substring(2));
				bw.newLine();
				}
				temp = inputs[0] + "." + inputs[1] + "." + inputs[2] + "." + inputs[3];
				//bw.write("rm -r " + read);
				//bw.newLine();
				
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}
		
	}
	//remove all the extra details in front of Nissan and Ally hdfs paths
	public void writeCSVPaths(){
		File fileToRead = null;
		BufferedReader br = null;
		BufferedWriter bw = null;
		String read = "";
		try{
			fileToRead = new File("C:\\software\\StrategyDirectorProject\\test_file\\ally_need_csv_paths.txt");
			bw = new BufferedWriter(new FileWriter("C:\\software\\StrategyDirectorProject\\test_file\\ally_csv_paths.txt"));
			br = new BufferedReader(new FileReader(fileToRead));
			while((read = br.readLine()) != null){
				bw.write(read.substring(read.lastIndexOf("/") + 1));
				bw.newLine();				
			}
			bw.close();
			br.close();
			
		}
		catch(Exception e){
			
			e.printStackTrace();
		}	
		
	}
	
	//only get user's name for condor jobs submitted - logs at /opt/condor/local/ViewHist
	//to remove duplicates on linux machine, use this command:  sort -u mnappmb21_users_01192021.log > mnappmb21_users_01192021.txt
	//sort -u works if your log file only contains the user's names
		public void writeCondorUsers(){
			File fileToRead = null;
			BufferedReader br = null;
			BufferedWriter bw = null;
			String read = "";
			String[] username;
			try{
				fileToRead = new File("C:\\software\\condor\\condor_users_list\\mnappmb41_users.log");
				bw = new BufferedWriter(new FileWriter("C:\\software\\condor\\condor_users_list\\mnappmb41_users_01192021.log"));
				br = new BufferedReader(new FileReader(fileToRead));
				while((read = br.readLine()) != null){
					
					username = read.split("\t");
					bw.write(username[1].substring(0,username[1].indexOf(".com") + 4));
					bw.newLine();				
				}
				bw.close();
				br.close();
				
			}
			catch(Exception e){
				
				e.printStackTrace();
			}
			
			
		}
		
		public void findCCSProblemChild(String filename, String wordToFind, String output){
			try{
				String content = "";
				String[] columns; 
				int count = 1;
				BufferedWriter bw = new BufferedWriter(new FileWriter(output));
				BufferedReader br = new BufferedReader(new FileReader(filename));
				while((content = br.readLine()) != null){
					if(content.contains("solutionid")){
					    columns = content.split(",");
					    for(String column : columns){
					    	System.out.println(column + " - " + count);
					    	count++;
					    }
					}
					/**if(content.contains(wordToFind))
					{
						bw.write(content);
						bw.newLine();
					}**/
					if(!content.contains("US2")){
						bw.write(content);
						bw.newLine();
					}
				}
				br.close();
				bw.close();
				
			}catch(Exception e){
				
				e.printStackTrace();
			}
		}

}

