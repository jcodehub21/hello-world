import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.DataTypes;

import scala.reflect.ClassTag;

/**
 * 04/14/2025: this class determines if using RollingPISv2 or RollingPISLIst class
 * http://www.mtitek.com/tutorials/bigdata/spark/spark-shell.php
 * https://stackoverflow.com/questions/27717379/spark-how-to-run-spark-file-from-spark-shell
 * RHEL:
 * echo $(date +'%m/%d/%Y' --date='-1 day') => 05/27/2025
 * echo $(date +'%m/%d/%Y' --date='1 day')  => 05/29/2025
 * echo $(date +'%m/%d/%Y' --date='day')    => 05/29/2025
 * 
 * 
 * https://docs.cloudera.com/runtime/7.3.1/spark-upgrade/topics/spark-application-migration.html
 * https://docs.cloudera.com/cdp-private-cloud-base/7.3.1/spark-upgrade/topics/ug_spark_717-323.html
 * @author JaneCheng
 *
 */
public class RolingPISFactory implements Serializable{
	private static final long serialVersionUID = 1L;
	String client = "";
	String portfolio = "";
	String datePeriod = "";
	String rollupPeriod = "";
	String parentOutputDir = "";
	String clientConfigFilename = "";
	String action = "";
	static Path clientOutputDir = null;
	static Configuration config = new Configuration();
	static FileSystem fs;
	static FileStatus[] listDirs = null; 
	SparkSession spark = null;
	Dataset<Row> clientConfig = null;
	Dataset<Row> clientRT = null;
	Dataset<Row> clientData = null;
	boolean hasMultiRT = false;  //client has pis11 and pis12 OR same record type with different lengths
	List<Row> rtData = null;
	RollingPISv3 rollingpisv3 = null;
	//RollingPISList rollingpislist = null;
	RollingPISListv3 rollingpislist = null;
	long counter = 0;
	String todayYYMM = "";
	int missingRT = 0;
	Broadcast<NmonBroadcast> nmbc = null;
	UDF1<String, Boolean> userdefinedfunction = null;
	String udfName = "checkValidDate";
	String clientTemp = ""; //check if we are still processing current client or the next client in the client list
	StringBuffer sb = new StringBuffer();
	String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
	String endTable = "</table>";
	Connection conn = null;
	ResultSet rs = null;
	Statement st = null;
	String addFixes = "n";
	 
	/**
	 * args[0] = client record type configuration file location on NFS ie /ptoan/dms_staging/parquet/rollingPISClientConf.csv
	 * args[1] = parent output directory to check client
	 * args[2] = file containing all client code to update or rollup ie /ptoan/dms_staging/parquet/rollingPISClientList.txt
	 * args[3] = roll up period
	 * check /data/hive_falcon if it already have current_PIS folder with yymm or need to start roll-up
	 */

	public static void main(String args[]){ 
		 RolingPISFactory driver = new RolingPISFactory();
		 driver.createSparkSession();
		 driver.uploadClientRecordType(args[0]);
		 driver.readFile(args);
		 driver.sendEmail();
	}
	
	public RolingPISFactory(){}
	
	public RolingPISFactory(String args[]){
		client = args[0];
		portfolio = args[1];
		parentOutputDir = args[2];
		rollupPeriod = args[3];
		clientOutputDir = new Path(parentOutputDir + "/" + client + "/" + portfolio + "/current_PIS");
		clientConfigFilename = args[3];
				//+ LocalDateTime.now().getMonth().getValue();
	}
	
	public void connectDB(){
		try{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	        conn = DriverManager.getConnection("jdbc:oracle:thin:@rhldatdms22001:1521/MDWP3.WORLD", "mdw", "mdw");  //05/25/2022 database migrated to SHK
		  }
		  catch(Exception e){e.printStackTrace();System.exit(-1);}
	}
	
	public void readFile(String[] args){
		String content = "";
		String[] data = null;
		try{
			System.out.println("Start: RollingPISFactory.readFile()");
			sb.append("Log file: /ptoan/dms_staging/parquet_logs/RollingPIS_Monthly_Job_rhldmsprd002-45001_" + LocalDate.now() + ".log <br><br>");
			sb.append("Rolling PIS for " + todayYYMM + ": <br>");			
    		sb.append(beginTable);
	        sb.append("<tr><td><b>Client</b></td><td><b>Portfolio</b></td><td><b>Recclass</b></td><td><b>YYMM</b></td><td><b>Date Updated</b></td></tr>");
			parentOutputDir = args[1];
			BufferedReader br = new BufferedReader(new FileReader(args[2]));
			rollupPeriod = args[3];
			if(args[4].equalsIgnoreCase("none")){
				todayYYMM = String.valueOf(LocalDateTime.now().getYear()).substring(2) + (LocalDateTime.now().getMonth().getValue() < 10 ? "0" + String.valueOf(LocalDateTime.now().getMonth().getValue()) : LocalDateTime.now().getMonth().getValue());
			}else{
				todayYYMM = args[4];
			}
			while((content = br.readLine()) != null){
				data = content.split(",");
				client = data[0];
				portfolio = data[1];
				addFixes = data[2];
				clientOutputDir = new Path(parentOutputDir + "/" + client + "/" + portfolio + "/current_PIS");
				System.out.println("Start Rolling PIS for client: " + client + "(" + portfolio + ")");
				System.out.println("Client output directory: " + clientOutputDir);
				initializeClient();
				analyzeDatePeriod();
			}
			rs = CommonUtil.queryDBForReport();
			while(rs.next()){
			   sb.append("<tr><td>").append(rs.getString(1)).append("</td><td>").append(rs.getString(2)).append("</td>");
			   sb.append("<td>").append(rs.getString(3)).append("</td><td>").append(rs.getString(4)).append("</td>");
			   sb.append("<td>").append(rs.getString(5)).append("</td></tr>");
		    }
			sb.append(endTable);
			br.close();			
			if(conn != null){
			     conn.close();
			}
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void initializeClient(){
		Row row = null;
		try{
			System.out.println("Start: RollingPISFactory.initializeClient()");
		    clientRT = clientConfig.select("*").where("client == \'" + client + "\' AND portfolio == \'" + portfolio + "\'");
			rtData = clientRT.collectAsList();
			counter = clientRT.count();
			if(counter > 1){				
				hasMultiRT = true;
				//rollingpislist = new RollingPISList(client, portfolio, parentOutputDir);
				rollingpislist = new RollingPISListv3(client, portfolio, parentOutputDir, addFixes);
				rollingpislist.processFromPISFactory(spark, nmbc);
				System.out.println("Initialized RollingPISList object for " + client + "(" + portfolio + ")");
			}
			else{
				hasMultiRT = false;
				rollingpisv3 = new RollingPISv3(client, portfolio, parentOutputDir, addFixes);
				rollingpisv3.processFromPISFactory(spark, nmbc);
				row = rtData.get(0);
				rollingpisv3.setRecordTypes(new String[]{row.get(2).toString(), row.get(3).toString(), row.get(4).toString(), row.get(5).toString(), row.get(6).toString(), row.get(7).toString()});
				System.out.println("Initialized RollingPISv3 object for " + client + "(" + portfolio + ")");
			}
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	//@SuppressWarnings("unchecked")
	public void analyzeDatePeriod(){
		//check client in /data/hive_falcon/<client>/<portfolio>/current_PIS to see if need rollup or update
		try{
			System.out.println("Start: RollingPISFactory.analyzeDatePeriod()");
			FileStatus[] dirStatus = null;
			String lastYYMM = "";	
	        
			if(!fs.exists(clientOutputDir)){
		    	fs.mkdirs(clientOutputDir);
		    	System.out.println("No client output directory found.  Created output directory at " + LocalDateTime.now());
			}
		    if(fs.exists(clientOutputDir)){
		    	dirStatus = fs.listStatus(clientOutputDir);
		    	if(dirStatus.length > 0){
		    	   //sort FileStatus object by getPath method in descending order
        		   //Arrays.sort(T, Comparator.comparing(Class::method).reversed())
        		   Arrays.sort(dirStatus, Comparator.comparing(FileStatus::getPath).reversed());
        		   lastYYMM = dirStatus[0].getPath().toString().substring(dirStatus[0].getPath().toString().lastIndexOf("/") + 1);
        		   if(lastYYMM != null){
        		     if(!lastYYMM.isEmpty()){
        		      while(Integer.parseInt(lastYYMM) < Integer.parseInt(todayYYMM)){ //removed todayYYMM for testing one month
        		         System.out.println("Found the latest folder at: " + clientOutputDir + "/"+ lastYYMM);
        		         //if last period is in December yy12, then update month is yy01
        		         if(lastYYMM.substring(2, 4).equalsIgnoreCase("12")){
        			        datePeriod = String.valueOf(Integer.parseInt(lastYYMM.substring(0, 2)) + 1) + "01"; 
        			        lastYYMM = String.valueOf(Integer.parseInt(lastYYMM.substring(0, 2)) + 1) + "01";         			     
        		         }
        		         else{
        			        datePeriod = String.valueOf(Integer.parseInt(lastYYMM) + 1);
        			        lastYYMM = String.valueOf(Integer.parseInt(lastYYMM) + 1);
        		         }
        		         action = "u";
        		         System.out.println("Start Update: " + datePeriod);
        		         if(hasMultiRT){
        		    	     rollingpislist.dateFolder = datePeriod;
        		    	     rollingpislist.action = action;
        		         }
        		         else{
        		    	     rollingpisv3.dateFolder = datePeriod;
        		    	     rollingpisv3.action = action;
        		         }
        		         analyzeData();
        		         analyzeAction();
        		         //sb.append("<tr><td>").append(client + " (" + portfolio + ")").append("</td><td>").append(datePeriod).append("</td></tr>");
        		       }
        		     }
        		   }
		    	}
        		else{ //need rollup to 2301
        			datePeriod = rollupPeriod;
        			action = "r";
        			System.out.println("Start Rollup for : " + client + ": YYMM: "+ datePeriod);
        			if(hasMultiRT){
      		    	  rollingpislist.dateFolder = datePeriod;
      		    	  rollingpislist.action = action;
      		        }
      		        else{
      		    	  rollingpisv3.dateFolder = datePeriod;
      		    	  rollingpisv3.action = action;
      		        }
                    //only need to analyze action because no data collected yet
        			//sb.append("<tr><td>").append(client + " (" + portfolio + ")").append("</td><td>2301</td></tr>");
        			analyzeAction();
        			analyzeDatePeriod();
        			
        		}
		    }
		}catch(Exception e){e.printStackTrace();}
	}
	
    public void createSparkSession(){		
		try{
			  System.out.println("Start: RollingPISFactory.createSparkSession()");
		  	  spark = SparkSession
		  			  .builder()
		  			 // .appName(client + "(" + portfolio + ") PISRollup")
		  			  .appName("PISRollup Automation Test")
		  			  .config("spark.dynamicAllocation.enabled", "false")
		  			  .config("spark.locality.wait.node", 0)  //added in to change spark locality
		  			  .config("spark.locality.wait.executor", 0)
		  			  .config("spark.debug.maxToStringFields", 2000)
		  			  .config("spark.sql.debug.maxToStringFields", 4000)
		  			  .config("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false") //gets rid of _SUCCESS files after parquet
		  			  .config("dfs.client.read.shortcircuit.skip.checksum", "true")
		  			  .config("parquet.summary.metadata.level", "NONE") //replaces parquet.enable.summary-metadata in Spark 3.3.0
		  			  .getOrCreate();
		  	  
		  	  //Set verbosity of output, options are: ALL, DEBUG, ERROR, FATAL, INFO (default), OFF, TRACE, WARN
		      spark.sparkContext().setLogLevel("WARN");
			  fs = FileSystem.get(config);
		      userdefinedfunction = new UDF();
			  //register the user defined function in spark
			  spark.udf().register(udfName, userdefinedfunction, DataTypes.BooleanType);
			  //setNmonBroadcast();

		}
		catch(Exception e){e.printStackTrace();}	
	}
	
	public void uploadClientRecordType(String clientConfigDir){
		try{
			System.out.println("Start: RollingPISFactory.uploadClientRecordType()");
			todayYYMM = String.valueOf(LocalDateTime.now().getYear()).substring(2) + (LocalDateTime.now().getMonth().getValue() < 10 ? "0" + String.valueOf(LocalDateTime.now().getMonth().getValue()) : LocalDateTime.now().getMonth().getValue());
			clientConfig = spark.read().option("inferSchema", true)
					.option("header", true)
					.csv("file://" + clientConfigDir);
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * Query data on NFS dmsdisks to find all PIS and NMON record lengths pertaining to YYMM
	 */
	public void analyzeData(){
		
		try{
			System.out.println("Start: RollingPISFactory.analyzeData()");			
			clientData = CommonUtil.queryClientData(spark, client, portfolio, datePeriod);			
			//check if client record type has the client data record length for yymm
			if(hasMultiRT){  //more than one row in clientRT
				clientData.foreach(row -> {
					for(int x = 0; x < rtData.size(); x++){
						//at least one row contains the pis or nmon record length from yymm 
						if(!rtData.get(x).mkString().contains(row.mkString())){
							missingRT++;
							System.out.println("RollingPISFactory.analyzeData(): " + client + "(" + portfolio + "): new RT not in rollingPISClientConf.csv: " + row.mkString());
						}else{
							missingRT--; //change to -1
						}
					}
				});
            }
			else{//only one row in clientRT
				String clientRTFirstRow = clientRT.first().mkString();
				clientData.foreach(row -> {
					//since only one pis and nmon record type, we just need to see if it contains the pis and nmon record length from yymm
					/**
					 * org.apache.spark.SparkException:  Dataset transformations and actions can only be invoked 
					 * by the driver, not inside of other Dataset transformations; 
					 * for example, dataset1.map(x => dataset2.values.count() * x) is invalid 
					 * because the values transformation and count action cannot be performed 
					 * inside of the dataset1.map transformation. For more information, see SPARK-28702.
					 * Below I used to have clientRT.first90.mkString().contains() which is another Dataset transformation
					 */
					if(!clientRTFirstRow.contains(row.mkString())){
						missingRT++;
						System.out.println("RollingPISFactory.analyzeData(): " + client + "(" + portfolio + "): new RT not in rollingPISClientConf.csv: " + row.mkString());
					}
				});
			}
			if(missingRT > 0){
				System.exit(-1);  //stop the program
			}
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	public void analyzeAction(){
		
		try{
			System.out.println("Start: RollingPISFactory.analyzeAction()");			
			
			/**
			 * if hasMultiRT is true, then use RollingPISList object
			 * else use RollingPISv2 object
			 * also need to include algorithm for clients who are not up-to-date with yymm
			 */
			if(hasMultiRT){
				rollingpislist.checkDirectoryFromPISFactory();
                for(Row rows : rtData){
                	rollingpislist.readDatasetFromPISFactory(new String[]{rows.get(2).toString(), rows.get(3).toString(), rows.get(4).toString(), rows.get(5).toString(),rows.get(6).toString(),rows.get(7).toString()});  //need to work on this code
                }
				rollingpislist.processDataset();
			}else{//one record type

				rollingpisv3.processDatePeriod();
			}
			
		}catch(Exception e){e.printStackTrace();}
	}
	
	/**
	 * Broadcast variables are read-only. 
	 * Once broadcasted, the data is immutable, meaning it cannot be modified or updated. 
	 */
	public void setNmonBroadcast(){
    	nmbc = spark.sparkContext().broadcast(new NmonBroadcast(), classTag(NmonBroadcast.class));
		  System.out.println("inside setNmonBroadcast(): broadcast NmonBroadcast class");
    }
	
	/**
     * input any class to broadcast in spark
     * returns the class T of ClassTag
     * @param clazz
     * @return 
     */
	 public static <T> ClassTag<T> classTag(Class<T> clazz) {
 	   return scala.reflect.ClassManifestFactory.fromClass(clazz);
	 }
	 
	 public void sendEmail(){

	    String to = "janecheng@fico.com";
	    String from = "janecheng@fico.com";
	    LocalDate today = LocalDate.now();
	    
	    try
	    {	    
	       //sb.append("<br> Thank you, <br> Jane Cheng");
	       String host = "mail.fairisaac.com";
	    
	       //create properties to store host and get or set the default mail session object
	       Properties props = new Properties();
	       props.put("mail.smtp.host", host);
	       Session session = Session.getInstance(props);
	    
	       //create the message object
	       MimeMessage msg = new MimeMessage(session);

	       //set the sender's email address
	       msg.setFrom(new InternetAddress(from));

	       //set the recipient's email address
	       msg.setRecipients(Message.RecipientType.TO, to);
	       
	       //set the subject heading
	       msg.setSubject("Rolling PIS " + today.getYear() + CalendarOps.convertSingleDigitToString(today.getMonthValue()) + " Report");

	       //set the date of sending the email; new date() initializes the to current date
	       msg.setSentDate(new Date());

	       //set the message body; setText method only uses text/plain
	       // msg.setText(msgBody);
	       Multipart mp = new MimeMultipart();
	          
	       //set the html body part
	       MimeBodyPart htmlbody = new MimeBodyPart();
	       htmlbody.setContent(sb.toString(), "text/html");
	       mp.addBodyPart(htmlbody);
	          
	       //need to use setContent method if using text/html
	       //msg.setContent(sb.toString(), "text/html");
	       msg.setContent(mp);

	       //send the email
	       Transport.send(msg);
	          
	     }
	       catch(Exception mex){

	          System.out.println("Error in sending: ");
	          mex.printStackTrace();
	          System.exit(1);
	       }

	    }	
}
