select fs.* from filestorage fs, files f where fs.filename like '/data/%' and fs.fileid = f.fileid and f.client = 'ts2_8167-f6' and f.portfolio = 'debit' and f.date_period < '1901';

select * from recordtypes where recordtype = 581;
select * from filestorage where fileid = 8224538;


select fs.filename, F.alt_file_name_suffix, fs.yymm from (select L.* from (select f.fileid, f.date_period, f.filename, r.recclass, r.alt_file_name_suffix, r.recordtype from files f, recordtypes r 
where r.recordtype = f.recordtype and f.client = 'ts2_8167-f6' 
and f.portfolio = 'debit' and f.date_period < '1901') L, recordtype_falcon6 rf where rf.recordtype = L.recordtype and rf.recclass in ('NMON'))F, filestorage fs
where fs.filetype = '2' and fs.fileid = F.fileid order by fs.yymm;

-- use the below query for rollup; works better to find files under /data/raw_falcon

select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*.bz2' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'ts2_9330-f6' 
and f.portfolio = 'none' and f.date_period between '1801' and '1812') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid) 
group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*.bz2' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'ts2_9330-f6' 
and f.portfolio = 'none' and f.date_period < '1901') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid) 
group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

--for update to use hdfs bz2 files under /data/raw_falcon
select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*.bz2' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'ts2_8167-f6' 
and f.portfolio = 'debit' and f.date_period = '2001') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid) 
group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

--for roll-up files under /dmsdisks*
select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*pis*.ascii.bz2' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'fiserv-eft-f6' 
and f.portfolio = 'none' and f.date_period < '1903') L, filestorage fs where fs.filetype = 'O' and fs.fileid in (L.fileid) 
group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

select L.fileid, L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*pis*.ascii.bz2' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r
		    	    	where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'its-shazam-f6' 
		    	    	and f.portfolio = 'none' and f.status = 'D' and f.date_period between 2202 and 2203) L, filestorage fs where fs.filestatus = 'O' and fs.filetype = 'O' and fs.fileid in (L.fileid)
		    	    	group by L.fileid, substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));
                        
                        select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*pis*.ascii.bz2' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r
		    	    	where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'its-shazam-f6' 
		    	    	and f.portfolio = 'none' and f.status = 'D' and f.date_period = 2203) L, filestorage fs where fs.filestatus = 'O' and fs.filetype = 'O' and fs.fileid in (L.fileid)
		    	    	group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

--for update to use parquet files under /data/parquet_falcon
select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'ts2_8167-f6' 
and f.portfolio = 'debit' and f.date_period = '2001') L, filestorage fs where fs.filetype = 'P' and fs.fileid in (L.fileid) 
group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

select L.alt_file_name_suffix, substr(fs.filename, 0, instr(fs.filename, '/', -1)) || '*.parquet' filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'cfg-f6' 
and f.portfolio = 'none' and f.date_period < '2008') L, filestorage fs where fs.filetype = 'P' and fs.fileid in (L.fileid) 
group by substr(fs.filename, 0, instr(fs.filename, '/', -1)), L.alt_file_name_suffix order by substr(fs.filename, 0, instr(fs.filename, '/', -1));

select L.alt_file_name_suffix, fs.filename from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'pis%' and r.recordtype = f.recordtype and f.client = 'ts2_8167-f6' 
and f.portfolio = 'debit' and f.date_period = '1901') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid);

-----------------------------  
--to get total filesize for the files in the above query
select sum(fs.filesize) total_size from (select f.fileid, r.alt_file_name_suffix from files f, recordtypes r 
where r.alt_file_name_suffix like 'nmon%' and r.recordtype = f.recordtype and f.client = 'ts2_8167-f6' 
and f.portfolio = 'debit' and f.date_period < '1901') L, filestorage fs where fs.filetype = '2' and fs.fileid in (L.fileid);
