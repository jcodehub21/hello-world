package org.jcservices;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocalFileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.KafkaFuture;

public class KafkaUtil implements Serializable{

	private static final long serialVersionUID = 1L;
	static AdminClient admin;
	static Properties props, adminProps, producerProps, consumerProps;
	static Producer<String,String> producer;
	static Consumer<String,String> consumer;
	static BufferedReader br;
	static ProducerRecord<String, String> record;
	static int recordCounter = 0;  //count the number of records so far for writing to kafka topic
	
	public KafkaUtil() {
		  // producerProps = new Properties();
		 //  producerProps.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "rhlmodhdp22506:9092,rhlmodhdp22507:9092,rhlmodhdp22508:9092");
		 //  producerProps.setProperty(ProducerConfig.ACKS_CONFIG, "1");
		//   producerProps.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
		//   producerProps.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
		//   producer = new KafkaProducer<>(producerProps);
	}
	
	public static Properties getProperties() {
		return props;
	}
	
	public static Properties getAdminProps() {
		return adminProps;
	}
	
	public static Properties getProducerProps() {
		return producerProps;
	}
	
	public static Properties getConsumerProps() {
		return consumerProps;
	}
	
	public static Producer<String,String> getProducer() {
		return producer;
	}
	
	/**
	 * using property file as input parameter
	 * @param propertyFile
	 */
	public static void setProperties(String propertyFile) {
		try {
		   props = new Properties();
		   props.load(new FileReader(new File(propertyFile)));
		   
		   adminProps = new Properties();
		   adminProps.setProperty(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, props.getProperty("bootstrap.servers"));
		   
		   producerProps = new Properties();
		   producerProps.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getProperty("bootstrap.servers"));
		   producerProps.setProperty(ProducerConfig.ACKS_CONFIG, "1");
		   producerProps.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, props.getProperty("key.serializer"));
		   producerProps.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, props.getProperty("value.serializer"));	 
		   
		   consumerProps = new Properties();
		   consumerProps.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, props.getProperty("bootstrap.servers"));
		   /** org.apache.kafka.common.KafkaException: Failed to construct kafka consumer:
		     *  enable.auto.commit cannot be set to true when default group id (null) is used
		     **/
		   //consumerProps.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
		   consumerProps.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, props.getProperty("key.deserializer"));
		   consumerProps.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, props.getProperty("value.deserializer"));
		   
		   admin = AdminClient.create(adminProps);
		   producer = new KafkaProducer<>(producerProps);
		   consumer = new KafkaConsumer<>(consumerProps);
		   
		}catch(IOException e) {e.printStackTrace();}
	}
	
	/**
	 * set the kafka.properties in hdfs
	 * this does not work
	 */
	public static void setProperties() {
		try {
		 // System.out.println("default path: " + Thread.currentThread().getContextClassLoader().getResource("").getPath());
		   props = new Properties();
		  props.load(KafkaUtil.class.getClassLoader().getResourceAsStream("src/org/jcservices/kafka.properties"));
		}catch(IOException e) {e.printStackTrace();}
	}
	
	/**
	 * The method createTopics returns a CreateTopicsResult with KafkaFutures as values. 
	 * As you are currently not blocking your code for this action to be finished (using get) 
	 * and not catching any Exception, your code will just run fine without any notification 
	 * that the broker is not available.
	 * createTopics will resolve to true if the topic was created successfully or false if it already exists. The method will throw exceptions in case of errors
     * KafkaFuture will throw an InterruptedExection and ExecutionException when your broker is not available
	 * @param topicName
	 * @param partition
	 * @param replicationFactor
	 */
	public static void createTopic(String topicName, int partition, short replicationFactor) {
		//boolean topicCreated = false;
		try {
			
			CreateTopicsResult result = admin.createTopics(Collections.singleton(new NewTopic(topicName, partition, replicationFactor)));
			//CreateTopicsResult.all() = Return a future which succeeds if all the topic creations succeed.
			KafkaFuture<Void> futureResult = result.all();	
			//KafkaFuture<Void>get() = Waits if necessary for this future to complete, and then returns its result
			futureResult.get();
			admin.close();  //close the admin
		}catch (InterruptedException e) {
		    e.printStackTrace();
		} catch (ExecutionException e) {
		    e.printStackTrace();
		}
		
	}
	
	/**
	 * read key/value pairs from HDFS csv file and write to topic
	 * @param csvFile
	 */
	public static void writeToTopics(String topicName, String csvFile, FileSystem fs) {
		try {
			String data;			
			br = new BufferedReader(new InputStreamReader(fs.open(new Path(csvFile))));
			while((data = br.readLine()) != null) {
                record = (new ProducerRecord<String,String>(topicName, data.substring(0, data.indexOf(",")), data.substring(data.indexOf(",") + 1)));
				
				producer.send(record, new Callback(){
					@Override
					public void onCompletion(RecordMetadata metadata, Exception exception) {
						if(exception != null) {
							System.out.println("Error while producing message to topic :" + metadata);
							exception.printStackTrace();
						}else {
			                String message = String.format("sent message to topic:%s partition:%s  offset:%s", metadata.topic(), metadata.partition(), metadata.offset());
			                System.out.println(message);
			            }
					}
					
				});
				recordCounter++;
				checkFlush(recordCounter);
				
			}
			//producer.flush();
			//producer.close();
			br.close();
		}catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * write record to kafka topic passed in by Spark
	 * using null key
	 * @param topicName
	 * @param record
	 */
	public static void writeToTopics(String topicName, String record) {
		try {		
			//producer = new KafkaProducer<>(getProducerProps());
			if(producer == null) {
				System.out.println("producer is null");
			}
			System.out.println("inside KafkaUtil.writeToTopics: " + record);
			producer.send(new ProducerRecord<String,String>(topicName, record));
			 producer.flush();
		   /** producer.send(new ProducerRecord<String,String>(topicName, record), new Callback(){
					@Override
					public void onCompletion(RecordMetadata metadata, Exception exception) {
						if(exception != null) {
							System.out.println("Error while producing message to topic :" + metadata);
							exception.printStackTrace();
						}else {
			                String message = String.format("sent message to topic:%s partition:%s  offset:%s", metadata.topic(), metadata.partition(), metadata.offset());
			                System.out.println(message);
			            }
					}
					
				}); **/
		   
		   // recordCounter++;
			//checkFlush(recordCounter);
			
			//producer.flush();
			//producer.close();
		}catch(Exception e) {e.printStackTrace();}
	}
	
	//not static 
	public void writeToTopics2(String topicName, String record) {
		try {		
			//producer = new KafkaProducer<>(getProducerProps());
			if(producer == null) {
				System.out.println("producer is null");
			}
			System.out.println("inside KafkaUtil.writeToTopics: " + record);
			producer.send(new ProducerRecord<String,String>(topicName, record));
			 producer.flush();
		   /** producer.send(new ProducerRecord<String,String>(topicName, record), new Callback(){
					@Override
					public void onCompletion(RecordMetadata metadata, Exception exception) {
						if(exception != null) {
							System.out.println("Error while producing message to topic :" + metadata);
							exception.printStackTrace();
						}else {
			                String message = String.format("sent message to topic:%s partition:%s  offset:%s", metadata.topic(), metadata.partition(), metadata.offset());
			                System.out.println(message);
			            }
					}
					
				}); **/
			
			//producer.flush();
			//producer.close();
		}catch(Exception e) {e.printStackTrace();}
	}
	
	/**
	 * read key/value pairs from local file system csv file and write to topic
	 * csvFile = file:///path/to/local/file
	 * @param csvFile
	 */
	public static void writeToTopics(String topicName, String csvFile, LocalFileSystem fs) {
		try {
			String data;
			//producer = new KafkaProducer<>(getProperties());
			br = new BufferedReader(new InputStreamReader(fs.open(new Path(csvFile)), "utf-8"));
			while((data = br.readLine()) != null) {
				record = (new ProducerRecord<String,String>(topicName, data.substring(0, data.indexOf(",")), data.substring(data.indexOf(",") + 1)));
				
				producer.send(record, new Callback(){
					@Override
					public void onCompletion(RecordMetadata metadata, Exception exception) {
						if(exception != null) {
							System.out.println("Error while producing message to topic :" + metadata);
							exception.printStackTrace();
						}else {
			                String message = String.format("sent message to topic:%s partition:%s  offset:%s", metadata.topic(), metadata.partition(), metadata.offset());
			                System.out.println(message);
			            }
					}
					
				});
				recordCounter++;
				checkFlush(recordCounter);
			}
			//producer.flush();
			//producer.close();
			br.close();
		}catch(Exception e) {e.printStackTrace();}
	}
	
	public static void readTopic(String topicName) {
		try {
			
		}catch(Exception e) {e.printStackTrace();}
	}
	
	//producer will flush every 10 messages
	public static void checkFlush(int numOfRecords) {
		try {
			if((numOfRecords % 10) == 0) {
				producer.flush();
			}
		}catch(Exception e) {e.printStackTrace();}
	}
	public void closeProducer() {
		//producer.flush();
		producer.close();
	}
	
    public static void closeConsumer() {
		consumer.close();
	}

}
