package org.jc

/**
 * Hello world!
 *
 */
object App extends Application {
  println( "Hello World!" )
}
