package jc.lambda.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.athena.AmazonAthena;
import com.amazonaws.services.athena.AmazonAthenaClientBuilder;
import com.amazonaws.services.athena.model.*;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AISACostReportHandler implements RequestHandler<Map<String,Object>, String> {

    LambdaLogger logger;
    AmazonAthena athena = AmazonAthenaClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
    AmazonSimpleEmailService ses = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(Regions.US_WEST_2).build();
    QueryExecutionContext qec = new QueryExecutionContext();
    StartQueryExecutionResult startQEC;
    GetQueryExecutionResult getQER;
    GetQueryResultsResult getQRR;
    LocalDate today;
    String sender, subject, awsAccountName, endDay, currentMonth;
    String bodyHTML = "";
    GeneralLinkList<OwnerInfo> ownerInfo = new GeneralLinkList<OwnerInfo>();
    StringBuffer sb = new StringBuffer();
    List<String> recipients = new ArrayList<String>();
    ExcelOps excel = new ExcelOps("/tmp/AISA.xlsx");
    String state;
    String executionId;

    @Override
    public String handleRequest(Map<String, Object> event, Context context) {
        logger = context.getLogger();
        today = LocalDate.now();
        currentMonth = CalendarOps.convertSingleDigitToString(today.getMonthValue());
        endDay = CalendarOps.convertSingleDigitToString(today.getDayOfMonth());
        qec.setDatabase(event.get("database").toString());
        startQEC = AthenaOps.startQuery(athena,qec,event.get("query").toString());
        executionId = startQEC.getQueryExecutionId();
        //getQER = AthenaOps.getQueryExecutionResult(athena,startQEC.getQueryExecutionId());
        //state = getQER.getQueryExecution().getStatus().getState();
        checkQueryStatus();
        sender = "janecheng@fico.com";
        String emailaddress = event.get("emailaddress").toString().substring(event.get("emailaddress").toString().indexOf("[") + 1, event.get("emailaddress").toString().indexOf("]"));
        if(emailaddress.contains(",")) {
            for (String email : emailaddress.split(",")) {
                recipients.add(email);
            }
        }
        else{
            recipients.add(emailaddress);
        }
        awsAccountName = event.get("awsaccountname").toString();
        //bodyHTML = sb.toString();
        bodyHTML = "Please see attached Excel Spreadsheet for PTO AISA Solution Costs.";
        subject = awsAccountName + " Cost Report as of " + CalendarOps.getMonthName(currentMonth) + " " + endDay +", " + today.getYear();

        /**
         * uses SES to check if the email address has been verified
         */
        GetIdentityVerificationAttributesResult getIVAR = ses.getIdentityVerificationAttributes(new GetIdentityVerificationAttributesRequest().withIdentities(recipients));
        getIVAR.getVerificationAttributes().forEach((email,status) -> {
            System.out.println("email: " + email + " => status: " + status);
            if(!status.getVerificationStatus().equalsIgnoreCase("Success")){
                recipients.remove(email);

            }
        });

       /** for(String email : recipients){
            emailaddress = email + ",";
        }
        emailaddress = emailaddress.substring(0,emailaddress.lastIndexOf(","));
        logger.log("emailaddress: " + emailaddress);
        **/

        /**SendEmailResult sendEmailResult = ses.sendEmail(new SendEmailRequest(sender,
                new Destination().withToAddresses(recipients),
                new Message(new Content(subject), new Body().withHtml(new Content(bodyHTML)))));
         **/
        CommonOps.sendSESEmailAttachment(ses,sender,recipients,subject,bodyHTML,excel.getWorkbookName());
        return "Success reading Athena database";
    }

    public void checkQueryStatus(){
        //boolean running = false;
        state = AthenaOps.getQueryStatus(athena,executionId);
        if(state.equals(QueryExecutionState.SUCCEEDED.toString())){
            logger.log("Query state is: " + state);
            processLargeDataRows();
        }else if(state.equals(QueryExecutionState.FAILED.toString())){
            throw new RuntimeException("The Amazon Athena query failed to run with error message: " + getQER.getQueryExecution().getStatus().getStateChangeReason());
        }else if(state.equals(QueryExecutionState.CANCELLED.toString())){
            throw new RuntimeException("The Amazon Athena query was cancelled.");
        }else{  //RUNNING state
            try {
                logger.log("Query state is: " + state);
                Thread.sleep(100000);
                checkQueryStatus();
            }catch (InterruptedException e) {
                logger.log("Thread interrupted while sleeping: ");
                Thread.currentThread().interrupt();
            }
        }
    }

    public void processSmallDataRows(){
        getQRR = AthenaOps.getQueryResultsRows(athena,startQEC.getQueryExecutionId());
        String beginTable = "<table border=\"1\" style=\"font-family:Arial;font-size:9pt\"}>";
        String endTable = "</table></br>";
        sb.append("The table below shows the cost per solution id per user.</br></br>");
        sb.append(beginTable);
        ResultSet rs = getQRR.getResultSet();
        //ResultSetMetadata = The metadata that describes the column structure and data types of a table of query results
        ResultSetMetadata rsMeta = rs.getResultSetMetadata();
        //The columns in the table
        List<ColumnInfo> columns = rsMeta.getColumnInfo();
        sb.append("<tr>");
        for(ColumnInfo column : columns){
            sb.append("<td><b>" + column.getName() + "</b></td>");
        }
        sb.append("</tr>");
        //The rows in the table
        List<Row> rows = rs.getRows();

        for(Row row : rows){
            sb.append("<tr>");
            //The data that populates a row/record in a query result table.
            List<Datum> record = row.getData();
            for(Datum data : record){
                sb.append("<td>" + data.getVarCharValue() + "</td>");
            }
            sb.append("</tr>");
        }
        sb.append(endTable);
    }

    public void processLargeDataRows(){
        getQRR = AthenaOps.getQueryResultsRows(athena,executionId);
        excel.createSheet("AISA");
        ResultSet rs = getQRR.getResultSet();
        //ResultSetMetadata = The metadata that describes the column structure and data types of a table of query results
        ResultSetMetadata rsMeta = rs.getResultSetMetadata();
        //The columns in the table
        List<ColumnInfo> columns = rsMeta.getColumnInfo();
        //excel.createColumn(columns);
        //The rows in the table
        List<Row> rows = rs.getRows();
        for(Row row : rows){
            //The data that populates a row/record in a query result table.
            List<Datum> record = row.getData();
            excel.addData(record);
        }
        excel.saveWorkbook();
    }
}
